package EHR.ClinicalAseesment;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class BloodGroup extends Abstraction {

	public BloodGroup(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	@FindBy(xpath = "//ngx-select[@formcontrolname='bldGroup']//div[contains(@class,'ngx-select__toggle')]")
	private WebElement bloodGroupDropdown;

	/*
	 * ========================= Confirm Checkbox =========================
	 */

	@FindBy(xpath = "//input[@formcontrolname='confirmflag']")
	private WebElement confirmBloodGroupCheckbox;

	/*
	 * ========================= Confirmed By ngx-select =========================
	 */

	@FindBy(xpath = "//ngx-select[@formcontrolname='confirmby']//div[contains(@class,'ngx-select__toggle')]")
	private WebElement confirmedByDropdown;

	/*
	 * ========================= Buttons =========================
	 */

	@FindBy(xpath = "//input[@value='Save']")
	private WebElement saveButton;

	@FindBy(xpath = "//input[@value='Reset']")
	private WebElement resetButton;

	/*
	 * ========================= Reusable Methods =========================
	 */

	public void selectBloodGroup() {
		clickUsingJS(bloodGroupDropdown);

	}

	public void confirmBloodGroup() {
		if (!confirmBloodGroupCheckbox.isSelected()) {
			clickUsingJS(confirmBloodGroupCheckbox);
		}
	}

	public void selectConfirmedBy() {
		clickUsingJS(confirmedByDropdown);

	}

	public void clickSave() {
		clickUsingJS(saveButton);
	}

	public void clickReset() {
		clickUsingJS(resetButton);
	}

	/*
	 * ========================= Helper Methods =========================
	 */

	@FindBy(xpath = "//ngx-select[@formcontrolname='reactions']//input[contains(@class,'ngx-select__search')]")
	private WebElement reactionsInput;

	public void enterReaction(String reaction) {
		reactionsInput.clear();
		reactionsInput.sendKeys(reaction);
	}

	private void clickUsingJS(WebElement element) {
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	}

	public void clickDropdown(String sectionName, String fieldName) {

		List<WebElement> dropdowns = driver.findElements(By.xpath("//div[.//div[normalize-space()='" + sectionName
				+ "']]//" + "ngx-select[@formcontrolname='" + fieldName + "']//div"));

		for (WebElement dropdown : dropdowns) {
			try {
				if (dropdown.isDisplayed() && dropdown.isEnabled()) {
					dropdown.click();
					return; // stop after successful click
				}
			} catch (Exception e) {
				// try next element
			}
		}

		throw new RuntimeException(
				"No clickable dropdown found for field '" + fieldName + "' in section '" + sectionName + "'");
	}

	public void enterText(String sectionName, String fieldName, String value) {

		List<WebElement> fields = driver.findElements(By.xpath("//div[.//div[normalize-space()='" + sectionName
				+ "']]//*[ " + "((self::input or self::textarea) and @formcontrolname='" + fieldName + "') " + "or "
				+ "(self::ngx-select[@formcontrolname='" + fieldName + "']//input)" + "]"));

		for (WebElement field : fields) {
			try {
				if (field.isDisplayed() && field.isEnabled()) {

					field.clear();
					field.sendKeys(value);
					return; // stop after successful entry
				}

			} catch (Exception e) {
				// ignore and try next element
			}
		}

		throw new RuntimeException("No editable field found for '" + fieldName + "' in section '" + sectionName + "'");
	}

	@FindBy(xpath = "//ul[contains(@class,'tabset')]")
	private WebElement tabSet;

	// ------------------ METHOD ------------------
	public void clickTabByName(String tabName) {
		WebElement tab = tabSet.findElement(
				By.xpath(".//span[contains(@class,'tab-text') and normalize-space()='" + tabName + "']/ancestor::li"));
		tab.click();
	}

}
