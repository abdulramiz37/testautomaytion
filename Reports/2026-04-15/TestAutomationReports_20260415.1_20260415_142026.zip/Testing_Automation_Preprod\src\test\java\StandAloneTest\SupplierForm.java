	package StandAloneTest;

	import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.WebDriverWait;
public class SupplierForm {



		public static void main(String[] args) throws InterruptedException {
//			WebDriver driver = new EdgeDriver();
//			WebDriver driver = new EdgeDriver();
//			driver.get("https://apps.ezovion.com/auth/login");
			 ChromeOptions options = new ChromeOptions();
		        options.addArguments("--incognito");

		        // Launch Chrome in incognito mode
		        WebDriver driver = new ChromeDriver(options);
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			driver.get("https://apps.ezovion.com/auth/login");

			driver.manage().window().maximize();
			

			driver.findElement(By.xpath("//div[@class=\"form-control-group\"]//input")).sendKeys("50107299");
			driver.findElement(By.xpath("//button[@size=\"large\"]")).click();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
		        // Wait until the button with text "CONTINUE" is clickable
		    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
			
		     driver.findElement(By.xpath("//input[@placeholder=\"Mobile No\"]")).sendKeys("7766554433");
			driver.findElement(By.xpath("//input[@placeholder=\"Password\"]")).sendKeys("12345");
			 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@status=\"primary\"]")));
			 Thread.sleep(2000);
			 driver.findElement(By.xpath("//button[@status=\"primary\"]")).click();
		




				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Masters']"))).click();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Master Set-up']"))).click();

				// 3. Warehouse
				//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Warehouse ']"))).click();

				// 4. Add Warehouse
			

				// 6. Click "Supplier"
				

				// Click "Supplier"


				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Supplier']"))).click();

				// 7. Click first expand/collapse button (role="button")
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[@role='button'])[1]"))).click();

				// 8. Enter Supplier Name
				//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[3]"))).sendKeys("supplier name");
		
				// 9. Click on first "Select"
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();

				// 10. Select "Pharmacy" (2nd option)
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Pharmacy'])[2]"))).click();

				// 11. Quantity
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[4]"))).sendKeys("2");

				// 12. Phone
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[7]"))).sendKeys("9876543210");

				// 13. Mobile
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[9]"))).sendKeys("9876543210");

				// 14. State Code
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[11]"))).sendKeys("1 jop");

				// 15. Pincode
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[13]"))).sendKeys("444002");

				// 16. City
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[14]"))).sendKeys("akola");

				// 17. Select State dropdown again
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();

				// 18. Select "Chamoli"
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Chamoli'])[1]"))).click();

				// 19. Final Save
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();
				for (int i = 0; i < 5; i++) {
				    try {
				        // Click the back icon
				        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-chevron-left']"))).click();

				        // Wait for Pharmacy heading to be visible
				        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h4[text()=' Pharmacy']")));
				        
				        // If visible, break the loop
				        System.out.println("Pharmacy page is visible.");
				        break;
				    } catch (Exception e) {
				        System.out.println("Attempt " + (i + 1) + ": Pharmacy not visible yet.");
				        if (i == 4) {
				            throw e; // Throw if maximum retries are reached
				        }
				    }
				}
				//a[text()=" Storage Shelf"]
			
				
		}
		}



