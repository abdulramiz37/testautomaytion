package Lab;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeoutException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import EzionAbstractionComponents.Abstraction;

public class SampleCollectedList extends Abstraction{

	public SampleCollectedList(WebDriver driver) {
		super(driver);
	    PageFactory.initElements(driver, this);
	}


    @FindBy(xpath = "//span[text()='Sample Collected List']")
    private WebElement adduserType;
     
    public void clickbuttonapproval() {
//		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
		WebElement refreshButton = driver.findElement(By.xpath("//a[contains(@class,'repeatcls') and contains(normalize-space(.), 'Refresh')]"));
		refreshButton.click();

	}
	public void clickReorderByWorkOrder(String actualWorkOrder)  {
		clickbuttonapproval();
	    boolean isFound = false;

	    while (!isFound) {
	        List<WebElement> rows = driver.findElements(
	            By.xpath("(//tbody)[2]/tr[contains(@class,'ng-star-inserted')]")
	        );
//	        waitForClickability(By.xpath("(//tbody)[2]/tr[contains(@class,'ng-star-inserted')]//td[3]"));
	        for (WebElement row : rows) {
	            try {
	                // Get Work Order from 3rd column
	 
	     WebElement workOrderCell = row.findElement(By.xpath(".//td[3]"));
	     
	                String workOrderText = workOrderCell.getAttribute("textContent").trim();
	                // or use getAttribute("innerText") if you prefer
	                // String workOrderText = workOrderCell.getAttribute("innerText").trim();

//	                String workOrderText = workOrderCell.getText().trim();

	                System.out.println(workOrderText);
	                if (workOrderText.equals(actualWorkOrder)) {
	                    // Bill No is also in 3rd td as per your structure
	                    String billNo = workOrderText;
	                    System.out.println("🧾 Bill No: " + billNo);

	                    // Click Reorder (last <li> in action column)
	                    WebElement reorderBtn = row.findElement(
	                        By.xpath(".//td[contains(@class,'action-table')]//li[last()-3]/a")
	                    );
	                    waitForClickability(reorderBtn);
	                    Actions actions2 = new Actions(driver);
	                    actions2.doubleClick(reorderBtn).perform();


	                    System.out.println("🔄 Clicked Reorder for Work Order: " + actualWorkOrder);
	                    isFound = true;
	                    break;
	                }
	            } catch (NoSuchElementException ignored) {}
	        }

	        if (!isFound) {
	            try {
	                WebElement nextButton = driver.findElement(
	                    By.xpath("//li[contains(@class,'pagination-next')]/a[contains(.,'Next')]")
	                );
	                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextButton);
	                System.out.println("➡️ Moved to next page...");
	            } catch (NoSuchElementException e) {
	                System.out.println("❌ No more pages. Work Order not found.");
	                break;
	            }
	        }
	    }
	}

	public void clickReorderByWorkOrder2(String actualWorkOrder) throws TimeoutException {
	    clickbuttonapproval();
	    clickbuttonapproval();
	    clickbuttonapproval();
	    clickbuttonapproval();
	    clickbuttonapproval();
	    clickbuttonapproval();
	    clickbuttonapproval();
	    clickbuttonapproval();
	    boolean isFound = false;
	    int retryCount = 0;

	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    while (!isFound && retryCount < 3) { // Retry a few times
	        try {
	            // ✅ Wait for the table to appear before reading rows
	            wait.until(ExpectedConditions.visibilityOfElementLocated(
	                By.xpath("(//tbody)[2]/tr[contains(@class,'ng-star-inserted')]")
	            ));

	            List<WebElement> rows = driver.findElements(
	                By.xpath("(//tbody)[2]/tr[contains(@class,'ng-star-inserted')]")
	            );

	            for (int i = 0; i < rows.size(); i++) {
	                try {
	                    // Re-locate the row again (to avoid stale reference)
	                    WebElement row = driver.findElements(
	                        By.xpath("(//tbody)[2]/tr[contains(@class,'ng-star-inserted')]")
	                    ).get(i);

	                    WebElement workOrderCell = row.findElement(By.xpath(".//td[3]"));
	                    String workOrderText = workOrderCell.getAttribute("textContent").trim();

	                    System.out.println("Found Work Order: " + workOrderText);

	                    if (workOrderText.equals(actualWorkOrder)) {
	                        System.out.println("🧾 Bill No: " + workOrderText);

	                        WebElement reorderBtn = row.findElement(
	                            By.xpath(".//td[contains(@class,'action-table')]//li[last()-3]/a")
	                        );

	                        waitForClickability(reorderBtn);
	                        new Actions(driver).doubleClick(reorderBtn).perform();

	                        System.out.println("🔄 Clicked Reorder for Work Order: " + actualWorkOrder);
	                        isFound = true;
	                        break;
	                    }

	                } catch (StaleElementReferenceException e) {
	                    System.out.println("⚠️ Row went stale. Retrying row...");
	                }
	            }

	            if (!isFound) {
	                try {
	                    // ✅ Wait for "Next" button to be clickable
	                    WebElement nextButton = wait.until(ExpectedConditions.elementToBeClickable(
	                        By.xpath("(//tbody)[2]/tr[contains(@class,'ng-star-inserted')]/ancestor::div[1]/ancestor::div[2]//li[contains(@class,'pagination-next')]/a[contains(.,'Next')]")
	                    ));

	                    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextButton);
	                    System.out.println("➡️ Moved to next page...");

	                    // ✅ Wait for table to refresh after clicking next
	                    wait.until(ExpectedConditions.stalenessOf(rows.get(0)));
	                    wait.until(ExpectedConditions.visibilityOfElementLocated(
	                        By.xpath("(//tbody)[2]/tr[contains(@class,'ng-star-inserted')]")
	                    ));

	                } catch (NoSuchElementException e) {
	                    System.out.println("❌ No more pages. Work Order not found.");
	                    break;
	                }
	            }

	        } catch (StaleElementReferenceException e) {
	            retryCount++;
	            System.out.println("⚠️ Retrying entire loop due to stale element (attempt " + retryCount + ")");
	        }
	    }

	    if (!isFound) {
	        System.out.println("❌ Failed to locate Work Order: " + actualWorkOrder);
	    }
	}


}
