

package PharmacyPurchaseOrder;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class PharmacyPurchaseOrderPage extends Abstraction {

    // Constructor
    public PharmacyPurchaseOrderPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    // ======= Static Locators =======
    @FindBy(xpath = "(//a[text()=' Add Purchase Order '])[1]")
    private WebElement addPurchaseOrderButton;

    @FindBy(xpath = "(//span[text()='Select'])[1]")
    private WebElement firstDropdownSelect;

    @FindBy(xpath = "//input[@formcontrolname='plannedDelDate']")
    private WebElement plannedDelDateInput;

    @FindBy(xpath = "(//span[text()='Search Medicine'])[1]")
    private WebElement searchMedicineBtn;

    @FindBy(xpath = "//input[@value='Add']")
    private WebElement addButton;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;
    
    @FindBy(xpath = "//span[normalize-space(text())='Please Fill Mandatory Fields']")
    private WebElement mandatoryFieldWarning;

    @FindBy(xpath = "//input[@placeholder='Search']")
    private WebElement search;

    // ======= Dynamic Locator Methods =======
    public WebElement getSpanByExactText(String exactText) {
    	String xpath = "//span[normalize-space(text())='" + exactText.trim() + "']";
        return driver.findElement(By.xpath(xpath));
    }

    public WebElement getMedicineByName(String medicineName) {
        String xpath = "//h4[text()='" + medicineName + "']";
        return driver.findElement(By.xpath(xpath));
    }
    public WebElement getInputByFormControl(String formControlName) {
        String xpath = "//input[@formcontrolname='" + formControlName + "']";
        return driver.findElement(By.xpath(xpath));
    }
    // ======= Action Method =======
    public void createPurchaseOrder(String location,String supplierName, String userName, String deliveryDate, String medicineName,String strips, String freeStrips, String mrp, String price) {

        // Step 1: Click Add Purchase Order
        waitForClickability(addPurchaseOrderButton).click();
        
        waitForClickability(firstDropdownSelect).click();
        waitForClickability(getSpanByExactText(location)).click();
        // Step 2: Select Supplier
        waitForClickability(firstDropdownSelect).click();
        waitForClickability(getSpanByExactText(supplierName)).click();

        // Step 3: Select Location
        waitForClickability(firstDropdownSelect).click();
        waitForClickability(getSpanByExactText(userName)).click();

        // Step 4: Enter Planned Delivery Date
        waitForVisibility(plannedDelDateInput);
        js.executeScript(
            "arguments[0].value='" + deliveryDate + "'; arguments[0].dispatchEvent(new Event('input'));",
            plannedDelDateInput
        );

        // Step 5: Search and Select Medicine
        waitForClickability(searchMedicineBtn).click();
        waitForClickability(search).sendKeys(medicineName);
        waitForClickability(getMedicineByName(medicineName)).click();
        List<WebElement> lastProduct = driver.findElements(By.xpath("//div[@class='last-product pt-3']"));
        if (lastProduct.isEmpty() || !lastProduct.get(0).isDisplayed()) {
            getInputByFormControl("oRDEREDNOOFSTRIPSQTY").sendKeys(strips);
            getInputByFormControl("freeQty").sendKeys(freeStrips);
            getInputByFormControl("mrp").sendKeys(mrp);
            getInputByFormControl("costPrice").sendKeys(price);
        }
        

       
    }
    public PharmacyPurchaseOrderTable save() {
    	
    	waitForClickability(addButton).click();
//        try {
//            if(waitForClickability(mandatoryFieldWarning).isDisplayed()){
//            	waitForClickability(addButton).click();
//            	
//            } else {
//            	waitForClickability(addButton).click();
//            	
//            }
//        } catch (NoSuchElementException e) {
//            System.out.println("✅ No validation error displayed.");
//        }
        js.executeScript("arguments[0].click();", saveButton);
        PharmacyPurchaseOrderTable orderTable= new PharmacyPurchaseOrderTable(driver);
        return orderTable;
    }
}
