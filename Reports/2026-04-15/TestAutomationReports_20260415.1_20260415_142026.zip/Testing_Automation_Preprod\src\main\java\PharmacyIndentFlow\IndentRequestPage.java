package PharmacyIndentFlow;

import java.util.List;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import EzionAbstractionComponents.Abstraction;

public class IndentRequestPage extends Abstraction {

    public IndentRequestPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    // ---------- Static Elements ----------
    @FindBy(xpath = "(//span[text()='Internal Indent'])[1]")
    WebElement internalIndentMenu;

    @FindBy(xpath = "(//a[text()=' Indent Request '])[1]")
    WebElement indentRequestTab;

    @FindBy(xpath = "(//span[text()='Select'])[1]")
    WebElement firstSelectDropdown;

    @FindBy(xpath = "//input[@formcontrolname='indentQuantity']")
    WebElement quantityInput;

    @FindBy(xpath = "(//input[@value='Add'])[1]")
    WebElement addButton;

    @FindBy(xpath = "(//input[@value='Save'])[1]")
    WebElement saveButton;

    @FindBy(xpath = "(//span[text()='Search Medicine'])[1]")
    WebElement searchButton;
    @FindBy(xpath = "(//input[@placeholder=\"Search\"])[1]")
    WebElement searchButton2;
   
    
    @FindBy(xpath = "//div[contains(@class,'succesfull-info-popup')]//span[contains(text(),'Please Fill Mandatory Fields')]")
    private WebElement mandatoryFieldErrorMessage;

    // ---------- Actions ----------

   

    public void openIndentRequestPage() {
       
        waitForClickability(indentRequestTab,0).click();
    }

    public void selectLocation(String locationName) {
        waitForClickability(firstSelectDropdown,0).click();
        By locationOption = By.xpath("(//span[text()='" + locationName + "'])[1]");
        WebElement locationElement = waitForVisibility(driver.findElement(locationOption),0);
        locationElement.click();
    }

    public void searchAndSelectMedicine(String medicineCardTitle) {
        waitForClickability(searchButton).click();
        searchButton2.sendKeys(medicineCardTitle);
        By resultOption = By.xpath("(//h4[text()='" + medicineCardTitle + "'])[1]");
        WebElement medicineCard = waitForClickability(driver.findElement(resultOption),0);
        medicineCard.click();
    }
//    public void searchAndSelectMedicine(String medicineName){
//        // Find the correct overlay containing mat-select-panel
////    	  searchButton.sendKeys(medicineCardTitle);
//    	 waitForClickability(searchButton).click();
//        List<WebElement> overlays = driver.findElements(By.cssSelector("div.cdk-overlay-pane"));
//        WebElement scrollablePanel = null;
//
//        for (WebElement overlay : overlays) {
//            try {
//                scrollablePanel = overlay.findElement(By.cssSelector("div.mat-select-panel"));
//                if (!overlay.findElements(By.cssSelector("mat-option")).isEmpty()) {
//                    break; // Found the overlay with actual options
//                }
//            } catch (NoSuchElementException e) {
//                // Not this overlay, try next
//            }
//        }
//
//        if (scrollablePanel == null) {
//            System.out.println("❌ Could not find the medicine dropdown overlay");
//            return;
//        }
//
//        boolean clicked = false;
//        int attempts = 0;
//
//        String xpath = ".//mat-option[.//h4[translate(normalize-space(.), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')='"
//                       + medicineName.toLowerCase() + "']]";
//
//        while (!clicked && attempts < 50) {
//            try {
//                WebElement option = waitForClickability(scrollablePanel.findElement(By.xpath(xpath)));
//
//                // Scroll option into view (center)
//                ((JavascriptExecutor) driver).executeScript(
//                        "arguments[0].scrollIntoView({block: 'center'});", option);
//
//                // Click via JS
//                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", option);
//
//                System.out.println("✅ Selected medicine: " + medicineName);
//                clicked = true;
//            } catch (NoSuchElementException e) {
//                // Scroll to load more options
//                ((JavascriptExecutor) driver).executeScript(
//                        "arguments[0].scrollTop = arguments[0].scrollHeight;", scrollablePanel);
////                Thread.sleep(200); // wait for DOM update
//            }
//            attempts++;
//        }
//
//        if (!clicked) {
//            System.out.println("❌ Could not select medicine: " + medicineName);
//        }
//    }

    public void addMedicine(String quantity) {
        waitForVisibility(quantityInput,0).sendKeys(quantity);
        clickWithJavaScript(waitForVisibility(addButton,0));
    }

    public void saveIndent() {
        clickWithJavaScript(waitForVisibility(saveButton,0));
    }

    public void completeIndentRequestFlow(String location, String RequestedBy, String department, String medicineCardTitle, String quantity) {
        selectLocation(location);
        selectLocation(RequestedBy);
        selectLocation(department);
        searchAndSelectMedicine(medicineCardTitle);
        addMedicine(quantity);
        
    }
    
    public IndentRequestTablePage save2() {
    	saveIndent();
    	IndentRequestTablePage tablePage= new IndentRequestTablePage(driver);
    	return tablePage;
    }
    public String getMandatoryFieldErrorMessage() {
        waitForVisibility(mandatoryFieldErrorMessage);
        return mandatoryFieldErrorMessage.getText().trim();
    }

}
