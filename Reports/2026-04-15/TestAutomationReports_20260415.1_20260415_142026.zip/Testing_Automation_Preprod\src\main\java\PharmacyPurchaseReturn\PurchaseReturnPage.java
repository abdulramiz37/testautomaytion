package PharmacyPurchaseReturn;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class PurchaseReturnPage extends Abstraction {


    @FindBy(xpath = "(//a[text()=' Add Purchase Return'])[1]")
    private WebElement addPurchaseReturnButton;

    @FindBy(xpath = "(//span[text()='Pharamacy Loaction'])[1]")
    private WebElement pharmacyLocation;

    @FindBy(xpath = "(//span[text()='Select'])[1]")
    private WebElement supplierDropdown;

    @FindBy(xpath = "(//span[text()='supplier name'])[2]")
    private WebElement supplierName;

    @FindBy(xpath = "//span[text()='Damaged Items']")
    private WebElement damagedItemReason;

    @FindBy(xpath = "//span[text()='syrup14']")
    private WebElement syrupItem;

    @FindBy(xpath = "//input[@formcontrolname='quantity']")
    private WebElement quantityInput;
    
    @FindBy(xpath = "//i[@class='fas fa-chevron-right']")
    private WebElement nextPage;
    
    @FindBy(xpath = "//input[@value='Add']")
    private WebElement addButton;

    @FindBy(xpath = "//textarea[@formcontrolname='returnRemarks']")
    private WebElement remarksInput;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//input[@value='Yes']")
    private WebElement yesButton;

    @FindBy(xpath = "//input[@value='Update & Approval']")
    private WebElement updateApprovalButton;

    @FindBy(xpath = "//input[@value='Save & Approval']")
    private WebElement updateSaveButton;
    
    @FindBy(xpath = "//input[@formcontrolname='quantity']/following-sibling::span[@style='color: red;']")
    WebElement quantityErrorMessage;


    public String getQuantityErrorMessage() {
        waitForVisibility(quantityErrorMessage); // assuming you have a wait method in your base class
        System.out.println(quantityErrorMessage.getText().trim());
        return quantityErrorMessage.getText().trim();
    }

    
    public PurchaseReturnPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    public WebElement getSpanByExactText(String exactText) {
        String xpath = "//span[text()='" + exactText + "']";
        return driver.findElement(By.xpath(xpath));
    }
    
    public void selectMedicineByName(String medicineName) {
        String xpath = "//mat-option[.//span[normalize-space(text())='" + medicineName + "']]";
        driver.findElement(By.xpath(xpath)).click();
    }


    public void createPurchaseReturn(String invoiceNo, String grnNo, String location, String supplier, String medicineName,String quantity) {
       
        waitForClickability(addPurchaseReturnButton).click();
//        waitForUrl("https://apps.ezovion.com/pages/masters/purchase_return");
        waitForUrl("https://ezopreprodstrgfrontend.z29.web.core.windows.net/pages/masters/purchase_return");

        waitForClickability(supplierDropdown).click();
        waitForClickability(getSpanByExactText(location)).click();

        waitForClickability(supplierDropdown).click();
        waitForClickability(getSpanByExactText(supplier)).click();

        String invoiceRange = invoiceNo + " - " + grnNo;
        WebElement option = waitForClickability(getSpanByExactText(invoiceRange));
        clickWithJavaScript(option);

        waitForClickability(damagedItemReason).click();
        
        selectMedicineByName(medicineName);

        waitForClickability(quantityInput).sendKeys(quantity);
             

   
    
    }
    
    // CLICK: Add Purchase Return
       public void clickAddPurchaseReturn() {
           waitForClickability(addPurchaseReturnButton).click();
       }

       // WAIT FOR: Purchase Return Page URL
       public void waitForPurchaseReturnUrl() {
           waitForUrl("https://ezopreprodstrgfrontend.z29.web.core.windows.net/pages/masters/purchase_return");
       }

       // CLICK: Supplier Dropdown (Location dropdown)
       public void openLocationDropdown() {
           waitForClickability(supplierDropdown).click();
       }
       public void selectRadioOptionByLabel(String labelText) {
           WebElement radio = driver.findElement(By.xpath("//label[contains(text(),'" + labelText + "')]/preceding-sibling::input[@type='radio']"));
           waitForClickability(radio).click();
           System.out.println("✔ Selected radio option: " + labelText);
       }
       // SELECT: Location by visible text
       public void selectLocation(String location) {
           waitForClickability(getSpanByExactText(location)).click();
       }

       // CLICK AGAIN: Supplier dropdown
       public void openSupplierDropdown() {
           waitForClickability(supplierDropdown).click();
       }

       // SELECT: Supplier by name
       public void selectSupplier(String supplier) {
           waitForClickability(getSpanByExactText(supplier)).click();
       }

       // SELECT: Invoice Range (Invoice No - GRN No)
       public void selectInvoiceUsingRange(String invoiceNo, String grnNo) {
           String invoiceRange = invoiceNo + " - " + grnNo;
           WebElement option = waitForClickability(getSpanByExactText(invoiceRange));
           clickWithJavaScript(option);
       }

       // CLICK: Damaged Item Reason dropdown
       public void openDamagedItemReason() {
           waitForClickability(damagedItemReason).click();
       }
       
    // Reason dropdown (click to open)
       @FindBy(xpath = "//label[contains(text(),'Reason')]/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
       private WebElement reasonDropdown;

       // All Reason options
       @FindBy(xpath = "//label[contains(text(),'Reason')]/following-sibling::ngx-select//ul//a")
       private List<WebElement> reasonOptions;

       public void selectReason2(String optionText) {
    	    // Click dropdown
//    	    WebElement input = driver.findElement(reasonDropdown);
    	    waitForClickability(reasonDropdown).click();

    	    // Type into input (optional but good for filtering)
//    	    input.sendKeys(optionText);

    	    // Select option
    	    WebElement option = driver.findElement(
    	            By.xpath("//ngx-select[@formcontrolname='reason']//span[contains(text(),'" + optionText + "')]")
    	    );
    	    waitForClickability(option).click();

    	    System.out.println("✔ Selected Reason: " + optionText);
    	}

       // SELECT: Medicine from list
       public void selectMedicine(String medicineName) {
           selectMedicineByName(medicineName);
       }

       // ENTER: Quantity
       public void enterQuantity(String quantity) {
           waitForClickability(quantityInput).sendKeys(quantity);
       }
       
    public void savePurchasePage(String review) {
    	   waitForClickability(addButton).click();

    	waitForVisibility(remarksInput).sendKeys(review);
        waitForClickability(saveButton).click();
        waitForClickability(yesButton).click();

//        waitForUrl("https://apps.ezovion.com/pages/masters/purchase_return");
        waitForUrl("https://ezopreprodstrgfrontend.z29.web.core.windows.net/pages/masters/purchase_return");
        
        System.out.println("Success done");
    }
    public void savePurchasePagemiscellaneous(String review) {
 	   waitForClickability(addButton).click();

 	waitForVisibility(remarksInput).sendKeys(review);
     waitForClickability(updateSaveButton).click();
//     waitForClickability(yesButton).click();

//     waitForUrl("https://apps.ezovion.com/pages/masters/purchase_return");
     waitForUrl("https://ezopreprodstrgfrontend.z29.web.core.windows.net/pages/masters/purchase_return");
     
     System.out.println("Success done");
 }
    public void saveDetails(String invoiceNo) {
        waitForPresenceOfAll(By.xpath("//table[@class='table table-hover table-style']/tbody/tr"));
        boolean matchFound = false;
        while (!matchFound) {
            List<WebElement> rows = waitForPresenceOfAll(By.xpath("//table[@class='table table-hover table-style']/tbody/tr"));

            for (WebElement row : rows) {
                String invoiceText = waitForVisibility(row.findElement(By.xpath("./td[4]/h4"))).getText().trim();
                System.out.println(invoiceText);
                if (invoiceText.equals(invoiceNo)) {
                    WebElement editButton = row.findElement(By.xpath(".//img[contains(@src,'edit.png')]"));
                    clickWithJavaScript(editButton);
                    System.out.println("✅ Clicked Edit for Invoice No: " + invoiceText);
                    matchFound = true;
                    break;
                }
            }

            if (!matchFound) {
                try {
                    WebElement nextPageButton = waitForClickability(nextPage);
                    clickWithJavaScript(nextPageButton);
                } catch (NoSuchElementException e) {
                    System.out.println("No more pages or 'Next Page' button not found.");
                    break;
                }
            }
        }

        waitForClickability(updateApprovalButton).click();
    }
    public void saveDetails(String invoiceNo, String actionType) {
        waitForPresenceOfAll(By.xpath("//table[@class='table table-hover table-style']/tbody/tr"));
        boolean matchFound = false;

        while (!matchFound) {

            List<WebElement> rows = waitForPresenceOfAll(
                By.xpath("//table[@class='table table-hover table-style']/tbody/tr")
            );

            for (WebElement row : rows) {

                String invoiceText = waitForVisibility(row.findElement(By.xpath("./td[2]"))).getText().trim();
                System.out.println("Found Invoice: " + invoiceText);

                if (invoiceText.equals(invoiceNo)) {

                    WebElement actionButton = null;

                    if (actionType.equalsIgnoreCase("edit")) {
                        actionButton = row.findElement(By.xpath(".//img[contains(@src,'edit.png')]"));
                        System.out.println("✔ Clicking EDIT button...");
                    } 
                    else if (actionType.equalsIgnoreCase("adjust")) {
                        actionButton = row.findElement(By.xpath(".//img[contains(@src,'phRtrnAdj')]"));
                        System.out.println("✔ Clicking PURCHASE RETURN ADJUSTMENT button...");
                    } 
                    else {
                        System.out.println("❌ Invalid action type. Use 'edit' or 'adjust'");
                        return;
                    }

                    clickWithJavaScript(actionButton);
                    matchFound = true;
                    break;
                }
            }

            if (!matchFound) {
                try {
                    WebElement nextPageButton = waitForClickability(nextPage);
                    clickWithJavaScript(nextPageButton);
                } catch (NoSuchElementException e) {
                    System.out.println("❌ No more pages or 'Next' button not found.");
                    break;
                }
            }
        }
    }

    private By tableRows = By.xpath("//tbody//tr");
    private By grnColumn = By.xpath("./td[2]"); 
    private By adjustAmountInput = By.xpath("./td[11]//input[@formcontrolname='input']");
    private By deleteButton = By.xpath("./td[12]//a[contains(@class,'delete')]");
    
    
    public void fillAdjustAmountByGRN(String targetGrn, String amount) {
        List<WebElement> rows = driver.findElements(tableRows);
        boolean found = false;

        for (WebElement row : rows) {
            String grn = row.findElement(grnColumn).getText().trim();

            if (grn.equals(targetGrn)) {
                WebElement input = row.findElement(adjustAmountInput);
                waitForVisibility(input).clear();
                input.sendKeys(amount);

                System.out.println("✔ Entered Adjust Amount " + amount + " for GRN: " + targetGrn);
                found = true;
                break;
            }
        

            else {
            // Click delete button on the last row OR the row where user wants
//            WebElement lastRow = rows.get(rows.size() - 1);
            WebElement delete = row.findElement(deleteButton);

            waitForClickability(delete).click();
            System.out.println("❌ GRN not found. Delete button clicked.");
        }
    }

    }
    
}
