package ezion.ResourcesMyHospital;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import EzionAbstractionComponents.Abstraction;

public class EmployeePage extends Abstraction {

    public EmployeePage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    // ---------------- Navigation ----------------
    @FindBy(xpath = "//a[text()=' Employee ']")
    private WebElement employee;

    @FindBy(xpath = "//a[text()=' Add Employee ']")
    private WebElement addEmployee;

    // ---------------- Personal Details ----------------
    @FindBy(id = "title")
    private WebElement titleDropdown;

    @FindBy(xpath = "//input[@formcontrolname='fName']")
    private WebElement firstNameInput;

    @FindBy(xpath = "//input[@formcontrolname='lName']")
    private WebElement lastNameInput;

    @FindBy(xpath = "//input[@formcontrolname='maritalStatus' and @value='Married']")
    private WebElement maritalStatusMarried;

    @FindBy(xpath = "//input[@formcontrolname='maritalStatus' and @value='Single']")
    private WebElement maritalStatusSingle;

    @FindBy(id = "gender")
    private WebElement genderDropdown;

    @FindBy(xpath = "//input[@formcontrolname='dobs']")
    private WebElement dobInput;

    @FindBy(xpath = "//input[@formcontrolname='age']")
    private WebElement ageInput;

    @FindBy(xpath = "//input[@formcontrolname='email']")
    private WebElement emailInput;

    @FindBy(xpath = "//input[@formcontrolname='mobile']")
    private WebElement mobileInput;

    @FindBy(xpath = "//input[@formcontrolname='altrMobile']")
    private WebElement altMobileInput;

    @FindBy(xpath = "//input[@formcontrolname='workPhone']")
    private WebElement workPhoneInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='employeeType']")
    private WebElement employeeTypeDropdown;

    @FindBy(xpath = "//input[@formcontrolname='empNum']")
    private WebElement employeeNumberInput;

    // ---------------- Communication Address ----------------
    @FindBy(xpath = "//input[@formcontrolname='streetname']")
    private WebElement streetInput;

    @FindBy(xpath = "//input[@formcontrolname='area']")
    private WebElement areaInput;

    @FindBy(xpath = "//input[@formcontrolname='pincode']")
    private WebElement pincodeInput;

    @FindBy(xpath = "//input[@formcontrolname='city']")
    private WebElement cityInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='district']")
    private WebElement districtDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='state']")
    private WebElement stateDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='country']")
    private WebElement countryDropdown;

    // ---------------- Department Details ----------------
    @FindBy(xpath = "//ngx-select[@formcontrolname='department']")
    private WebElement departmentDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='jobCategory']")
    private WebElement jobCategoryDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='designation']")
    private WebElement designationDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='branchLocation']")
    private WebElement branchDropdown;

    @FindBy(xpath = "//input[@formcontrolname='doj']")
    private WebElement dojInput;

    @FindBy(xpath = "//input[@formcontrolname='dol']")
    private WebElement dolInput;

    @FindBy(xpath = "//input[@formcontrolname='isactive']")
    private WebElement isActiveCheckbox;

    @FindBy(xpath = "//input[@formcontrolname='onenable']")
    private WebElement enableSignatureCheckbox;

    // ---------------- Optional Personal Section ----------------
    @FindBy(xpath = "//input[@formcontrolname='fathersName']")
    private WebElement fatherNameInput;

    @FindBy(xpath = "//input[@formcontrolname='spouseName']")
    private WebElement spouseNameInput;

    // ---------------- Utility Methods ----------------
    public void clickAddEmployeeButton() {
        waitForClickability(employee).click();
        waitForClickability(addEmployee).click();
    }

    protected void clearAndType(WebElement element, String value) {
        waitForVisibility(element);
        element.clear();
        element.sendKeys(value);
    }

    protected void selectFromDropdownByVisibleText(WebElement dropdown, String text) {
        waitForClickability(dropdown).click();
        WebElement option = driver.findElement(By.xpath("//span[contains(text(),'" + text + "')]"));
        waitForClickability(option).click();
    }

    protected void setCheckbox(WebElement checkbox, boolean checked) {
        if (checkbox.isSelected() != checked) {
            waitForClickability(checkbox).click();
        }
    }

    // ---------------- Field Methods ----------------
    public void selectTitle(String title) {
        selectFromDropdownByVisibleText(titleDropdown, title);
    }

    public void enterFirstName(String firstName) {
        clearAndType(firstNameInput, firstName);
    }

    public void enterLastName(String lastName) {
        clearAndType(lastNameInput, lastName);
    }

    public void selectMaritalStatus(String status) {
        if (status.equalsIgnoreCase("Married")) {
            maritalStatusMarried.click();
        } else {
            maritalStatusSingle.click();
        }
    }

    public void selectGender(String gender) {
        selectFromDropdownByVisibleText(genderDropdown, gender);
    }

    public void enterDOB(String dob) {
        clearAndType(dobInput, dob);
    }

    public void enterAge(String age) {
        clearAndType(ageInput, age);
    }

    public void enterEmail(String email) {
        clearAndType(emailInput, email);
    }

    public void enterMobile(String mobile) {
        clearAndType(mobileInput, mobile);
    }

    public void enterAltMobile(String altMobile) {
        clearAndType(altMobileInput, altMobile);
    }

    public void enterWorkPhone(String phone) {
        clearAndType(workPhoneInput, phone);
    }

    public void selectEmployeeType(String type) {
        selectFromDropdownByVisibleText(employeeTypeDropdown, type);
    }

    public String getEmployeeNumber() {
        return employeeNumberInput.getAttribute("value");
    }

    public void enterStreet(String street) {
        clearAndType(streetInput, street);
    }

    public void enterArea(String area) {
        clearAndType(areaInput, area);
    }

    public void enterPincode(String pin) {
        clearAndType(pincodeInput, pin);
    }

    public void enterCity(String city) {
        clearAndType(cityInput, city);
    }

    public void selectDistrict(String district) {
        selectFromDropdownByVisibleText(districtDropdown, district);
    }

    public void selectState(String state) {
        selectFromDropdownByVisibleText(stateDropdown, state);
    }

    public void selectCountry(String country) {
        selectFromDropdownByVisibleText(countryDropdown, country);
    }

    public void selectDepartment(String department) {
        selectFromDropdownByVisibleText(departmentDropdown, department);
    }

    public void selectJobCategory(String jobCategory) {
        selectFromDropdownByVisibleText(jobCategoryDropdown, jobCategory);
    }

    public void selectDesignation(String designation) {
        selectFromDropdownByVisibleText(designationDropdown, designation);
    }

    public void selectBranch(String branch) {
        selectFromDropdownByVisibleText(branchDropdown, branch);
    }

    public void enterDOJ(String doj) {
        clearAndType(dojInput, doj);
    }

    public void enterDOL(String dol) {
        clearAndType(dolInput, dol);
    }

    public void setIsActive(boolean value) {
        setCheckbox(isActiveCheckbox, value);
    }

    public void setEnableSignature(boolean value) {
        setCheckbox(enableSignatureCheckbox, value);
    }

    public void enterFatherName(String fatherName) {
        clearAndType(fatherNameInput, fatherName);
    }

    public void enterSpouseName(String spouseName) {
        clearAndType(spouseNameInput, spouseName);
    }

    // ---------------- Form Fill Method ----------------
    public void fillEmployeeForm(
        String title,
        String firstName,
        String lastName,
        String maritalStatus,
        String gender,
        String dob,
        String age,
        String email,
        String mobile,
        String altMobile,
        String workPhone,
        String employeeType,
        String street,
        String area,
        String pincode,
        String city,
        String district,
        String state,
        String country,
        String department,
        String jobCategory,
        String designation,
        String branch,
        String doj,
        String dol,
        boolean isActive,
        boolean enableSignature,
        String fatherName,
        String spouseName
    ) {
        clickAddEmployeeButton();
        selectTitle(title);
        enterFirstName(firstName);
        enterLastName(lastName);
        selectMaritalStatus(maritalStatus);
        selectGender(gender);
        enterDOB(dob);
//        enterAge(age);
        enterEmail(email);
        enterMobile(mobile);
        enterAltMobile(altMobile);
        enterWorkPhone(workPhone);
        selectEmployeeType(employeeType);

        enterStreet(street);
        enterArea(area);
        enterPincode(pincode);
        enterCity(city);
        selectDistrict(district);
        selectState(state);
        selectCountry(country);

        selectDepartment(department);
        selectJobCategory(jobCategory);
        selectDesignation(designation);
        selectBranch(branch);
        enterDOJ(doj);
//        enterDOL(dol);
//        setIsActive(isActive);
//        setEnableSignature(enableSignature);
//
//        enterFatherName(fatherName);
//        enterSpouseName(spouseName);
    }
}
