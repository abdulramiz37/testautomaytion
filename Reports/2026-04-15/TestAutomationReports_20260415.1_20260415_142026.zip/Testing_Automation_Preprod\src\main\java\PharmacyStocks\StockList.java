package PharmacyStocks;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class StockList extends Abstraction {
    public StockList(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    
}
    @FindBy(xpath = "//input[@role='combobox']")
    WebElement comboBoxInput;
    
    public void enterValueInComboBox(String value) {
        waitForClickability(comboBoxInput).click();  // click inside
        comboBoxInput.clear();
        comboBoxInput.sendKeys(value);
        comboBoxInput.sendKeys(Keys.ENTER);
    }
    @FindBy(xpath = "//span[normalize-space()='Stock']")
    WebElement stockMenu;

    // Stock List submenu
    @FindBy(xpath = "//span[normalize-space()='Stock List']")
    WebElement stockListMenu;
    
    
 // Click on "Stock" menu
    public void clickStockMenu() {
    	clickWithJavaScript(stockMenu);
        System.out.println("✅ Clicked on Stock menu");
    }

    // Click on "Stock List" submenu
    public void clickStockListMenu() {
    	clickWithJavaScript(stockListMenu);
        System.out.println("✅ Clicked on Stock List submenu");
    }
    public String findMedicineAndClickEdit(String targetMedicine, String targetBatch, String targetStock) {
        boolean isFound = false;
        String foundStock = "";

        while (!isFound) {
            // All table rows
            List<WebElement> rows = driver.findElements(
                By.xpath("//table[@class='table table-hover table-style']/tbody/tr")
            );

            for (int i = 0; i < rows.size(); i++) {
                try {
                    WebElement row = rows.get(i);

                    // Medicine Name (td[1] → h4)
                    String medicineName = row.findElement(By.xpath("./td[1]//h4")).getText().trim();

                    // Batch Number (td[4] → h4)
                    String batchNumber = row.findElement(By.xpath("./td[4]//h4")).getText().trim();

                    // Stock Quantity (td[5] → h4)
                    String stockQty = row.findElement(By.xpath("./td[5]//h4")).getText().trim();

                    System.out.println("Row " + (i + 1) + ": Medicine=" + medicineName +
                            ", Batch=" + batchNumber + ", Stock=" + stockQty);

                    // Match with target values
                    if (medicineName.equalsIgnoreCase(targetMedicine)
                            && batchNumber.equalsIgnoreCase(targetBatch)
                            && stockQty.equalsIgnoreCase(targetStock)) {

                

                        System.out.println("✅ Clicked Edit for: " + medicineName +
                                ", Batch: " + batchNumber + ", Stock: " + stockQty);

                        isFound = true;
                        foundStock = stockQty;
                        break;
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("⚠️ Skipping stale or missing row at index " + i);
                }
            }

            // If not found → go to next page
            if (!isFound) {
                try {
                    WebElement nextButton2 = driver.findElement(
                        By.xpath("//a[@role='button']//i[contains(@class,'fa-chevron-right')]")
                    );
                    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextButton2);
                } catch (NoSuchElementException e) {
                    System.out.println("❌ Next page button not found. Ending search.");
                    break;
                }
            }
        }

        return foundStock;
    }

}