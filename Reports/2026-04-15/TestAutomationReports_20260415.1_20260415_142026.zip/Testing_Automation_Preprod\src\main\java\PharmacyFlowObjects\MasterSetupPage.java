package PharmacyFlowObjects;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


import EzionAbstractionComponents.Abstraction;
import PharmacyFlowObjects.PharmacyStore.StorePage;

public class MasterSetupPage extends Abstraction {

    public MasterSetupPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    // --- Web Elements ---

    @FindBy(xpath = "//a[text()=' Warehouse ']")
    private WebElement warehouseTab;

    @FindBy(xpath = "//a[text()=' Add Warehouse ']")
    private WebElement addWarehouseButton;

    @FindBy(xpath = "//input[@formcontrolname='warehousecode']")
    private WebElement warehouseCodeInput;

    @FindBy(xpath = "//input[@formcontrolname='warehousename']")
    private WebElement warehouseNameInput;

    @FindBy(xpath = "//input[@formcontrolname='warehouseshortname']")
    private WebElement warehouseShortNameInput;

    @FindBy(xpath = "//div[@class='ngx-select dropdown']")
    private WebElement countryDropdown;


    @FindBy(xpath = "//input[@type='button' and @value='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//input[@formcontrolname='warehousecode']/following-sibling::span[@style='color: red; font-size: smaller;']")
    private WebElement codeError;

    @FindBy(xpath = "//input[@formcontrolname='warehousename']/following-sibling::span[@style='color: red; font-size: smaller;']")
    private WebElement nameError;

    @FindBy(xpath = "//input[@formcontrolname='warehouseshortname']/following-sibling::span[@style='color: red; font-size: smaller;']")
    private WebElement shortNameError;

    // --- Actions ---
    private WebElement getSpanByTextCountry(String text) {
        String xpath = String.format("//span[text()='%s']", text);
        return driver.findElement(By.xpath(xpath));
    }
    public void navigateToAddWarehouse() {
        waitForClickability(warehouseTab).click();
        waitForClickability(addWarehouseButton).click();
    }

    public void fillWarehouseDetails(String code, String name, String shortName, String country) {
        waitForVisibility(warehouseCodeInput).sendKeys(code);
    
        waitForVisibility(warehouseNameInput).sendKeys(name);

        waitForVisibility(warehouseShortNameInput).sendKeys(shortName);

        waitForClickability(countryDropdown).click();  // ✅ First open the dropdown
        waitForClickability(getSpanByTextCountry(country),4).click();  // ✅ Then select country dynamically	
        // You can add more countries here if needed
    }
    public String codeError() {
    	System.out.println(codeError.getText());
        return codeError.getText();
    }
    
    public String nameError() {
    	System.out.println(nameError.getText());
        return nameError.getText();
    }
    
    public String shortNameError() {
    	System.out.println(shortNameError.getText());
        return shortNameError.getText();
    }
    public void clickSave() {
        waitForClickability(saveButton).click();
    }

    public void createWarehouse(String code, String name, String shortName, String country) {
        navigateToAddWarehouse();
        
        fillWarehouseDetails(code, name, shortName, country);
       
   
    }
    public StorePage backbutton() {
        waitForPharmacyPageWithBackClick();
        StorePage storePage= new StorePage(driver);
        return storePage;
    }
}

