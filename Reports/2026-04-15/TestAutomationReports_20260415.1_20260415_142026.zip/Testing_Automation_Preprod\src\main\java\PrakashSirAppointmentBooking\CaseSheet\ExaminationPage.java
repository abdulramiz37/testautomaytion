package PrakashSirAppointmentBooking.CaseSheet;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import EzionAbstractionComponents.Abstraction;

public class ExaminationPage extends Abstraction {

    WebDriver driver;

    public ExaminationPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // --- Section Toggle ---
    @FindBy(xpath = "//h4[normalize-space(text())='Examination']/following::img[contains(@class,'openclose')][1]")
    private WebElement examinationToggleIcon;

    // --- Dropdowns ---
    @FindBy(xpath = "//ngx-select[@formcontrolname='examination']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement examinationDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='severity']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement severityDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='performDoc']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement performingDoctorDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='performNurse']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement performingNurseDropdown;

    // --- Text Fields ---
    @FindBy(xpath = "//input[@formcontrolname='problemsince']")
    private WebElement problemSinceInput;

    @FindBy(xpath = "//textarea[@formcontrolname='patientexaminationNotes']")
    private WebElement notesTextarea;

    // --- Buttons ---
    @FindBy(xpath = "//button[@nbtooltip='Add']")
    private WebElement addExaminationBtn;

    @FindBy(xpath = "//button[@nbtooltip='Reset']")
    private WebElement resetExaminationBtn;

    // --- Success Messages ---
    @FindBy(xpath = "//span[normalize-space(text())='Examination Saved Successfully']")
    private WebElement successSaveMsg;

    @FindBy(xpath = "//span[normalize-space(text())='Examination Updated Successfully']")
    private WebElement successUpdateMsg;

    @FindBy(xpath = "//span[normalize-space(text())='Examination Deleted Successfully']")
    private WebElement successDeleteMsg;

    // --- Actions ---
    public void clickExaminationToggle() {
    	clickWithJavaScript(examinationToggleIcon);
    }
    @FindBy(xpath = "//input[@placeholder='Select Examination' and contains(@class,'ngx-select__search')]")
    private WebElement examinationDropdown2;

 // Add New Examination button
    @FindBy(xpath = "//button[contains(@class,'add-btn-icon') and contains(.,'Add New Examination')]")
    private WebElement addNewExaminationBtn;

    public String finalExamination;   // accessible outside

    public void selectExamination(String examName) {
        // open dropdown
        problemSinceInput.click();
        problemSinceInput.click();
        problemSinceInput.click();
        examinationDropdown.click();

        finalExamination = examName;

        // If examName is null or empty, generate a random name
        if (examName == null || examName.trim().isEmpty()) {
            int length = 6;
            String alphabet = "abcdefghijklmnopqrstuvwxyz";
            StringBuilder sb = new StringBuilder();
            java.util.Random random = new java.util.Random();
            for (int i = 0; i < length; i++) {
                sb.append(alphabet.charAt(random.nextInt(alphabet.length())));
            }
            finalExamination = sb.toString();
        }

        // type in examination name
        examinationDropdown2.sendKeys(finalExamination);

        // look for existing exam in dropdown
        List<WebElement> examOptions = driver.findElements(
            By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + finalExamination + "']")
        );

        if (!examOptions.isEmpty()) {
            // select existing exam
            examOptions.get(0).click();
            System.out.println("Examination Selected from dropdown: " + finalExamination);
        } else {
            // click Add New (similar to complaints flow)
            addNewExaminationBtn.click();
            System.out.println("New Examination Added: " + finalExamination);
        }
    }


    public void setProblemSince(String text) {
        problemSinceInput.clear();
        problemSinceInput.sendKeys(text);
    }

    public void selectSeverity(String severity) {
        severityDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + severity + "']"));
        option.click();
    }

    public void selectPerformingDoctor(String doctorName) {
        performingDoctorDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + doctorName + "']"));
        option.click();
    }

    public void selectPerformingNurse(String nurseName) {
        performingNurseDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + nurseName + "']"));
        option.click();
    }

    public void enterNotes(String notes) {
        notesTextarea.clear();
        notesTextarea.sendKeys(notes);
    }

    public void clickAddExamination() {
        addExaminationBtn.click();
    }

    public void clickResetExamination() {
        resetExaminationBtn.click();
    }

    // --- Validation ---
    public boolean isSaveSuccessDisplayed() {
        return successSaveMsg.isDisplayed();
    }

    public boolean isUpdateSuccessDisplayed() {
        return successUpdateMsg.isDisplayed();
    }

    public boolean isDeleteSuccessDisplayed() {
        return successDeleteMsg.isDisplayed();
    }
    
    // Page header
    @FindBy(xpath = "//div[@class='lightbox-title' and normalize-space()='Add Examination']")
    private WebElement addNewExaminationButton;

    // Select Type dropdown
    @FindBy(xpath = "//ngx-select[@formcontrolname='type']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement selectTypeDropdown;

    // Name field
    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement nameInput;

    // Department dropdown
    @FindBy(xpath = "//ngx-select[@formcontrolname='departmentId']//input[@type='text']")
    private WebElement departmentDropdownInput;

    // Is Active checkbox
    @FindBy(xpath = "//input[@formcontrolname='isActive']")
    private WebElement isActiveCheckbox;

    // Attribute input
    @FindBy(xpath = "//input[@formcontrolname='attribute']")
    private WebElement attributeInput;

    // Add Attribute button
    @FindBy(xpath = "//input[@value='Add Attribute']")
    private WebElement addAttributeBtn;

    // Reset button
    @FindBy(xpath = "//input[@value='Reset']")
    private WebElement resetBtn;

    // Save button
    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveBtn;

    // Cancel button
    @FindBy(xpath = "//input[@value='Cancel']")
    private WebElement cancelBtn;

    // ---------------------- METHODS ----------------------

    public boolean isPageDisplayed() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        try {
            wait.until(ExpectedConditions.visibilityOf(addNewExaminationButton));
            return addNewExaminationButton.isDisplayed();
        } catch (TimeoutException e) {
            return false;
        }
    }


    public void selectType(String type) {
        selectTypeDropdown.click();
        WebElement option = driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + type + "']"));
        option.click();
    }

    public void enterName(String name) {
        nameInput.clear();
        nameInput.sendKeys(name);
    }

    @FindBy(xpath = "//div[contains(@class,'lightbox-close')]")
    private WebElement closeLightboxDiv;

    public void clickCloseLightbox() {
        closeLightboxDiv.click();
    }

    
    public void selectDepartments(String[] deptNames) {
        for (String deptName : deptNames) {
     
            waitForVisibility(departmentDropdownInput).clear();
            waitForVisibility(departmentDropdownInput).sendKeys(deptName);
            waitForVisibility(departmentDropdownInput).sendKeys(Keys.ENTER);
        }
    }

    public void setActive(boolean value) {
        if (value && !isActiveCheckbox.isSelected()) {
            isActiveCheckbox.click();
        } else if (!value && isActiveCheckbox.isSelected()) {
            isActiveCheckbox.click();
        }
    }

    public void enterAttribute(String attribute) {
    	attributeInput.click();
        attributeInput.clear();
        attributeInput.sendKeys(attribute);
    }

    public void clickAddAttribute() {
        addAttributeBtn.click();
    }

    public void clickReset() {
        resetBtn.click();
    }

    public void clickSave() {
        saveBtn.click();
    }

    public void clickCancel() {
        cancelBtn.click();
    }

}
