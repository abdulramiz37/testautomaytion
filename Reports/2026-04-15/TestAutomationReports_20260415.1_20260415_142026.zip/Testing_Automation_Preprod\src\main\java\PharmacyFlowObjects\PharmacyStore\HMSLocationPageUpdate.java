 package PharmacyFlowObjects.PharmacyStore;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.*;

import EzionAbstractionComponents.Abstraction;

public class HMSLocationPageUpdate extends Abstraction {

    WebDriver driver;
 

    public HMSLocationPageUpdate(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
   
    }

    // WebElements using PageFactory
    @FindBy(xpath = "//a[text()=' HMS Location ']")
    private WebElement hmsLocationTab;

    @FindBy(xpath = "//a[text()=' Add Hospital Location']")
    private WebElement addHospitalLocationBtn;

    @FindBy(xpath = "//input[@formcontrolname='locationName']")
    private WebElement locationNameInput;

    @FindBy(xpath = "//input[@formcontrolname='mobile']")
    private WebElement mobileInput;

    @FindBy(xpath = "//input[@formcontrolname='email']")
    private WebElement emailInput;

    @FindBy(xpath = "(//span[@class='checkmark'])[2]")
    private WebElement checkboxSecondOption;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveBtn;

    @FindBy(xpath = "//span[contains(text(),'Name Already Exists..')]")
    private WebElement errorMessage;
 
    // ---------- Actions ----------
    
    public String duplicateErrorMessage() {
    	return errorMessage.getText();
    }
    public void clickHMSLocationTab() {
    	waitForVisibility(hmsLocationTab).click();
    }

    public void clickAddHospitalLocation() {
    	waitForVisibility(addHospitalLocationBtn).click();
    }

    public void enterLocationName(String name) {
    	waitForVisibility(locationNameInput).sendKeys(name);
        int counter = 1;
        String uniqueName = name;

       while (true) {
           waitForVisibility(locationNameInput).clear();
           locationNameInput.sendKeys(uniqueName);

           try {
               new WebDriverWait(driver, Duration.ofSeconds(0))
                   .until(ExpectedConditions.invisibilityOfElementLocated(
                       By.xpath("//span[contains(text(),'Name Already Exists..')]")));
               break;
           } catch (TimeoutException e) {
               counter++;
               uniqueName = name + counter;
           }
       }
        
    }

    public void enterMobileNumber(String mobile) {
    	waitForVisibility(mobileInput).sendKeys(mobile);
    }

    public void enterEmail(String email) {
    	waitForVisibility(emailInput).sendKeys(email);
    }

    public void selectSecondCheckboxOption() {
    	waitForVisibility(checkboxSecondOption).click();
    }

    public void clickSave() {
    	waitForVisibility(saveBtn).click();
    }

    // Combined action for test
    public void addHospitalLocation(String name, String mobile, String email) {
        clickHMSLocationTab();
        clickAddHospitalLocation();
        enterLocationName(name);
        enterMobileNumber(mobile);
        enterEmail(email);
        selectSecondCheckboxOption();
       
    }
    
    public PharmacyDashBoardPage save() {
    	   clickSave();
  	  waitForPharmacyPageWithBackClick();
  	  PharmacyDashBoardPage pharmacyDashboard= new PharmacyDashBoardPage(driver);
  	  return pharmacyDashboard;
  }
}
