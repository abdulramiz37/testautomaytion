package StandAloneTest;

 


	import java.time.Duration;

	import org.openqa.selenium.By;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.edge.EdgeDriver;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.WebDriverWait;
	import org.testng.annotations.Test;
	@Test
	public class BranchIndentFlow{
		

		public void PPLE() throws InterruptedException {

		WebDriver driver = new EdgeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://apps.ezovion.com/auth/login");

		driver.manage().window().maximize();
		

		driver.findElement(By.xpath("//div[@class=\"form-control-group\"]//input")).sendKeys("50107299");
		driver.findElement(By.xpath("//button[@size=\"large\"]")).click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
	        // Wait until the button with text "CONTINUE" is clickable
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
		
	     driver.findElement(By.xpath("//input[@placeholder=\"Mobile No\"]")).sendKeys("7766554433");
		driver.findElement(By.xpath("//input[@placeholder=\"Password\"]")).sendKeys("12345");
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@status=\"primary\"]")));
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//button[@status=\"primary\"]")).click();
		 for (int i = 0; i < 5; i++) { // Try up to 5 times
			    try {
			        
			        Thread.sleep(3000); // wait for any transition

			        WebElement adminTab = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Admin']")));
			        adminTab.click();
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Roles Management']"))).click();
			        break; // Exit loop if successful
			    } catch (Exception e) {
			        System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
			        if (i == 4) {
			            throw e; // Re-throw if max attempts reached
			        }
			    }
			}
		 
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Pharmacy']"))).click();
		 
		// Click "Indent"
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Indent'])[1]"))).click();
		 
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Branch Indent'])[1]"))).click();
//		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Internal Indent'])[1]"))).click();
		 

		 
		 // Click "Indent Request"
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[text()=' Indent Request '])[1]"))).click();
		 

		 
		 // Click first "Select" (Assumed for Location)
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();
		 

		 
		 // Click "Pharamacy Loaction"
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Pharamacy Loaction'])[1]"))).click();

		 // Wait and interact with Date Input
		 

		 
			

		 // Click second "Select"
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();

		 
		 // Click "Fddf"
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Fddf'])[1]"))).click();
		 

		 
		 // Click third "Select"
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();
		 

		 
		 // Click "Dddd"
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Dddd'])[1]"))).click();
		 

		 
		 // Click "Search Medicine"
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Search Medicine'])[1]"))).click();
		 
		 
		 
		 // Click on Syrup medicine card
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//h4[text()='syrup'])[1]"))).click();
		 

		 
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='indentQuantity']"))).sendKeys("5");
		 

		 WebElement addButton2 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@value='Add'])[1]")));

		 JavascriptExecutor js2 = (JavascriptExecutor) driver;
		 js2.executeScript("arguments[0].click();", addButton2);


		 // Click on first edit icon
		 
		
		 WebElement saveButton2 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@value='Save'])[1]")));

		
		 js2.executeScript("arguments[0].click();", saveButton2);

				 
							 
							Thread.sleep(2000);	
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//img[@src='../.././../../assets/images/edit.png'])[1]"))).click();

		 // Click on "Add" button
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@value='Add'])[1]"))).click();

		 // Click on "Send Request" button
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@value='Send Request'])[1]"))).click();

		 // Click on "Indent Approval"
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Indent Approval'])[1]"))).click();
			Thread.sleep(2000);
		 // Click on edit icon again (assuming same icon reused in approval section)
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//img[@src='../.././../../assets/images/edit.png'])"))).click();

		 // Click "Update" button
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@value='Update'])[1]"))).click();
		 
}
 }
