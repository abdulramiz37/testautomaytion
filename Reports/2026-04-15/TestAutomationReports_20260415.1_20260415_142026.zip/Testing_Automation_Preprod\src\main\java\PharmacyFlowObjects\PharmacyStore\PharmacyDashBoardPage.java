package PharmacyFlowObjects.PharmacyStore;

import org.openqa.selenium.WebDriver;

public class PharmacyDashBoardPage {

	public PharmacyDashBoardPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
	}

}
