package WareHouseSetup.MyHospital.Service;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class AddServicePage extends Abstraction {

    public AddServicePage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//a[text()=' Service']")
    private WebElement serviceTab;

    @FindBy(xpath = "//a[contains(@class,'btn-plus') and .//img[@alt='add']]")
    private WebElement addServiceBtn;

    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement nameInput;

    @FindBy(xpath = "//input[@formcontrolname='price']")
    private WebElement priceInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='gst']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement gstDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='scid']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement categoryDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='sscid']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement subCategoryDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='outsidelab']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement outsideLabDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='associated']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement associatedDropdown;

    @FindBy(xpath = "//input[@formcontrolname='srvReqNo']")
    private WebElement serviceRequestNoInput;

    @FindBy(xpath = "//input[@formcontrolname='srvAccCode']")
    private WebElement serviceAccountingCodeInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='departmentId']")
    private WebElement departmentDropdown;

    @FindBy(xpath = "//input[@formcontrolname='isEditable']")
    private WebElement isEditableCheckbox;

    @FindBy(xpath = "//input[@formcontrolname='isActive']")
    private WebElement isActiveCheckbox;

    @FindBy(xpath = "//input[@formcontrolname='zeroServiceFlag']")
    private WebElement allowZeroCheckbox;

    @FindBy(xpath = "//input[@formcontrolname='workOrderFlag']")
    private WebElement workOrderCheckbox;

    @FindBy(xpath = "//input[@formcontrolname='restrictType' and @value='1']")
    private WebElement restrictAllRadio;

    @FindBy(xpath = "//input[@formcontrolname='restrictType' and @value='2']")
    private WebElement restrictWeekDaysRadio;

    @FindBy(xpath = "//input[@formcontrolname='restrictType' and @value='3']")
    private WebElement restrictWeekendRadio;

    @FindBy(xpath = "//input[@formcontrolname='restrictType' and @value='4']")
    private WebElement restrictManualRadio;

    @FindBy(xpath = "//ngx-select[@formcontrolname='dateTimeInfoRequired']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement dateTimeRequiredDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='employeeInfoRequired']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement employeeInfoDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='physicianInfoRequired']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement physicianInfoDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='casesheetParentId']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement caseSheetDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='caseSheetId']//input[@role='combobox']")
    private WebElement caseSheetPagesInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='appendDoctorName']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement appendDoctorNameDropdown;

    @FindBy(xpath = "//input[@formcontrolname='attribute']")
    private WebElement attributeInput;

    @FindBy(xpath = "//input[@type='button' and @value='Add Attribute']")
    private WebElement addAttributeButton;

    @FindBy(xpath = "//input[@type='button' and @value='Save' and contains(@class,'btn-primary')]")
    private WebElement saveButton;

    public void openServiceForm() {
        waitForClickability(serviceTab).click();
        waitForClickability(addServiceBtn).click();
    }

    public void selectDropdownOption(WebElement dropdown, String optionText) {
        waitForClickability(dropdown).click();
        By optionLocator = By.xpath("//span[contains(text(),'" + optionText + "')]");
        waitForClickability(optionLocator).click();
    }
    

    public void selectDropdownOption2(WebElement dropdown, String optionText) {
        waitForClickability(dropdown).click();
        By optionLocator = By.xpath("(//span[contains(text(),'" + optionText + "')])[2]");
        waitForClickability(optionLocator).click();
    }

    public void fillAddServiceForm(
    	    String name,
    	    String price,
    	    String gst,
    	    String category,
    	    String subCategory,
    	    String outsideLab,
    	    String associatedWith,
    	    String serviceReqNo,
    	    String serviceAccCode,
    	    String department,
    	    boolean isEditable,
    	    boolean isActive,
    	    boolean allowZero,
    	    boolean workOrder
    
    	) {
    	openServiceForm();
    	    waitForVisibility(nameInput).sendKeys(name);
    	    waitForVisibility(priceInput).sendKeys(price);

    	    selectDropdownOption(gstDropdown, gst);
    	    selectDropdownOption2(categoryDropdown, category);
    	    selectDropdownOption(subCategoryDropdown, subCategory);
//    	    selectDropdownOption(outsideLabDropdown, outsideLab);
    	    selectDropdownOption(associatedDropdown, associatedWith);

    	    waitForVisibility(serviceRequestNoInput).sendKeys(serviceReqNo);
    	    waitForVisibility(serviceAccountingCodeInput).sendKeys(serviceAccCode);

    	    selectDropdownOption(departmentDropdown, department);

    	    if (isEditable != isEditableCheckbox.isSelected()) isEditableCheckbox.click();
    	    if (isActive != isActiveCheckbox.isSelected()) isActiveCheckbox.click();
    	    if (allowZero != allowZeroCheckbox.isSelected()) allowZeroCheckbox.click();
    	    if (workOrder != workOrderCheckbox.isSelected()) workOrderCheckbox.click();
    	    saveButton.click();


    	}



    
}
