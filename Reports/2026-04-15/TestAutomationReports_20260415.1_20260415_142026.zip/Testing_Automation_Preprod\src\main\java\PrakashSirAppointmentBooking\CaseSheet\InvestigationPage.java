package PrakashSirAppointmentBooking.CaseSheet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class InvestigationPage extends Abstraction {

    WebDriver driver;

    public InvestigationPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // --- Section Toggle ---
    @FindBy(xpath = "//h4[normalize-space(text())='Investigation']/following::img[contains(@class,'openclose')][1]")
    private WebElement investigationToggleIcon;

    // --- Dropdowns ---
    @FindBy(xpath = "//ngx-select[@formcontrolname='serviceId']")
    private WebElement serviceDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='performDoc']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement performingDoctorDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='performNurse']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement performingNurseDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='discountType']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement discountTypeDropdown;

    // --- Text Fields ---
    @FindBy(xpath = "//textarea[@formcontrolname='testResults']")
    private WebElement testResultsTextarea;

    @FindBy(xpath = "//textarea[@formcontrolname='notes']")
    private WebElement notesTextarea;

    @FindBy(xpath = "//input[@formcontrolname='amount']")
    private WebElement amountInput;

    @FindBy(xpath = "//input[@formcontrolname='discountPercentage']")
    private WebElement discountAmountInput;

    @FindBy(xpath = "//input[@formcontrolname='netAmount']")
    private WebElement netAmountInput;

    // --- Checkboxes ---
    @FindBy(xpath = "//label[contains(.,'Outside Test')]/span[@class='checkmark']")
    private WebElement outsideTestCheckbox;

    @FindBy(xpath = "//label[contains(.,'Provide Discount')]/span[@class='checkmark']")
    private WebElement provideDiscountCheckbox;

    // --- Buttons ---
    @FindBy(xpath = "//button[@nbtooltip='Add']")
    private WebElement addInvestigationBtn;

    @FindBy(xpath = "//button[@nbtooltip='Send Item']")
    private WebElement sendItemBtn;

    @FindBy(xpath = "//button[@nbtooltip='Reset']")
    private WebElement resetInvestigationBtn;

    // --- Success Messages ---
    @FindBy(xpath = "//span[normalize-space(text())='Investigation Saved Successfully']")
    private WebElement successSaveMsg;

    @FindBy(xpath = "//span[normalize-space(text())='Investigation Updated Successfully']")
    private WebElement successUpdateMsg;

    @FindBy(xpath = "//span[normalize-space(text())='Investigation Deleted Successfully']")
    private WebElement successDeleteMsg;

    // --- Actions ---
    public void clickInvestigationToggle() {
    	clickWithJavaScript(investigationToggleIcon);
    }

    public void selectService(String serviceName) {
        serviceDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + serviceName + "']"));
        clickWithJavaScript(option);
    }

    public void enterTestResults(String results) {
        testResultsTextarea.clear();
        testResultsTextarea.sendKeys(results);
    }

    public void selectPerformingDoctor(String doctorName) {
        performingDoctorDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + doctorName + "']"));
        option.click();
    }

    public void selectPerformingNurse(String nurseName) {
        performingNurseDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + nurseName + "']"));
        option.click();
    }

    public void checkOutsideTest() {
        if (!outsideTestCheckbox.isSelected()) {
            outsideTestCheckbox.click();
        }
    }

    public void enterNotes(String notes) {
        notesTextarea.clear();
        notesTextarea.sendKeys(notes);
    }

    public void checkProvideDiscount() {
        if (!provideDiscountCheckbox.isSelected()) {
            provideDiscountCheckbox.click();
        }
    }

    public void enterAmount(String amount) {
        amountInput.clear();
        amountInput.sendKeys(amount);
    }

    public void enterDiscountAmount(String discount) {
        discountAmountInput.clear();
        discountAmountInput.sendKeys(discount);
    }

    public void selectDiscountType(String discountType) {
        discountTypeDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + discountType + "']"));
        option.click();
    }

    public String getNetAmount() {
        return netAmountInput.getAttribute("value");
    }

    public void clickAddInvestigation() {
        addInvestigationBtn.click();
    }
    
    

    public void clickSendItem() {
        sendItemBtn.click();
    }

    public void clickResetInvestigation() {
        resetInvestigationBtn.click();
    }

    // --- Validation ---
    public boolean isSaveSuccessDisplayed() {
        return successSaveMsg.isDisplayed();
    }

    public boolean isUpdateSuccessDisplayed() {
        return successUpdateMsg.isDisplayed();
    }

    public boolean isDeleteSuccessDisplayed() {
        return successDeleteMsg.isDisplayed();
    }
}
