package PrakashSirAppointmentBooking;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class AppointmentBooking extends Abstraction {

    public AppointmentBooking(WebDriver driver) {
       super(driver);
         this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//label[contains(text(), 'Title')]/following-sibling::ngx-select//div[contains(@class, 'ngx-select__toggle')]")
    private WebElement titleDropdown;

    @FindBy(xpath = "//input[@formcontrolname='patName']")
    private WebElement patientNameInput;

    @FindBy(xpath = "//label[contains(text(), 'Gender')]/following-sibling::ngx-select//div[contains(@class, 'ngx-select__toggle')]")
    private WebElement genderDropdown;

    @FindBy(xpath = "//input[@formcontrolname='patientDOB']")
    private WebElement dateOfBirthInput;

    @FindBy(xpath = "//input[@formcontrolname='age']")
    private WebElement ageYearsInput;

    @FindBy(xpath = "//input[@formcontrolname='patientMonth']")
    private WebElement ageMonthsInput;

    @FindBy(xpath = "//input[@formcontrolname='patientDays']")
    private WebElement ageDaysInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='patientMobileCountryCode']//div[contains(@class, 'ngx-select__toggle')]")
    private WebElement mobileCountryCodeDropdown;

    @FindBy(xpath = "//input[@formcontrolname='mobile']")
    private WebElement mobileNumberInput;

    @FindBy(xpath = "//input[@formcontrolname='patientPincode']")
    private WebElement pincodeInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='cityAreaId']//div[contains(@class, 'ngx-select__toggle')]")
    private WebElement areaDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='district']//div[contains(@class, 'ngx-select__toggle')]")
    private WebElement districtDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='state']//div[contains(@class, 'ngx-select__toggle')]")
    private WebElement stateDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='country']//div[contains(@class, 'ngx-select__toggle')]")
    private WebElement countryDropdown;

    @FindBy(xpath = "//input[@formcontrolname='patientAddressLine1']")
    private WebElement address1Input;

    @FindBy(xpath = "//input[@formcontrolname='patientAddressLine2']")
    private WebElement address2Input;

    @FindBy(xpath = "//ngx-select[@formcontrolname='patientCity']//div[contains(@class, 'ngx-select__toggle')]")
    private WebElement cityDropdown;

    @FindBy(xpath = "//input[@formcontrolname='aaadhar']")
    private WebElement aadharInput;
 
  
    
    @FindBy(xpath = "//span[text()='Frontdesk Dashboard']")
    private WebElement frontendDesk;
    
    @FindBy(xpath = "//span[text()='Appointment']")
    private WebElement appointment;
    
    @FindBy(xpath = "//input[@placeholder='Search: Doctor Name/Department']")
    private WebElement doctorSeARCH;
    
    @FindBy(css = "li.additional-time")
    private WebElement additionalTimeButton;
  
    @FindBy(css = "ul.appointment-slots li.legend")
    private List<WebElement> availableSlots;

    @FindBy(xpath = "//input[@type='button' and @value='Confirm Slot']")
    private WebElement confirmSlotButton;

    @FindBy(xpath = "//input[@formcontrolname='autoCheckIN']")
    private WebElement checkInCheckbox;
    
    @FindBy(xpath = "//input[@formcontrolname='temp']")
    private WebElement temperatureInput;

    @FindBy(xpath = "//input[@formcontrolname='weight']")
    private WebElement weightInput;

    @FindBy(xpath = "//input[@formcontrolname='height']")
    private WebElement heightInput;

    @FindBy(xpath = "//input[@formcontrolname='bmi']")
    private WebElement bmiInput;

    @FindBy(xpath = "//input[@formcontrolname='randomsugar']")
    private WebElement bsRandomInput;

    @FindBy(xpath = "//input[@formcontrolname='fsugar']")
    private WebElement bsFastingInput;

    @FindBy(xpath = "//input[@formcontrolname='ppsugar']")
    private WebElement bsPPInput;

    @FindBy(xpath = "//input[@formcontrolname='bPSys']")
    private WebElement bpSysInput;

    @FindBy(xpath = "//input[@formcontrolname='bPDia']")
    private WebElement bpDiaInput;

    @FindBy(xpath = "//input[@formcontrolname='pulse']")
    private WebElement pulseInput;

    @FindBy(xpath = "//input[@formcontrolname='spo']")
    private WebElement spo2Input;

    @FindBy(xpath = "//input[@formcontrolname='respRate']")
    private WebElement respRateInput;

    @FindBy(xpath = "//input[@formcontrolname='heartRate']")
    private WebElement heartRateInput;

    @FindBy(xpath = "(//div[contains(@class,'ngx-select__toggle')])[17]")
    private WebElement chiefComplaintsDropdown;

    @FindBy(xpath = "//input[@formcontrolname='duration']")
    private WebElement noOfDaysInput;

    @FindBy(xpath = "//input[@formcontrolname='autoCheckIN']")
    private WebElement checkInCheckbox2;

    @FindBy(xpath = "//input[@formcontrolname='autoCheckOut']")
    private WebElement checkOutCheckbox;

    @FindBy(xpath = "//input[@type='button' and @value='+' and contains(@class, 'btn-search')]")
    private WebElement addButton;

    @FindBy(xpath = "//input[@value='Book Appointment']")
    WebElement bookAppointmentButton;
    
    @FindBy(xpath = "//input[@value='Yes']")
    WebElement yesButton;

 
    		
    	    @FindBy(xpath = "(//input[@value='Cancel'])[2]")
    	    WebElement cancel;
    	    
    public void clickAddButton() {
        waitForClickability(addButton).click();
    }
 
    public void opentheappointmentpage() {
    
    	waitForClickability(appointment).click();
     	waitForClickability(frontendDesk).click();
   
        
    }
    public void clickDoctorByName(String doctorName) {
    	   waitForUrl(("https://ezopreprodstrgfrontend.z29.web.core.windows.net/pages/patientservices/Frontdesk-Dashboard"));
//    	 waitForUrl(("https://apps.ezovion.com/pages/patientservices/Frontdesk-Dashboard"));
    
    		waitForClickability(doctorSeARCH).click();
        String xpath = "//nb-option//h4[contains(normalize-space(),'" + doctorName + "')]";
        WebElement doctorElement = driver.findElement(By.xpath(xpath));
        waitForClickability(doctorElement).click();
    }

    public void selectTitle(String title) {
        titleDropdown.click();
        driver.findElement(By.xpath("//span[text()='" + title + "']")).click();
    }

    public void enterPatientName(String name) {
        patientNameInput.clear();
        patientNameInput.sendKeys(name);
    }
    
    

    public void selectGender(String gender) {
        genderDropdown.click();
        driver.findElement(By.xpath("//span[text()='" + gender + "']")).click();
    }

    public void enterDateOfBirth(String dob) {
        dateOfBirthInput.clear();
        dateOfBirthInput.sendKeys(dob);
    }

    public void enterAge(String years, String months, String days) {
        ageYearsInput.clear();
        ageYearsInput.sendKeys(years);
        ageMonthsInput.clear();
        ageMonthsInput.sendKeys(months);
        ageDaysInput.clear();
        ageDaysInput.sendKeys(days);
    }

    public void selectMobileCountryCode(String code) {
        mobileCountryCodeDropdown.click();
        driver.findElement(By.xpath("//span[text()='" + code + "']")).click();
    }
public String lastEnteredMobileNumber;
    public void enterMobileNumber(String mobile) {
        if (mobile == null || mobile.isEmpty()) {
            mobile = generateRandomIndianMobileNumber();
        }
        lastEnteredMobileNumber=mobile;
        mobileNumberInput.clear();
        mobileNumberInput.sendKeys(mobile);
    }

    private String generateRandomIndianMobileNumber() {
        Random random = new Random();
        // Indian mobile numbers typically start with 6, 7, 8, or 9
        int firstDigit = 6 + random.nextInt(4); // gives 6 to 9
        long remainingDigits = (long)(random.nextDouble() * 1_000_000_000L);
        return firstDigit + String.format("%09d", remainingDigits);
    }
    public void enterPincode(String pincode) {
        pincodeInput.clear();
        pincodeInput.sendKeys(pincode);
    }

    public void selectArea(String area) {
        areaDropdown.click();
        driver.findElement(By.xpath("//span[text()='" + area + "']")).click();
    }



    public void enterAddress1(String address) {
        address1Input.clear();
        address1Input.sendKeys(address);
    }

    public void enterAddress2(String address) {
        address2Input.clear();
        address2Input.sendKeys(address);
    }

    public void selectCity(String city) {
        cityDropdown.click();
        driver.findElement(By.xpath("//span[text()='" + city + "']")).click();
    }

    public void enterAadhar(String aadhar) {
        aadharInput.clear();
        aadharInput.sendKeys(aadhar);
    }

   

    public void selectAnySlotAndConfirm() {
        waitForClickability(additionalTimeButton).click();
        if (availableSlots.isEmpty()) {
            System.out.println("❌ No available slots found.");
            return;
        }

        WebElement firstSlot = availableSlots.get(0);
        waitForClickability(firstSlot).click();
        System.out.println("✅ Selected Slot: " + firstSlot.getText().trim());

        waitForClickability(confirmSlotButton).click();
        System.out.println("✅ Clicked Confirm Slot.");
    }

    public void selectCheckIn() {
        if (!checkInCheckbox.isSelected()) {
            waitForClickability(checkInCheckbox).click();
            System.out.println("✅ Check-in checkbox selected.");
        } else {
            System.out.println("ℹ️ Check-in checkbox was already selected.");
        }
    }
    public void enterTemperature(String temp) {
        temperatureInput.clear();
        temperatureInput.sendKeys(temp);
    }

    public void enterWeight(String weight) {
        weightInput.clear();
        weightInput.sendKeys(weight);
    }

    public void enterHeight(String height) {
        heightInput.clear();
        heightInput.sendKeys(height);
    }

    public String getBMI() {
        return bmiInput.getAttribute("value");
    }

    public void enterBSRandom(String value) {
        bsRandomInput.clear();
        bsRandomInput.sendKeys(value);
    }

    public void enterBSFasting(String value) {
        bsFastingInput.clear();
        bsFastingInput.sendKeys(value);
    }

    public void enterBSPP(String value) {
        bsPPInput.clear();
        bsPPInput.sendKeys(value);
    }

    public void enterBPSys(String value) {
        bpSysInput.clear();
        bpSysInput.sendKeys(value);
    }

    public void enterBPDia(String value) {
        bpDiaInput.clear();
        bpDiaInput.sendKeys(value);
    }

    public void enterPulse(String value) {
        pulseInput.clear();
        pulseInput.sendKeys(value);
    }

    public void enterSpO2(String value) {
        spo2Input.clear();
        spo2Input.sendKeys(value);
    }

    public void enterRespRate(String value) {
        respRateInput.clear();
        respRateInput.sendKeys(value);
    }

    public void enterHeartRate(String value) {
        heartRateInput.clear();
        heartRateInput.sendKeys(value);
    }
    
    public void selectChiefComplaint(String complaintName) {
        chiefComplaintsDropdown.click();
        WebElement option = driver.findElement(By.xpath("//span[normalize-space()='" + complaintName + "']"));
        waitForClickability(option).click();
    }

    public void enterNoOfDays(String days) {
        noOfDaysInput.clear();
        noOfDaysInput.sendKeys(days);
        clickAddButton();

    }

    public void selectCheckIn2() {
        if (!checkInCheckbox.isSelected()) {
            waitForClickability(checkInCheckbox2).click();
        }
    }

    public void selectCheckOut() {
        if (!checkOutCheckbox.isSelected()) {
            waitForClickability(checkOutCheckbox).click();
        }
    }
    public void save() {
        waitForClickability(bookAppointmentButton).click();
//        waitForClickability(yesButton).click();
    }
    public void cancelButton() {
    	waitForClickability(cancel).click();
    }
    
    public void selectdepartment(String doctorName) {
        // Open dropdown
        driver.findElement(By.xpath("//label[contains(text(),'Department')]/following::div[contains(@class,'ngx-select__toggle')][1]"))
              .click();

        // Click doctor by text
        String xpath = "//ul[contains(@class,'ngx-select__choices')]//span[text()='" + doctorName + "']";
        driver.findElement(By.xpath(xpath)).click();
    }
    
    @FindBy(xpath = "//label[contains(text(),'Doctor')]/following::ngx-select[1]//input")
    private WebElement doctorSearchInput;
    public void selectDoctor(String doctorName) {

        // Click the Doctor dropdown
        WebElement dropdown = driver.findElement(By.xpath(
            "//label[contains(text(),'Doctor')]/following::div[contains(@class,'ngx-select__toggle')][1]"
        ));
        dropdown.click();

        // Type in the search box
        doctorSearchInput.sendKeys(doctorName);

        // Correct XPath (handles <strong> inside span)
        String xpath = "//ul[contains(@class,'ngx-select__choices')]//a[contains(@class,'ngx-select__item')]//*[normalize-space()='" 
                        + doctorName + "']";

        // Click the doctor option
        WebElement doctor = driver.findElement(By.xpath(xpath));
        doctor.click();
    }
    
    @FindBy(xpath = "//input[@formcontrolname='startDate']")
    private WebElement startDateInput;
    
    @FindBy(xpath = "//label[contains(text(),'Start Date')]/following::i[@class='fas fa-sync-alt'][1]")
    private WebElement startDateSyncIcon;
    
    @FindBy(xpath = "//input[@formcontrolname='startDate']/following-sibling::span//img[@alt='image']")
    private WebElement startDateCalendarIcon;
    
    // -------------------- End Date ---------------------------
    @FindBy(xpath = "//input[@formcontrolname='endDate']")
    private WebElement endDateInput;
    
    @FindBy(xpath = "//input[@formcontrolname='endDate']/following-sibling::span//img[@alt='image']")
    private WebElement endDateCalendarIcon;
    
    public void setStartDate(String dateTime) {
        startDateInput.clear();
        startDateInput.sendKeys(dateTime);
    }
    
    public void setEndDate(String date) {
        endDateInput.clear();
        endDateInput.sendKeys(date);
    }

}


