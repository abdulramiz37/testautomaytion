package StandAloneTest;

import java.awt.Desktop.Action;
import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
@Test
public class PurchaseOrderPolishCode {
	public void PPLE() throws InterruptedException {

	WebDriver driver = new EdgeDriver();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	driver.get("https://apps.ezovion.com/auth/login");
	//driver.manage().deleteAllCookies();
	driver.manage().window().maximize();
	

	driver.findElement(By.xpath("//div[@class=\"form-control-group\"]//input")).sendKeys("50107299");
	driver.findElement(By.xpath("//button[@size=\"large\"]")).click();
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
        // Wait until the button with text "CONTINUE" is clickable
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
	
     driver.findElement(By.xpath("//input[@placeholder=\"Mobile No\"]")).sendKeys("7766554433");
	driver.findElement(By.xpath("//input[@placeholder=\"Password\"]")).sendKeys("12345");
	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@status=\"primary\"]")));
	 driver.findElement(By.xpath("//button[@status=\"primary\"]")).click();
	 for (int i = 0; i < 5; i++) { // Try up to 5 times
		    try {
		        WebElement adminTab = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Admin']")));
		        adminTab.click();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Roles Management']"))).click();
		        break; // Exit loop if successful
		    } catch (Exception e) {
		        System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
		        if (i == 4) {
		            throw e; // Re-throw if max attempts reached
		        }
		    }
		}

	// 1. Click on "Pharmacy"
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Pharmacy']"))).click();

				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Purchase'])[1]"))).click();

				// 2. Click on "Purchase Order"
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Purchase Order'])[1]"))).click();

				// 3. Click on "Add Purchase Order"
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[text()=' Add Purchase Order '])[1]"))).click();

				// 4. Click on "Select" (first dropdown)
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();

				// 5. Click on "supplier name"
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Supplier Name 9'])[1]"))).click();

				// 6. Click on "Select" (again if needed)
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();

				// 7. Click on "Fddf" option
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Fddf'])[1]"))).click();
				
				// 1. Wait until the element is visible
				WebElement plannedDelDateInput = wait.until(ExpectedConditions.visibilityOfElementLocated(
				    By.xpath("//input[@formcontrolname='plannedDelDate']")));

				// 2. Set MM/DD/YYYY value using JavaScriptExecutor
				((JavascriptExecutor) driver).executeScript(
				    "arguments[0].value='07/12/2025'; arguments[0].dispatchEvent(new Event('input'));", 
				    plannedDelDateInput
				);
				
				
				// 1. Click on the second "Search Medicine" button
				wait.until(ExpectedConditions.elementToBeClickable(
				    By.xpath("(//span[text()='Search Medicine'])[1]"))).click();

				// 2. Wait for the medicine with name "medicine1syrup" to appear (e.g., in a modal or list)
				wait.until(ExpectedConditions.visibilityOfElementLocated(
				    By.xpath("//h4[text()='medicine1syrup']"))).click();

					// 11. Click on "Add" button
					wait.until(ExpectedConditions.elementToBeClickable(
					    By.xpath("//input[@value='Add']"))).click();

					// 12. Click on "Save" button
					wait.until(ExpectedConditions.elementToBeClickable(
					    By.xpath("//input[@value='Save']"))).click();

					String targetSupplierName = "Supplier Name 9";
					String targetStatus = "New";

					// Get all rows of the table body
					boolean isFound = false;
				String poNumber="";
					while (!isFound) {
					    List<WebElement> rows = driver.findElements(By.xpath("//table[@class='table table-hover table-style']/tbody/tr"));

					    for (int i = 0; i < rows.size(); i++) {
					        try {
					            // Refetch the row to avoid StaleElementReferenceException
					            WebElement row = driver.findElements(By.xpath("//table[@class='table table-hover table-style']/tbody/tr")).get(i);

					 
					            String supplierName = row.findElement(By.xpath("./td[4]")).getText().trim();
					            String status = row.findElement(By.xpath("./td[9]/span")).getText().trim();
					            if (supplierName.equalsIgnoreCase(targetSupplierName) && status.equalsIgnoreCase(targetStatus)) {
					                WebElement editIcon = row.findElement(By.xpath("./td[10]//img[contains(@src,'edit.png')]"));
					                wait.until(ExpectedConditions.elementToBeClickable(editIcon)).click();

					                System.out.println("✅ Clicked Edit for Supplier: " + supplierName + ", Status: " + status);
					                isFound = true;
					                break;
					            }
					        } catch ( NoSuchElementException e) {
					            System.out.println("⚠️ Skipping stale or missing row at index " + i);
					        }
					    }

					    if (!isFound) {
					        try {
					            WebElement nextButton = driver.findElement(By.xpath("(//i[@class='fas fa-chevron-right'])[1]"));
					            String classAttr = nextButton.getAttribute("class");

					            if (classAttr.contains("disabled")) {
					                System.out.println("❌ Reached last page. Entry not found.");
					                break;
					            }

					            // Click next page using JS
					            JavascriptExecutor js = (JavascriptExecutor) driver;
					            js.executeScript("arguments[0].click();", nextButton);

					        } catch (NoSuchElementException e) {
					            System.out.println("❌ Next page button not found. Ending search.");
					            break;
					        }
					    }
					}

							// ✅ Click the "Sent to Approve" button
							wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Sent to Approve']"))).click();

							// ✅ Click the close icon of lightbox
							wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='lightbox-close']"))).click();
							
							JavascriptExecutor js = (JavascriptExecutor) driver;
							WebElement tab = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//li[@class='tab ng-star-inserted'])[1]")));

							Actions actions = new Actions(driver);
							actions.moveToElement(tab).click().perform();

							String targetSupplier = "Supplier Name 9";
							String targetStatus2 = "Waiting";

							boolean isFound2 = false;
							
							while (!isFound2) {
								List<WebElement> rows2 = driver.findElements(By.xpath("(//table[@class='table table-hover table-style']/tbody)[2]/tr"));

								for (int i = 0; i < 10; i++) {
								    try {
								        WebElement row2 = rows2.get(i);
								           poNumber= row2.findElement(By.xpath("./td[3]")).getText().trim();
								        String supplierName = row2.findElement(By.xpath("./td[4]")).getText().trim();
								        String status = row2.findElement(By.xpath("./td[9]/span")).getText().trim();

								        if (supplierName.equalsIgnoreCase(targetSupplierName) && status.equalsIgnoreCase(targetStatus2)) {
								            WebElement editIcon = row2.findElement(By.xpath("./td[10]//img[contains(@src,'edit.png')]"));
								            wait.until(ExpectedConditions.elementToBeClickable(editIcon)).click();

								            System.out.println("✅ Clicked Edit for Supplier: " + supplierName + ", Status: " + status);
								            isFound2 = true;
								            break;
								        }
								    } catch (NoSuchElementException e) {
								        System.out.println("⚠️ Skipping stale or missing row at index " + i);
								    }
								}

								if (!isFound2) {
								    try {
								        WebElement nextButton2 = driver.findElement(By.xpath("(//a[@tabindex=\"0\"])[2]"));

								        // Click next page using JS
								        JavascriptExecutor js2 = (JavascriptExecutor) driver;
								        js2.executeScript("arguments[0].click();", nextButton2);

								    } catch (NoSuchElementException e) {
								        System.out.println("❌ Next page button not found. Ending search.");
								    } 
								}
							}
							 String expectedUrl = "https://apps.ezovion.com/pages/pharmacy/po";
				             wait.until(ExpectedConditions.urlToBe(expectedUrl));
						wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@value='Update'])[1]"))).click();	
						
				
						
						
						wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='PO Tracking List'])[1]"))).click();
						String expectedUrl2 = "https://apps.ezovion.com/pages/pharmacy/po-tracking-report";
						String targetPONumber = poNumber;

						boolean success = false;

						for (int attempt = 1; attempt <= 5; attempt++) {
						    try {
						        // Wait for URL
						        wait.until(ExpectedConditions.urlToBe(expectedUrl2));
						        Assert.assertTrue(driver.getCurrentUrl().equals(expectedUrl2), "Current URL should be PO Tracking Report page");

						        // Wait for table rows
						        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
						            By.xpath("//table[contains(@class,'table-hover')]/tbody/tr")));

						        success = true; // If both waits are successful, break out of loop
						        break;

						    } catch (Exception e) {
						        System.out.println("Attempt " + attempt + " failed: " + e.getMessage());

						        if (attempt == 5) {
						            throw e; // After final attempt, rethrow exception to fail the test
						        }

						        // Optional: wait a bit before retrying (e.g., 1 second)
						        
						    }
						}
						
						 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class=\"mat-select-arrow ng-tns-c363-148\"]"))).click();
						 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//mat-option[@role=\"option\"])[2]"))).click();
						 List<WebElement> rows = driver.findElements(By.xpath("//table[contains(@class,'table-hover')]/tbody/tr"));

						 boolean found = false;

						 for (WebElement row : rows) {
						     try {
						         String poNumber2 = row.findElement(By.xpath("./td[3]")).getText().trim();
					System.out.println(poNumber2);
						         if (poNumber2.equals(targetPONumber)) {
						             WebElement purchaseIcon = row.findElement(By.xpath(".//img[contains(@src,'phar.png')]"));

						             js.executeScript("arguments[0].scrollIntoView({block: 'center'});", purchaseIcon);
						             js.executeScript("arguments[0].click();", purchaseIcon);

						             System.out.println("✅ Clicked Purchase icon for PO No.: " + poNumber);
						             found = true;
						             break;
						         }

						     } catch (NoSuchElementException e) {
						         System.out.println("⚠️ Skipping row due to structure issue.");
						     }
						 }

						 if (!found) {
						     System.out.println("❌ PO No. " + targetPONumber + " not found.");
						 }

					      wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();
					     wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Pharamacy Loaction'])[1]"))).click();

						 int invoiceNo = 1;

					     while (true) {
					         driver.findElement(By.xpath("//input[@formcontrolname='invNo']")).clear();
					         driver.findElement(By.xpath("//input[@formcontrolname='invNo']")).sendKeys(String.valueOf(invoiceNo));

					         if (driver.findElements(By.xpath("//*[contains(text(), 'Invoice No Already Exists')]")).isEmpty()) {
					             System.out.println("✅ Unique Invoice No: " + invoiceNo);
					             break;
					         }

					         invoiceNo++;
					     }

					     WebElement invDate = wait.until(ExpectedConditions.visibilityOfElementLocated(
					             By.xpath("//input[@formcontrolname='invDate']")));
					     ((JavascriptExecutor) driver).executeScript(
					             "arguments[0].value='06/12/2025'; arguments[0].dispatchEvent(new Event('input'));", invDate);

					     WebElement invDueDate = wait.until(ExpectedConditions.visibilityOfElementLocated(
					             By.xpath("//input[@formcontrolname='invDueDate']")));
					     ((JavascriptExecutor) driver).executeScript(
					             "arguments[0].value='06/12/2025'; arguments[0].dispatchEvent(new Event('input'));", invDueDate);

					     wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Search'])[1]"))).click();
					     WebElement syrupItem = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='mat-option-text']/span[contains(text(), 'medicine')]")));
					    
					     js.executeScript("arguments[0].click();", syrupItem);

					     WebElement batchNumberField = wait.until(ExpectedConditions.visibilityOfElementLocated(
					             By.xpath("//input[@formcontrolname='BatchNumber']")));
					     batchNumberField.sendKeys("4");

					     WebElement expiryDateInput = wait.until(ExpectedConditions.visibilityOfElementLocated(
					             By.xpath("//input[@formcontrolname='expiryDate']")));
					     ((JavascriptExecutor) driver).executeScript(
					             "const input = arguments[0];" +
					                     "const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;" +
					                     "nativeInputValueSetter.call(input, '2027-07');" +
					                     "input.dispatchEvent(new Event('input', { bubbles: true }));" +
					                     "input.dispatchEvent(new Event('change', { bubbles: true }));",
					             expiryDateInput);

					      String payableAmtElement =  driver.findElement(By.xpath("//label[text()='Payable Amt']/following-sibling::p")).getText().trim();
					      wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@formcontrolname='invValue'])[1]"))).sendKeys(payableAmtElement);
					      wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Add']"))).click();
					      wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();
					      wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value=\"Yes\"]"))).click();
					      wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value=\"Approve\"]"))).click();

	}
}