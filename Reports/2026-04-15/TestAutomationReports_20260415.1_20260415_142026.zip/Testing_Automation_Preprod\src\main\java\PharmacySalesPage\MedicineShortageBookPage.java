package PharmacySalesPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

import org.openqa.selenium.By;

public class MedicineShortageBookPage extends Abstraction{

    WebDriver driver;

    public MedicineShortageBookPage(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    /* =========================
       DROPDOWN TOGGLES
       ========================= */

    @FindBy(xpath = "//label[contains(text(),'Requested By')]/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement requestedByDropdown;

    @FindBy(xpath = "//label[contains(text(),'Medicine Name')]/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement medicineDropdown;

    @FindBy(xpath = "//label[contains(text(),'Priority')]/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement priorityDropdown;

    @FindBy(xpath = "//label[contains(text(),'Status')]/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement statusDropdown;

    /* =========================
       COMMON UL (OPTIONS)
       ========================= */

    @FindBy(xpath = "//ul[contains(@class,'ngx-select__choices')]")
    private WebElement commonDropdownUL;

    /* =========================
       OTHER FIELDS
       ========================= */

    @FindBy(xpath = "//input[@formcontrolname='requestedByDate']")
    private WebElement requestedDateInput;

    @FindBy(xpath = "//input[@formcontrolname='others']")
    private WebElement othersInput;

    @FindBy(xpath = "//input[@formcontrolname='emergencyQty']")
    private WebElement emergencyQtyInput;

    @FindBy(xpath = "//textarea[@formcontrolname='remarks']")
    private WebElement remarksTextarea;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;

    /* =========================
       COMMON DROPDOWN METHOD
       ========================= */

    private void selectFromDropdown(WebElement dropdown, String optionText) {
        dropdown.click();
        commonDropdownUL
                .findElement(By.xpath(".//li//span[normalize-space()='" + optionText + "']"))
                .click();
    }

    /* =========================
       BUSINESS METHODS
       ========================= */

    public void selectRequestedBy(String name) {
        selectFromDropdown(requestedByDropdown, name);
    }

    public void selectMedicine(String medicine) {
        selectFromDropdown(medicineDropdown, medicine);
    }

    public void selectPriority(String priority) {
        selectFromDropdown(priorityDropdown, priority);
    }

    public void selectStatus(String status) {
        selectFromDropdown(statusDropdown, status);
    }

    public void enterRequestedDate() {
        requestedDateInput.clear();
        requestedDateInput.sendKeys(todayDate);
    }

    public void enterOthers(String value) {
        othersInput.clear();
        othersInput.sendKeys(value);
    }

    public void enterEmergencyQty(String qty) {
        emergencyQtyInput.clear();
        emergencyQtyInput.sendKeys(qty);
    }

    public void enterRemarks(String remarks) {
        remarksTextarea.clear();
        remarksTextarea.sendKeys(remarks);
    }

    public void clickSave() {
        saveButton.click();
    }
}
