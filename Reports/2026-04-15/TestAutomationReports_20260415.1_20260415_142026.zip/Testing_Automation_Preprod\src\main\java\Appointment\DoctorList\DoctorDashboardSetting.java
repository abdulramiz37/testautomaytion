package Appointment.DoctorList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class DoctorDashboardSetting extends Abstraction{

    WebDriver driver;

    public DoctorDashboardSetting(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // --- Locators ---

    // In-Patient Visit Times
    @FindBy(xpath = "//input[@formcontrolname='morningVisTime']")
    private WebElement morningVisitTime;

    @FindBy(xpath = "//input[@formcontrolname='noonVisTime']")
    private WebElement afternoonVisitTime;

    @FindBy(xpath = "//input[@formcontrolname='eveningVisTime']")
    private WebElement eveningVisitTime;

    @FindBy(xpath = "//input[@formcontrolname='nightVisTime']")
    private WebElement nightVisitTime;

    // OT Alerts
    @FindBy(xpath = "//input[@formcontrolname='futureAlert']")
    private WebElement futureAlert;

    @FindBy(xpath = "//input[@formcontrolname='pastAlert']")
    private WebElement pastAlert;

    // Checkboxes
    @FindBy(xpath = "//input[@formcontrolname='futureTask']")
    private WebElement showFutureTasksCheckbox;

    @FindBy(xpath = "//input[@formcontrolname='vcTask']")
    private WebElement showVideoCallTasksCheckbox;

    // Dropdown (ngx-select)
    @FindBy(xpath = "//ngx-select[@formcontrolname='moduleStatus']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement defaultTabDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='moduleStatus']//a//span[contains(text(),'OP')]")
    private WebElement defaultTabOP;

    @FindBy(xpath = "//ngx-select[@formcontrolname='moduleStatus']//a//span[contains(text(),'IP')]")
    private WebElement defaultTabIP;

    @FindBy(xpath = "//ngx-select[@formcontrolname='moduleStatus']//a//span[contains(text(),'OT')]")
    private WebElement defaultTabOT;

    // Notification
    @FindBy(xpath = "//label[text()='Notifications Shown section']/following-sibling::input")
    private WebElement notificationsSection;

    @FindBy(xpath = "//input[@formcontrolname='labReport']")
    private WebElement labReportCheckbox;

    @FindBy(xpath = "//input[@formcontrolname='radiologyReport']")
    private WebElement radiologyReportCheckbox;

    // Buttons
    @FindBy(xpath = "//button[@type='submit' and contains(text(),'Save')]")
    private WebElement saveButton;

    @FindBy(xpath = "//button[@type='reset' and contains(text(),'Reset')]")
    private WebElement resetButton;

    @FindBy(xpath = "//button[contains(text(),'Cancel')]")
    private WebElement cancelButton;

    
    @FindBy(xpath = "//span[text()='Doctor Dashboard Setting']")
    private WebElement Dashboard;

    // --- Methods ---

    public void clickButtonApproval() {
    	WebElement container = driver.findElement(By.cssSelector(".scrollable-container"));
    	WebElement targetElement = driver.findElement(By.xpath("//span[text()='Doctor Dashboard Setting']"));

    	JavascriptExecutor js = (JavascriptExecutor) driver;

    	// Scroll the container to bring the target element into view
    	js.executeScript("arguments[0].scrollTop = arguments[1].offsetTop;", container, targetElement);


    	Dashboard.click();

        // Then click

    }
    public void enterMorningVisitTime(String time) {
    	clickButtonApproval();
        morningVisitTime.clear();
        morningVisitTime.sendKeys(time);
    }

    public void enterAfternoonVisitTime(String time) {
        afternoonVisitTime.clear();
        afternoonVisitTime.sendKeys(time);
    }

    public void enterEveningVisitTime(String time) {
        eveningVisitTime.clear();
        eveningVisitTime.sendKeys(time);
    }

    public void enterNightVisitTime(String time) {
        nightVisitTime.clear();
        nightVisitTime.sendKeys(time);
    }

    public void enterFutureAlert(String alertHours) {
        futureAlert.clear();
        futureAlert.sendKeys(alertHours);
    }

    public void enterPastAlert(String alertHours) {
        pastAlert.clear();
        pastAlert.sendKeys(alertHours);
    }

    public void setShowFutureTasks(boolean enable) {
        if (showFutureTasksCheckbox.isSelected() != enable) {
            showFutureTasksCheckbox.click();
        }
    }

    public void setShowVideoCallTasks(boolean enable) {
        if (showVideoCallTasksCheckbox.isSelected() != enable) {
            showVideoCallTasksCheckbox.click();
        }
    }

    public void selectDefaultTab(String tabName) {
        defaultTabDropdown.click();
        switch (tabName.toUpperCase()) {
            case "OP":
                defaultTabOP.click();
                break;
            case "IP":
                defaultTabIP.click();
                break;
            case "OT":
                defaultTabOT.click();
                break;
        }
    }

    public void enterNotificationSection(String text) {
        notificationsSection.clear();
        notificationsSection.sendKeys(text);
    }

    public void setLabReportAlert(boolean enable) {
        if (labReportCheckbox.isSelected() != enable) {
            labReportCheckbox.click();
        }
    }

    public void setRadiologyReportAlert(boolean enable) {
        if (radiologyReportCheckbox.isSelected() != enable) {
            radiologyReportCheckbox.click();
        }
    }

    public void clickSave() {
        saveButton.click();
    }

    public void clickReset() {
        resetButton.click();
    }

    public void clickCancel() {
        cancelButton.click();
    }
}
