package TestComponents;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EzionpageObjects.UserIdPage;
import PharmacyIndentFlow.IndentApprovalTablePage;
import PharmacyIndentFlow.IndentRequestPage;
import PharmacyIndentFlow.IndentRequestTablePage;
import abdulTest.BaseTest;

public class IndentFlow2 extends BaseTest {

    UserIdPage data;
    IndentRequestPage indentRequestPage;
    IndentRequestTablePage indentRequestTablePage;
    IndentApprovalTablePage indentApprovalTablePage;
    HashMap<String, String> currentInput;
    String indentNumber;

    // ✅ Step 1: Login and Navigate to Indent Page
    @Test(dataProvider = "getData")
    public void IndentFlow2_ShouldLoginAndNavigateToIndentPage(HashMap<String, String> input) throws InterruptedException {
        this.currentInput = input;

//        data = login.login(input.get("userId"));
//        data.enterMobileNumber(input.get("personId"));
//        data.enterPassword(input.get("password"));
//        data.clickContinue();
        String userId = prop.getProperty("USER_ID");
        String personId = prop.getProperty("PERSON_ID");
        String password = prop.getProperty("PASSWORD");
        String browser = System.getProperty("BROWSER");
        data = login.login(userId);
        data.enterMobileNumber(personId);
        data.enterPassword(password);
        data.clickContinue();
        data.navigateSalesWithRetrystart();
        System.out.println("Browser: " + browser);
//        System.out.println("Base URL: " + baseUrl);
        System.out.println("User ID: " + userId);
        System.out.println("Person ID: " + personId);
        indentRequestPage = data.indentPage();
        indentRequestPage.openIndentRequestPage();
    }

    // ✅ Step 2: Create Indent Request
    @Test(dependsOnMethods = "IndentFlow2_ShouldLoginAndNavigateToIndentPage")
    public void IndentFlow2_ShouldCreateIndentRequestForLocation() throws InterruptedException {
        indentRequestPage.completeIndentRequestFlow(
            currentInput.get("location"),
            currentInput.get("RequestedBy"),
            currentInput.get("department"),
            currentInput.get("medicineCardTitle"),
            currentInput.get("quantity")
        );
        indentRequestTablePage = indentRequestPage.save2();
    }

    // ✅ Step 3: Edit Indent and Send Request
    @Test(dependsOnMethods = "IndentFlow2_ShouldCreateIndentRequestForLocation")
    public void IndentFlow2_ShouldEditIndentAndSendRequest() {
        indentNumber = indentRequestTablePage.findAndEditIndentWithStatus("New");

        if (indentNumber != null) {
            System.out.println("✅ Edited Indent No: " + indentNumber);
            indentRequestTablePage.clickSendRequest();
        } else {
            throw new RuntimeException("❌ No indent with status 'NEW' found.");
        }
    }

    // ✅ Step 4: Approve Indent Request
    @Test(dependsOnMethods = "IndentFlow2_ShouldEditIndentAndSendRequest")
    public void IndentFlow2_ShouldApproveIndentRequest() {
        indentApprovalTablePage = indentRequestTablePage.indentApproval();
        boolean approved = indentApprovalTablePage.findAndEditIndentForApproval(indentNumber);

        if (approved) {
            indentApprovalTablePage.clickUpdateButton();
            System.out.println("✅ Indent approved successfully.");
        } else {
            throw new RuntimeException("❌ Indent not found for approval.");
        }
    }

    // ✅ Data Provider
    @DataProvider
    public Object[][] getData() throws IOException {
        List<HashMap<String, String>> data = getJsonDataToMap(
            System.getProperty("user.dir") + "//src//main//java//ezion//Resources//IndentFlow.json"
        );
        return new Object[][] { { data.get(0) } };
    }
}
