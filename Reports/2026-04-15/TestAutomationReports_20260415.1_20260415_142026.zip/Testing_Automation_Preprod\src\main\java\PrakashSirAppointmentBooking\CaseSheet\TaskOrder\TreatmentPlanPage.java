package PrakashSirAppointmentBooking.CaseSheet.TaskOrder;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import EzionAbstractionComponents.Abstraction;

public class TreatmentPlanPage extends Abstraction {

    WebDriver driver;

    public TreatmentPlanPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // --- Locators ---
    @FindBy(xpath = "//ngx-select[@formcontrolname='treatmentPlanId']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement treatmentPlanDropdown;

    @FindBy(xpath = "//input[@formcontrolname='nextVisitDate']")
    private WebElement nextVisitDateInput;

    @FindBy(xpath = "//input[@formcontrolname='startDate']")
    private WebElement actualStartDateInput;

    @FindBy(xpath = "//input[@formcontrolname='endDate']")
    private WebElement actualEndDateInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='doctorID']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement physicianDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='treatmentStatus']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement treatmentStatusDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='followUp']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement followUpDropdown;

    @FindBy(xpath = "//textarea[@formcontrolname='treatmentPlanNotes']")
    private WebElement notesTextArea;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//input[@value='Reset']")
    private WebElement resetButton;

    @FindBy(xpath = "//span[normalize-space(text())='Treatment Plan']")
    private WebElement treatmentPlanTab;

    @FindBy(xpath = "//a[normalize-space(text())='Add Treatment Plan']")
    private WebElement addTreatmentPlanButton;


    // --- Methods with Wait ---
    public void clickTreatmentPlanTab() {
    	clickWithJavaScript(treatmentPlanTab);
    }

    public void clickAddTreatmentPlan() {
    	clickWithJavaScript(addTreatmentPlanButton);
    }

    public void selectTreatmentPlan(String planName) {
        waitForClickability(treatmentPlanDropdown).click();
        WebElement option = driver.findElement(
            org.openqa.selenium.By.xpath("//ul//li//span[normalize-space(text())='" + planName + "']")
        );
        waitForClickability(option).click();
    }

    public void setNextVisitDate(String date) {
        waitForClickability(nextVisitDateInput).clear();
        nextVisitDateInput.sendKeys(date);
    }

    public void setActualStartDate(String date) {
        waitForClickability(actualStartDateInput).clear();
        actualStartDateInput.sendKeys(date);
    }

    public void setActualEndDate(String date) {
        waitForClickability(actualEndDateInput).clear();
        actualEndDateInput.sendKeys(date);
    }

    public void selectPhysician(String physicianName) {
        waitForClickability(physicianDropdown).click();
        WebElement option = driver.findElement(
            org.openqa.selenium.By.xpath("//ul//li//span[normalize-space(text())='" + physicianName + "']")
        );
        waitForClickability(option).click();
    }

    public void selectTreatmentStatus(String status) {
        waitForClickability(treatmentStatusDropdown).click();
        WebElement option = driver.findElement(
            org.openqa.selenium.By.xpath("//ul//li//span[normalize-space(text())='" + status + "']")
        );
        waitForClickability(option).click();
    }

    public void selectFollowUpMode(String followUp) {
        waitForClickability(followUpDropdown).click();
        WebElement option = driver.findElement(
            org.openqa.selenium.By.xpath("//ul//li//span[normalize-space(text())='" + followUp + "']")
        );
        waitForClickability(option).click();
    }

    public void enterNotes(String notes) {
        waitForClickability(notesTextArea).clear();
        notesTextArea.sendKeys(notes);
    }

    public void clickSave() {
        waitForClickability(saveButton).click();
    }

    public void clickReset() {
        waitForClickability(resetButton).click();
    }
}
