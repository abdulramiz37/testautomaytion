

package PharmacyFlowObjects.PharmacyStore;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import EzionAbstractionComponents.Abstraction;

public class StorePage extends Abstraction {

    public StorePage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    // --- Locators ---
    @FindBy(xpath = "//a[text()=' Store']")
    private WebElement storeTab;

    @FindBy(xpath = "//a[text()=' Add Store Name ']")
    private WebElement addStoreNameButton;

    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement storeNameInput;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;
    
    @FindBy(xpath = "//div[@class='back-icon']")
    private WebElement backIcon;
    
    @FindBy(xpath = "//span[contains(text(),'Store Name')]/following-sibling::ngx-validation-message//div[@style='color: red;'] | //input[@formcontrolname='name']/following-sibling::span[contains(@style,'color: red')]")
    private WebElement storeNameError;

    // --- Actions ---
    public void navigateToAddStore() {
        waitForClickability(storeTab).click();
        waitForClickability(addStoreNameButton).click();
    }

    public void enterStoreName(String storeName) {
        waitForVisibility(storeNameInput).sendKeys(storeName);
    }
    public String getError() {
    	System.out.println(storeNameError.getText());
    	return storeNameError.getText();
    }
    public void clickSave() {
        waitForClickability(saveButton).click();
    }

    public void createStore(String name) {
        navigateToAddStore();
        enterStoreName(name);
      
    }
    
  public SupplierPage save() {
	  clickSave();
//	     waitForClickability(backIcon).click();
	    SupplierPage supplierpage = new SupplierPage(driver);
		return supplierpage;
  }
}
