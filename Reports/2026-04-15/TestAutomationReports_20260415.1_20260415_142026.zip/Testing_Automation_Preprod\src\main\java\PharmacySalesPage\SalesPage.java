package PharmacySalesPage;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.ExpectedConditions;

import EzionAbstractionComponents.Abstraction;

public class SalesPage extends Abstraction {

    public SalesPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }
    @FindBy(xpath = "//mat-select[@formcontrolname='medicine_id']")
    private WebElement searchMedicineDropdown;

    public void openSearchMedicineDropdown() {
        searchMedicineDropdown.click();
    }
    // Static Elements
    @FindBy(xpath = "//a[text()=' Counter Sales ']")
    WebElement counterSalesTab;

    @FindBy(xpath = "//input[@formcontrolname='mobilenumber']")
    WebElement mobileInput;

    @FindBy(xpath = "//input[@role='combobox']")
    WebElement customerNameInput;

    @FindBy(xpath = "//button[@class='btn btn-primary ng-star-inserted']")
    WebElement searchCustomerBtn;

    @FindBy(xpath = "//span[text()='Select Doctor']")
    WebElement selectDoctorDropdown;

    @FindBy(xpath = "//input[@formcontrolname='quantity']")
    WebElement quantityInput;

    @FindBy(xpath = "//input[@value='Add']")
    WebElement addButton;

    @FindBy(xpath = "//input[@value='Save']")
    WebElement saveButton;

    @FindBy(xpath = "//input[@value='Yes']")
    WebElement yesButton;

    @FindBy(xpath = "(//b[@class='headerfont'])[3]")
    WebElement billNumber;

    @FindBy(xpath = "(//span[text()='Sales'])[2]")
    WebElement salesMenu;

    @FindBy(css = "table.table-style tbody tr")
    List<WebElement> billTableRows;

    @FindBy(xpath = "(//i[@class='fas fa-chevron-right'])[1]")
    WebElement nextPageButton;

    // -------------------- Action Methods --------------------
   public String lastEnteredMobileNumber;
    public void enterMobileNumber(String mobile) {
        WebElement mobileField = waitForVisibility(mobileInput);
        mobileField.clear();

        if (mobile == null || mobile.trim().isEmpty()) {
            mobile = generateRandomMobileNumber();
        }

        // Store in public variable so it can be accessed later
        lastEnteredMobileNumber = mobile;

        mobileField.sendKeys(mobile);
    }
public    String storedFirstName;
    public void enterFirstName(String firstName) {
        if (firstName == null || firstName.isEmpty()) {
            firstName = generateRandomName();
        }
        storedFirstName = firstName; 
        waitForVisibility(customerNameInput).clear();
        customerNameInput.sendKeys(firstName);
    }
    
   public  String external;
    public void externaldoctor(String firstName) {
        if (firstName == null || firstName.isEmpty()) {
            firstName = generateRandomName();
        }
        external = firstName; 
        waitForVisibility(doctorDropdownInput).clear();
        doctorDropdownInput.sendKeys(firstName);
    }

    private String generateRandomName() {
        String[] chars = "abcdefghijklmnopqrstuvwxyz".split("");
        Random random = new Random();

        int length = 5 + random.nextInt(3); // random length between 5–7
        StringBuilder word = new StringBuilder();

        for (int j = 0; j < length; j++) {
            word.append(chars[random.nextInt(chars.length)]);
        }

        return word.toString();
    }
    public String generateRandomMobileNumber() {
        Random rand = new Random();
        StringBuilder number = new StringBuilder();
        number.append(rand.nextInt(3) + 7); // first digit: 7, 8, or 9

        for (int i = 0; i < 9; i++) {
            number.append(rand.nextInt(10));
        }

        return number.toString();
    }
    
    
	public void createSalesFlow(String mobile, String customerName, String doctorName, String medicineName, String qty) {
        waitForClickability(counterSalesTab).click();

        enterMobileNumber(mobile);
        enterFirstName(customerName);
        
        while (true) {
            try {
                // Wait for the button to be clickable and click it
                waitForClickability(searchCustomerBtn).click();
                System.out.println(":1");
            } catch (TimeoutException | NoSuchElementException | StaleElementReferenceException e) {
                // Element is no longer clickable or present — stop clicking
                System.out.println("Search Customer button is no longer clickable or present.");
                break;
            }
        }
        By customerOption = By.xpath("//strong[text()='" + customerName + "']");
//        waitForClickability(driver.findElement(customerOption)).click();
        while (true) {
            try {
                // Wait for the button to be clickable and click it
                waitForClickability(customerOption).click();
                System.out.println(":2");
            } catch (TimeoutException | NoSuchElementException | StaleElementReferenceException e) {
                // Element is no longer clickable or present — stop clicking
                System.out.println("Search Customer button is no longer clickable or present.");
                break;
            }
        }
        waitForClickability(selectDoctorDropdown).click();
        By doctorOption = By.xpath("//span[text()='" + doctorName + "']");
        waitForClickability(driver.findElement(doctorOption)).click();

        By dynamicMedicineCard = By.xpath("//h4[text()='" + medicineName + "']");
        waitForClickability(driver.findElement(dynamicMedicineCard)).click();

        waitForVisibility(quantityInput).sendKeys(qty);
        waitForClickability(addButton).click();
//
//        js.executeScript("arguments[0].scrollIntoView(true);", saveButton);
//        js.executeScript("arguments[0].click();", saveButton);
//
//        js.executeScript("arguments[0].click();", yesButton);
    }
	   @FindBy(xpath = "(//span[text()='Sales'])[1]")
	    private WebElement sales;
	    

	    @FindBy(xpath = "(//span[text()='Sales'])[2]")
	    private WebElement sales2;
	 // 🔹 Main Sales Flow
	    public void createSalesFlow3(String mobile, String customerName, String doctorName) {
	        
	        waitForClickability(sales2).click();
	        waitForClickability(counterSalesTab).click();

	        enterMobileNumber(mobile);
	        enterFirstName(customerName);

	        // Search & Select Customer
	        while (true) {
	            try {
	                waitForClickability(searchCustomerBtn).click();
	                System.out.println(":1");
	            } catch (TimeoutException | NoSuchElementException | StaleElementReferenceException e) {
	                System.out.println("Search Customer button is no longer clickable or present.");
	                break;
	            }
	        }

	        By customerOption = By.xpath("//strong[text()='" + customerName + "']");
	        while (true) {
	            try {
	                waitForClickability(customerOption).click();
	                System.out.println(":2");
	            } catch (TimeoutException | NoSuchElementException | StaleElementReferenceException e) {
	                System.out.println("Customer option is no longer clickable or present.");
	                break;
	            }
	        }

	        // Select Doctor
	        waitForClickability(selectDoctorDropdown).click();
	        By doctorOption = By.xpath("//span[text()='" + doctorName + "']");
	        waitForClickability(driver.findElement(doctorOption)).click();

	        // 🔹 Call medicine selection method
	       
	    }
	    @FindBy(xpath = "//label[text()='External Dr']")
	    WebElement externalDoctorLabel;
	    @FindBy(xpath = "//input[@placeholder='Select Doctor']")
	    WebElement doctorDropdownInput;
	    @FindBy(xpath = "//button[contains(text(),'Add') and contains(text(),'Referral Doctor')]")
	    WebElement addReferralDoctorButton;
	    
	    public void clickAddReferralDoctor() {
	        addReferralDoctorButton.click();
	    }
	    public void creditbill(String mobile, String customerName, String doctorName) {
	        
//	        waitForClickability(sales2).click();
	        waitForClickability(counterSalesTab).click();

	        enterMobileNumber(mobile);
	        enterFirstName(customerName);

	        // Search & Select Customer
	        while (true) {
	            try {
	                waitForClickability(searchCustomerBtn).click();
	                System.out.println(":1");
	            } catch (TimeoutException | NoSuchElementException | StaleElementReferenceException e) {
	                System.out.println("Search Customer button is no longer clickable or present.");
	                break;
	            }
	        }

	        By customerOption = By.xpath("//strong[text()='" + customerName + "']");
	        while (true) {
	            try {
	                waitForClickability(customerOption).click();
	                System.out.println(":2");
	            } catch (TimeoutException | NoSuchElementException | StaleElementReferenceException e) {
	                System.out.println("Customer option is no longer clickable or present.");
	                break;
	            }
	        }
	        externalDoctorLabel.click();
	        // Select Doctor
	        waitForClickability(selectDoctorDropdown).click();
	        externaldoctor(doctorName);
	      
//	        By doctorOption = By.xpath("//span[text()='" + doctorName + "']");
//	        waitForClickability(driver.findElement(doctorOption)).click();

	        // 🔹 Call medicine selection method
	       
	    }
	    @FindBy(xpath = "(//i[contains(@class,'ngx-select__clear-icon')])[2]")
	    WebElement clearDropdownIcon;

	    public void selecctdynamicdoctor(String externaldoctor) {
	    	waitForClickability(clearDropdownIcon).click();
	        waitForClickability(selectDoctorDropdown).click();
	        By doctorOption = By.xpath("//span[contains(text(), '" + externaldoctor + "')]");
	        waitForClickability(driver.findElement(doctorOption)).click();
	    }
	 // 🔹 Reusable method to select multiple medicines
	    public void selectMedicines(List<String> medicineNames) throws InterruptedException {
	        // Find the correct overlay containing mat-select-panel
	        List<WebElement> overlays = driver.findElements(By.cssSelector("div.cdk-overlay-pane"));
	        WebElement scrollablePanel = null;

	        for (WebElement overlay : overlays) {
	            try {
	                scrollablePanel = overlay.findElement(By.cssSelector("div.mat-select-panel"));
	                if (!overlay.findElements(By.cssSelector("mat-option")).isEmpty()) {
	                    break; // Found the overlay with actual options
	                }
	            } catch (NoSuchElementException e) {
	                // Not this overlay, try next
	            }
	        }

	        if (scrollablePanel == null) {
	            System.out.println("❌ Could not find the medicine dropdown overlay");
	            return;
	        }

	        for (String medicineName : medicineNames) {
	            boolean clicked = false;
	            int attempts = 0;

	            String xpath = ".//mat-option[.//h4[translate(normalize-space(.), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')='"
	                           + medicineName.toLowerCase() + "']]";

	            while (!clicked && attempts < 50) {
	                try {
	                    WebElement option = waitForClickability(scrollablePanel.findElement(By.xpath(xpath)));

	                    // Scroll option into view (center)
	                    ((JavascriptExecutor) driver).executeScript(
	                            "arguments[0].scrollIntoView({block: 'center'});", option);

	                    // Click via JS
	                    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", option);

	                    System.out.println("✅ Selected medicine: " + medicineName);
	                    clicked = true;
	                } catch (NoSuchElementException e) {
	                    // Scroll to load more options
	                    ((JavascriptExecutor) driver).executeScript(
	                            "arguments[0].scrollTop = arguments[0].scrollHeight;", scrollablePanel);
	                    Thread.sleep(200); // wait for DOM update
	                }
	                attempts++;
	            }

	            if (!clicked) {
	                System.out.println("❌ Could not select medicine: " + medicineName);
	            }
	        }
	    }


public void qty(String qty) {
    waitForVisibility(quantityInput).sendKeys(qty);
}
public void addbtn() {
    waitForClickability(addButton).click();
}
	@FindBy(xpath = "//input[@type='button' and @value='Hold Bill']")
	WebElement holdBillBtn;

	public void clickHoldBill() {
	    holdBillBtn.click();
	}
	@FindBy(xpath = "//span[normalize-space()='Unbilled List']")
	WebElement unbilledListTab;
	
	public void patientlist() {
		unbilledListTab.click();
	}

	public void createSalesFlow2(String medicineName, String qty) {


        By dynamicMedicineCard = By.xpath("//h4[text()='" + medicineName + "']");
        waitForClickability(driver.findElement(dynamicMedicineCard)).click();

        waitForVisibility(quantityInput).sendKeys(qty);
        waitForClickability(addButton).click();
     // Example: press ESC to close
        

//
//        js.executeScript("arguments[0].scrollIntoView(true);", saveButton);
//        js.executeScript("arguments[0].click();", saveButton);
//
//        js.executeScript("arguments[0].click();", yesButton);
    }
	
	public void selectMedicine(String name) {
	    driver.findElement(
	        By.xpath("//mat-option//h4[contains(normalize-space(.),'" + name + "')]/ancestor::mat-option")

	    ).click();
	

   
        waitForClickability(addButton).click();
     
    }
	@FindBy(xpath = "//input[@formcontrolname='commondiscountpercentage']")
	WebElement commonDiscountPercentageInput;
	public void enterCommonDiscountPercentage(String value) {
	    commonDiscountPercentageInput.clear();
	    commonDiscountPercentageInput.sendKeys(value);
	}

	public void excape() {
		
		Actions act = new Actions(driver);
        act.sendKeys(Keys.ESCAPE).perform();
	}
	
	public void enter() throws AWTException, InterruptedException {
	       Robot robot = new Robot();
	      // wait a bit for Save As dialog to appear
	       Thread.sleep(2000); // w
	        robot.keyPress(KeyEvent.VK_ENTER);
	        robot.keyRelease(KeyEvent.VK_ENTER);
	}
	public boolean findMedicineAndClick123(String targetMedicineName, String actionType) {
	    // Get all rows from table
	    List<WebElement> rows = waitForPresenceOfAll(
	        By.xpath("(//table[@class='table table-hover'])[1]/tbody/tr")
	    );

	    for (int i = 0; i < rows.size(); i++) {
	        WebElement row = driver.findElements(
	            By.xpath("(//table[@class='table table-hover'])[1]/tbody/tr")
	        ).get(i);

	        // Medicine name is in 2nd <td>
	        String medicineName = row.findElement(By.xpath("./td[2]")).getText().trim();
	        System.out.println(medicineName);

	        if (medicineName.equalsIgnoreCase(targetMedicineName)) {
	            WebElement actionIcon;

	            if (actionType.equalsIgnoreCase("edit")) {
	                actionIcon = row.findElement(
	                    By.xpath("./td[last()]//img[contains(@src,'edit.png')]")
	                );
	            } else if (actionType.equalsIgnoreCase("delete")) {
	                actionIcon = row.findElement(
	                    By.xpath("./td[last()]//img[contains(@src,'p7.png')]")
	                );
	            } else {
	                throw new IllegalArgumentException("❌ Invalid action type: " + actionType);
	            }

	            // Scroll into view and click
	            waitForClickability(actionIcon).click();

	            System.out.println("✅ Clicked " + actionType + " for Medicine: " + medicineName);
	            return true;
	        }
	    }

	    return false; // medicine not matched in table
	}

    public String getBillNumber() {
        return waitForVisibility(billNumber).getText().trim();
    }
    
    public SearchAndReturnBill search() {
    	SearchAndReturnBill returnbill= new SearchAndReturnBill(driver);
    	return returnbill;
    }

	@FindBy(xpath = "//label[normalize-space()='Batch']/following-sibling::p")
	WebElement batchNumber;

	// Stick Quantity
	@FindBy(xpath = "//label[normalize-space()='Stk. Qty']/following-sibling::p")
	WebElement stickQuantity;

	// Method to get values
	public String getBatchNumber() {
	    return batchNumber.getText().trim();
	}

	public String getStickQuantity() {
	    return stickQuantity.getText().trim();
	}
}

