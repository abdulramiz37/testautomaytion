package PharmacySalesPage.Accounts;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class Creditbill extends Abstraction {

	public Creditbill(WebDriver driver) {
		super(driver);
		  PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "//div[@class='pagi-block pagi-block-right']//i[contains(@class,'fa-chevron-right')]")
	WebElement nextPageButton;
	
	@FindBy(xpath = "(//a[@title='Accounts'])[2]")
	WebElement accounts;
	
	@FindBy(xpath = "(//a[@title='Credit Bill'])[1]")
	WebElement credit;
	
	public void creditbillacoounts() {
		waitForClickability(accounts).click();
		waitForClickability(credit).click();
	}
	public boolean clickEditByPatientName(String targetPatientName) {
	    boolean isFound = false;

	    while (!isFound) {
	        List<WebElement> rows = waitForPresenceOfAll(
	            By.xpath("//table[@class='table table-hover table-style']/tbody/tr")
	        );

	        for (WebElement row : rows) {
	            try {
	                String patientName = row.findElement(By.xpath("./td[2]//h4")).getText().trim();

	                if (patientName.equalsIgnoreCase(targetPatientName)) {
	                    WebElement editIcon = row.findElement(
	                        By.xpath(".//td[last()]//img[contains(@src,'edit.png')]")
	                    );

	                    // Scroll + JS click to avoid interception
	                    ((JavascriptExecutor) driver).executeScript(
	                        "arguments[0].scrollIntoView({block: 'center'});", editIcon);
	                    Thread.sleep(500);
	                    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", editIcon);

	                    System.out.println("✅ Clicked Edit for Patient: " + patientName);
	                    isFound = true;
	                    break;
	                }

	            } catch (StaleElementReferenceException | NoSuchElementException e) {
	                System.out.println("⚠️ Skipping stale/missing row");
	            } catch (InterruptedException ie) {
	                Thread.currentThread().interrupt();
	            }
	        }

	        if (!isFound) {
	            try {
	                String classAttr = nextPageButton.getAttribute("class");
	                if (classAttr.contains("disabled")) {
	                    System.out.println("❌ Reached last page. Patient not found.");
	                    break;
	                }
	                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextPageButton);
	            } catch (NoSuchElementException e) {
	                System.out.println("❌ Next page button not found. Ending search.");
	                break;
	            }
	        }
	    }
	    return isFound;
	}


}
