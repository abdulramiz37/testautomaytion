package PharmacyStocksAccounts;



import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import EzionAbstractionComponents.Abstraction;

public class CreditNotePage extends Abstraction {

    WebDriver driver;

    // ==============================
    // CONSTRUCTOR
    // ==============================
    public CreditNotePage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // ==============================
    // LOCATORS
    // ==============================

    // Header – Location
    @FindBy(xpath = "//ngx-select[@formcontrolname='pharmacyCounter']//div[contains(@class,'ngx-select__toggle')]")
    public WebElement locationDropdown;


    // Supplier Name
    @FindBy(xpath = "//label[contains(text(),'Supplier Name')]/following::div[contains(@class,'ngx-select')][1]")
    public WebElement supplierNameDropdown;

    // Contact
    @FindBy(xpath = "//input[@formcontrolname='supplierContactNo']")
    public WebElement supplierContact;

    // Email
    @FindBy(xpath = "//input[@formcontrolname='supplierEmail']")
    public WebElement supplierEmail;

    // Address
    @FindBy(xpath = "//textarea[@formcontrolname='supplierAddress']")
    public WebElement supplierAddress;

    // Credit Note Reason
    @FindBy(xpath = "//label[contains(text(),'Credit Note Reason')]/following::div[contains(@class,'ngx-select')][1]")
    public WebElement creditNoteReasonDropdown;

    // Credit Note Date
    @FindBy(xpath = "//input[@formcontrolname='creditNoteDate']")
    public WebElement creditNoteDate;

    // Credit Note No
    @FindBy(xpath = "//input[@formcontrolname='creditNoteNo']")
    public WebElement creditNoteNo;

    // Supplier Notes
    @FindBy(xpath = "//textarea[@formcontrolname='supplierNotes']")
    public WebElement supplierNotes;

    // Auto Adjustment radio
    @FindBy(id = "inlineRadio1")
    public WebElement radioAutoAdjustment;

    // Manual Adjustment radio
    @FindBy(id = "inlineRadio2")
    public WebElement radioManualAdjustment;

    @FindBy(xpath = "//label[contains(text(),'Invoice No')]/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    public WebElement invoiceselect;
    

    // Buttons
    @FindBy(xpath = "//input[@value='Save']")
    public WebElement saveButton;

    @FindBy(xpath = "//input[@value='Cancel']")
    public WebElement cancelButton;

    @FindBy(xpath = "//input[@value='Reset']")
    public WebElement resetButton;

    // ==============================
    // METHODS
    // ==============================
    @FindBy(xpath = "//div[contains(@class,'add-btn-cls')]//img[contains(@class,'hd-add')]")
    private WebElement addButton;
    
    public void clickAddButton() {
        waitForClickability(addButton).click();
    }

    @FindBy(xpath = "//input[@type='button' and @value='Add']")
    private WebElement addButton2;

    public void clickAddButton2() {
        waitForVisibility(addButton2).click();
    }

    // ----- Location -----
    public void selectLocation(String locationName) {
        selectFromNgxDropdown(locationDropdown, locationName);
    }

    // ----- Supplier Name -----
    public void selectSupplierName(String supplier) {
        selectFromNgxDropdown(supplierNameDropdown, supplier);
    }

    // Read-only fields
    public String getSupplierContact() {
        return supplierContact.getAttribute("value");
    }

    public String getSupplierEmail() {
        return supplierEmail.getAttribute("value");
    }

    public String getSupplierAddress() {
        return supplierAddress.getText().trim();
    }
    public void selectFromNgxDropdown(WebElement dropdown,String visibleText) {
    	waitForClickability(dropdown).click();
        driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + visibleText + "']")).click();
    }
    public void selectFromNgxDropdown(String visibleText) {
//    	waitForClickability(dropdown).click();
        driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + visibleText + "']")).click();
    }
    // ----- Credit Note Reason -----
    public void selectCreditNoteReason(String reason) {
        selectFromNgxDropdown(creditNoteReasonDropdown, reason);
    }

    // ----- Credit Note Date -----
    public void enterCreditNoteDate() {
        waitForVisibility(creditNoteDate).clear();
        creditNoteDate.sendKeys(todayDate);
    }

    // ----- Credit Note Number -----
    public void enterCreditNoteNumber(String number) {
        waitForVisibility(creditNoteNo).clear();
        creditNoteNo.sendKeys(number);
    }

    // ----- Supplier Notes -----
    public void enterSupplierNotes(String notes) {
        waitForVisibility(supplierNotes).clear();
        supplierNotes.sendKeys(notes);
    }

    // ----- Adjustment Type -----
    public void selectAutoAdjustment() {
        waitForClickability(radioAutoAdjustment).click();
    }

    public void selectManualAdjustment() {
        waitForClickability(radioManualAdjustment).click();
    }
    
    public void invoiceselect() {
        waitForClickability(invoiceselect).click();
    }
    @FindBy(xpath = "//input[contains(@class,'ngx-select__search')]")
    private WebElement invoiceSearchInput;
    
    public void searchInvoice(String invoiceNo) {
        waitForVisibility(invoiceSearchInput).clear();
        invoiceSearchInput.sendKeys(invoiceNo);
    }
    // ----- Buttons -----
    public void clickSave() {
        waitForClickability(saveButton).click();
    }

    public void clickCancel() {
        waitForClickability(cancelButton).click();
    }

    public void clickReset() {
        waitForClickability(resetButton).click();
    }

    // ==============================
    // MASTER METHOD
    // ==============================

    public void createCreditNote(
            String location,
            String supplier,
            String reason,
            String date,
            String creditNoteNumber,
            String notes,
            String adjustmentType
    ) {
        selectLocation(location);
        selectSupplierName(supplier);
        selectCreditNoteReason(reason);
        enterCreditNoteDate();
        enterCreditNoteNumber(creditNoteNumber);
        enterSupplierNotes(notes);

        if (adjustmentType.equalsIgnoreCase("Auto")) {
            selectAutoAdjustment();
        } else {
            selectManualAdjustment();
        }

        clickSave();
    }
}

