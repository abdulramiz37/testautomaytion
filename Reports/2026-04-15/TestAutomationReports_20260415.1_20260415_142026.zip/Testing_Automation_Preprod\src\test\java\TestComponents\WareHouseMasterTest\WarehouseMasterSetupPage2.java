package TestComponents.WareHouseMasterTest;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EzionpageObjects.UserIdPage;

import PharmacyFlowObjects.MasterSetupPage;

import WareHouseSetup.Accounts.BankPage;
import WareHouseSetup.Accounts.LedgerDetailsPage;
import WareHouseSetup.Accounts.LocationSetupPage;
import WareHouseSetup.Accounts.PayerPage;
import WareHouseSetup.Accounts.Payer_Check_List_Page;
import WareHouseSetup.Approval.Approval;
import WareHouseSetup.Approval.Branchbased.BillCancelPage;
import WareHouseSetup.Approval.Branchbased.BillDiscountPage;
import WareHouseSetup.Approval.Branchbased.Branch_Based_Master;
import WareHouseSetup.Approval.MedicalHistory.Allergy;
import WareHouseSetup.Approval.MedicalHistory.SocialHabits;
import WareHouseSetup.Approval.Tenant_Master.CallStatusPage;
import WareHouseSetup.Approval.Tenant_Master.Tenant_Based_Master;
import WareHouseSetup.IPpharmacy.AdmissionTypePage;
import WareHouseSetup.IPpharmacy.BedPage;
import WareHouseSetup.IPpharmacy.BedViewPage;
import WareHouseSetup.IPpharmacy.BuildingPage;
import WareHouseSetup.IPpharmacy.DischargeReasonPage;
import WareHouseSetup.IPpharmacy.FloorPage;
import WareHouseSetup.IPpharmacy.NursingCounterPage;
import WareHouseSetup.IPpharmacy.RoomPage;
import WareHouseSetup.IPpharmacy.WardInformationPage;
import WareHouseSetup.MyHospital.Bill_Head_Page;
import WareHouseSetup.MyHospital.DepartmentPage;
import WareHouseSetup.MyHospital.DesignationPage;
import WareHouseSetup.MyHospital.ExternalDoctorPage;
import WareHouseSetup.MyHospital.GraceChargesSetUp;
import WareHouseSetup.MyHospital.PackageTypePage;
import WareHouseSetup.MyHospital.ReferralsPage;
import WareHouseSetup.MyHospital.ShiftPage;
import WareHouseSetup.MyHospital.UserRestrictionsPage;
import WareHouseSetup.MyHospital.UsertypePage;
import WareHouseSetup.MyHospital.ValidityTypePage;
import WareHouseSetup.MyHospital.VisitModePage;
import WareHouseSetup.MyHospital.Service.AddServicePage;
import WareHouseSetup.MyHospital.Service.AddServiceSubCategoryPage;
import WareHouseSetup.MyHospital.Service.GeneralPackagePage;
import WareHouseSetup.MyHospital.Service.LabGroupPage;
import WareHouseSetup.MyHospital.Service.LabPackagePage;
import WareHouseSetup.MyHospital.Service.LabTestPage;
import WareHouseSetup.MyHospital.Service.ServiceCatergoryPage;
import WareHouseSetup.Settings.HospitalSchedulePage;
import WareHouseSetup.Settings.MandotorySettingPage;
import WareHouseSetup.Settings.Unique_id_Generator;
import abdulTest.BaseTest;
import abdulTest.BaseTest2;
import ezion.Resources.EnvUtil;

public class WarehouseMasterSetupPage2 extends BaseTest {

    UserIdPage data;
    
    @Test(dataProvider = "getDataForLogin", priority = 1)
    public void login(HashMap<String, String> input) throws InterruptedException {
        data = login.login(EnvUtil.get("USER_ID"));
        data.enterMobileNumber(EnvUtil.get("PERSON_ID"));
        data.enterPassword(EnvUtil.get("PASSWORD"));

        data.clickContinue();
        data.openMasterSetup();
    }

//    @Test(dataProvider = "getDataForLogin", priority = 2, dependsOnMethods = "login")
//    public void testApprovalMaster(HashMap<String, String> input) {
//       
//        Approval approvalPage = new Approval(driver);
//        approvalPage.clickbuttonapproval();
//        approvalPage.selectUserName(input.get("userName"));
//        approvalPage.selectAccountType(input.get("accountType"));
//        approvalPage.selectAccountSubType(input.get("accountSubType"));
//        approvalPage.clickSave();
//        Assert.assertTrue(data.isIncorrectCredentialAlertDisplayed().contains("Incorrect Passworh, Please Enter the valid password"));
//    }
//
//    @Test(dataProvider = "getDataForLogin", priority = 3, dependsOnMethods = "login")
//    public void testItemDiscount(HashMap<String, String> input) {
//        data.masterSetupOpenOnly();
//        Branch_Based_Master branchBased = new Branch_Based_Master(driver);
//        branchBased.clickbuttonapproval();
//        branchBased.fillItemDiscountForm(
//            input.get("discountName"),
//            input.get("discountCode"),
//            input.get("discountDescription"),
//            Boolean.parseBoolean(input.get("isActive"))
//        );
//    }
//
//    @Test(dataProvider = "getDataForLogin", priority = 4, dependsOnMethods = "login")
//    public void testBillDiscount(HashMap<String, String> input) {
//        BillDiscountPage billPage = new BillDiscountPage(driver);
//        billPage.clickbuttonapproval();
//        billPage.fillBillDiscountForm(
//            input.get("name"),
//            input.get("code"),
//            input.get("description"),
//            Boolean.parseBoolean(input.get("isActive"))
//        );
//    }
//
//    @Test(dataProvider = "getDataForLogin", priority = 5, dependsOnMethods = "login")
//    public void testBillCancel(HashMap<String, String> input) {
//        BillCancelPage billPage = new BillCancelPage(driver);
//        billPage.clickbuttonapproval();
//        billPage.fillBalanceForm(
//            input.get("billCancelName"),
//            input.get("billCancelCode"),
//            input.get("billCancelDescription"),
//            input.get("isActive").equalsIgnoreCase("true")
//        );
//    }
//
//    @Test(dataProvider = "getDataForLogin", priority = 6, dependsOnMethods = "login")
//    public void testCallCategory(HashMap<String, String> input) {
//        data.masterSetupOpenOnly();
//        Tenant_Based_Master tenant = new Tenant_Based_Master(driver);
//        tenant.clickbuttonapproval();
//        tenant.fillCallCategoryForm(
//            input.get("categoryName"),
//            input.get("categoryCode"),
//            input.get("categoryDescription"),
//            Boolean.parseBoolean(input.get("isActive"))
//        );
//    }
//
//    @Test(dataProvider = "getDataForLogin", priority = 7, dependsOnMethods = "login")
//    public void testCallStatus(HashMap<String, String> input) {
//        CallStatusPage callStatus = new CallStatusPage(driver);
//        callStatus.clickbuttonapproval();
//        callStatus.fillCallStatusForm(
//            input.get("callStatusName"),
//            input.get("callStatusCode"),
//            input.get("callStatusDescription"),
//            Boolean.parseBoolean(input.get("isActive"))
//        );
//    }
//
//    @Test(dataProvider = "getDataForLogin", priority = 8, dependsOnMethods = "login")
//    public void testUniqueIdGeneration(HashMap<String, String> input) {
//       
//        Unique_id_Generator uniqueId = new Unique_id_Generator(driver);
//
//        uniqueId.selectUniqueIdFor(input.get("UniqueIDFor"));
//        uniqueId.enterText(input.get("Text"));
//        uniqueId.enterNumber(input.get("Number"));
//        uniqueId.selectDateFormat(input.get("DateFormat"));
//        uniqueId.selectPrefix(input.get("Prefix"));
//        uniqueId.selectTenantBased();
//
//        if (input.get("EnableText").equalsIgnoreCase("yes")) uniqueId.selectTextCheckbox();
//        if (input.get("EnableDateFormat").equalsIgnoreCase("yes")) uniqueId.selectDateFormatCheckbox();
//
//        int attempts = 0;
//        while (!uniqueId.isSaveSuccessMessageDisplayed() && attempts < 5) {
//        	   uniqueId.clickSave();
//               if (uniqueId.isLengthErrorDisplayed()) uniqueId.incrementDigit();
//               attempts++;
//        }
//
//        uniqueId.clickSave();
//    }
//    
//    @Test(dataProvider = "getDataForLogin", priority = 9, dependsOnMethods = "login")
//    public void mandotorySetting(HashMap<String, String> input) {
//        data.masterSetupOpenOnly();
//        MandotorySettingPage mandotoryPage = new MandotorySettingPage(driver);
//        
//        // Example: Selecting a page from dropdown based on input map
//        String pageName = input.get("Page Name"); // make sure your data has this key
//        mandotoryPage.selectPageOption(pageName);
//    }
//
//    
//    @Test(dataProvider = "getDataForLogin", priority = 10, dependsOnMethods = "login")
//    public void testSlotScheduleForm(HashMap<String, String> input) {
//    	  data.masterSetupOpenOnly();
//    	HospitalSchedulePage slotSchedulePage = new HospitalSchedulePage(driver);
//    	slotSchedulePage.fillSlotScheduleFormForMultipleDays(
//    		        input.get("fromDate"),
//    		        input.get("toDate"),
//    		        input.get("timeSlot"),
//    		        input.get("dayOfWeek"),
//    		        input.get("branch"),
//    		        input.get("fromTime"),
//    		        input.get("toTime")
//    		    );
//    }
//
//    @Test(dataProvider = "getDataForLogin", priority = 10, dependsOnMethods = "login")
//    public void Hospital_UserType(HashMap<String, String> input) {
//    	  data.masterSetupOpenOnly();
//    	
//    	  UsertypePage usertypePage = new UsertypePage(driver);
//    	  usertypePage.fillUsertypeForm("Adminsn");
//    }
//
//    @Test(dataProvider = "getDataForLogin", priority = 11, dependsOnMethods = "login")
//    public void Hospital_Department(HashMap<String, String> input) {
//    	  data.masterSetupOpenOnly();
//    	
//    	  DepartmentPage departmentPage = new DepartmentPage(driver);
//    	    departmentPage.fillDepartmentForm("Cardiologyke", "Main Branch", true, true);
//    }
//    
//    @Test(dataProvider = "getDataForLogin", priority = 12, dependsOnMethods = "login")
//    public void Hospital_ShiftTimes(HashMap<String, String> input) {
//    	  data.masterSetupOpenOnly();
//    	
//    	  ShiftPage shiftPage = new ShiftPage(driver);
//    	    shiftPage.fillShiftForm("Morning Shift", "08:00", "14:00");
//
// 
//    }
//    
//    @Test(dataProvider = "getDataForLogin", priority = 13, dependsOnMethods = "login")
//    public void Hospital_fillDesignationForm(HashMap<String, String> input) {
//    	  data.masterSetupOpenOnly();
//    	
//    	  DesignationPage designationPage = new DesignationPage(driver);
//    	  designationPage.fillDesignationForm("Automation QA Lead", true);
//
// 
//    }
//
//   	
//    	  @Test(dataProvider = "getDataForLogin", priority = 14, dependsOnMethods = "login")
//    	  public void Hospital_AddServicePage(HashMap<String, String> input) {
//    	      // Navigate to the Master Setup module
//    	      data.masterSetupOpenOnly();
//
//    	      // Create page object
//    	   
//    	      AddServicePage addServicePage = new AddServicePage(driver);
//    	      addServicePage.fillAddServiceForm(
//    	    	        "Blood Test2",             // name
//    	    	        "350",                    // price
//    	    	        "5",                    // gst
//    	    	        "General",                    // category
//    	    	        "GENERAL SERVICES",              // subCategory
//    	    	        "Outside Lab A",          // outsideLab
//    	    	        "Service referral",               // associatedWith
//    	    	        "SAC008",                 // serviceReqNo
//    	    	        "SAC009",                 // serviceAccCode
//    	    	        "Vd",       // department
//    	    	        true,                     // isEditable
//    	    	        true,                     // isActive
//    	    	        false,                    // allowZero
//    	    	        false                  // workOrder
//    	        
//    	    	    );
//
//
//    	      }
//
//    	  
//    	  
//    
//    	    
//    	    @Test(dataProvider = "getDataForLogin", priority = 15, dependsOnMethods = "login")
//    	    public void Hospital_AddServiceCategoryPage(HashMap<String, String> input) {
//    	    	  
//    	    	
//    	    	  ServiceCatergoryPage designationPage = new ServiceCatergoryPage(driver);
//    	    	  designationPage.openServiceForm();
//    	    	  designationPage.fillServiceCategoryForm("Radiology", "RAD01", "1", true);
//    	    	 
//
//
//    	 
//    	    }
//    	      
//    	  	  @Test(dataProvider = "getDataForLogin", priority = 16, dependsOnMethods = "login")
//        	  public void Hospital_AddServiceSubCategoryPage(HashMap<String, String> input) {
//        	      // Navigate to the Master Setup module
//        	 
//    	  	
//        	      // Create page object
//        	   
//        	      AddServiceSubCategoryPage page = new AddServiceSubCategoryPage(driver);
//        	      page.fillAddServiceSubCategoryForm(
//        	          "Radiology", 
//        	          "X-Ray - Chest", 
//        	          "Petty cash", 
//        	          "5", 
//        	          "Radiology Group", 
//        	          true, 
//        	          false, 
//        	          true
//        	      );
//        	      page.clickSave();
//
//
//
//        	      }
//    
//    	  	@Test(dataProvider = "getDataForLogin", priority = 17, dependsOnMethods = "login")
//    	  	public void Hospital_LabTest(HashMap<String, String> input) {
//    	  		LabTestPage labTestPage = new LabTestPage(driver);
//
//    	  		labTestPage.fillLabTestForm(
//    	  		    "Blood Sugar2",  // testName
//    	  		    "Lab",          // category
//    	  		    "0",            // gst
//    	  		    "2",            // serviceno
//    	  		    "2",
//    	  		    "Cells/Cumm",        // unit
//    	  		    
//    	  		    "URINE PATHOLOGY",          // labCategory
//    	  		    "90",           // defaultValue
//    	  		    "ELISA", // labTestMethod
//    	  		    "EDTA",        // labTestMaterial
//    	  		    "Cervical Swab"  ,      // sampleType
//    	  		    "Input Field",
//    	  		    "Text Field",
//    	  		    "4",
//    	  		    "1",
//    	  		    "2",
//    	  		    "1",
//    	  		    "2",
//    	  		    "1",
//    	  		    "2",
//    	  		    "1",
//    	  		    "2"
//    	  		);
//
//    	  	}
//    	  	
//    	  	@Test(dataProvider = "getDataForLogin", priority = 18, dependsOnMethods = "login")
//    	  	public void Hospital_LabGroup(HashMap<String, String> input) {
//    	  	    // Navigate to Master Setup (custom abstraction call)
//    	  		LabGroupPage labGroupPage = new LabGroupPage(driver);
//
//    	  		labGroupPage.fillForm(
//    	  		    "General Tests",
//    	  		    "500",
//    	  		    "Yes",
//    	  		    "Yes",
//    	  		    "Lab",
//    	  		    "URINE PATHOLOGY",
//    	  		    "0",
//    	  		    "1",
//    	  		    true,
//    	  		    true,
//    	  		    "Weekdays",
//    	  		    "Blood Sugar1"
//    	  		);
//
//
//    	  	    // Optional: Add validation/assertion here if required
//    	  	}
//
//    	  	@Test(dataProvider = "getDataForLogin", priority = 19, dependsOnMethods = "login")
//    	  	public void Hospital_LabPackage(HashMap<String, String> input) {
//    	  	    // Navigate to Master Setup (custom abstraction call)
//    	  		LabPackagePage labGroupPage = new LabPackagePage(driver);
//
//    	  		labGroupPage.fillForm(
//    	  		    "General Tests",
//    	  		    "500",
//    	  		    "Yes",
//    	  		    "Yes",
//    	  		    "Lab",
//    	  		    "URINE PATHOLOGY",
//    	  		    "0",
//    	  		    "1",
//    	  		    true,
//    	  		    true,
//    	  		    "Weekdays",
//    	  		    "Blood Sugar1"
//    	  		);
//
//
//    	  	    // Optional: Add validation/assertion here if required
//    	  	}
//    	  	
//    	  	@Test(dataProvider = "getDataForLogin", priority = 20, dependsOnMethods = "login")
//    	  	public void Hospital_GeneralPackage(HashMap<String, String> input) {
//    	  	    // Navigate to Master Setup (custom abstraction call)
//    	  	
//    	  		GeneralPackagePage gp = new GeneralPackagePage(driver);
//    	  		gp.fillForm("Basic Health", "1000", "Gold", "Active", "Yes", true,
//    	  		    "30 Days", "Radiology", "OP", "500", "5000", true, "weekdays", "Blood Sugar");
//    	  	    // Optional: Add validation/assertion here if required
//    	  	}
//    	  	  
//    	 	    
//    	  	@Test(dataProvider = "getDataForLogin", priority = 17, dependsOnMethods = "login")
//    	  	public void Hospital_Bill_Head_Page(HashMap<String, String> input) {
//    	  	    // Navigate to Master Setup (custom abstraction call)
//    	  	    data.masterSetupOpenOnly();
//
//    	  	    // Initialize Bill Head Page object
//    	  	    Bill_Head_Page billHeadPage = new Bill_Head_Page(driver);
//
//    	  	    // Fill the form using input map
//    	  	    billHeadPage.fillBillHeadForm(
//    	  	    		"Emergency Bill",
//    	  	    		"1",
//    	  	    		"Emergency dept billing",
//    	  	        Boolean.parseBoolean(input.get("isActive"))
//    	  	    );
//
//    	  	    // Click Save (you can wrap this in a method if you like)
//    	  	    billHeadPage.clickSave();
//
//    	  	    // Optional: Add validation/assertion here if required
//    	  	}
//
//    	  	  
//
//      	    
//    	      @Test(dataProvider = "getDataForLogin", priority = 18, dependsOnMethods = "login")
//        	    public void Hospital_External_Doctor(HashMap<String, String> input) {
//        	    	  data.masterSetupOpenOnly();
//    	    	  ExternalDoctorPage externalPage = new ExternalDoctorPage(driver);
//
//        	       // Fill the form using input map
//    	    	  externalPage.addPhysician(
//    	    			  "Dr.", // Dr.
//    	    			  "John", // John
//    	    			  "Doe", // Doe
//    	    			  "John D.", // Display name (optional)
//    	    			  "Male", // Male
//    	    			  "01/01/1980", // 01/01/1980
//    	    			  "44", // 44
//    	    			  "john@example.com", // john@example.com
//    	    			  "9876543210", // 9876543210
//    	    			  "9123456780", // Alternate mobile (optional)
//    	    			  "0221234567", // Work phone (optional)
//    	    			  "ABCDE1234F", // ABCDE1234F
//    	    			  "General", // General
//    	    			  "Therapist", // Therapist
//    	    			  "Permanent Employee", // Permanent Employee
//    	    			  "Senior" // Senior
//
//    	    	        );
//    	    	  externalPage.clickSaveButton();
//       
//        	 
//        	    }  
//    	    	   
//    	      @Test(dataProvider = "getDataForLogin", priority = 19, dependsOnMethods = "login")
//    	      public void Hospital_testUserRestrictionsForm(HashMap<String, String> input) {
//    	    	  data.masterSetupOpenOnly();
//    	          UserRestrictionsPage page = new UserRestrictionsPage(driver);
//
//    	          page.fillUserRestrictionsForm("OP Bill", "Only Selected", true, true);
//
//    	          if (page.isDuplicateErrorDisplayed()) {
//    	              System.out.println("Duplicate entry error is shown.");
//    	          } else {
//    	              System.out.println("Form submitted successfully.");
//    	          }
//    	      }
//
//    	      @Test(dataProvider = "getDataForLogin", priority = 19, dependsOnMethods = "login")
//    	      public void Hospital_ReferralFormPage (HashMap<String, String> input) {
//    	    	  data.masterSetupOpenOnly();
//    	    	  ReferralsPage referralForm = new ReferralsPage(driver);
//
//    	    	  referralForm.fillReferralForm(
//    	    	      "External Doctor",              // Referral type
//    	    	      "Dr. Ashwin",          // Name
//    	    	      "MediCare Clinic",     // Clinic
//    	    	      "ashwin@clinic.com",   // Email
//    	    	      "9876544220",          // Mobile
//    	    	      "9123457689",          // Alt Mobile
//    	    	      "123, Lake View Rd",   // Address
//    	    	      true                   // isActive checkbox
//    	    	  );
//
//    	      }
//
//    	      @Test(dataProvider = "getDataForLogin", priority = 20, dependsOnMethods = "login")
//    	      public void Hospital_VisitModePage (HashMap<String, String> input) {
//    	    	  data.masterSetupOpenOnly();
//    	    	  VisitModePage visitModePage = new VisitModePage(driver);
//    	    	  visitModePage.fillVisitModeForm("Outpatixxent", true);
//
//    	    	  if (visitModePage.isNameAlreadyExistsDisplayed()) {
//    	    	      System.out.println("Name Already Exists, try with a different one.");
//    	    	  }
//
//
//    	      }
//    	  
//    	      @Test(dataProvider = "getDataForLogin", priority = 21, dependsOnMethods = "login")
//    	      public void testFillPackageTypeForm(HashMap<String, String> input) {
//    	    	  data.masterSetupOpenOnly();
//    	          PackageTypePage packageTypePage = new PackageTypePage(driver);
//    	          packageTypePage.fillAndSubmitPackageTypeForm("Gold",true);
//    	      }
//    	      @Test(dataProvider = "getDataForLogin", priority = 22, dependsOnMethods = "login")
//    	      public void testFillValidityTypeForm(HashMap<String, String> input) {
//    	    	  data.masterSetupOpenOnly();
//    	    	  ValidityTypePage validityPage = new ValidityTypePage(driver);
//    	          validityPage.fillValidityTypeForm("Days", "30");
//    	      }
////    
//
//    	  
//
//    	          @Test(dataProvider = "getDataForLogin", priority = 22, dependsOnMethods = "login")
//    	          public void Accounts_PayerPage(HashMap<String, String> input) {
//    	         
//    	        	  data.masterSetupOpenOnly();
//
//    	              PayerPage payerPage = new PayerPage(driver);
//
//    	              payerPage.fillForm(
//    	                  "Corporate",                // Type
//    	                  "Test Payer",               // Payer Name
//    	                  "Private",                  // Policy Ownership
//    	                  "1234567890",               // Work Phone
//    	                  "test@payer.com",           // Office Email
//    	                  "https://payer.com",        // Website
//    	                  "John Doe",                 // Contact Name
//    	                  "9876543210",               // Mobile
//    	                  "8765432109",               // Alt Mobile
//    	                  "john.doe@payer.com",       // Contact Email
//    	                  "123 Main Street",          // Address
//    	                  "30",                       // Credit Days
//    	                  "18",                       // GST
//    	                  "10",                       // TDS
//    	                  "Timely Settlement",                  // Settlement Category
//    	                  true,                       // Is Active
//    	                  false                       // Variable Price
//    	              );
//
//    	              payerPage.clickSave();
//
//    	
//
//    	          
//    	          
//    	      }
//
//    	       @Test(dataProvider = "getDataForLogin", priority = 22, dependsOnMethods = "login")
//    	          public void Payer_Check_List_Page(HashMap<String, String> input) {
//    	    		  data.masterSetupOpenOnly();
//    	        	  Payer_Check_List_Page checklistPage = new Payer_Check_List_Page(driver);
//
//    	          checklistPage.fillChecklistForm(
//    	              "Document Header",
//    	              "Self",
//    	              "Initial Assessent",
//    	              "1",
//    	              true,   // Mandatory
//    	              true,   // Active
//    	              false   // Approve Required
//    	          );
//
//
//    	          }
//    	       @Test(dataProvider = "getDataForLogin", priority = 23, dependsOnMethods = "login")
//    	       public void Bank_Details_Page_Test(HashMap<String, String> input) {
//    	           data.masterSetupOpenOnly();  // Navigate to master setup or required page
//
//    	           BankPage bankPage = new BankPage(driver);  // Initialize page object
//
//    	           bankPage.fillBankDetailsForm(
//    	               "Ramiz Abdul",        // Account Name
//    	               "1234567890",         // Account Number
//    	               "SBIN0001234",        // IFSC Code
//    	               "SBI",                // Bank Name
//    	               "Main Branch",        // Branch Name
//    	               "Savings",            // Account Type
//    	               "123",
//    	               "Pharmacy"
//    	                                 // Active status
//    	           );
//    	       }
//    	       @Test(dataProvider = "getDataForLogin", priority = 24, dependsOnMethods = "login")
//    	       public void testAddLocationSetup(HashMap<String, String> input) {
//    	    	   
//    	           data.masterSetupOpenOnly(); // Navigate to Master Setup
//    	           LocationSetupPage locationPage = new LocationSetupPage(driver);
//
//    	           locationPage.fillLocationSetupForm("Central Store", "Near Wing A", "Fddf");
//    	       }

    
//    	       @Test(dataProvider = "getDataForLogin", priority = 25, dependsOnMethods = "login")
//    	       public void testLedgerCreation(HashMap<String, String> input) {
//    	
//    	           data.masterSetupOpenOnly();
//
//    	           LedgerDetailsPage ledgerPage = new LedgerDetailsPage(driver);
//    	           ledgerPage.fillLedgerForm("Cash Ledger1", "DOCTOR ACC", "LED123");
//    	       }

//    @Test(dataProvider = "getDataForLogin", priority = 26, dependsOnMethods = "login")
//    public void testCreateDischargeReason(HashMap<String, String> input) {
//
//        data.masterSetupOpenOnly();
//        DischargeReasonPage dischargeReasonPage = new DischargeReasonPage(driver);
//        dischargeReasonPage.clickbuttonapproval();
//        
//        dischargeReasonPage.enterName("Test Discharge Reason");
//
//        // Set Active
//        dischargeReasonPage.setIsActive(true);
//
//        // Click Save
//        dischargeReasonPage.clickSave();
//
//    }
//    
//    
//    @Test(dataProvider = "getDataForLogin", priority = 27, dependsOnMethods = "login")
//    public void testCreateAdmissionType(HashMap<String, String> input) {
//    	AdmissionTypePage admissionTypePage = new AdmissionTypePage(driver);
//        data.masterSetupOpenOnly();
//        admissionTypePage.clickbuttonapproval();
//        
//        admissionTypePage.enterAdmissionTypeName("Test Admission Type");
//
//        // Select Category
//        admissionTypePage.selectCategory("Emergency"); // replace with actual category from dropdown
//
//        // Set as Default
//        admissionTypePage.setDefault(true);
//
//        // Set Active
//        admissionTypePage.setActive(true);
//
//        // Click Save
//        admissionTypePage.clickSave();
//
//    }
//    
//    @Test(dataProvider = "getDataForLogin", priority = 28, dependsOnMethods = "login")
//    public void testCreateWardInformation(HashMap<String, String> input) {
//    	WardInformationPage   wardPage = new WardInformationPage(driver);;
//        data.masterSetupOpenOnly();
//        wardPage.clickbuttonapproval();
//        wardPage.enterWardName("General Ward A");
//        wardPage.selectWardMapping("1");
//        wardPage.enterFullDayTariff("5000");
//        wardPage.enterHalfDayTariff("2500");
//        wardPage.enterHourlyTariff("500");
//        wardPage.selectGST("5");
//        wardPage.enterPeopleAllowed("4");
//        List<String> facilities = Arrays.asList("Fan", "AC", "Toilet");
//        wardPage.selectFacilities(facilities);
//        
//        List<String> services = Arrays.asList("Blood Test","Blood Test2");
//        wardPage.selectComboService(services);
//        wardPage.selectCalculationMethod("24 HRS");
//        wardPage.setICU(false);
//        wardPage.setActive(true);
//
//        // Save
//        wardPage.clickSave();
//
//        // Add assertion (example: verify title or success popup)
//        String actualTitle = driver.getTitle();
//        Assert.assertTrue(actualTitle.contains("Ward"), "Page title does not contain 'Ward'");
//    }
//    
//    @Test(dataProvider = "getDataForLogin", priority = 29, dependsOnMethods = "login")
//    public void testAddBuilding(HashMap<String, String> input) {
//
//        data.masterSetupOpenOnly();
//        BuildingPage buildingPage = new BuildingPage(driver);
//        buildingPage.clickbuttonapproval();
//        buildingPage.enterBuildingName("Main Building - A");
//        buildingPage.clickSave();
//
//        // Example assertion (update as per your app response)
//        Assert.assertTrue(driver.getPageSource().contains("Saved Successfully"));
//    }
//    

//    
//    @Test(dataProvider = "getDataForLogin", priority = 29, dependsOnMethods = "login")
//    public void testAddFloorCreation(HashMap<String, String> input) {
//
//        data.masterSetupOpenOnly();
//        FloorPage floorPage = new FloorPage(driver);
//        floorPage.clickbuttonapproval();
//        floorPage.selectBuildingName("Main Building - A");
//
//        // Enter Floor Name
//        floorPage.enterFloorName("Second Floor");
//
//        // Cancel
//        floorPage.clickSave();
//
//        // Example assertion (update as per your app response)
//        Assert.assertTrue(driver.getPageSource().contains("Saved Successfully"));
//    }
//    
//    @Test(dataProvider = "getDataForLogin", priority = 30, dependsOnMethods = "login")
//    public void testAddRoom(HashMap<String, String> input) {
//
//        data.masterSetupOpenOnly();
//        RoomPage roomPage = new RoomPage(driver);
//        
//        roomPage.clickbuttonapproval();
//        roomPage.selectBuilding("Main Building - A");
//
//        // Select Floor
//        roomPage.selectFloor("Second Floor");
//
//        // Enter Room Number
//        roomPage.enterRoomNumber("101");
//
//        // Set Active
//        roomPage.setIsActive(true);
//
//        // Save
//        roomPage.clickSave();
//
//        // ✅ Example Assertion (replace with actual success message / redirect check)
//        Assert.assertTrue(driver.getPageSource().contains("Room saved successfully"), 
//                          "Room was not saved successfully!");
//    }
//    
//    @Test(dataProvider = "getDataForLogin", priority = 31, dependsOnMethods = "login")
//    public void testCreateNurseCounterSetup(HashMap<String, String> input) {
//
//        data.masterSetupOpenOnly();
//        NursingCounterPage nursingPage = new NursingCounterPage(driver);
//        nursingPage.clickbuttonapproval();
//        nursingPage.selectBuilding("Main Building - A");
//        nursingPage.selectFloor("Second Floor");
//        nursingPage.enterNursingCounterName("Emergency Counter");
//        nursingPage.setIsActive(true);
//        nursingPage.clickSave();
//
//    }
//    
//    @Test(dataProvider = "getDataForLogin", priority = 32, dependsOnMethods = "login")
//    public void testCreateBedSetup(HashMap<String, String> input) {
//
//        data.masterSetupOpenOnly();
//        BedPage bedSetupPage = new BedPage(driver);
//        bedSetupPage.clickbuttonapproval();
//        bedSetupPage.selectBedCategory("Bed");
//        bedSetupPage.selectBuilding("Main Building - A");
//        bedSetupPage.selectFloor("Second Floor");
//        bedSetupPage.selectRoom("101");
//        bedSetupPage.selectWard("General Ward A");
//        bedSetupPage.selectNursingCounter("Emergency Counter");
//        bedSetupPage.enterBedNumber("B-18");
//        bedSetupPage.setIsActive(true);
//
//        // Click Save
//        bedSetupPage.clickSave();
//
//        // Assertion (basic example – check URL or success message)
//        String currentUrl = driver.getCurrentUrl();
//        Assert.assertTrue(currentUrl.contains("bed-setup"), "Bed setup not saved successfully!");
//    }
//    
//    @Test(dataProvider = "getDataForLogin", priority = 33, dependsOnMethods = "login")
//    public void testCreateBedView(HashMap<String, String> input) {
//
//        data.masterSetupOpenOnly();
//        BedViewPage bedSetupPage = new BedViewPage(driver);
//        bedSetupPage.clickbuttonapproval();
//        bedSetupPage.clickOnBed("1");
//        
//    }
//    
//  @Test(dataProvider = "getDataForLogin", priority = 34, dependsOnMethods = "login")
//  public void testGraceChargesSetUpForm(HashMap<String, String> input) {
//
//      data.masterSetupOpenOnly();
//
//      GraceChargesSetUp grace = new GraceChargesSetUp(driver);
//      grace.clickbuttonapproval();
//      grace.selectDepartment("General");
//      grace.selectDoctor("Dr. zz");
//
//      grace.enterSubVisitValidity("5");
//      grace.enterSecondVisitValidity("10");
//      grace.enterThirdVisitValidity("15");
//
//      grace.clickTimingInfo();
//      grace.selectServiceForRow("OPD", "Blood Test");
//   // Complete fee structure for OPD
//      grace.enterOPFee("OPD", "100.00");
//      grace.enterIPFee("OPD", "200.00");
//      grace.enterMorningFirstVisitFee("OPD", "50.00");
//      grace.enterMorningFirstSubVisitFee("OPD", "25.00");
//      grace.enterMorningFirstVisitFeeToPhysician("OPD", "75.00");
//      grace.enterMorningFirstSubVisitFeeToPhysician("OPD", "40.00");
//      grace.enterMorningFirstOutsideLabReportFee("OPD", "30.00");
//      grace.enterMorningSecondVisitFee("OPD", "45.00");
//      grace.enterMorningSecondSubVisitFee("OPD", "20.00");
//      grace.enterMorningSecondVisitFeeToPhysician("OPD", "70.00");
//      grace.enterMorningSecondSubVisitFeeToPhysician("OPD", "35.00");
//      grace.enterMorningSecondOutsideLabReportFee("OPD", "25.00");
//      grace.enterMorningThirdVisitFee("OPD", "40.00");
//      grace.enterMorningThirdSubVisitFee("OPD", "15.00");
//      grace.enterMorningThirdVisitFeeToPhysician("OPD", "65.00");
//      grace.enterMorningThirdSubVisitFeeToPhysician("OPD", "30.00");
//      grace.enterMorningThirdOutsideLabReportFee("OPD", "20.00");
//      grace.enterMorningAfterThirdVisitFee("OPD", "35.00");
//      grace.enterMorningAfterThirdVisitFeeToPhysician("OPD", "60.00");
//      grace.enterMorningAfterThirdOutsideLabReportFee("OPD", "15.00");
//
//      // Noon fees
//      grace.enterNoonFirstVisitFee("OPD", "55.00");
//      grace.enterNoonFirstSubVisitFee("OPD", "28.00");
//      grace.enterNoonFirstVisitFeeToPhysician("OPD", "78.00");
//      grace.enterNoonFirstSubVisitFeeToPhysician("OPD", "42.00");
//      grace.enterNoonFirstOutsideLabReportFee("OPD", "32.00");
//      grace.enterNoonSecondVisitFee("OPD", "48.00");
//      grace.enterNoonSecondSubVisitFee("OPD", "22.00");
//      grace.enterNoonSecondVisitFeeToPhysician("OPD", "72.00");
//      grace.enterNoonSecondSubVisitFeeToPhysician("OPD", "37.00");
//      grace.enterNoonSecondOutsideLabReportFee("OPD", "27.00");
//      grace.enterNoonThirdVisitFee("OPD", "43.00");
//      grace.enterNoonThirdSubVisitFee("OPD", "17.00");
//      grace.enterNoonThirdVisitFeeToPhysician("OPD", "67.00");
//      grace.enterNoonThirdSubVisitFeeToPhysician("OPD", "32.00");
//      grace.enterNoonThirdOutsideLabReportFee("OPD", "22.00");
//      grace.enterNoonAfterThirdVisitFee("OPD", "38.00");
//      grace.enterNoonAfterThirdVisitFeeToPhysician("OPD", "62.00");
//      grace.enterNoonAfterThirdOutsideLabReportFee("OPD", "17.00");
//
//      // Evening fees
//      grace.enterEveningFirstVisitFee("OPD", "60.00");
//      grace.enterEveningFirstSubVisitFee("OPD", "30.00");
//      grace.enterEveningFirstVisitFeeToPhysician("OPD", "80.00");
//      grace.enterEveningFirstSubVisitFeeToPhysician("OPD", "45.00");
//      grace.enterEveningFirstOutsideLabReportFee("OPD", "35.00");
//      grace.enterEveningSecondVisitFee("OPD", "52.00");
//      grace.enterEveningSecondSubVisitFee("OPD", "25.00");
//      grace.enterEveningSecondVisitFeeToPhysician("OPD", "75.00");
//      grace.enterEveningSecondSubVisitFeeToPhysician("OPD", "40.00");
//      grace.enterEveningSecondOutsideLabReportFee("OPD", "30.00");
//      grace.enterEveningThirdVisitFee("OPD", "47.00");
//      grace.enterEveningThirdSubVisitFee("OPD", "20.00");
//      grace.enterEveningThirdVisitFeeToPhysician("OPD", "70.00");
//      grace.enterEveningThirdSubVisitFeeToPhysician("OPD", "35.00");
//      grace.enterEveningThirdOutsideLabReportFee("OPD", "25.00");
//      grace.enterEveningAfterThirdVisitFee("OPD", "42.00");
//      grace.enterEveningAfterThirdVisitFeeToPhysician("OPD", "65.00");
//      grace.enterEveningAfterThirdOutsideLabReportFee("OPD", "20.00");
//
//      // Night fees
//      grace.enterNightFirstVisitFee("OPD", "70.00");
//      grace.enterNightFirstSubVisitFee("OPD", "35.00");
//      grace.enterNightFirstVisitFeeToPhysician("OPD", "90.00");
//      grace.enterNightFirstSubVisitFeeToPhysician("OPD", "50.00");
//      grace.enterNightFirstOutsideLabReportFee("OPD", "40.00");
//      grace.enterNightSecondVisitFee("OPD", "60.00");
//      grace.enterNightSecondSubVisitFee("OPD", "30.00");
//      grace.enterNightSecondVisitFeeToPhysician("OPD", "85.00");
//      grace.enterNightSecondSubVisitFeeToPhysician("OPD", "45.00");
//      grace.enterNightSecondOutsideLabReportFee("OPD", "35.00");
//      grace.enterNightThirdVisitFee("OPD", "55.00");
//      grace.enterNightThirdSubVisitFee("OPD", "25.00");
//      grace.enterNightThirdVisitFeeToPhysician("OPD", "80.00");
//      grace.enterNightThirdSubVisitFeeToPhysician("OPD", "40.00");
//      grace.enterNightThirdOutsideLabReportFee("OPD", "30.00");
//      grace.enterNightAfterThirdVisitFee("OPD", "50.00");
//      grace.enterNightAfterThirdVisitFeeToPhysician("OPD", "75.00");
//      grace.enterNightAfterThirdOutsideLabReportFee("OPD", "25.00");
//      
//      grace.selectServiceForRow("General Ward A", "Blood Test2");
//      grace.enterOPFee("General Ward A", "120.00");
//      grace.enterIPFee("General Ward A", "250.00");
//      grace.enterMorningFirstVisitFee("General Ward A", "60.00");
//      grace.enterMorningFirstSubVisitFee("General Ward A", "30.00");
//      grace.enterMorningFirstVisitFeeToPhysician("General Ward A", "85.00");
//      grace.enterMorningFirstSubVisitFeeToPhysician("General Ward A", "45.00");
//      grace.enterMorningFirstOutsideLabReportFee("General Ward A", "35.00");
//      grace.enterMorningSecondVisitFee("General Ward A", "55.00");
//      grace.enterMorningSecondSubVisitFee("General Ward A", "25.00");
//      grace.enterMorningSecondVisitFeeToPhysician("General Ward A", "80.00");
//      grace.enterMorningSecondSubVisitFeeToPhysician("General Ward A", "40.00");
//      grace.enterMorningSecondOutsideLabReportFee("General Ward A", "30.00");
//      grace.enterMorningThirdVisitFee("General Ward A", "50.00");
//      grace.enterMorningThirdSubVisitFee("General Ward A", "20.00");
//      grace.enterMorningThirdVisitFeeToPhysician("General Ward A", "75.00");
//      grace.enterMorningThirdSubVisitFeeToPhysician("General Ward A", "35.00");
//      grace.enterMorningThirdOutsideLabReportFee("General Ward A", "25.00");
//      grace.enterMorningAfterThirdVisitFee("General Ward A", "45.00");
//      grace.enterMorningAfterThirdVisitFeeToPhysician("General Ward A", "70.00");
//      grace.enterMorningAfterThirdOutsideLabReportFee("General Ward A", "20.00");
//
//      // Noon fees for General Ward A
//      grace.enterNoonFirstVisitFee("General Ward A", "65.00");
//      grace.enterNoonFirstSubVisitFee("General Ward A", "32.00");
//      grace.enterNoonFirstVisitFeeToPhysician("General Ward A", "88.00");
//      grace.enterNoonFirstSubVisitFeeToPhysician("General Ward A", "47.00");
//      grace.enterNoonFirstOutsideLabReportFee("General Ward A", "37.00");
//      grace.enterNoonSecondVisitFee("General Ward A", "58.00");
//      grace.enterNoonSecondSubVisitFee("General Ward A", "27.00");
//      grace.enterNoonSecondVisitFeeToPhysician("General Ward A", "82.00");
//      grace.enterNoonSecondSubVisitFeeToPhysician("General Ward A", "42.00");
//      grace.enterNoonSecondOutsideLabReportFee("General Ward A", "32.00");
//      grace.enterNoonThirdVisitFee("General Ward A", "53.00");
//      grace.enterNoonThirdSubVisitFee("General Ward A", "22.00");
//      grace.enterNoonThirdVisitFeeToPhysician("General Ward A", "77.00");
//      grace.enterNoonThirdSubVisitFeeToPhysician("General Ward A", "37.00");
//      grace.enterNoonThirdOutsideLabReportFee("General Ward A", "27.00");
//      grace.enterNoonAfterThirdVisitFee("General Ward A", "48.00");
//      grace.enterNoonAfterThirdVisitFeeToPhysician("General Ward A", "72.00");
//      grace.enterNoonAfterThirdOutsideLabReportFee("General Ward A", "22.00");
//
//      // Evening fees for General Ward A
//      grace.enterEveningFirstVisitFee("General Ward A", "70.00");
//      grace.enterEveningFirstSubVisitFee("General Ward A", "35.00");
//      grace.enterEveningFirstVisitFeeToPhysician("General Ward A", "90.00");
//      grace.enterEveningFirstSubVisitFeeToPhysician("General Ward A", "50.00");
//      grace.enterEveningFirstOutsideLabReportFee("General Ward A", "40.00");
//      grace.enterEveningSecondVisitFee("General Ward A", "62.00");
//      grace.enterEveningSecondSubVisitFee("General Ward A", "30.00");
//      grace.enterEveningSecondVisitFeeToPhysician("General Ward A", "85.00");
//      grace.enterEveningSecondSubVisitFeeToPhysician("General Ward A", "45.00");
//      grace.enterEveningSecondOutsideLabReportFee("General Ward A", "35.00");
//      grace.enterEveningThirdVisitFee("General Ward A", "57.00");
//      grace.enterEveningThirdSubVisitFee("General Ward A", "25.00");
//      grace.enterEveningThirdVisitFeeToPhysician("General Ward A", "80.00");
//      grace.enterEveningThirdSubVisitFeeToPhysician("General Ward A", "40.00");
//      grace.enterEveningThirdOutsideLabReportFee("General Ward A", "30.00");
//      grace.enterEveningAfterThirdVisitFee("General Ward A", "52.00");
//      grace.enterEveningAfterThirdVisitFeeToPhysician("General Ward A", "75.00");
//      grace.enterEveningAfterThirdOutsideLabReportFee("General Ward A", "25.00");
//
//      // Night fees for General Ward A
//      grace.enterNightFirstVisitFee("General Ward A", "80.00");
//      grace.enterNightFirstSubVisitFee("General Ward A", "40.00");
//      grace.enterNightFirstVisitFeeToPhysician("General Ward A", "100.00");
//      grace.enterNightFirstSubVisitFeeToPhysician("General Ward A", "55.00");
//      grace.enterNightFirstOutsideLabReportFee("General Ward A", "45.00");
//      grace.enterNightSecondVisitFee("General Ward A", "70.00");
//      grace.enterNightSecondSubVisitFee("General Ward A", "35.00");
//      grace.enterNightSecondVisitFeeToPhysician("General Ward A", "95.00");
//      grace.enterNightSecondSubVisitFeeToPhysician("General Ward A", "50.00");
//      grace.enterNightSecondOutsideLabReportFee("General Ward A", "40.00");
//      grace.enterNightThirdVisitFee("General Ward A", "65.00");
//      grace.enterNightThirdSubVisitFee("General Ward A", "30.00");
//      grace.enterNightThirdVisitFeeToPhysician("General Ward A", "90.00");
//      grace.enterNightThirdSubVisitFeeToPhysician("General Ward A", "45.00");
//      grace.enterNightThirdOutsideLabReportFee("General Ward A", "35.00");
//      grace.enterNightAfterThirdVisitFee("General Ward A", "60.00");
//      grace.enterNightAfterThirdVisitFeeToPhysician("General Ward A", "85.00");
//      grace.enterNightAfterThirdOutsideLabReportFee("General Ward A", "30.00");
//      
//      grace.selectServiceForRow("ward1", "f");
//   // Complete fee structure for ward1
//      grace.enterOPFee("ward1", "150.00");
//      grace.enterIPFee("ward1", "300.00");
//      grace.enterMorningFirstVisitFee("ward1", "75.00");
//      grace.enterMorningFirstSubVisitFee("ward1", "38.00");
//      grace.enterMorningFirstVisitFeeToPhysician("ward1", "95.00");
//      grace.enterMorningFirstSubVisitFeeToPhysician("ward1", "50.00");
//      grace.enterMorningFirstOutsideLabReportFee("ward1", "40.00");
//      grace.enterMorningSecondVisitFee("ward1", "65.00");
//      grace.enterMorningSecondSubVisitFee("ward1", "30.00");
//      grace.enterMorningSecondVisitFeeToPhysician("ward1", "85.00");
//      grace.enterMorningSecondSubVisitFeeToPhysician("ward1", "45.00");
//      grace.enterMorningSecondOutsideLabReportFee("ward1", "35.00");
//      grace.enterMorningThirdVisitFee("ward1", "60.00");
//      grace.enterMorningThirdSubVisitFee("ward1", "25.00");
//      grace.enterMorningThirdVisitFeeToPhysician("ward1", "80.00");
//      grace.enterMorningThirdSubVisitFeeToPhysician("ward1", "40.00");
//      grace.enterMorningThirdOutsideLabReportFee("ward1", "30.00");
//      grace.enterMorningAfterThirdVisitFee("ward1", "55.00");
//      grace.enterMorningAfterThirdVisitFeeToPhysician("ward1", "75.00");
//      grace.enterMorningAfterThirdOutsideLabReportFee("ward1", "25.00");
//
//      // Noon fees for ward1
//      grace.enterNoonFirstVisitFee("ward1", "78.00");
//      grace.enterNoonFirstSubVisitFee("ward1", "39.00");
//      grace.enterNoonFirstVisitFeeToPhysician("ward1", "98.00");
//      grace.enterNoonFirstSubVisitFeeToPhysician("ward1", "52.00");
//      grace.enterNoonFirstOutsideLabReportFee("ward1", "42.00");
//      grace.enterNoonSecondVisitFee("ward1", "68.00");
//      grace.enterNoonSecondSubVisitFee("ward1", "32.00");
//      grace.enterNoonSecondVisitFeeToPhysician("ward1", "88.00");
//      grace.enterNoonSecondSubVisitFeeToPhysician("ward1", "47.00");
//      grace.enterNoonSecondOutsideLabReportFee("ward1", "37.00");
//      grace.enterNoonThirdVisitFee("ward1", "63.00");
//      grace.enterNoonThirdSubVisitFee("ward1", "28.00");
//      grace.enterNoonThirdVisitFeeToPhysician("ward1", "83.00");
//      grace.enterNoonThirdSubVisitFeeToPhysician("ward1", "42.00");
//      grace.enterNoonThirdOutsideLabReportFee("ward1", "32.00");
//      grace.enterNoonAfterThirdVisitFee("ward1", "58.00");
//      grace.enterNoonAfterThirdVisitFeeToPhysician("ward1", "78.00");
//      grace.enterNoonAfterThirdOutsideLabReportFee("ward1", "27.00");
//
//      // Evening fees for ward1
//      grace.enterEveningFirstVisitFee("ward1", "82.00");
//      grace.enterEveningFirstSubVisitFee("ward1", "41.00");
//      grace.enterEveningFirstVisitFeeToPhysician("ward1", "102.00");
//      grace.enterEveningFirstSubVisitFeeToPhysician("ward1", "55.00");
//      grace.enterEveningFirstOutsideLabReportFee("ward1", "45.00");
//      grace.enterEveningSecondVisitFee("ward1", "72.00");
//      grace.enterEveningSecondSubVisitFee("ward1", "35.00");
//      grace.enterEveningSecondVisitFeeToPhysician("ward1", "92.00");
//      grace.enterEveningSecondSubVisitFeeToPhysician("ward1", "50.00");
//      grace.enterEveningSecondOutsideLabReportFee("ward1", "40.00");
//      grace.enterEveningThirdVisitFee("ward1", "67.00");
//      grace.enterEveningThirdSubVisitFee("ward1", "30.00");
//      grace.enterEveningThirdVisitFeeToPhysician("ward1", "87.00");
//      grace.enterEveningThirdSubVisitFeeToPhysician("ward1", "45.00");
//      grace.enterEveningThirdOutsideLabReportFee("ward1", "35.00");
//      grace.enterEveningAfterThirdVisitFee("ward1", "62.00");
//      grace.enterEveningAfterThirdVisitFeeToPhysician("ward1", "82.00");
//      grace.enterEveningAfterThirdOutsideLabReportFee("ward1", "30.00");
//
//      // Night fees for ward1
//      grace.enterNightFirstVisitFee("ward1", "90.00");
//      grace.enterNightFirstSubVisitFee("ward1", "45.00");
//      grace.enterNightFirstVisitFeeToPhysician("ward1", "110.00");
//      grace.enterNightFirstSubVisitFeeToPhysician("ward1", "60.00");
//      grace.enterNightFirstOutsideLabReportFee("ward1", "50.00");
//      grace.enterNightSecondVisitFee("ward1", "80.00");
//      grace.enterNightSecondSubVisitFee("ward1", "40.00");
//      grace.enterNightSecondVisitFeeToPhysician("ward1", "100.00");
//      grace.enterNightSecondSubVisitFeeToPhysician("ward1", "55.00");
//      grace.enterNightSecondOutsideLabReportFee("ward1", "45.00");
//      grace.enterNightThirdVisitFee("ward1", "75.00");
//      grace.enterNightThirdSubVisitFee("ward1", "35.00");
//      grace.enterNightThirdVisitFeeToPhysician("ward1", "95.00");
//      grace.enterNightThirdSubVisitFeeToPhysician("ward1", "50.00");
//      grace.enterNightThirdOutsideLabReportFee("ward1", "40.00");
//      grace.enterNightAfterThirdVisitFee("ward1", "70.00");
//      grace.enterNightAfterThirdVisitFeeToPhysician("ward1", "90.00");
//      grace.enterNightAfterThirdOutsideLabReportFee("ward1", "35.00");
//      
//  }
    
    @Test(dataProvider = "getDataForLogin", priority = 35, dependsOnMethods = "login")
  public void testCreateBedView(HashMap<String, String> input) {

      data.masterSetupOpenOnly();
      SocialHabits social= new SocialHabits(driver);
    
      social.clickbuttonapproval();
      social.enterSocialHabitName("fgf");
      social.setIsActive(true);
      social.enterAttribute("gg");
      social.clickAddAttribute();
      social.clickSave();
  }  
  
  @Test(dataProvider = "getDataForLogin", priority = 36, dependsOnMethods = "login")
  public void allergy(HashMap<String, String> input) {

      data.masterSetupOpenOnly();
      Allergy allerg= new Allergy(driver);
      allerg.clickbuttonapproval();
      allerg.enterAllergyName("cc");
      allerg.enterAttribute("dd");
      allerg.clickAddAttribute();
      allerg.clickSave();
   
  }  
  
  @Test(dataProvider = "getDataForLogin", priority = 37, dependsOnMethods = "login")
  public void MEDICALHISTORY1(HashMap<String, String> input) {

      data.masterSetupOpenOnly();
      Allergy allerg= new Allergy(driver);
      allerg.clickaddmedicalhistory();
      allerg.dropdown();
      allerg.selectTypeFromNgxSelect("Mental General");
      allerg.enterAllergyName("cc");
      allerg.enterAttribute("dd");
      allerg.clickAddAttribute();
      allerg.clickSave();
   
  }  
  
//  @Test(dataProvider = "getDataForLogin", priority = 37, dependsOnMethods = "login")
//  public void MEDICALHISTORY(HashMap<String, String> input) throws InterruptedException {
//
//      data.masterSetupOpenOnly();
//      Allergy allerg= new Allergy(driver);
//      allerg.clickByText("Service");
//      allerg.clickByText("Lab Test");
//      Thread.sleep(5000);
//      allerg.clickActionByCategoryttt("Blood Sugar"," //a[@title='Edit']");
//      Thread.sleep(5000);
//      allerg.byTextAttach("Mins","/ancestor::div[1]//input").clear();
//      allerg.byTextAttach("Mins","/ancestor::div[1]//input").sendKeys("30");
//      allerg.clickByButtonValue("Save");
//  } 
//  
//  @Test(dataProvider = "getDataForLogin", priority = 37, dependsOnMethods = "login")
//  public void PayerEsc(HashMap<String, String> input) throws InterruptedException {
//
//      data.masterSetupOpenOnly();
//      Allergy allerg= new Allergy(driver);
//      allerg.clickByText("Payer",2);
//      allerg.clickActionByCategoryttt("Test Payer","//a[@title='View/Edit']");
//      allerg.clickByText("ESIC");
//      allerg.clickByButtonValue("Update");
//      data.masterSetupOpenOnly();
//      allerg.clickByText("Service");
//      Thread.sleep(5000);
//      allerg.clickActionByCategoryttt("Blood Test","//a[@title='Edit']");
//      allerg.clickByButtonValue("Enable to Edit");
//      Thread.sleep(5000);     
//      allerg.byTextAttach("ESIC Panel", "/ancestor::div[1]//div[@class='ngx-select__selected ng-star-inserted']").click();
//      allerg.selectTypeFromNgxSelect("panel 3");
//      allerg.clickByButtonValue("Update");
//      
//  } 
    
    @DataProvider
    public Object[][] getDataForLogin() throws IOException {
        List<HashMap<String, String>> data = getJsonDataToMap(
            System.getProperty("user.dir") + "//src//main//java//ezion//Resources//WareHouseMaster.json"
        );
        return new Object[][] { { data.get(0) } };
    }
}
