
package WareHouseSetup.Accounts;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import EzionAbstractionComponents.Abstraction;

public class Payer_Check_List_Page extends Abstraction {

    public Payer_Check_List_Page(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    // --- Dropdowns ---
    @FindBy(xpath = "//label[contains(text(),'Checklist Header')]/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement checklistHeaderDropdown;

    @FindBy(xpath = "//label[contains(text(),'Type')]/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement typeDropdown;

    @FindBy(xpath = "//div[contains(@class,'ngx-select__item')]")
    private List<WebElement> dropdownOptions;

    // --- Text Inputs ---
    @FindBy(xpath = "//input[@formcontrolname='checkListName']")
    private WebElement checklistNameInput;

    @FindBy(xpath = "//input[@formcontrolname='rowNumber']")
    private WebElement rowNumberInput;

    // --- Checkboxes ---
    @FindBy(xpath = "//label[contains(., 'Mandatory Flag')]//span[@class='checkmark']")
    private WebElement mandatoryCheckbox;

    @FindBy(xpath = "//label[contains(., 'Active Flag')]//span[@class='checkmark']")
    private WebElement activeFlagCheckbox;

    @FindBy(xpath = "//label[contains(., 'Approve Required Flag')]//span[@class='checkmark']")
    private WebElement approveRequiredFlagCheckbox;

    // --- Buttons ---
    @FindBy(xpath = "//input[@type='button' and @value='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
    private WebElement cancelButton;
    
    @FindBy(xpath = "//a[text()=' Payer Check-List']")
    private WebElement userType;

    @FindBy(xpath = "//a[text()=' Add Payer Check List ']")
    private WebElement adduserType;
     
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}
    // ==========================
    // ==== Action Methods ======
    // ==========================

    public void selectChecklistHeader(String optionText) {
        selectDynamicDropdown(checklistHeaderDropdown, optionText);
    }

    public void selectType(String optionText) {
        selectDynamicDropdown(typeDropdown, optionText);
    }


    public void enterChecklistName(String name) {
        waitForVisibility(checklistNameInput).sendKeys(name);
    }

    public void enterRowNumber(String row) {
        waitForVisibility(rowNumberInput).sendKeys(row);
    }

    public void setMandatoryFlag(boolean check) {
        setCheckbox(mandatoryCheckbox, check);
    }

    public void setActiveFlag(boolean check) {
        setCheckbox(activeFlagCheckbox, check);
    }

    public void setApproveRequiredFlag(boolean check) {
        setCheckbox(approveRequiredFlagCheckbox, check);
    }

    public void clickSave() {
        waitForClickability(saveButton).click();
    }

    public void clickCancel() {
        waitForClickability(cancelButton).click();
    }

    // ==========================
    // ====== Utilities =========
    // ==========================

    private void selectDynamicDropdown(WebElement dropdownToggle, String valueToSelect) {
        // Open the dropdown
        waitForClickability(dropdownToggle).click();

        // Wait for options to load dynamically
        List<WebElement> options = waitForPresenceOfAll(By.xpath("//a[contains(@class,'ngx-select__item') and contains(@class,'dropdown-item')]/span"));

        // Scroll + select matching option
        for (WebElement option : options) {
            String optionText = option.getText().trim();
            System.out.println(optionText);
            if (optionText.equalsIgnoreCase(valueToSelect)) {
                waitForClickability(option).click();
                return;
            }
        }

        throw new RuntimeException("Option '" + valueToSelect + "' not found in dropdown.");
    }

    private void setCheckbox(WebElement checkbox, boolean shouldCheck) {
        if (checkbox.isSelected() != shouldCheck) {
            waitForClickability(checkbox).click();
        }
    }
    
    public void fillChecklistForm(
    	    String checklistHeader,
    	    String type,
    	    String checklistName,
    	    String rowNumber,
    	    boolean mandatoryFlag,
    	    boolean activeFlag,
    	    boolean approveRequiredFlag
    	) {
    	    // Select dropdown: Checklist Header
    	clickbuttonapproval();
    	    selectChecklistHeader(checklistHeader);

    	    // Select dropdown: Type
    	    selectType(type);

    	    // Enter checklist name
    	    enterChecklistName(checklistName);

    	    // Enter row number
    	    enterRowNumber(rowNumber);

    	    // Set checkbox states
    	    setMandatoryFlag(mandatoryFlag);
    	    setActiveFlag(activeFlag);
    	    setApproveRequiredFlag(approveRequiredFlag);

    	    // Click Save button
    	    clickSave();
    	}

}
