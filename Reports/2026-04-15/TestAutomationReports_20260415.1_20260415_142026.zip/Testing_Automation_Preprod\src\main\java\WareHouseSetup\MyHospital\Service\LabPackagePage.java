package WareHouseSetup.MyHospital.Service;





	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;

	import EzionAbstractionComponents.Abstraction;

	public class LabPackagePage extends Abstraction {

	    WebDriver driver;

	    public LabPackagePage(WebDriver driver) {
	    	super(driver);
	        this.driver = driver;
	        PageFactory.initElements(driver, this);
	    }

	    // Locators

	    @FindBy(xpath = "(//input[@formcontrolname='name'])[6]")
	    private WebElement labGroupNameInput;

	    @FindBy(xpath = "(//input[@formcontrolname='price'])[4]")
	    private WebElement labGroupPriceInput;

	    @FindBy(xpath = "(//ngx-select[@formcontrolname='isActive']//div[contains(@class,'ngx-select__toggle')])[2]")
	    private WebElement isActiveDropdown;

	    @FindBy(xpath = "(//ngx-select[@formcontrolname='isEditable']//div[contains(@class,'ngx-select__toggle')])[2]")
	    private WebElement allowEditingDropdown;

	    @FindBy(xpath = "(//ngx-select[@formcontrolname='scid']//div[contains(@class,'ngx-select__toggle')])[4]")
	    private WebElement serviceCategoryDropdown;

	    @FindBy(xpath = "(//ngx-select[@formcontrolname='sscid']//div[contains(@class,'ngx-select__toggle')])[4]")
	    private WebElement departmentDropdown;
	    
	    @FindBy(xpath = "(//ngx-select[@formcontrolname='gst']//div[contains(@class,'ngx-select__toggle')])[4]")
	    private WebElement gstDropdown;

	    @FindBy(xpath = "(//input[@formcontrolname='srvReqNo'])[4]")
	    private WebElement serviceRequestNumberInput;

	    @FindBy(xpath = "(//label[contains(text(),'Allow Zero ')])[4]")
	    private WebElement allowZeroCheckbox;

	    @FindBy(xpath = "//input[@formcontrolname='isNotes']")
	    private WebElement addNotesCheckbox;

	    @FindBy(xpath = "(//input[@name='restrictType' and @value='1'])[4]")
	    private WebElement restrictAllRadio;

	    @FindBy(xpath = "(//input[@name='restrictType' and @value='2'])[4]") //
	    private WebElement restrictWeekdaysRadio;

	    @FindBy(xpath = "(//input[@name='restrictType' and @value='3'])[4]")
	    private WebElement restrictWeekendRadio;

	    @FindBy(xpath = "(//input[@name='restrictType' and @value='4'])[4]")
	    private WebElement restrictManualRadio;

	    @FindBy(xpath = "(//ngx-select[@formcontrolname='ltid']//div[contains(@class,'ngx-select__toggle')])[2]")
	    private WebElement selectLabTestDropdown;

	    @FindBy(xpath = "(//input[@value='Add'])[2]")
	    private WebElement addLabTestButton;

	    @FindBy(xpath = "//input[@value='Save']")
	    private WebElement saveButton;

	    @FindBy(xpath = "//input[@value='Cancel']")
	    private WebElement cancelButton;

	    // Methods
	    @FindBy(xpath = "//span[text()='Lab Package']")
	    private WebElement serviceTab;

	    @FindBy(xpath = "//a[contains(@class,'btn-plus') and .//img[@alt='add']]")
	    private WebElement addServiceBtn;
	    // ========== Form Fill Method ==========

	    public void openServiceForm() {
	    	clickWithJavaScript(serviceTab);
	    	clickWithJavaScript(addServiceBtn);
	    }
	    public void enterLabGroupName(String name) {
	        labGroupNameInput.clear();
	        labGroupNameInput.sendKeys(name);
	    }

	    public void enterLabGroupPrice(String price) {
	        labGroupPriceInput.clear();
	        labGroupPriceInput.sendKeys(price);
	    }

	    public void clickIsActiveDropdown() {
	        isActiveDropdown.click();
	    }

	    public void clickAllowEditingDropdown() {
	        allowEditingDropdown.click();
	    }

	    public void selectServiceCategory() {
	        serviceCategoryDropdown.click();
	        // add code to select specific value from dropdown if required
	    }
	    public void selectDepartment() {
	        departmentDropdown.click();
	        // add code to select specific value from dropdown if required
	    }

	    public void selectGST() {
	        gstDropdown.click();
	        // add code to select specific value from dropdown if required
	    }

	    public void enterServiceRequestNumber(String srNo) {
	        serviceRequestNumberInput.clear();
	        serviceRequestNumberInput.sendKeys(srNo);
	    }

	    public void toggleAllowZero(boolean value) {
	        if (allowZeroCheckbox.isSelected() != value) {
	            allowZeroCheckbox.click();
	        }
	    }

	    public void toggleAddNotes(boolean value) {
	        if (addNotesCheckbox.isSelected() != value) {
	            addNotesCheckbox.click();
	        }
	    }

	    public void selectRestrictAll() {
	        restrictAllRadio.click();
	    }

	    public void selectRestrictWeekdays() {
	        restrictWeekdaysRadio.click();
	    }

	    public void selectRestrictWeekend() {
	        restrictWeekendRadio.click();
	    }

	    public void selectRestrictManual() {
	        restrictManualRadio.click();
	    }

	    public void selectLabTest() {
	        selectLabTestDropdown.click();
	        // add selection logic
	    }

	    public void clickAddLabTest() {
	        addLabTestButton.click();
	    }

	    public void clickSave() {
	        saveButton.click();
	    }

	    public void clickCancel() {
	        cancelButton.click();
	    }
	    public void selectDropdownOption(String text) {
	        WebElement option = driver.findElement(
	            By.xpath("//ul[contains(@class,'ngx-select__choices')]//a[contains(@class,'ngx-select__item')]//span[text()='" + text + "']")
	        );
	        waitForClickability(option).click();
	    }
	    public void fillForm(
	            String groupName,
	            String price,
	            String isActiveOption,
	            String allowEditingOption,
	            String serviceCategory,
	            String department,
	            String gst,
	            String serviceRequestNo,
	            boolean allowZero,
	            boolean addNotes,
	            String restrictType, // "All", "Weekdays", "Weekend", or "Manual"
	            String labTestToSelect
	    ) {
	    	openServiceForm();
	        enterLabGroupName(groupName);
	        enterLabGroupPrice(price);

	        // Dropdown selections
	        clickIsActiveDropdown();
	        selectDropdownOption(isActiveOption);

	        clickAllowEditingDropdown();
	        selectDropdownOption(allowEditingOption);

	        selectServiceCategory();
	        selectDropdownOption(serviceCategory);

//	        selectDepartment();
//	        selectDropdownOption(department);

	        selectGST();
	        selectDropdownOption(gst);

	        enterServiceRequestNumber(serviceRequestNo);
	        toggleAllowZero(allowZero);
//	        toggleAddNotes(addNotes);

	        // Radio button for restrict type
	        switch (restrictType.toLowerCase()) {
	            case "all":
	                selectRestrictAll();
	                break;
	            case "weekdays":
	                selectRestrictWeekdays();
	                break;
	            case "weekend":
	                selectRestrictWeekend();
	                break;
	            case "manual":
	                selectRestrictManual();
	                break;
	            default:
	                throw new IllegalArgumentException("Invalid restrict type: " + restrictType);
	        }

	        // Lab test dropdown and selection
	        selectLabTest();
	        selectDropdownOption(labTestToSelect);
	        clickAddLabTest();

	        // Save form
//	        clickSave();
	    }

	}



