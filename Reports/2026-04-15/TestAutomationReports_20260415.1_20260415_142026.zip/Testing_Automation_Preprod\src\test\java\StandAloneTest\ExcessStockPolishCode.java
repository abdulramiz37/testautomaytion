
	package StandAloneTest;

	import java.time.Duration;
	import java.util.List;
import java.util.concurrent.TimeoutException;

import org.openqa.selenium.By;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.edge.EdgeDriver;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.WebDriverWait;
	import org.testng.annotations.Test;

	@Test
	public class ExcessStockPolishCode {
	    public void PPLE() {
	        WebDriver driver = new EdgeDriver();
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	        driver.get("https://apps.ezovion.com/auth/login");
	        driver.manage().window().maximize();

	        // Login
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class=\"form-control-group\"]//input")))
	            .sendKeys("50107299");
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@size=\"large\"]"))).click();
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")))
	            .sendKeys("7766554433");
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Password\"]")))
	            .sendKeys("12345");
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@status=\"primary\"]"))).click();

	        // Navigate to Admin > Roles Management
	        for (int i = 0; i < 5; i++) {
	            try {
	                WebElement adminTab = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Admin']")));
	                adminTab.click();
	                wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Roles Management']"))).click();
	                break;
	            } catch (Exception e) {
	                System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
	                if (i == 4) throw e;
	            }
	        }

	        // Navigate through menus
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Masters']"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Master Set-up']"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Medicine']"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Add Medicine ']"))).click();

	        // Generate unique medicine name
	        String baseName = "SyrupEzovion ";
	        int counter =1;
	        String supplierName = baseName + counter;
	        WebElement nameField = wait.until(ExpectedConditions.visibilityOfElementLocated(
	            By.xpath("(//input[@type='text'])[3]")));

	        while (true) {
	            nameField.clear();
	            nameField.sendKeys(supplierName);
	            
	            // Wait a brief moment for the validation to complete
	            try {
	                // Check for absence of error message with a short timeout
	                new WebDriverWait(driver, Duration.ofSeconds(0))
	                    .until(ExpectedConditions.invisibilityOfElementLocated(
	                        By.xpath("//span[contains(text(),'Name Already Exists..')]")));
	                
	                System.out.println("Supplier added with name: " + supplierName);
	                break;
	            } catch (org.openqa.selenium.TimeoutException e) {
	                // Error message is still present or appeared
	                counter++;
	                supplierName = baseName + counter;
	            }
	        }
	    	wait.until(webDriver -> ((JavascriptExecutor) webDriver)
				    .executeScript("return document.readyState").equals("complete"));
	        // Complete medicine details
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[4]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Schedule A1']"))).click();
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[5]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()=' SHOULDER IMBO']"))).click();
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[6]"))).click();

	        // Retry logic for CALTEN click
	        for (int i = 0; i < 2; i++) {
	            try {
	                wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='\tCALTEN']"))).click();
	                break;
	            } catch (Exception e) {
	                System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
	                if (i == 1) throw e;
	            }
	        }

	        // Complete remaining medicine details
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[7]"))).click();
	        
	        // Retry logic for Bisacodyl click
	        for (int i = 0; i < 11; i++) {
	            try {
	                WebElement element = wait.until(ExpectedConditions.elementToBeClickable(
	                    By.xpath("//span[text()=' Bisacodyl Ip: 5 ']")));
	                element.click();
	                break;
	            } catch (Exception e) {
	                System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
	                if (i == 10) throw e;
	            }
	        }

	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[8]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='ajhj']"))).click();
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='number'])[1]")))
	            .sendKeys("5000");
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='minQty']")))
	            .sendKeys("10");
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='maxQty']")))
	            .sendKeys("50");
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[12]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='0']"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();

	        // Add opening stock
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Pharmacy']"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[@title='Stock'])[1]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[@title='Opening Stock'])[1]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()='Add Opening Stock']"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Pharamacy Loaction'])[1]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Select ']"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='" + supplierName + "'])[1]"))).click();

	        // Fill stock details
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='batchNumber']")))
	            .sendKeys("456");
	        
	        WebElement expiry = wait.until(ExpectedConditions.visibilityOfElementLocated(
	            By.xpath("//input[@formcontrolname='expiryDate']")));
	        ((JavascriptExecutor) driver).executeScript(
	            "arguments[0].value='2025-07'; arguments[0].dispatchEvent(new Event('input'));", expiry);

	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='pricePerStrips']")))
	            .sendKeys("4");
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='mrpPerStrip']")))
	            .sendKeys("4");
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='sellPriceStrip']")))
	            .sendKeys("4");
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='qtyInStrips']")))
	            .sendKeys("4");
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='qtyInUnits']")))
	            .sendKeys("4");
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();

	  
	    }
	
}
