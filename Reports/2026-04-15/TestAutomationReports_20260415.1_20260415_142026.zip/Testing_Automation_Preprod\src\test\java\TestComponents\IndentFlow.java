package TestComponents;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EzionpageObjects.UserIdPage;
import PharmacyIndentFlow.IndentApprovalTablePage;
import PharmacyIndentFlow.IndentIssue;
import PharmacyIndentFlow.IndentRequestPage;
import PharmacyIndentFlow.IndentRequestTablePage;
import abdulTest.BaseTest;

public class IndentFlow extends BaseTest {

    @Test(dataProvider = "getData")
    public void IndentFlowTest(HashMap<String, String> input) throws InterruptedException {
        // Login
        UserIdPage data = login.login(input.get("userId"));
        data.enterMobileNumber(input.get("personId"));
        data.enterPassword(input.get("password"));
        data.clickContinue();

        // Navigate to Indent Page
        IndentRequestPage indentPage = data.indentPage();
        indentPage.openIndentRequestPage();

        // Complete the indent creation flow
        indentPage.completeIndentRequestFlow(
            input.get("location"),
            input.get("RequestedBy"),
            input.get("department"),
            input.get("medicineCardTitle"),
            input.get("quantity")
        );

        // Go to table page and perform actions
        IndentRequestTablePage indentTable = indentPage.save2();

        // Search for the indent with status "NEW" and edit it
        String indentNumber = indentTable.findAndEditIndentWithStatus("New");


            indentTable.clickSendRequest();

            // Move to approval flow
            IndentApprovalTablePage indentApproval = indentTable.indentApproval();
           indentApproval.findAndEditIndentForApproval(indentNumber);

           
           IndentIssue indentIssue=      indentApproval.clickUpdateButton();
     
                
           indentIssue.findAndClickReceiveButton(indentNumber);
           indentIssue.completeReceiveFlow(input.get("quantity"));
       
         
        
    }

    @DataProvider
    public Object[][] getData() throws IOException {
        List<HashMap<String, String>> data = getJsonDataToMap(
            System.getProperty("user.dir") + "//src//main//java//ezion//Resources//IndentFlow.json"
        );
        return new Object[][] { { data.get(0) } };
    }
}
