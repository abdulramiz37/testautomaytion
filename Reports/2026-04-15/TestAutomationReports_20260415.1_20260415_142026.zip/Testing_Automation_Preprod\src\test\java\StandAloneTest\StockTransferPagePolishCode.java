package StandAloneTest;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

@Test
public class StockTransferPagePolishCode {
    public void PPLE() {
        WebDriver driver = new EdgeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://apps.ezovion.com/auth/login");
        driver.manage().window().maximize();
        
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

        // Login process
        driver.findElement(By.xpath("//div[@class=\"form-control-group\"]//input")).sendKeys("50107299");
        driver.findElement(By.xpath("//button[@size=\"large\"]")).click();
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
        driver.findElement(By.xpath("//input[@placeholder=\"Mobile No\"]")).sendKeys("7766554433");
        driver.findElement(By.xpath("//input[@placeholder=\"Password\"]")).sendKeys("12345");
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@status=\"primary\"]"))).click();
        
        // Navigate to Admin > Roles Management
        for (int i = 0; i < 5; i++) {
            try {
                WebElement adminTab = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Admin']")));
                adminTab.click();
                wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Roles Management']"))).click();
                break;
            } catch (Exception e) {
                System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
                if (i == 4) throw e;
            }
        }
        
        // Navigate through Pharmacy menu
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Pharmacy']"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Indent'])[1]"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Stock Transfer'])[1]"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[text()=' Add Transfer '])[1]"))).click();
        
        // Fill transfer form
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='issueDate']"))).sendKeys("06/21/2025");
        
        // Transfer by
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[text()='Transfer by']/following::div[contains(@class,'ngx-select__toggle')][1]"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Fddf')]"))).click();
        
        // Destination Location
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[text()='Destination Location']/following::div[contains(@class,'ngx-select__toggle')][1]"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[contains(text(),'Pharamacy Loaction')])[2]"))).click();
        
        // Destination Warehouse
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[text()='Destination Warehouse']/following::div[contains(@class,'ngx-select__toggle')][1]"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'primary warehouse')]"))).click();
        
        // Transfer Status
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[text()='Transfer Status']/following::div[contains(@class,'ngx-select__toggle')][1]"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Approved')]"))).click();
        
        // Add product
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Search Medicine'])[1]"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='mat-option-text'][.//h4[contains(normalize-space(),'medicine1syrup')]]"))).click();
        
        // Set quantity and add
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='quantity']"))).sendKeys("4");
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Add']"))).click();
        
        // Save using JavaScript click
        WebElement saveButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']")));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", saveButton);
        
        // Clean up (you might want to add this)
        // driver.quit();
    }
}