package TestComponents;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EzionpageObjects.UserIdPage;
import PharmacyPurchaseOrder.POTrackingPage;
import PharmacyPurchaseOrder.PharmacyPoOrderPurchasePage;
import PharmacyPurchaseOrder.PharmacyPurchaseOrderPage;
import PharmacyPurchaseOrder.PharmacyPurchaseOrderTable;
import abdulTest.BaseTest;

public class PharmacyPurchaseOrder2 extends BaseTest {

    UserIdPage data;
    PharmacyPurchaseOrderPage purchaseOrderPage;
    PharmacyPurchaseOrderTable orderTable;
    POTrackingPage poTrackingPage;
    PharmacyPoOrderPurchasePage poOrderPurchasePage;
    HashMap<String, String> input;
    String poNumber;

    
    @Test(dataProvider = "getData")
    public void PharmacyPurchaseOrder2_Login(HashMap<String, String> input) throws InterruptedException {
        this.input = input;
        String userId = prop.getProperty("USER_ID");
        String personId = prop.getProperty("PERSON_ID");
        String password = prop.getProperty("PASSWORD");
        String browser = System.getProperty("BROWSER");
        data = login.login(userId);
        data.enterMobileNumber(personId);
        data.enterPassword(password);
        data.clickContinue();
       
        System.out.println("Browser: " + browser);
//        System.out.println("Base URL: " + baseUrl);
        System.out.println("User ID: " + userId);
        System.out.println("Person ID: " + personId);
        data.navigateSalesWithRetrystart();
    }

    @Test(dependsOnMethods = "PharmacyPurchaseOrder2_Login")
    public void PharmacyPurchaseOrder2_CreateAndSavePO() {
        purchaseOrderPage = data.orderPage();

        purchaseOrderPage.createPurchaseOrder(
        		 input.get("location"),	
            input.get("supplierName"),
            input.get("userName"),
            input.get("deliveryDate"),
            input.get("medicineName"),
            input.get("strips"),
            input.get("freeStrips"),
            input.get("mrp"),
            input.get("price")
        );

        orderTable = purchaseOrderPage.save();
    }

    @Test(dependsOnMethods = "PharmacyPurchaseOrder2_CreateAndSavePO")
    public void PharmacyPurchaseOrder2_ApproveFirstTabPO() {
        boolean found = orderTable.clickEditOnPurchaseOrder(
            input.get("supplierName"),
            input.get("statusToEdit")
        );

     // Enable checkbox
        orderTable.toggleChangePOStatus(true);

        // Select PO Status
        orderTable.selectPOStatus("Sent to Approve");
        orderTable.selectFinalVerificationBy("Employee");
        orderTable.selectEmployee("Fddf");


        // Enter Notes
        orderTable.enterNotes("Cancel due to wrong item");

        // Click Update
        orderTable.clickUpdate();
    }

    @Test(dependsOnMethods = "PharmacyPurchaseOrder2_ApproveFirstTabPO")
    public void PharmacyPurchaseOrder2_EditSecondTabPO() {
        poNumber = orderTable.clickEditFromSecondTabAndUpdate(
            input.get("supplierName"),
            input.get("secondTabStatus")
        );
        System.out.println("✅ Updated PO Number: " + poNumber);
    }
//
    @Test(dependsOnMethods = "PharmacyPurchaseOrder2_EditSecondTabPO")
    public void PharmacyPurchaseOrder2_VerifyPOInTrackingPage() throws InterruptedException {
    	   orderTable.toggleChangePOStatus(true);

           // Select PO Status
           orderTable.selectPOStatus("Approved");
//           Thread.sleep(5000);
           orderTable.selectFinalVerificationBy2("Fddf (Employee)");
//           orderTable.selectEmployee("Fddf (Employee)");


           // Enter Notes
           orderTable.enterNotes("Cancel due to wrong item");

           // Click Update
           orderTable.clickUpdate();
    }
//
//    @Test(dependsOnMethods = "PharmacyPurchaseOrder2_VerifyPOInTrackingPage")
//    public void PharmacyPurchaseOrder2_FillPurchaseForm() {
//        poOrderPurchasePage = poTrackingPage.selectPharmacyLocation();
//        poOrderPurchasePage.selectPharmacyLocation(input.get("pharmacyLocation"));
//        poOrderPurchasePage.enterUniqueInvoiceNumber(input.get("invoiceNumber"));
//        poOrderPurchasePage.setInvoiceDates(input.get("invoiceDate"));
//        poOrderPurchasePage.searchAndSelectMedicine(input.get("medicineName"));
//        poOrderPurchasePage.enterBatchAndExpiry(input.get("batchNumber"), input.get("expiryDate"));
//        poOrderPurchasePage.enterPayableAmountAndSubmit();
//    }
//
    @DataProvider
    public Object[][] getData() throws IOException {
        List<HashMap<String, String>> data = getJsonDataToMap(
            System.getProperty("user.dir") + "//src//main//java//ezion//Resources//PharmacyPurchaseOrder.json"
        );
        return new Object[][] { { data.get(0) } };
    }
}
