package Appointment;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class PayerDetailPage extends Abstraction {

    private WebDriver driver;

    public PayerDetailPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // ------------------ COMMON LOCATORS ------------------

    // TAB Navigation
    @FindBy(xpath = "//span[normalize-space()='Payer Detail']")
    private WebElement payerDetailTab;

    // Payer Details
    @FindBy(xpath = "//label[text()=' Payer Type']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement payerTypeDropdown;

    @FindBy(xpath = "//label[text()=' Payer Sub Type ']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement payerSubTypeDropdown;

    // Credit Details (Common for all)
    @FindBy(xpath = "//input[@formcontrolname='creditLimit']")
    private WebElement creditLimitInput;

    @FindBy(xpath = "//input[@formcontrolname='approvalAmt']")
    private WebElement approvalAmountInput;

    @FindBy(xpath = "//label[text()=' Status']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement statusDropdown;

    @FindBy(xpath = "//input[@formcontrolname='claimAuthorizationNo']")
    private WebElement claimAuthorizationNoInput;

    @FindBy(xpath = "//input[@formcontrolname='same_payer_for_multiple_bills']")
    private WebElement samePayerForMultipleBillsCheckbox;

    @FindBy(xpath = "//input[@formcontrolname='isAmtValidationFlag']")
    private WebElement skipAmountValidationCheckbox;

    // ECHS Details (Common for all when ECHS sub-type selected)
    @FindBy(xpath = "//input[@formcontrolname='srvNo']")
    private WebElement serviceNoInput;

    @FindBy(xpath = "//label[contains(text(),'Service Department')]/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement serviceDepartmentDropdown;

    @FindBy(xpath = "//input[@formcontrolname='srvRegNo']")
    private WebElement regNoInput;

    // Buttons
    @FindBy(xpath = "//input[@value='Save Payer']")
    private WebElement savePayerButton;

    @FindBy(xpath = "//input[@value='Cancel']")
    private WebElement cancelButton;

    @FindBy(xpath = "//input[@value='Clear']")
    private WebElement clearButton;

    @FindBy(xpath = "//div[contains(@class,'header-component-right')]//a[contains(@class,'btn-family')]")
    private WebElement addPayerButton;

    // ------------------ INSURANCE SPECIFIC LOCATORS ------------------
    @FindBy(xpath = "//label[contains(text(),'Insurance Name')]/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement insuranceNameDropdown;

    @FindBy(xpath = "//label[contains(text(),'Policy Type')]/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement policyTypeDropdown;

    @FindBy(xpath = "//label[contains(text(),'TPA Name')]/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement tpaNameDropdown;

    @FindBy(xpath = "//input[@formcontrolname='insCardNumber']")
    private WebElement insuranceCardNumberInput;

    @FindBy(xpath = "//input[@formcontrolname='insPolicyName']")
    private WebElement policyNameInput;

    @FindBy(xpath = "//input[@formcontrolname='insPolicyNumber']")
    private WebElement policyNumberInput;

    @FindBy(xpath = "//input[@formcontrolname='insValidUpto']")
    private WebElement validUptoDateInput;

    @FindBy(xpath = "//label[contains(text(),'Patient Type')]/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement patientTypeDropdown;

    @FindBy(xpath = "//input[@formcontrolname='insPolicyHolderName']")
    private WebElement policyHolderNameInput;

    @FindBy(xpath = "//input[@formcontrolname='primaryBeneficiaryEmpId']")
    private WebElement primaryBeneficiaryEmpIdInput;

    @FindBy(xpath = "//input[@formcontrolname='insurerMemberId']")
    private WebElement insurerMemberIdInput;

    @FindBy(xpath = "//input[@formcontrolname='insPolicyHolderEmployment']")
    private WebElement employmentTypeInput;

    // ------------------ CORPORATE SPECIFIC LOCATORS ------------------
    @FindBy(xpath = "//label[contains(text(),'Name Of Company/Organization')]/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement companyNameDropdown;

    @FindBy(xpath = "//label[contains(text(),'Patient Type')]/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement corporatePatientTypeDropdown;

    @FindBy(xpath = "//input[@formcontrolname='corpEmpName']")
    private WebElement employeeNameInput;

    @FindBy(xpath = "//input[@formcontrolname='corpEmpId']")
    private WebElement employeeIdInput;

    @FindBy(xpath = "//input[@formcontrolname='corpEmpDesignation']")
    private WebElement employeeDesignationInput;

    @FindBy(xpath = "//input[@formcontrolname='corpEmpDepartment']")
    private WebElement employeeDepartmentInput;

    // ------------------ SPONSORSHIP SPECIFIC LOCATORS ------------------
    @FindBy(xpath = "//label[contains(text(),'Sponsor Name')]/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement sponsorNameDropdown;

    @FindBy(xpath = "//textarea[@formcontrolname='sponNotes']")
    private WebElement sponsorNotesTextarea;

    @FindBy(xpath = "//label[@class='char-remain']")
    private WebElement characterRemainingLabel;

    // ------------------ COMMON METHODS ------------------
    public void clickAddPayer() {
        waitForClickability(addPayerButton).click();
    }

    public void openPayerTab() {
        waitForClickability(payerDetailTab).click();
    }

    public void selectPayerType(String type) {
        waitForClickability(payerTypeDropdown).click();
        selectOptionFromDropdown(type);
    }

    public void selectPayerSubType(String subType) {
        waitForClickability(payerSubTypeDropdown).click();
        selectOptionFromDropdown(subType);
    }

    public void enterCreditLimit(String credit) {
        waitForVisibility(creditLimitInput).clear();
        creditLimitInput.sendKeys(credit);
    }

    public void enterApprovalAmount(String amount) {
        waitForVisibility(approvalAmountInput).clear();
        approvalAmountInput.sendKeys(amount);
    }

    public void selectStatus(String statusName) {
        waitForClickability(statusDropdown).click();
        selectOptionFromDropdown(statusName);
    }

    public void enterClaimAuthorizationNo(String claimNo) {
        waitForVisibility(claimAuthorizationNoInput).clear();
        claimAuthorizationNoInput.sendKeys(claimNo);
    }

    public void setSamePayerForAllBills(boolean value) {
        if (samePayerForMultipleBillsCheckbox.isSelected() != value) {
            samePayerForMultipleBillsCheckbox.click();
        }
    }

    public void setSkipCreditValidation(boolean value) {
        if (skipAmountValidationCheckbox.isSelected() != value) {
            skipAmountValidationCheckbox.click();
        }
    }

    // ECHS Common Methods
    public void enterServiceNo(String serviceNo) {
        waitForVisibility(serviceNoInput).clear();
        serviceNoInput.sendKeys(serviceNo);
    }

    public void selectServiceDepartment(String department) {
        waitForClickability(serviceDepartmentDropdown).click();
        selectOptionFromDropdown(department);
    }

    public void enterRegNo(String regNo) {
        waitForVisibility(regNoInput).clear();
        regNoInput.sendKeys(regNo);
    }

    // Button Methods
    public void clickSavePayer() {
        waitForClickability(savePayerButton).click();
    }

    public void clickCancel() {
        waitForClickability(cancelButton).click();
    }

    public void clickClear() {
        waitForClickability(clearButton).click();
    }

    // ------------------ INSURANCE SPECIFIC METHODS ------------------
    public void selectInsuranceName(String insuranceName) {
        waitForClickability(insuranceNameDropdown).click();
        selectOptionFromDropdown(insuranceName);
    }

    public void selectPolicyType(String policyType) {
        waitForClickability(policyTypeDropdown).click();
        selectOptionFromDropdown(policyType);
    }

    public void selectTPAName(String tpaName) {
        waitForClickability(tpaNameDropdown).click();
        selectOptionFromDropdown(tpaName);
    }

    public void enterInsuranceCardNumber(String cardNumber) {
        waitForVisibility(insuranceCardNumberInput).clear();
        insuranceCardNumberInput.sendKeys(cardNumber);
    }

    public void enterPolicyName(String policyName) {
        waitForVisibility(policyNameInput).clear();
        policyNameInput.sendKeys(policyName);
    }

    public void enterPolicyNumber(String policyNumber) {
        waitForVisibility(policyNumberInput).clear();
        policyNumberInput.sendKeys(policyNumber);
    }

    public void enterValidUptoDate(String date) {
        waitForVisibility(validUptoDateInput).clear();
        validUptoDateInput.sendKeys(date);
    }

    public void selectPatientType(String patientType) {
        waitForClickability(patientTypeDropdown).click();
        selectOptionFromDropdown(patientType);
    }

    public void enterPolicyHolderName(String holderName) {
        waitForVisibility(policyHolderNameInput).clear();
        policyHolderNameInput.sendKeys(holderName);
    }

    public void enterPrimaryBeneficiaryEmpId(String empId) {
        waitForVisibility(primaryBeneficiaryEmpIdInput).clear();
        primaryBeneficiaryEmpIdInput.sendKeys(empId);
    }

    public void enterInsurerMemberId(String memberId) {
        waitForVisibility(insurerMemberIdInput).clear();
        insurerMemberIdInput.sendKeys(memberId);
    }

    public void enterEmploymentType(String employmentType) {
        waitForVisibility(employmentTypeInput).clear();
        employmentTypeInput.sendKeys(employmentType);
    }

    // ------------------ CORPORATE SPECIFIC METHODS ------------------
    public void selectCompanyName(String companyName) {
        waitForClickability(companyNameDropdown).click();
        selectOptionFromDropdown(companyName);
    }

    public void selectCorporatePatientType(String patientType) {
        waitForClickability(corporatePatientTypeDropdown).click();
        selectOptionFromDropdown(patientType);
    }

    public void enterEmployeeName(String empName) {
        waitForVisibility(employeeNameInput).clear();
        employeeNameInput.sendKeys(empName);
    }

    public void enterEmployeeId(String empId) {
        waitForVisibility(employeeIdInput).clear();
        employeeIdInput.sendKeys(empId);
    }

    public void enterEmployeeDesignation(String designation) {
        waitForVisibility(employeeDesignationInput).clear();
        employeeDesignationInput.sendKeys(designation);
    }

    public void enterEmployeeDepartment(String department) {
        waitForVisibility(employeeDepartmentInput).clear();
        employeeDepartmentInput.sendKeys(department);
    }

    // ------------------ SPONSORSHIP SPECIFIC METHODS ------------------
    public void selectSponsorName(String sponsorName) {
        waitForClickability(sponsorNameDropdown).click();
        selectOptionFromDropdown(sponsorName);
    }

    public void enterSponsorNotes(String notes) {
        waitForVisibility(sponsorNotesTextarea).clear();
        sponsorNotesTextarea.sendKeys(notes);
    }

    public String getCharacterRemainingCount() {
        return waitForVisibility(characterRemainingLabel).getText();
    }

    // ------------------ UTILITY METHODS ------------------
    private void selectOptionFromDropdown(String optionText) {
        WebElement option = driver.findElement(By.xpath("//ul[@role='menu']//span[normalize-space()='" + optionText + "']"));
        waitForClickability(option).click();
    }

    public boolean isElementPresent(By by) {
        try {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public void waitForElementToDisappear(By by) {
        waitForInvisibility(driver.findElement(by));
    }
}
