package PharmacyPurchaseReturn;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class PharmacyPurchasePage extends Abstraction {

    private String generatedInvoiceNo;

    public PharmacyPurchasePage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    public WebElement getSpanByExactText(String exactText) {
        String xpath = "//span[text()='" + exactText + "']";
        return driver.findElement(By.xpath(xpath));
    }

    public WebElement getInputByFormControl(String formControlName) {
        String xpath = "//input[@formcontrolname='" + formControlName + "']";
        return driver.findElement(By.xpath(xpath));
    }

    @FindBy(xpath = "(//span[text()='Purchase'])[2]")
    private WebElement purchaseMenu;

    @FindBy(xpath = "(//a[text()=' Add Purchase '])[1]")
    private WebElement addPurchaseBtn;

    @FindBy(xpath = "(//span[text()='Select'])[1]")
    private WebElement locationDropdown;

    @FindBy(xpath = "(//span[text()='Search'])[1]")
    private WebElement searchBtn;

    @FindBy(xpath = "//span[text()='syrup14 ']")
    private WebElement syrupItem;

    @FindBy(xpath = "//label[text()='Payable Amt']/following-sibling::p")
    private WebElement payableAmtLabel;

    @FindBy(xpath = "(//input[@formcontrolname='invValue'])[1]")
    private WebElement invoiceValueInput;

    @FindBy(xpath = "//input[@value='Add']")
    private WebElement addBtn;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveBtn;

    @FindBy(xpath = "//input[@value='Yes']")
    private WebElement yesBtn;

    @FindBy(xpath = "//input[@value='Approve']")
    private WebElement approveBtn;

    @FindBy(xpath = "(//span[text()='Search'])[1]")
    private WebElement searchMedicineBtn;
    
    @FindBy(xpath = "(//mat-option//following-sibling::*//input | //mat-option//input)[2]")
    private WebElement inputbox;
    
    public String getGeneratedInvoiceNo() {
        return generatedInvoiceNo;
    }

    public void getMedicineByName(String medicineName) {
    	String xpath = "//*[contains(text(),'" + medicineName + "')]";
    	driver.findElement(By.xpath(xpath)).click();
    }

    
    public void createNewPurchase(String location, String supplier,String invoiceNumber, String invDate, String dueDate, String expiryDate,
                                  String medicineName, String batchNo, String strips, String freeStrips, String mrp, String price) {

        waitForClickability(purchaseMenu).click();
        waitForClickability(addPurchaseBtn).click();

        waitForClickability(locationDropdown).click();
        waitForClickability(getSpanByExactText(location)).click();

        waitForClickability(locationDropdown).click();
        waitForClickability(getSpanByExactText(supplier)).click();

        int invoiceNo = Integer.parseInt(invoiceNumber);
        while (true) {
            WebElement invInput = getInputByFormControl("invNo");
            invInput.clear();
            invInput.sendKeys(String.valueOf(invoiceNo));

            By validationMsg = By.xpath("//*[contains(text(), 'Invoice No Already Exists')]");
            try {
                waitForVisibility(driver.findElement(validationMsg), 3);
                invoiceNo++;
            } catch (Exception e) {
                break;
            }
        }

        generatedInvoiceNo = String.valueOf(invoiceNo);

        js.executeScript("arguments[0].value='" + invDate + "'; arguments[0].dispatchEvent(new Event('input'));",
            getInputByFormControl("invDate"));
        js.executeScript("arguments[0].value='" + dueDate + "'; arguments[0].dispatchEvent(new Event('input'));",
            getInputByFormControl("invDueDate"));
        
        
        waitForClickability(searchMedicineBtn).click();
        WebElement searchBox = driver.findElement(
                By.xpath("(//mat-option//following-sibling::*//input | //mat-option//input)[2]")
            );
            // 3. Type inside the search box
        waitForClickability(searchBox).sendKeys(medicineName);
        getMedicineByName(medicineName);


        getInputByFormControl("BatchNumber").sendKeys(batchNo);

        WebElement expiry = getInputByFormControl("expiryDate");
        js.executeScript(
            "const input = arguments[0];" +
            "const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;" +
            "setter.call(input, '" + expiryDate + "');" +
            "input.dispatchEvent(new Event('input', { bubbles: true }));" +
            "input.dispatchEvent(new Event('change', { bubbles: true }));",
            expiry);

        List<WebElement> lastProduct = driver.findElements(By.xpath("//div[@class='last-product pt-2']"));
        if (lastProduct.isEmpty() || !lastProduct.get(0).isDisplayed()) {
            getInputByFormControl("noOfStrips").sendKeys(strips);
            getInputByFormControl("freeStrips").sendKeys(freeStrips);
            getInputByFormControl("mrpPerStrip").sendKeys(mrp);
            getInputByFormControl("pricePerStrip").sendKeys(price);
        }

        String amt = null;
        for (int i = 0; i < 50; i++) {
            WebElement amtEl = waitForVisibility(payableAmtLabel, 30);
            amt = amtEl.getText().trim();
            System.out.println(amt);
            if (!amt.equals("-")) break;
        }

        waitForVisibility(invoiceValueInput).sendKeys(amt);
        waitForClickability(addBtn).click();
        
     
    }
    public GRNVerificationPage save() {
        waitForClickability(saveBtn).click();
        waitForClickability(yesBtn).click();
        waitForClickability(approveBtn).click();
        GRNVerificationPage grnPage= new GRNVerificationPage(driver);
        return grnPage;
        }
}
