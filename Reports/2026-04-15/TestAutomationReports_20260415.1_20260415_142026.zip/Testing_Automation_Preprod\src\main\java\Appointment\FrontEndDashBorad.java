package Appointment;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class FrontEndDashBorad extends Abstraction {

	public FrontEndDashBorad(WebDriver driver) {
		super(driver);
		 this.driver = driver;
	        PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[contains(@class,'ngx-select__selected')]//span[contains(@class,'ngx-select__selected-single')]//span")
	private WebElement selectedCalendarValue;

	public void clickCalendarDropdown() {
		selectedCalendarValue.click();
	}
	public void selectDateRange(String optionText) {
		
		clickCalendarDropdown();
	    driver.findElement(By.xpath(
	        "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + optionText + "']"
	    )).click();
	}
	@FindBy(xpath = "//input[@value='Search' and @type='button']")
	private WebElement searchButton;

	public void clickSearchButton() {
	    searchButton.click();
	}
	public void findPatientByMobile(String targetMobileNumber, String menuOption) {
	    boolean isPatientFound = false;
	    int clickCount = 0; // To avoid infinite loop

	    while (!isPatientFound) {

	        // All patient rows
	        List<WebElement> rows = driver.findElements(
	            By.xpath("//tr[contains(@class,'appt-row')]")
	        );

	        for (WebElement row : rows) {
	            try {
	                // Extract mobile number from the correct <p> element
	                WebElement phoneElement = row.findElement(
	                    By.xpath(".//p[img[contains(@src,'phone')]]")
	                );

	                String mobileText = phoneElement.getText().replaceAll("[^0-9]", "").trim();
	                System.out.println("📞 Found Mobile: " + mobileText);

	                String checkInXpath = ".//ul[contains(@class,'list_img')]//a[@nbtooltip='Check In']";

	             // Find all matches (0 or 1 normally)
	             List<WebElement> checkInButtons = row.findElements(By.xpath(checkInXpath));

	             // Condition: exists AND displayed
	             boolean isCheckInDisplayed =
	                     !checkInButtons.isEmpty() &&
	                     checkInButtons.get(0).isDisplayed();

	             if (mobileText.equals(targetMobileNumber) && isCheckInDisplayed) {

	                 WebElement checkInButton = checkInButtons.get(0);
	                 waitForClickability(checkInButton).click();

	                 System.out.println("✅ Check In button clicked for mobile: " + targetMobileNumber);

	                 isPatientFound = true;
	                 break;
	             }


	            } catch (NoSuchElementException ignore) {
	                // Row does not have mobile number container — safe to skip
	            } 
	        }

	        // If found → stop loop
	        if (isPatientFound) break;

	        // If not found → go to next page
	        if (clickCount >= 14) {
	            System.out.println("⛔ Stopped after 14 pages. Patient not found.");
	            break;
	        }

	        try {
	            WebElement nextButton = driver.findElement(
	                By.xpath("//i[contains(@class,'fa-chevron-right')]/ancestor::a")
	            );

	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextButton);

	            clickCount++;
	            System.out.println("➡️ Next Page: " + clickCount);

	  

	        } catch (NoSuchElementException e) {
	            System.out.println("❌ Next button not found. Ending search.");
	            break;
	        }
	    }
	}

}
