package WareHouseSetup.Approval.Branchbased;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class Branch_Based_Master extends Abstraction{

	public Branch_Based_Master(WebDriver driver) {
		super(driver);
	    this.driver = driver;
	    PageFactory.initElements(driver, this);
	}
	  @FindBy(xpath = "//a[text()=' Add Item Discount ']")
	    private WebElement addbranchbased;
	    
	    @FindBy(xpath = "//a[text()='Branch Based Master']")
	    private WebElement branchbased;
	    
	 // Locators
	    @FindBy(xpath = "//input[@formcontrolname='reasonName']")
	    private WebElement discountNameInput;

	    @FindBy(xpath = "//input[@formcontrolname='reasonCode']")
	    private WebElement discountCodeInput;

	    @FindBy(xpath = "//textarea[@formcontrolname='reasonDescription']")
	    private WebElement discountDescriptionTextarea;

	    @FindBy(xpath = "//label[contains(., 'Is Active')]//span[@class='checkmark']")
	  
	    private WebElement isActiveCheckbox;

	    @FindBy(xpath = "//input[@value='Save' and @type='button']")
	    private WebElement saveButton;

	    @FindBy(xpath = "//input[@value='Cancel' and @type='button']")
	    private WebElement cancelButton;

	    
	    
		public void clickbuttonapproval() {
			waitForClickability(branchbased).click();
			waitForClickability(addbranchbased).click();
		}
		
		public void enterDiscountName(String name) {
		    discountNameInput.clear();
		    discountNameInput.sendKeys(name);
		}

		public void enterDiscountCode(String code) {
		    discountCodeInput.clear();
		    discountCodeInput.sendKeys(code);
		}

		public void enterDiscountDescription(String description) {
		    discountDescriptionTextarea.clear();
		    discountDescriptionTextarea.sendKeys(description);
		}

		public void setActiveStatus(boolean shouldBeActive) {
		    if (shouldBeActive && !isActiveCheckbox.isSelected()) {
		        waitForClickability(isActiveCheckbox).click();
		    } else if (!shouldBeActive && isActiveCheckbox.isSelected()) {
		        waitForClickability(isActiveCheckbox).click();
		    }
		}

		public void clickSave() {
		    waitForClickability(saveButton).click();
		}

		public void clickCancel() {
		    waitForClickability(cancelButton).click();
		}

		public void fillItemDiscountForm(String name, String code, String description, boolean isActive) {
		    enterDiscountName(name);
		    enterDiscountCode(code);
		    enterDiscountDescription(description);
		    setActiveStatus(isActive);
		    clickSave();
		}
		
		

}
