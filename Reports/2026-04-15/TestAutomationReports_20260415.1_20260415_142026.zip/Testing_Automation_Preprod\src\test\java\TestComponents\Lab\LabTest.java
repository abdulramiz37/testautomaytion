package TestComponents.Lab;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeoutException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EzionpageObjects.UserIdPage;
import Lab.ApprovedListPage;
import Lab.LabWorkOrder;
import Lab.NewListTable;
import Lab.Re_TestPage;
import Lab.SampleCollectedList;
import Lab.SampleCollected_EditWorkList;
import Lab.WaitingApprovalPage;
import Registration.NewRegistrationPage;
import Registration.PatientList;
import Registration.ServiceList;
import abdulTest.BaseTest;
import ezion.Resources.EnvUtil;

public class LabTest extends BaseTest {
	 UserIdPage data;
	    
	    @Test(dataProvider = "getDataForLogin", priority = 1)
	    public void login(HashMap<String, String> input) throws InterruptedException {
//	        data = login.login(EnvUtil.get("USER_ID"));
//	        data.enterMobileNumber(EnvUtil.get("PERSON_ID"));
//	        data.enterPassword(EnvUtil.get("PASSWORD"));

	        data = login.login("27590791");
	        data.enterMobileNumber("9884887874");
	        data.selectOptionByName("Pondicherry");
	        data.enterPassword("Ezovion$1");
	        data.clickContinue();
	        Thread.sleep(8000);
//	        data.openMasterSetup();
	    }
	    String targetMobileNumber;
	    @Test(dataProvider = "getDataForLogin", priority = 2)
	    public void testNewPatientRegistration(HashMap<String, String> input) {
	        // Create an instance of the NewRegistrationPage with the driver
	        NewRegistrationPage registrationPage = new NewRegistrationPage(driver);

	        // Call the fillNewRegistrationForm method with all necessary form values
	        registrationPage.clickbuttonapproval();
	        registrationPage.selectTitle();
	        registrationPage.selectOptionFromNgxDropdown("Mr.");
	        registrationPage.enterFirstName("John");
	        registrationPage.enterMiddleName("doe");
	        registrationPage.enterLastName("abraham");
	        registrationPage.selectGender();
	        registrationPage.selectOptionFromNgxDropdown("Male");
//	        registrationPage.enterDOB2("2025-May-12");
	        registrationPage.enterDOB("01/15/1980");
	        registrationPage.enterMobileNumber("");
	        targetMobileNumber=registrationPage.lastEnteredMobileNumber;
//	        targetMobileNumber="7411081113";
	        registrationPage.selectNationality("Indian");
	        registrationPage.save();

System.out.println(targetMobileNumber);
	        
	    }
	    
	    
	    @Test(dataProvider = "getDataForLogin", priority = 3)
	    public void PatientRegistration(HashMap<String, String> input) {
	    	PatientList patient = new PatientList(driver);
	    	patient.patientlist();
	    	patient.patientlist();
	    	patient.patientlist();
	    	patient.findPatientByMobile(targetMobileNumber);
	    	
	    	ServiceList service = new ServiceList(driver);
//	    	Blood Sugar2 - LabTest
	     	service.fillBillingForm("General", "Dr. Ankit", "Self","Blood Urea - LabTest","10","%","5");
	        
	    }
	    
	    String workId ;    
	    @Test(dataProvider = "getDataForLogin", priority = 4)
	    public void NewList(HashMap<String, String> input) throws InterruptedException {
	    
	    	NewListTable listTable = new NewListTable(driver);
	    	listTable.clickbuttonapproval();
	    	Thread.sleep(5000);
	    	listTable.clickActionByPatientAndPhysician(
	    			"Mr.John doe abraham", 
	    			"Dr. Ankit");
	    	
	 workId = listTable.workId;
	    	
//	    	String workId = "808088";
	    	System.out.println(workId);
	    }
	    
	    
	    
	    @Test(dataProvider = "getDataForLogin", priority = 5)
	    public void labworkOrder(HashMap<String, String> input) {
	    	LabWorkOrder labOrder= new LabWorkOrder(driver);
	    	labOrder.clickCheckboxByTestName("Blood Urea");
	    	
	    }
//	    
	    @Test(dataProvider = "getDataForLogin", priority = 6)
	    public void sampleList(HashMap<String, String> input) throws InterruptedException, TimeoutException  {
	    	
	    	
	    	
//	    	String workId = "808088";
	
//	    	System.out.println(workId);
	    	SampleCollectedList sampleList = new SampleCollectedList(driver);
	  
	    	System.out.println(workId +"new");
	    	sampleList.clickReorderByWorkOrder2(workId);
//	    	
	    }
//	    
	    @Test(dataProvider = "getDataForLogin", priority = 7)
	    public void sampleList_workorderList(HashMap<String, String> input) throws InterruptedException, TimeoutException {

	    	SampleCollected_EditWorkList worklist = new SampleCollected_EditWorkList(driver);
	    	Thread.sleep(5000);
//	    	worklist.clickEditIconByTestName("Blood Urea");
	    	worklist.editTestValueByTestName("Blood Urea","2","jsdd");
//	    	worklist.fillHistopathologyForm(
//	    		    "HP-001",
//	    		    "Livdf",
//	    		    "Brodf",
//	    		    "Abdf",
//	    		    "Shdfh",
//	    		    "Hadsf"
//	    		);
	    	
	    	
	    	worklist.selectDropdownValue("Sathish");
	    }
	    
	    @Test(dataProvider = "getDataForLogin", priority = 8)
	    public void waitingList(HashMap<String, String> input) throws TimeoutException {
	    	WaitingApprovalPage waitingApproval = new WaitingApprovalPage(driver);
	    	waitingApproval.clickReorderByWorkOrder(workId);
	    	waitingApproval.selectApprovalStatus("Approved");
	    }
	    
	    @Test(dataProvider = "getDataForLogin", priority = 9)
	    public void approvalList(HashMap<String, String> input) throws InterruptedException {
	    	ApprovedListPage approval = new ApprovedListPage(driver);
	    	approval.clickReorderByWorkOrder(workId);
	    	Re_TestPage retest = new Re_TestPage(driver);
	    	Thread.sleep(5000);
	    	retest.clickCheckboxForTest("Blood Urea");
	    	retest.clickGenerateWorkOrder();
	    	retest.selectRequestedByEmployee("Sathish");
	    	retest.selectApprovedByEmployee("Sathish");
	    }
	    
	    @DataProvider
	    public Object[][] getDataForLogin() throws IOException {
	        List<HashMap<String, String>> data = getJsonDataToMap(
	            System.getProperty("user.dir") + "//src//main//java//ezion//Resources//WareHouseMaster.json"
	        );
	        return new Object[][] { { data.get(0) } };
	    }
}
