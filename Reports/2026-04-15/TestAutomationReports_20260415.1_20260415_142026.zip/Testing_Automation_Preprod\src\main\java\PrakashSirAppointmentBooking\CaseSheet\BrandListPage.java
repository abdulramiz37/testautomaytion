package PrakashSirAppointmentBooking.CaseSheet;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

import java.util.List;

public class BrandListPage extends Abstraction {

    WebDriver driver;

    public BrandListPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // --- Section Header ---
    @FindBy(xpath = "//span[normalize-space()='Add Vaccine']")
    private WebElement addVaccineHeader;

    // --- Dropdowns ---
    @FindBy(xpath = "//label[normalize-space()='Medicine']/following-sibling::ngx-select[1]")
    private WebElement medicineDropdown;

    @FindBy(xpath = "//label[normalize-space()='Vaccine Name']/following-sibling::ngx-select[1]")
    private WebElement vaccineDropdown;

    // --- Buttons ---
    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveBtn;

    @FindBy(xpath = "//input[@value='Cancel']")
    private WebElement cancelBtn;

    // --- Table ---
    @FindBy(xpath = "//table//tbody/tr")
    private List<WebElement> addedVaccineRows;

    // --- Actions ---

    public boolean isBrandListPageLoaded() {
        return addVaccineHeader.isDisplayed();
    }
 // --- Section Toggle ---
    @FindBy(xpath = "//h4[normalize-space()='Brand List']/following::img[contains(@class,'openclose')][1]")
    private WebElement brandListToggleIcon;

    public void toggleBrandListSection() {
        clickWithJavaScript(brandListToggleIcon);
    }
    @FindBy(xpath = "//a[normalize-space()='Add Combo Vaccine']")
    private WebElement addComboVaccineBtn;

    // Method to click (toggle) the button
    public void toggleAddComboVaccine() {
        addComboVaccineBtn.click();
    }
//    public void selectMedicine(String medicineName) {
//        medicineDropdown.click();
//        WebElement option = driver.findElement(By.xpath(
//                "//ul[@role='menu']//li[@role='menuitem']/a/span[contains(text(),'" + medicineName + "')]"));
//        option.click();
//    }
    
    public void selectMedicine(String medicineName) {
        // open dropdown
        medicineDropdown.click();

        // locate option dynamically using the given string
        WebElement option = driver.findElement(
            By.xpath("//ul[contains(@class,'ngx-select__choices')]//span" +
                     "[contains(translate(normalize-space(.), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '" 
                     + medicineName.toLowerCase() + "')]")
        );

        option.click();
    }
    public void selectMedicine1(String partialMedicineName) {
        // Open dropdown
        medicineDropdown.click();

        // Build XPath for partial case-insensitive match
        String xpath = String.format(
            "(//ul[contains(@class,'ngx-select__choices')]//span[" +
            "contains(translate(normalize-space(.), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '%s')" +
            "])[1]",
            partialMedicineName.toLowerCase()
        );

  

        // Click with JavaScript to avoid overlay/interception issues
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", xpath);

        System.out.println("✅ Selected medicine containing: " + partialMedicineName);
    }

    
    public void changeVaccines2(List<String> newVaccines) {
        for (String vaccineName : newVaccines) {
            // Step 1: Open dropdown
            vaccineDropdown.click();

            // Step 2: Enter vaccine name in search input
//            WebElement searchInput = driver.findElement(
//                By.xpath("//input[@placeholder='Search Vaccine']")
//            );
//            searchInput.clear();
//            searchInput.sendKeys(vaccineName);

            // Step 3: Wait & select first matching result
            WebElement option = driver.findElement(
                By.xpath("//ul[contains(@class,'ngx-select__choices')]//span" +
                         "[contains(translate(normalize-space(.), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '" 
                         + vaccineName.toLowerCase() + "')]")
            );
            option.click();
            clickSave();
        }

        // Step 4: Save after selecting all vaccines
        
    }


    public void clickSave() {
        saveBtn.click();
    }

//    public void changeVaccines(List<String> newVaccines) {
//        // Example: clear previous selection (depends on UI)
//        // If there's a clear button in your dropdown, you can click it here.
//        // Or if multiple selection is allowed, it may keep old ones — depends on your HTML.
//
//        // Select new set of vaccines
//    	changeVaccines2(newVaccines);
//
//        // Save again
//        clickSave();
//    }

//    public void selectVaccine(String vaccineName) {
//        vaccineDropdown.click();
//        WebElement option = driver.findElement(By.xpath(
//                "//ul[@role='menu']//li[@role='menuitem']/a/span[contains(text(),'" + vaccineName + "')]"));
//        option.click();
//    }

  

    public void clickCancel() {
        cancelBtn.click();
    }

    public int getAddedVaccineCount() {
        return addedVaccineRows.size();
    }

    public String getAddedVaccineDetailsByRow(int rowIndex) {
        return addedVaccineRows.get(rowIndex - 1).getText(); // 1-based index
    }
}
