package Accounts;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class CreditBillSelf extends Abstraction {
	
	
	public CreditBillSelf(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
	
    @FindBy(xpath = "//span[text()='Accounts']")
    private WebElement userType;

    @FindBy(xpath = "//span[text()='Credit Bill - Self']")
    private WebElement adduserType;
	
	private By billNoCol = By.xpath(".//td[5]");
	private By rowCheckbox = By.xpath(".//td[1]//input[@type='checkbox']");
	@FindBy(xpath = "//tbody/tr")
	private List<WebElement> patientRows;
	
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		clickWithJavaScript(adduserType);
	}
    public boolean selectPatientByBillNo(String targetBillNo) {
        boolean isFound = false;
        int clickCount = 0;

        while (!isFound) {

            // Get all rows fresh each time
            List<WebElement> rows = waitForPresenceOfAll(
                By.xpath("(//table)[2]//tbody/tr")
            );

            for (int i = 0; i < rows.size(); i++) {
                try {
                    WebElement row = rows.get(i);

                    // Bill No is in td[5]
                    String billNo = row.findElement(By.xpath(".//td[5]")).getText().trim();

                    if (billNo.equals(targetBillNo)) {

                        WebElement checkbox = row.findElement(
                            By.xpath(".//td[1]//input[@type='checkbox']")
                        );

                        ((JavascriptExecutor) driver).executeScript(
                            "arguments[0].scrollIntoView(true);", checkbox
                        );
                        waitForClickability(checkbox).click();

                        System.out.println("✔ Selected row with Bill No: " + targetBillNo);

                        isFound = true;
                        break;
                    }

                } catch (NoSuchElementException e) {
                    System.out.println("⚠️ Row " + i + " is missing required elements. Skipping.");
                }
            }

            // If FOUND → STOP PAGE LOOP
            if (isFound) break;

            // ▶ Try NEXT PAGE
            try {
                WebElement nextPage = driver.findElement(
                    By.xpath("(//div[@class='pagi-block pagi-block-right']//a)[1]")
                );

                String classAttr = nextPage.getAttribute("class");

                // If next page is disabled → end
                if (classAttr != null && classAttr.contains("disabled")) {
                    System.out.println("❌ Reached last page. Bill No not found.");
                    break;
                }

                // Stop after 14 clicks
                if (clickCount >= 14) {
                    System.out.println("⛔ Stopped after 14 page clicks. Bill No not found.");
                    break;
                }

                // Scroll and click
                ((JavascriptExecutor) driver).executeScript(
                    "arguments[0].scrollIntoView(true);", nextPage
                );
                ((JavascriptExecutor) driver).executeScript(
                    "arguments[0].click();", nextPage
                );

                clickCount++;
                System.out.println("➡️ Moving to next page... (Click " + clickCount + ")");

            } catch (NoSuchElementException e) {
                System.out.println("❌ Next page button NOT FOUND. Ending search.");
                break;
            }
        }

        return isFound;
    }

	@FindBy(xpath = "//input[@type='button' and @value='Receipt']")
	private WebElement receiptButton;
	
    public void receptionist() {
		waitForClickability(receiptButton).click();
	
	}

}
