package Lab;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import EzionAbstractionComponents.Abstraction;

public class NewListTable extends Abstraction {

	public NewListTable(WebDriver driver) {
		super(driver);
	    PageFactory.initElements(driver, this);
	}
	  @FindBy(xpath = "//span[text()='Lab']")
	    private WebElement addtenant;
	    
	    @FindBy(xpath = "//span[text()='Lab Order Queue']")
	    private WebElement Tenantbutton;
  // --- Action Methods ---
	   
//	    String expectedUrl = "https://apps.ezovion.com/pages/lab/labqueue/null";
		
	    String expectedUrl = "https://ezopreprodstrgfrontend.z29.web.core.windows.net/pages/lab/labqueue/null";
	public void clickbuttonapproval() {
	

		waitForClickability(addtenant,5).click();
	
	    for (int i = 0; i < 5; i++) {
	        try {
	        	waitForClickability(Tenantbutton,4).click();   // Click Tenant button
	            waitForUrl(expectedUrl);                     // Wait until URL matches
	         
	            waitForVisibility(driver.findElement(
	            	    By.xpath("//tbody/tr[contains(@class,'ng-star-inserted')]")
	            	));

	            	List<WebElement> rows = driver.findElements(
	            	    By.xpath("//tbody/tr[contains(@class,'ng-star-inserted')]")
	            	);

	            System.out.println("✅ Tenant page loaded on attempt " + (i + 1));
	            return; // success, exit loop
	        } catch (Exception e) {
	            System.out.println("❌ Attempt " + (i + 1) + " failed: " + e.getMessage());
	            if (i == 4) {
	                throw new RuntimeException("Failed to load Tenant page after 5 attempts", e);
	            }
	        }
	    }
	}
	 public String workId=null;
	public void clickActionByPatientAndPhysician(String patientName, String physicianName) {
         

	    boolean isFound = false;

	    while (!isFound) {
	        List<WebElement> rows = driver.findElements(
	            By.xpath("//tbody/tr[contains(@class,'ng-star-inserted')]")
	        );

	        for (WebElement row : rows) {
	            try {
	                // Locate patient name cell
	                WebElement patientNameCell = row.findElement(
	                    By.xpath(".//td[normalize-space()='" + patientName + "']")
	                );

	                // Locate physician cell
	                WebElement physicianCell = row.findElement(
	                    By.xpath(".//td[normalize-space()='" + physicianName + "']")
	                );

	                if (patientNameCell.getText().trim().equalsIgnoreCase(patientName) &&
	                    physicianCell.getText().trim().equalsIgnoreCase(physicianName)) {

	                    // Extract Work ID (third column in your HTML sample)
	                    WebElement workIdCell = row.findElement(By.xpath(".//td[3]"));
	                    this.workId = workIdCell.getText().trim();
	                    System.out.println(workId);

	                    // Click Action button in the same row
	                    WebElement actionButton = row.findElement(
	                        By.xpath(".//td[@class='text-center']//a/img")
	                    );
	                    waitForClickability(actionButton).click();

	                    System.out.println("✅ Clicked Action for: " + patientName + " | " + physicianName);
	                    isFound = true;
	                    break;
	                }
	            } catch (NoSuchElementException ignored) {}
	        }

	        if (!isFound) {
	            try {
	                WebElement nextButton = driver.findElement(
	                    By.xpath("//i[contains(@class, 'fa-chevron-right')]/ancestor::a")
	                );
	                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextButton);
	                System.out.println("➡️ Moved to next page...");
	            } catch (NoSuchElementException e) {
	                System.out.println("❌ No more pages. Patient & Physician not found.");
	                break;
	            }
	        }
	    }
	}

	public void clickActionByPatientAndPhysician(String patientName) {

		boolean isFound = false;

		while (!isFound) {

			List<WebElement> rows = driver.findElements(By.xpath("//tbody/tr[contains(@class,'ng-star-inserted')]"));

			for (WebElement row : rows) {
				try {
					// Patient Name (2nd column)
					WebElement patientCell = row.findElement(By.xpath(".//td[2]"));

					// Physician Name (4th column - adjust if needed)
					WebElement physicianCell = row.findElement(By.xpath(".//td[8]"));

					String patientText = patientCell.getText().trim();
					String physicianText = physicianCell.getText().trim();

					if (patientText.equalsIgnoreCase(patientName)) {

						// Work ID (3rd column)
						WebElement workIdCell = row.findElement(By.xpath(".//td[3]"));
						this.workId = workIdCell.getText().trim();
						System.out.println("🆔 Work ID: " + workId);

						// Action button
						WebElement actionBtn = row.findElement(By.xpath(".//td[@class='text-center']//a/img"));
						waitForClickability(actionBtn).click();


						isFound = true;
						break;
					}

				} catch (NoSuchElementException ignored) {
				}
			}

			if (!isFound) {
				try {
					WebElement nextBtn = driver
							.findElement(By.xpath("//i[contains(@class,'fa-chevron-right')]/ancestor::a"));
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextBtn);
					System.out.println("➡️ Moved to next page...");
				} catch (NoSuchElementException e) {
					System.out.println("❌ No more pages. Record not found.");
					break;
				}
			}
		}
	}

}
