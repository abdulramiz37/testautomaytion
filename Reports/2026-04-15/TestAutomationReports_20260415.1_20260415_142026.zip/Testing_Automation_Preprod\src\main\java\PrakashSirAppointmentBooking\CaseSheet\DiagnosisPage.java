package PrakashSirAppointmentBooking.CaseSheet;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import EzionAbstractionComponents.Abstraction;

public class DiagnosisPage extends Abstraction {

    WebDriver driver;

    public DiagnosisPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // --- Section Toggle ---
    @FindBy(xpath = "//h4[normalize-space(text())='Diagnosis']/following::img[contains(@class,'openclose')][1]")
    private WebElement diagnosisToggleIcon;

    // --- Dropdowns ---
    @FindBy(xpath = "//mat-select[@formcontrolname='diagnosisId']")
    private WebElement diagnosisDropdown;
    
    @FindBy(xpath = "(//input[contains(@class,'mat-select-search-input')])[2]")
    private WebElement diagnosisSearchInput;
    @FindBy(xpath = "//ngx-select[@formcontrolname='performDoc']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement performingDoctorDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='performNurse']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement performingNurseDropdown;

    // --- Text Fields ---
    @FindBy(xpath = "//textarea[@formcontrolname='treatmentGiven']")
    private WebElement treatmentGivenTextarea;

    // --- Checkboxes ---
    @FindBy(xpath = "//label[contains(.,'High Risk')]/span[@class='checkmark']")
    private WebElement highRiskCheckbox;

    // --- Buttons ---
    @FindBy(xpath = "//button[@nbtooltip='Add']")
    private WebElement addDiagnosisBtn;

    @FindBy(xpath = "//button[@nbtooltip='Reset']")
    private WebElement resetDiagnosisBtn;

    // --- Success Messages ---
    @FindBy(xpath = "//span[normalize-space(text())='Diagnosis Saved Successfully']")
    private WebElement successSaveMsg;

    @FindBy(xpath = "//span[normalize-space(text())='Diagnosis Updated Successfully']")
    private WebElement successUpdateMsg;

    @FindBy(xpath = "//span[normalize-space(text())='Diagnosis Deleted Successfully']")
    private WebElement successDeleteMsg;

    // --- Actions ---
    public void clickDiagnosisToggle() {
        clickWithJavaScript(diagnosisToggleIcon);
    }
    @FindBy(xpath = "//button[contains(@class,'add-btn-icon') and contains(.,'Add New Diagnosis')]")
    private WebElement addNewDiagnosisBtn;



    public String finalDiagnosis;   // accessible outside

    public void selectDiagnosis(String diagnosisName) {
        // open dropdown
        diagnosisDropdown.click();

        finalDiagnosis = diagnosisName;

        // If diagnosisName is null or empty, generate a random one
        if (diagnosisName == null || diagnosisName.trim().isEmpty()) {
            int length = 6;
            String alphabet = "abcdefghijklmnopqrstuvwxyz";
            StringBuilder sb = new StringBuilder();
            java.util.Random random = new java.util.Random();
            for (int i = 0; i < length; i++) {
                sb.append(alphabet.charAt(random.nextInt(alphabet.length())));
            }
            finalDiagnosis = sb.toString();
        }
        diagnosisSearchInput.click();
        // type in diagnosis
        diagnosisSearchInput.sendKeys(finalDiagnosis);

        // look for existing diagnosis in dropdown
        List<WebElement> diagnosisOptions = driver.findElements(
        		By.xpath("//mat-option//span//h4[contains(text(),'" + finalDiagnosis + "')]") );
       

        if (!diagnosisOptions.isEmpty()) {
            // select existing diagnosis
            diagnosisOptions.get(0).click();
            System.out.println("Diagnosis Selected from dropdown: " + finalDiagnosis);
        } else {
            // click Add New if available (similar to complaints/examination flow)
            addNewDiagnosisBtn.click();
            System.out.println("New Diagnosis Added: " + finalDiagnosis);
        }
    }

    public void selectPerformingDoctor(String doctorName) {
        performingDoctorDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + doctorName + "']"));
        option.click();
    }

    public void selectPerformingNurse(String nurseName) {
        performingNurseDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + nurseName + "']"));
        option.click();
    }

    public void enterTreatmentGiven(String treatment) {
        treatmentGivenTextarea.clear();
        treatmentGivenTextarea.sendKeys(treatment);
    }

    public void checkHighRisk() {
        if (!highRiskCheckbox.isSelected()) {
            highRiskCheckbox.click();
        }
    }

    public void clickAddDiagnosis() {
        addDiagnosisBtn.click();
    }

    public void clickResetDiagnosis() {
        resetDiagnosisBtn.click();
    }

    // --- Validation ---
    public boolean isSaveSuccessDisplayed() {
        return successSaveMsg.isDisplayed();
    }

    public boolean isUpdateSuccessDisplayed() {
        return successUpdateMsg.isDisplayed();
    }

    public boolean isDeleteSuccessDisplayed() {
        return successDeleteMsg.isDisplayed();
    }
    
    
//    add method
    
    @FindBy(xpath = "//input[@formcontrolname='code']")
    private WebElement diagnosisCodeInput;

    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement diagnosisNameInput;

    @FindBy(xpath = "//input[@formcontrolname='localDescription']")
    private WebElement localDescriptionInput;

    @FindBy(xpath = "//input[@formcontrolname='attribute']")
    private WebElement attributeInput;

    @FindBy(xpath = "//input[@value='Add Attribute']")
    private WebElement addAttributeButton;

    @FindBy(xpath = "//input[@value='Reset']")
    private WebElement resetButton;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//input[@value='Cancel']")
    private WebElement cancelButton;

    // ---------- Success / Error Messages ----------
    @FindBy(xpath = "//span[text()='Record Created Successfully ']")
    private WebElement successCreateMsg;

    @FindBy(xpath = "//span[text()='Record Updated Successfully ']")
    private WebElement successUpdateMsg2;

    @FindBy(xpath = "//span[text()='Record Not Successfully Created']")
    private WebElement failureCreateMsg;

    @FindBy(xpath = "//span[text()='Record Not Successfully Updated']")
    private WebElement failureUpdateMsg;

    @FindBy(xpath = "//span[text()='Please Fill Mandatory Fields']")
    private WebElement mandatoryFieldError;

    // ---------- Constructor ----------

    @FindBy(xpath = "//div[@class='lightbox-title' and normalize-space()='Add Diagnosis']")
    private WebElement addDiagnosisTitle;

    // ---------- Methods ----------
    public boolean isPageDisplayed() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        try {
            wait.until(ExpectedConditions.visibilityOf(addDiagnosisTitle));
            return addDiagnosisTitle.isDisplayed();
        } catch (TimeoutException e) {
            return false;
        }
    }
    
 // Locator for the close button of Add Diagnosis popup
    @FindBy(xpath = "//div[contains(@class,'lightbox-close')]/i[@class='fa fa-times']")
    private WebElement closeAddDiagnosisPopup;
    public void clickCloseAddDiagnosisPopup() {
        closeAddDiagnosisPopup.click();
    }

    public void enterDiagnosisCode(String code) {
        diagnosisCodeInput.clear();
        diagnosisCodeInput.sendKeys(code);
    }

    public void enterDiagnosisName(String name) {
        diagnosisNameInput.clear();
        diagnosisNameInput.sendKeys(name);
    }

    public void enterLocalDescription(String description) {
        localDescriptionInput.clear();
        localDescriptionInput.sendKeys(description);
    }

    public void enterAttribute(String attribute) {
        attributeInput.clear();
        attributeInput.sendKeys(attribute);
    }

    public void clickAddAttribute() {
        addAttributeButton.click();
    }

    public void clickReset() {
        resetButton.click();
    }

    public void clickSave() {
        saveButton.click();
    }

    public void clickCancel() {
        cancelButton.click();
    }

    // ---------- Validation Methods ----------
    public boolean isSuccessCreateDisplayed() {
        return successCreateMsg.isDisplayed();
    }

    public boolean isSuccessUpdateDisplayed() {
        return successUpdateMsg.isDisplayed();
    }

    public boolean isFailureCreateDisplayed() {
        return failureCreateMsg.isDisplayed();
    }

    public boolean isFailureUpdateDisplayed() {
        return failureUpdateMsg.isDisplayed();
    }

    public boolean isMandatoryFieldErrorDisplayed() {
        return mandatoryFieldError.isDisplayed();
    }

}

