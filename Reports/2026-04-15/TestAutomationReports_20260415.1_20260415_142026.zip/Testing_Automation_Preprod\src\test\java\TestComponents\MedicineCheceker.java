package TestComponents;



	import java.io.IOException;
	import java.util.HashMap;
	import java.util.List;

	import org.testng.annotations.DataProvider;
	import org.testng.annotations.Test;

	import EzionpageObjects.UserIdPage;
	import PharmacyFlowObjects.MasterSetupPage;
	import PharmacyFlowObjects.RolesManagementPage;
import PharmacyFlowObjects.PharmacyStore.CustomerPage;
import PharmacyFlowObjects.PharmacyStore.HMSLocationPage;
import PharmacyFlowObjects.PharmacyStore.MedicinePage;
import PharmacyFlowObjects.PharmacyStore.PharmacyLocationPage;
import PharmacyFlowObjects.PharmacyStore.StorageShelfPage;
	import PharmacyFlowObjects.PharmacyStore.StorePage;
	import PharmacyFlowObjects.PharmacyStore.SupplierPage;
	import abdulTest.BaseTest;

	public class MedicineCheceker extends BaseTest {
	
	    @Test(dataProvider = "getDataForLogin11", groups = "negative")
	    public void Login11(HashMap<String, String> input) throws InterruptedException {
	        UserIdPage data = login.login("72333663");
	        data.enterMobileNumber("1681445143");
	        data.selectOptionByName("Chattogram");
	        data.enterPassword("Gdhs@2024");
	        data.clickContinue();
	        data.openMasterSetup();
	        MedicinePage medicinePage = new MedicinePage(driver);
	        medicinePage.addmedicine();
	    for(int i=0;i<=10;i++) {
//	            MedicinePage medicinePage = new MedicinePage(driver);

	            // Add Medicine with manual values
	            medicinePage.addMedicine(
	                "",   // medicineName
	                "Schedule A1",            // scheduleText
	                "CAPSULE",       // categoryText
	                "Orlistat", // compositionText
	                "3 M HEALTH CARE",    // manufacturerText
	                "100"           // quantity
	            );

	            // Fill additional fields manually
	            medicinePage.enterMinQty("1");
	            medicinePage.enterMaxQty("200");
	            medicinePage.enterReorderQty("20");
	            medicinePage.enterReorderLevel("5");
	            medicinePage.enterHSNCode("30049099");
	            medicinePage.selectGST("0");
	            medicinePage.selectDiscountRequired("Yes");
	            medicinePage.enterDescription("Used for fever and mild pain relief");
	            medicinePage.enterDiscount("5");
	             medicinePage.selectVaccineCheckbox(); // Uncomment if required
	            medicinePage.enterAttribute("OTC");
	            medicinePage.enterCostPrice("8.50");
	            medicinePage.enterMRP("12.00");
	            medicinePage.enterSellPrice("11.00");
	            medicinePage.enterNoOfStrips("10");
	            medicinePage.enterFreeStrips("1");

	            // Save medicine
	            medicinePage.save();
	            System.out.println(i);
	        }

	    }
	
	    @DataProvider
	    public Object[][] getDataForLogin11() throws IOException {
	        List<HashMap<String, String>> data = getJsonDataToMap(
	            System.getProperty("user.dir") + "//src//main//java//ezion//Resources//NegativeTestScenario.json"
	        );
	        return new Object[][] { { data.get(10) } };
	    }
	}


