package PrakashSirAppointmentBooking.CaseSheet.TaskOrder;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class CounsellingPage extends Abstraction{

    WebDriver driver;

    public CounsellingPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
 // Tabs
    @FindBy(xpath = "//a[normalize-space()='Refer to Admission']")
    private WebElement referToAdmissionTab;

    @FindBy(xpath = "//a[normalize-space()='Refer to Appointment']")
    private WebElement referToAppointmentTab;

    @FindBy(xpath = "//a[normalize-space()='Counselling']")
    private WebElement counsellingTab;

    // Counselling Form Fields
    @FindBy(xpath = "//ngx-select[@placeholder='Select Counselling Name']")
    private WebElement counsellingNameDropdown;

    @FindBy(xpath = "//ngx-select[@placeholder='Select Counsellor Name']")
    private WebElement counsellorNameDropdown;

    @FindBy(xpath = "//label[normalize-space()='Performing Doctor']/following::div[contains(@class,'ngx-select__toggle')][1]")
    private WebElement performingDoctorDropdown;

    @FindBy(xpath = "//label[normalize-space()='Performing Nurse']/following::div[contains(@class,'ngx-select__toggle')][1]")
    private WebElement performingNurseDropdown;

    // Duration Options
    @FindBy(xpath = "//label[normalize-space()='Duration']/following::ul[1]/li/a[normalize-space()='10 Minutes']")
    private WebElement duration10Mins;

    @FindBy(xpath = "//label[normalize-space()='Duration']/following::ul[1]/li/a[normalize-space()='20 Minutes']")
    private WebElement duration20Mins;

    @FindBy(xpath = "//label[normalize-space()='Duration']/following::ul[1]/li/a[normalize-space()='30 Minutes']")
    private WebElement duration30Mins;

    // Notes
    @FindBy(xpath = "//textarea[@formcontrolname='notes']")
    private WebElement notesField;

    // Buttons
    @FindBy(xpath = "//input[@value='Add Counselling']")
    private WebElement addCounsellingBtn;

    @FindBy(xpath = "//input[@value='Reset']")
    private WebElement resetBtn;

    // Table (first row data)
    @FindBy(xpath = "//table[contains(@class,'added-table')]//tr[1]/td[2]")
    private WebElement firstRowCounsellingName;

    @FindBy(xpath = "//table[contains(@class,'added-table')]//tr[1]/td[3]")
    private WebElement firstRowCounsellorDetails;

    // Success/Error Popups
    @FindBy(xpath = "//div[@class='succesfull-info-popup']/span[contains(text(),'Counselling Saved Successfully')]")
    private WebElement counsellingSavedMsg;

    @FindBy(xpath = "//div[@class='succesfull-info-popup']/span[contains(text(),'Counselling Updated Successfully')]")
    private WebElement counsellingUpdatedMsg;

    @FindBy(xpath = "//div[@class='succesfull-info-popup']/span[contains(text(),'Please Check the Fields')]")
    private WebElement counsellingErrorMsg;

 // Tabs
    public void clickCounsellingTab() {
        counsellingTab.click();
    }

    // Dropdown Selections (generic method)
    private void selectDropdownValue(WebElement dropdown, String value) {
        dropdown.click();
        WebElement option = driver.findElement(
            By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'" 
                     + value.toLowerCase() + "')]")
        );
        option.click();
    }

    public void selectCounsellingName(String counselling) {
        selectDropdownValue(counsellingNameDropdown, counselling);
    }

    public void selectCounsellorName(String counsellor) {
        selectDropdownValue(counsellorNameDropdown, counsellor);
    }

    public void selectPerformingDoctor(String  doctor) {
        selectDropdownValue(performingDoctorDropdown, doctor);
    }

    public void selectPerformingNurse(String nurse) {
        selectDropdownValue(performingNurseDropdown, nurse);
    }

    // Duration
    public void selectDuration(String duration) {
        WebElement durationOption = driver.findElement(
            By.xpath("//ul[@class='healper-input']//a[normalize-space()='" + duration + "']")
        );
        durationOption.click();
    }

    // Notes
    public void enterNotes(String notes) {
        notesField.clear();
        notesField.sendKeys(notes);
    }

    // Actions
    public void clickAddCounselling() {
        addCounsellingBtn.click();
    }

    public void clickReset() {
        resetBtn.click();
    }

    // Validations
    public boolean isCounsellingSaved() {
        return counsellingSavedMsg.isDisplayed();
    }

    public boolean isCounsellingUpdated() {
        return counsellingUpdatedMsg.isDisplayed();
    }

    public boolean isCounsellingError() {
        return counsellingErrorMsg.isDisplayed();
    }

    // Table Data
    public String getFirstRowCounsellingName() {
        return firstRowCounsellingName.getText().trim();
    }

    public String getFirstRowCounsellorDetails() {
        return firstRowCounsellorDetails.getText().trim();
    }

}
