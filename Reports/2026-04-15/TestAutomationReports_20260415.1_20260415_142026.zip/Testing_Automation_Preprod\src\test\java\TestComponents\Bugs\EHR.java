package TestComponents.Bugs;



import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeoutException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EHR.ClinicalAseesment.BloodGroup;
import EHR.ClinicalAseesment.EHRHomePage;
import EzionpageObjects.UserIdPage;
import Lab.ApprovedListPage;
import Lab.LabWorkOrder;
import Lab.NewListTable;
import Lab.Re_TestPage;
import Lab.SampleCollectedList;
import Lab.SampleCollected_EditWorkList;
import Lab.WaitingApprovalPage;
import PrakashSirAppointmentBooking.EMR;
import Radiology.Radiology;
import Registration.NewRegistrationPage;
import Registration.PatientList;
import Registration.ServiceList;
import abdulTest.BaseTest;

public class EHR extends BaseTest {
	 UserIdPage data;
	  NewRegistrationPage registrationPage ;
   @Test(dataProvider = "getDataForLogin",priority = 1)
   public void Login(HashMap<String, String> input) throws InterruptedException {
       // Login
//       data = login.login(EnvUtil.get("USER_ID"));
//       data.enterMobileNumber(EnvUtil.get("PERSON_ID"));
//       data.enterPassword(EnvUtil.get("PASSWORD"));
//
//       data.clickContinue();
//   Thread.sleep(8000);
       String userId = prop.getProperty("USER_ID");
       String personId = prop.getProperty("PERSON_ID");
       String password = prop.getProperty("PASSWORD");
       String browser = System.getProperty("BROWSER");
       data = login.login(userId);
       data.enterMobileNumber(personId);
       data.enterPassword(password);
       data.clickContinue();
       System.out.println("Browser: " + browser);
//       System.out.println("Base URL: " + baseUrl);
       System.out.println("User ID: " + userId);
       System.out.println("Person ID: " + personId);
       data.clickContinue();
      
       data.navigateSalesWithRetry();
       }
   String targetMobileNumber;
   String firstname;
   @Test(dataProvider = "getDataForLogin",priority = 2)
   public void patientName(HashMap<String, String> input) {
       // Step 1: Search patient
       registrationPage = new NewRegistrationPage(driver);

       // Call the fillNewRegistrationForm method with all necessary form values
       registrationPage.clickbuttonapproval();
//       registrationPage.selectTitle();
       registrationPage.selectOptionFromNgxDropdown("Mr.");
       registrationPage.enterFirstName("");
       firstname=registrationPage.storedFirstName;
       registrationPage.enterMiddleName("doe");
       registrationPage.enterLastName("abraham");
       registrationPage.selectGender();
       registrationPage.selectOptionFromNgxDropdown("Male");
       registrationPage.enterDOB("12/12/2024");
       registrationPage.enterMobileNumber("");
       targetMobileNumber=registrationPage.lastEnteredMobileNumber;
//       targetMobileNumber="7411081113";
       registrationPage.save();

//System.out.println(targetMobileNumber);
   } 
//   
   @Test(dataProvider = "getDataForLogin", priority = 3)
   public void PatientRegistration(HashMap<String, String> input) throws InterruptedException {
   	PatientList patient = new PatientList(driver);
   	patient.patientlist();
   	patient.patientlist();
   	patient.patientlist();
   	patient.findPatientByMobile(targetMobileNumber);
   	System.out.println(driver.getCurrentUrl());
   	ServiceList service = new ServiceList(driver);
//   	Blood Sugar2 - LabTest
//    	service.fillBillingForm("General", "Dr. Izaan", "Self","Blood Sugar - LabTest","10","%","5");
//   	Thread.sleep(5000);
	service.clickByText("Department");
   	
   	service.byTextAttach("Department", "/ancestor::div[1]//ngx-select").click();
   	
	service.byTextAttach("Department", "/ancestor::div[1]//input").sendKeys("General");
	Thread.sleep(5000);
 	service.clickByText("General");
 	
   	service.clickByText("Physician");
   	
   	
   	service.byTextAttachClickable("Physician", "/ancestor::div[1]//ngx-select").click();
   	
	service.byTextAttachClickable("Physician", "/ancestor::div[1]//input").sendKeys("ramiz");
	
// 	service.clickByText("Dr. Ramiz");
   	
//    clickPhysicianDropdown();
   	service.selectDropdownOption("Dr. Ramiz");

//   	service.clickBillTypeDropdown();
 	
 	   	
   	service.clickByText("Bill Type");
   	service.byTextAttach("Bill Type", "/ancestor::div[1]//ngx-select").click();
   	
	service.byTextAttach("Bill Type", "/ancestor::div[1]//input").sendKeys("self");
	
// 	service.clickByText("Self");
 	
 	
    service.selectDropdownOption("Self");
//    service.clickPayerSelectDropdown();
//    service.selectDropdownOption("Test Payer");
    
//    service.clickServiceNameDropdown();
    
//    service.selectDropdownOption("Blood Sugar - LabTest"); // or any other service
   	service.clickByText("Service Name");
   	service.byTextAttach("Service Name", "/ancestor::div[1]//ngx-select").click();
   	
	service.byTextAttach("Service Name", "/ancestor::div[1]//input").sendKeys("Blood Sugar - LabTest");
	
	service.selectDropdownOption("Blood Sugar - LabTest");
    service.enterQuantity("10");

    service.clickDiscountTypeDropdown();
    service.selectDropdownOption("%");

    service.enterDiscountPercentage("5");

    service.clickAddButton();
    
   	service.clickByText("Service Name");
   	service.byTextAttach("Service Name", "/ancestor::div[1]//ngx-select").click();
   	
	service.byTextAttach("Service Name", "/ancestor::div[1]//input").sendKeys("vfx - Radiology");
	
	service.selectDropdownOption("vfx - Radiology");
    service.enterQuantity("10");

    service.clickDiscountTypeDropdown();
    service.selectDropdownOption("%");

    service.enterDiscountPercentage("5");

    service.clickAddButton();
       service.save();
       }
   String getbillNo;
   String workId ;    
   @Test(dataProvider = "getDataForLogin", priority = 4)
   public void NewList(HashMap<String, String> input) throws InterruptedException {
   	ServiceList patient = new ServiceList(driver);
   	Thread.sleep(5000);
   	getbillNo=patient.getBillNo();
   	System.out.println(getbillNo);
   	NewListTable listTable = new NewListTable(driver);
   	listTable.clickbuttonapproval();
   	Thread.sleep(5000);
   	listTable.clickActionByPatientAndPhysician(
   			getbillNo);
   	
workId = listTable.workId;
   	
//   	String workId = "808088";
   	System.out.println(workId);
   }
   @Test(dataProvider = "getDataForLogin", priority = 5)
   public void labworkOrder(HashMap<String, String> input) throws InterruptedException {
   	LabWorkOrder labOrder= new LabWorkOrder(driver);
   	Thread.sleep(5000);
   	Thread.sleep(5000);
   	labOrder.clickCheckboxByTestName("Blood Sugar");
   	
   }
////   
   @Test(dataProvider = "getDataForLogin", priority = 6)
   public void sampleList(HashMap<String, String> input) throws InterruptedException, TimeoutException  {
   	
   	
   	
//   	String workId = "808088";
   	Thread.sleep(5000);
//   	System.out.println(workId);
   	SampleCollectedList sampleList = new SampleCollectedList(driver);
 
   	System.out.println(workId +"new");
   	sampleList.clickReorderByWorkOrder2(workId);
   }
//   
   @Test(dataProvider = "getDataForLogin", priority = 7)
   public void sampleList_workorderList(HashMap<String, String> input) throws InterruptedException, TimeoutException {

   	SampleCollected_EditWorkList worklist = new SampleCollected_EditWorkList(driver);
   	Thread.sleep(5000);
//   	worklist.clickEditIconByTestName("Blood Urea");
   	worklist.editTestValueByTestName("Blood Sugar","2","jsdd");
//   	worklist.fillHistopathologyForm(
//   		    "HP-001",
//   		    "Livdf",
//   		    "Brodf",
//   		    "Abdf",
//   		    "Shdfh",
//   		    "Hadsf"
//   		);
   	
   	
   	worklist.selectDropdownValue("Cb");
   }
   @Test(dataProvider = "getDataForLogin", priority = 8)
   public void waitingList(HashMap<String, String> input) throws InterruptedException, TimeoutException {
   	WaitingApprovalPage waitingApproval = new WaitingApprovalPage(driver);
   	Thread.sleep(5000);
   	waitingApproval.clickReorderByWorkOrder(workId);
   	waitingApproval.clickByButtonValue("Save");
    	Thread.sleep(5000);
    	
   }
   
   @Test(dataProvider = "getDataForLogin", priority = 9)
   public void approvalList(HashMap<String, String> input) throws InterruptedException {
   	ApprovedListPage approval = new ApprovedListPage(driver);
	Thread.sleep(5000);
   	approval.clickReorderByWorkOrder(workId);
   	Re_TestPage retest = new Re_TestPage(driver);
   	Thread.sleep(5000);
   	retest.clickCheckboxForTest("Blood Sugar");
   	retest.clickGenerateWorkOrder();
   	retest.selectRequestedByEmployee("Cb");
   	retest.selectApprovedByEmployee("Cb");
   }
   
   
   @Test(dataProvider = "getDataForLogin",priority = 10)
   public void radiology(HashMap<String, String> input) throws InterruptedException {
   	ApprovedListPage approval = new ApprovedListPage(driver);
   	approval.clickByText("Radiology");
   	approval.clickByText("Radiology Order List");
   	
   	approval.clickActionByCategory(firstname, "View");
   	Thread.sleep(5000);
   	
   	Radiology radio = new Radiology(driver);
   	radio.clickActionByTitle("Attachment");
   	Thread.sleep(5000);
   	String path = System.getProperty("user.dir") + "\\test-output\\passed.png";
   	radio.uploadFile(path);
   	approval.clickByText("Add");
   	Thread.sleep(5000);
   	approval.clickByButtonValue("Cancel",2);
   	approval.clickByText("New", 2); 
   	approval.selectTypeFromNgxSelect("Completed");
    
   	
   	approval.clickByButtonValue("Update");
   	
   
   }
   
   
   
//   	
   @Test(dataProvider = "getDataForLogin",priority = 11)
   public void testEditLastVisit(HashMap<String, String> input) throws InterruptedException {
       // Step 1: Search patient
   	Thread.sleep(5000);
   	EMR	emrPage = new EMR(driver);
       emrPage.enterPatientNameOrMobile(registrationPage.storedFirstName);

       // Step 2: Click the first John abraham in list
       emrPage.clickFirstJohnAbraham(registrationPage.storedFirstName, 1);

       // Step 3: Click EMR / Accounts
       emrPage.clickEmrAccounts();
//       emrPage.clickClinicalAssessmentEdit();
//       emrPage.clickCaseSheetWrapper();
//       Thread.sleep(5000);
//       emrPage.clickDoctorName("Dr. Izaan");
       // Step 4: Click Edit in last visit
    
   }
//   

   
 @Test(dataProvider = "getDataForLogin",priority = 12)
 public void HighRisk(HashMap<String, String> input) throws InterruptedException {
	  
	  	EMR	emrPage = new EMR(driver);
	  BloodGroup blood = new BloodGroup(driver);
	   emrPage.clickClinicalAssessmentEdit();
	   
	  Thread.sleep(4000);
	  blood.selectBloodGroup();
	  blood.selectTypeFromNgxSelect("A+");
	  blood.selectConfirmedBy();
	  blood.selectTypeFromNgxSelect("Cb");
	  blood.confirmBloodGroup();
	  blood.clickSave();
	  
	  blood.clickTabByName("Allergies");
	  blood.clickDropdown("Add Allergy","allergyId");
	  blood.selectTypeFromNgxSelect("Milk");
	  blood.enterText("Add Allergy","duration", "5");
	  blood.clickDropdown("Add Allergy","period");
	  blood.selectTypeFromNgxSelect("days");
	  blood.clickDropdown("Add Allergy","severity");
	  blood.selectTypeFromNgxSelect("Intermittent");
	  blood.enterReaction("ok");
//	  blood.clickDropdown("Add Allergy","reactions");
	  blood.clickDropdown("Add Allergy","isActive");
	  blood.selectTypeFromNgxSelect("Active");
	  blood.enterText("Add Allergy","notes", "Occasional smoker");
	  blood.clickByButtonValue("Add Allergy");
	  
	  
	  
	  
	  blood.clickTabByName("Social Habits");
//	  blood.clickDropdown()
	  blood.clickDropdown("Add Social Habits","socialHabitsId");
	  blood.selectTypeFromNgxSelect("fgf");
	  blood.clickDropdown("Add Social Habits","period");
	  blood.selectTypeFromNgxSelect("days");
	  blood.clickDropdown("Add Social Habits","socialHabitStatus");
	  blood.selectTypeFromNgxSelect("Occasional");
	  blood.enterText("Add Social Habits","quantity", "5");

	  
	  
	  blood.clickDropdown("Add Social Habits","quantityInPeriod");
	  blood.selectTypeFromNgxSelect("Per Day");
	  blood.enterText("Add Social Habits","duration", "5");
	  blood.enterText("Add Social Habits","notes", "Occasional smoker");
	  blood.clickByButtonValue("Add Social Habit");
	  
	  
	  blood.clickTabByName("Medical History");
	  blood.clickDropdown("","historyType");
	  blood.selectTypeFromNgxSelect("Medical History");
	  blood.clickDropdown("","medicalHistoryId");
	  blood.selectTypeFromNgxSelect("cc");
	  blood.enterText("","duration", "5");
	  blood.clickDropdown("","period");
	  blood.selectTypeFromNgxSelect("day(s)");
	  blood.enterText("","notes", "Occasional smoker");
//	  blood.clickByButtonValue("Social Habits");
	  blood.clickByButtonValue("Add Medical History");
	  
	  
	  blood.clickTabByName("Family Medical History");
	  blood.clickDropdown("Add Family Medical History","medicalHistoryId");
	  blood.selectTypeFromNgxSelect("cc");
	  blood.clickDropdown("Add Family Medical History","relationship");
	  blood.selectTypeFromNgxSelect("Father");
	  blood.enterText("Add Family Medical History","duration", "5");
	  blood.clickDropdown("Add Family Medical History","period");
	  blood.selectTypeFromNgxSelect("days");
	  blood.enterText("Add Family Medical History","notes", "Occasional smoker");
	  blood.clickByButtonValue("Add Medical History",2);
	  
	  blood.clickTabByName("Current Medication");
	  blood.clickDropdown("Add Patient Current Medication","mid");
	  blood.selectTypeFromNgxSelect("hfdostmae");
	  blood.enterText("Add Patient Current Medication","reason", "Occasional smoker");
	  blood.clickByButtonValue("Add Current Medication");
	  
	  blood.clickTabByName("Catheter");
	  blood.clickDropdown("","bedSore");
	  blood.selectTypeFromNgxSelect("Yes");
	  blood.clickDropdown("","catheterUsage");
	  blood.selectTypeFromNgxSelect("Yes");
	  blood.clickDropdown("","catheterType");
	  blood.selectTypeFromNgxSelect("Foley Catheter");
	  blood.enterText("","cathetersize", "Occasional smoker");
	  blood.clickDropdown("","levelofInjury");
	  blood.selectTypeFromNgxSelect("jj");	  
	  blood.clickDropdown("","percentageofDisability");
	  blood.selectTypeFromNgxSelect("jj");	 
	  blood.clickDropdown("","urineBag");
	  blood.selectTypeFromNgxSelect("Yes");
	  blood.clickByButtonValue("Save",1);
	  
	  blood.clickTabByName("Study");
	  blood.clickDropdown("Study Detail","studyName");
	  blood.selectTypeFromNgxSelect("study");
	  blood.enterText("Study Detail","studyCode", "Occasional smoker");
	  blood.enterText("Study Detail","studyDescription", "Occasional smoker");
	  blood.clickByButtonValue("Add Study Detail");
	  
	  blood.clickTabByName("Mental General");
	  blood.clickDropdown("","medicalHistoryId");
	  blood.selectTypeFromNgxSelect("cc");
	  blood.clickDropdown("","attributeDetail");
	  blood.selectTypeFromNgxSelect("dd");
	  blood.enterText("","notes", "Occasional smoker");
	  blood.clickByButtonValue("Add Mental General");
	  
	  
	  blood.clickTabByName("Physical General");
	  blood.clickDropdown("","medicalHistoryId");
	  blood.selectTypeFromNgxSelect("vh");
	  blood.clickDropdown("","attributeDetail");
	  blood.selectTypeFromNgxSelect("fgf");
	  blood.enterText("","notes", "Occasional smoker");
	  blood.clickByButtonValue("Add Physical General");
	  
	  blood.clickTabByName("Physical Makeup");
	  blood.clickDropdown("","medicalHistoryId");
	  blood.selectTypeFromNgxSelect("vh");
//	  blood.clickDropdown("","attributeDetail");
//	  blood.selectTypeFromNgxSelect("hjbj");
	  blood.enterText("","notes", "Occasional smoker");
	  blood.clickByButtonValue("Add Physical Makeup");
	  
	  blood.clickTabByName("Clinical Findings");
	  blood.enterText("","git", "Occasional smoker");
	  blood.enterText("","rs", "Occasional smoker");
	  blood.enterText("","lungs", "Occasional smoker");
	  blood.enterText("","cvs", "Occasional smoker");
	  blood.enterText("","cns", "Occasional smoker");
	
	  blood.clickByButtonValue("Add");
//	  blood.enterText("","notes", "Occasional smoker");
	  
	  
	  
	  
 }
 
 @Test(dataProvider = "getDataForLogin",priority = 14)
 public void testEditLastVisit2(HashMap<String, String> input) throws InterruptedException {
     // Step 1: Search patient
 	Thread.sleep(5000);
 	EMR	emrPage = new EMR(driver);
     emrPage.enterPatientNameOrMobile(registrationPage.storedFirstName);

     // Step 2: Click the first John abraham in list
     emrPage.clickFirstJohnAbraham(registrationPage.storedFirstName, 1);

     // Step 3: Click EMR / Accounts
     emrPage.clickEmrAccounts();
//     emrPage.clickClinicalAssessmentEdit();
//     emrPage.clickCaseSheetWrapper();
//     Thread.sleep(5000);
//     emrPage.clickDoctorName("Dr. Izaan");
     // Step 4: Click Edit in last visit
  
 }
// 
 @Test(dataProvider = "getDataForLogin",priority = 15)
 public void testehrhomePag(HashMap<String, String> input) throws InterruptedException {
     // Step 1: Search patient
 	EHRHomePage homepage = new EHRHomePage(driver);
 	homepage.clickByText("Attachments");
 	homepage.clickByText("Add New");
 	
 	homepage.clickNgxSelect("Category");
 	homepage.selectTypeFromNgxSelect("Billing");
 	homepage.clickNgxSelect("Sub category");
 	homepage.selectTypeFromNgxSelect("Physician_Master");
 	homepage.clickNgxSelect("Uploaded by");
 	homepage.selectTypeFromNgxSelect("Fddf");
 	homepage.clickNgxSelect("Source");
 	homepage.selectTypeFromNgxSelect("Hospital");
 	String path = System.getProperty("user.dir") + "\\test-output\\passed.png";
 	homepage.uploadFileByLabel("Upload Attachments", path); // abstraction
 	homepage.clickByText("Upload"); // abstraction
 	homepage.clickLightboxClose(); //abstraction
 	homepage.clickActionByCategory("Billing", "Download");
 	 Thread.sleep(5000);
 	homepage.robotEnter();
 }
 
 @Test(dataProvider = "getDataForLogin",priority = 16)
 public void labgraps(HashMap<String, String> input) throws InterruptedException {
     // Step 1: Search patient
	  Thread.sleep(5000);
 	EHRHomePage homepage = new EHRHomePage(driver);
 	homepage.clickByText("Lab",2
 			
 			);
 	homepage.clickByText("InterpretAI");
 	homepage.clickActionByCategory2("Blood Sugar", "Graph");
// 	homepage.clickLightboxClose("lightbox-close", 1);
 	
 }
 
 @Test(dataProvider = "getDataForLogin",priority = 17)
 public void vaccinations(HashMap<String, String> input) throws InterruptedException {
     // Step 1: Search patient
	  Thread.sleep(5000);
 	EHRHomePage homepage = new EHRHomePage(driver);
 	homepage.clickByText("Vaccinations",1
 			
 			);
 	homepage.clickByButtonValue("Add Past Vaccine");

 	homepage.clickDropdown("Add Past Vaccines History","vaccineId");
 	homepage.selectTypeFromNgxSelect("BCG");
   BloodGroup blood = new BloodGroup(driver);
   blood.enterText("Add Past Vaccines History","planned_Date", "03/05/2026");
// 	blood.clickLightboxClose("lightbox-close", 2);
 	 blood.enterText("Add Past Vaccines History","notes", "Occasional smoker");
 	 blood.clickByButtonValue("Add Past Vaccine",2);
 }
 @DataProvider
 public Object[][] getDataForLogin() throws IOException {
     List<HashMap<String, String>> data = getJsonDataToMap(
         System.getProperty("user.dir") + "//src//main//java//ezion//Resources//AppointMent.json"
     );
     return new Object[][] { { data.get(0) } };
 }
}
