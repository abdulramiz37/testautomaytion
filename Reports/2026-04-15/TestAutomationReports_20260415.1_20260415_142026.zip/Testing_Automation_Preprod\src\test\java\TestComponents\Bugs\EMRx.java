package TestComponents.Bugs;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeoutException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import org.testng.Assert;

import EzionpageObjects.UserIdPage;
import PrakashSirAppointmentBooking.AppointmentBooking;
import PrakashSirAppointmentBooking.EMR;
import PrakashSirAppointmentBooking.CaseSheet.BrandListPage;
import PrakashSirAppointmentBooking.CaseSheet.ChiefComplaintsPage;
import PrakashSirAppointmentBooking.CaseSheet.DiagnosisPage;
import PrakashSirAppointmentBooking.CaseSheet.ExaminationPage;
import PrakashSirAppointmentBooking.CaseSheet.HighRiskPage;
import PrakashSirAppointmentBooking.CaseSheet.InstructionPage;
import PrakashSirAppointmentBooking.CaseSheet.InvestigationPage;
import PrakashSirAppointmentBooking.CaseSheet.NurseNotesPage;
import PrakashSirAppointmentBooking.CaseSheet.OpAssessmentTemplatePage;
import PrakashSirAppointmentBooking.CaseSheet.PrescriptionPage;
import PrakashSirAppointmentBooking.CaseSheet.VaccinationTableActions;
import PrakashSirAppointmentBooking.CaseSheet.VaccinePage;
import PrakashSirAppointmentBooking.CaseSheet.VitalPage;
import PrakashSirAppointmentBooking.CaseSheet.TaskOrder.AdmissionReferralPage;
import PrakashSirAppointmentBooking.CaseSheet.TaskOrder.CounsellingPage;
import PrakashSirAppointmentBooking.CaseSheet.TaskOrder.InjectionPage;
import PrakashSirAppointmentBooking.CaseSheet.TaskOrder.PatientTherapyPage;
import PrakashSirAppointmentBooking.CaseSheet.TaskOrder.TreatmentPage;
import PrakashSirAppointmentBooking.CaseSheet.TaskOrder.TreatmentPlanPage;
import PrakashSirAppointmentBooking.CaseSheet.TaskOrder.VaccinationPage;
import Registration.NewRegistrationPage;
import abdulTest.BaseTest;
import ezion.Resources.EnvUtil;

public class EMRx  extends BaseTest {
	
	 UserIdPage data;
	  NewRegistrationPage registrationPage ;
    @Test(dataProvider = "getDataForLogin",priority = 1)
    public void Login(HashMap<String, String> input) throws InterruptedException {
        // Login
//        data = login.login(EnvUtil.get("USER_ID"));
//        data.enterMobileNumber(EnvUtil.get("PERSON_ID"));
//        data.enterPassword(EnvUtil.get("PASSWORD"));
//
//        data.clickContinue();
//    Thread.sleep(8000);
        String userId = prop.getProperty("USER_ID");
        String personId = prop.getProperty("PERSON_ID");
        String password = prop.getProperty("PASSWORD");
        String browser = System.getProperty("BROWSER");
        data = login.login(userId);
        data.enterMobileNumber(personId);
        data.enterPassword(password);
        data.clickContinue();
        System.out.println("Browser: " + browser);
//        System.out.println("Base URL: " + baseUrl);
        System.out.println("User ID: " + userId);
        System.out.println("Person ID: " + personId);
        data.clickContinue();
        data.navigateSalesWithRetry();
        }
    
    @Test(dataProvider = "getDataForLogin",priority = 2)
    public void patientName(HashMap<String, String> input) {
        // Step 1: Search patient
        registrationPage = new NewRegistrationPage(driver);

        // Call the fillNewRegistrationForm method with all necessary form values
        registrationPage.clickbuttonapproval();
        registrationPage.selectTitle();
        registrationPage.selectOptionFromNgxDropdown("Mr.");
        registrationPage.enterFirstName("");
        registrationPage.enterMiddleName("doe");
        registrationPage.enterLastName("abraham");
        registrationPage.selectGender();
        registrationPage.selectOptionFromNgxDropdown("Male");
        registrationPage.enterDOB("12/12/2024");
        registrationPage.enterMobileNumber("");
//        targetMobileNumber=registrationPage.lastEnteredMobileNumber;
//        targetMobileNumber="7411081113";
        registrationPage.save();

//System.out.println(targetMobileNumber);
    } 
    

    @Test(dataProvider = "getDataForLogin",priority = 3)
    public void testEditLastVisit(HashMap<String, String> input) throws InterruptedException {
        // Step 1: Search patient
    	Thread.sleep(5000);
    	EMR	emrPage = new EMR(driver);
        emrPage.enterPatientNameOrMobile(registrationPage.storedFirstName);

        // Step 2: Click the first John abraham in list
        emrPage.clickFirstJohnAbraham(registrationPage.storedFirstName, 1);

        // Step 3: Click EMR / Accounts
        emrPage.clickEmrAccounts();
        emrPage.clickCaseSheetWrapper();
//        Thread.sleep(5000);
        emrPage.clickDoctorName("Dr. Izaan");
        // Step 4: Click Edit in last visit
//        emrPage.clickEditLastVisit();
    }
//    
    @Test(dataProvider = "getDataForLogin",priority = 4)
    public void HighRisk(HashMap<String, String> input) {
        // Step 1: Search patient
    	HighRiskPage riskpage=new  HighRiskPage(driver);
    	String[] diseaseList = {"TB", "Dengue"};
    	riskpage.selectMultipleHighRisks(diseaseList);
    	riskpage.closethebutton();
    }
    
    @Test(dataProvider = "getDataForLogin",priority = 5)
    public void VitalPagee(HashMap<String, String> input) {
        // Step 1: Search patient
    	VitalPage vitalsPage = new VitalPage(driver);
    	  vitalsPage.enterTemperature("98.6");
          vitalsPage.enterSpO2("97");
          vitalsPage.enterPulse("72");
          vitalsPage.enterHeartRate("75");
          vitalsPage.enterRespRate("16");
          vitalsPage.enterWeight("70");
          vitalsPage.enterHeight("170");
          vitalsPage.enterSize("4");
          vitalsPage.enterBPSys("120");
          vitalsPage.enterBPDia("80");
          vitalsPage.enterPostSugar("110");
          vitalsPage.enterPreSugar("95");
          vitalsPage.enterRandomSugar("105");
          vitalsPage.enterWaist("32");
          vitalsPage.enterBodyFat("18");
          vitalsPage.enterVisceralFat("10");
//          vitalsPage.clickDropdown1("Izaan");
          vitalsPage.byTextAttach("Vital","/ancestor::div[3]//ngx-select[@formcontrolname='performDoc']").click();
        //*[normalize-space(text())='Vital']/ancestor::div[3]//ngx-select[@formcontrolname='performDoc']
          vitalsPage.clickDropdown2("FddfFgf");
          vitalsPage.selectWheelChairUsage("yes");
          vitalsPage.byTextAttach("Vital","/ancestor::div[3]//input[@type='button']").click();
          vitalsPage.byTextAttach("Vital","/ancestor::div[2]//div//img").click();
        
        
      }
    
    @Test(dataProvider = "getDataForLogin", priority = 6)
    public void ChiefComplaints(HashMap<String, String> input) {
        
        // Step 1: Create Page Object
        ChiefComplaintsPage chiefComplaintsPage = new ChiefComplaintsPage(driver);
//        chiefComplaintsPage.clickChiefComplaintsAddIcon();
        
        // Step 2: Define multiple complaints dynamically
        List<Map<String, String>> complaintsList = new ArrayList<>();

        // Complaint 1
        Map<String, String> comp1 = new HashMap<>();
        comp1.put("complaint", "prakashhsir");
        comp1.put("period", "5d");
        comp1.put("history", "Patient has had backache for 5 days");
        comp1.put("doctor", "Izaan");
        comp1.put("nurse", "Fddf");
        comp1.put("notes", "No previous history of injury.");

        // Multiple departments as comma separated
        comp1.put("departments", "card");

        complaintsList.add(comp1);

        // Complaint 2
        Map<String, String> comp2 = new HashMap<>();
        comp2.put("complaint", "Coronary atherosclerosis");
        comp2.put("period", "3d");
        comp2.put("history", "Patient complains of intermittent headache");
        comp2.put("doctor", "Izaan");
        comp2.put("nurse", "Fddf");
        comp2.put("notes", "No history of migraine.");
        complaintsList.add(comp2);
        
        Map<String, String> comp3 = new HashMap<>();
        comp3.put("complaint", "Fibroids");
        comp3.put("period", "3d");
        comp3.put("history", "Patient complains of intermittent headache");
        comp3.put("doctor", "Izaan");
        comp3.put("nurse", "Fddf");
        comp3.put("notes", "No history of migraine.");
        complaintsList.add(comp3);
        
        
        Map<String, String> comp4 = new HashMap<>();
        comp4.put("complaint", "Gum Swelling");
        comp4.put("period", "3d");
        comp4.put("history", "Patient complains of intermittent headache");
        comp4.put("doctor", "Izaan");
        comp4.put("nurse", "Fddf");
        comp4.put("notes", "No history of migraine.");
        complaintsList.add(comp4);

        // Add more complaints if needed
        // ...

        // Step 3: Loop through each complaint and fill the form
        for (Map<String, String> comp : complaintsList) {
   
            chiefComplaintsPage.selectChiefComplaint(comp.get("complaint"));
            try {
                if (chiefComplaintsPage.isAddNewComplaintPresent()) {

                    chiefComplaintsPage.clickAddNewComplaint();

                    // Fill complaint form
                    chiefComplaintsPage.enterComplaint(chiefComplaintsPage.finalComplaint);

                    // Handle multiple departments
                    String[] departments = comp.get("departments").split(",");
                    chiefComplaintsPage.selectDepartments(departments);

                    // Set active toggle
                    chiefComplaintsPage.setActive(true);

                    // Add attribute
                    chiefComplaintsPage.enterAttribute(chiefComplaintsPage.finalComplaint);
                    chiefComplaintsPage.clickAddAttribute();

                    // Save the complaint
                    chiefComplaintsPage.clickSave();
                    chiefComplaintsPage.clickCloseLightbox();
                }
            } catch (Exception e) {
                System.out.println("⚠️ Error while adding Chief Complaint: " + e.getMessage());
                e.printStackTrace();
            }
            chiefComplaintsPage.enterPeriod(comp.get("period"));
            chiefComplaintsPage.enterPresentHistory(comp.get("history"));
            chiefComplaintsPage.selectPerformingDoctor(comp.get("doctor"));
            chiefComplaintsPage.selectPerformingNurse(comp.get("nurse"));
            chiefComplaintsPage.enterNotes(comp.get("notes"));

            // Click Add
            chiefComplaintsPage.clickAddButton();
            chiefComplaintsPage.clickChiefComplaintsAddIcon();
        
            }
        
    }


    @Test(dataProvider = "getDataForLogin", priority = 18)
    public void examination(HashMap<String, String> input) throws InterruptedException {

        // Step 1: Create Page Object
        ExaminationPage examinationPage = new ExaminationPage(driver);
        examinationPage.clickExaminationToggle();

        // Step 2: Define multiple examinations dynamically
        List<Map<String, String>> examinationList = new ArrayList<>();

        // Examination 1
        Map<String, String> exam1 = new HashMap<>();
        exam1.put("examination", "jbscjakbh");
        exam1.put("problemSince", "2 Weeks");
        exam1.put("severity", "Moderate");
        exam1.put("doctor", "Izaan");
        exam1.put("nurse", "Fddf");
        exam1.put("notes", "Patient showing moderate symptoms. Monitor regularly.");
      exam1.put("departments", "card");
        examinationList.add(exam1);

        // Examination 2
        Map<String, String> exam2 = new HashMap<>();
        exam2.put("examination", "Audiometry");
        exam2.put("problemSince", "1 Week");
        exam2.put("severity", "Low");
        exam2.put("doctor", "Izaan");
        exam2.put("nurse", "Fddf");
        exam2.put("notes", "Blood pressure slightly elevated.");
        examinationList.add(exam2);

        // Add more examinations if needed...
        // ...

        // Step 3: Loop through each examination and fill the form
        for (Map<String, String> exam : examinationList) {
            try {
                // Select or add examination
                examinationPage.selectExamination(exam.get("examination"));

                // If new exam creation popup appears
                if (examinationPage.isPageDisplayed()) {
//                    examinationPage.clickAddExamination();

                    examinationPage.selectType("General");
//                    examinationPage.enterName("Blood Pressure Test");
                  String[] departments = exam.get("departments").split(",");
                    examinationPage.selectDepartments(departments);
                    examinationPage.setActive(true);
                    examinationPage.enterAttribute("Systolic/Diastolic");
                    examinationPage.clickAddAttribute();
                    examinationPage.clickSave();
                    examinationPage.clickCloseLightbox();
                }
            }
                catch (Exception e) {
                    System.out.println("⚠️ Error while adding Examination: " + e.getMessage());
                    e.printStackTrace();
                }
            
                // Fill remaining details
                examinationPage.setProblemSince(exam.get("problemSince"));
                examinationPage.selectSeverity(exam.get("severity"));
                examinationPage.selectPerformingDoctor(exam.get("doctor"));
                examinationPage.selectPerformingNurse(exam.get("nurse"));
                examinationPage.enterNotes(exam.get("notes"));

                // Add to list
                examinationPage.clickAddExamination();

                // Reopen the section for next loop if needed

            }
        

        // Step 4: Collapse Examination section
        examinationPage.clickExaminationToggle();
    }
//
    @Test(dataProvider = "getDataForLogin", priority = 19)
    public void investigation(HashMap<String, String> input) throws InterruptedException {

        // Step 1: Create Page Object
        InvestigationPage investigationPage = new InvestigationPage(driver);
        investigationPage.clickInvestigationToggle();

        // Step 2: Define multiple investigations dynamically
        List<Map<String, String>> investigationList = new ArrayList<>();

        // Investigation 1
        Map<String, String> inv1 = new HashMap<>();
        inv1.put("service", "Basic Health - GeneralPackage");
        inv1.put("doctor", "Izaan");
        inv1.put("nurse", "Fddf");
        inv1.put("results", "Hemoglobin slightly low, needs monitoring.");
        inv1.put("notes", "Recommend further iron studies.");
        inv1.put("outsideTest", "true");
        inv1.put("provideDiscount", "true");
        inv1.put("discountType", "By Percentage");
        inv1.put("discountAmount", "10");
        investigationList.add(inv1);

        // Investigation 2
//        Map<String, String> inv2 = new HashMap<>();
//        inv2.put("service", "General Tests");
//        inv2.put("doctor", "Izaan");
//        inv2.put("nurse", "Fddf");
//        inv2.put("results", "Normal results.");
//        inv2.put("notes", "No further action required.");
//        inv2.put("outsideTest", "false");
//        inv2.put("provideDiscount", "false");
//        investigationList.add(inv2);

        // Step 3: Loop through each investigation and fill the form
        for (Map<String, String> inv : investigationList) {
//        	investigationPage.scrollToElementCenter("//*[normalize-space(text())='Investigation']/ancestor::div[3]//*[normalize-space(text())='Service']/ancestor::div[1]//ng-select//input");
            investigationPage.clickByTextAttachJS("Investigation", "/ancestor::div[3]//*[normalize-space(text())='Service']/ancestor::div[1]//ng-select");
            investigationPage.byTextAttach("Investigation", "/ancestor::div[3]//*[normalize-space(text())='Service']/ancestor::div[1]//ng-select//input").sendKeys("basic health");
            investigationPage.byTextAttach(inv.get("service"),"").click();
//            investigationPage.selectPerformingDoctor(inv.get("doctor"));
            investigationPage.selectPerformingNurse(inv.get("nurse"));
            investigationPage.enterTestResults(inv.get("results"));
            investigationPage.enterNotes(inv.get("notes"));

            // Handle Outside Test
            if (inv.get("outsideTest").equalsIgnoreCase("true")) {
                investigationPage.checkOutsideTest();
            }

            // Handle Discount
            if (inv.get("provideDiscount").equalsIgnoreCase("true")) {
                investigationPage.checkProvideDiscount();
                investigationPage.selectDiscountType(inv.get("discountType"));
                investigationPage.enterDiscountAmount(inv.get("discountAmount"));
            }

            // Click Add Investigation
            investigationPage.clickAddInvestigation();
        }

        // Step 4: Collapse Investigation section
        investigationPage.clickInvestigationToggle();
    }

//    @Test(dataProvider = "getDataForLogin", priority = 20)
//    public void diagnosis(HashMap<String, String> input) throws InterruptedException {
//
//        // Step 1: Create Page Object
//        DiagnosisPage diagnosisPage = new DiagnosisPage(driver);
//
//        // Step 2: Open Diagnosis section
//        diagnosisPage.clickDiagnosisToggle();
//
//        // Step 3: Define multiple diagnoses dynamically
//        List<Map<String, String>> diagnosisList = new ArrayList<>();
//
//        // Diagnosis 1
//        Map<String, String> diag1 = new HashMap<>();
//        diag1.put("diagnosis", "");
//        diag1.put("doctor", "Izaan");
//        diag1.put("nurse", "Fddf");
//        diag1.put("treatment", "Patient shows symptoms of early diabetes, lifestyle modification advised.");
//        diagnosisList.add(diag1);
//
//        // Diagnosis 2
//        Map<String, String> diag2 = new HashMap<>();
//        diag2.put("diagnosis", "diarrhoea");
//        diag2.put("doctor", "Izaan");
//        diag2.put("nurse", "Fddf");
//        diag2.put("treatment", "Blood pressure elevated, advised regular monitoring and medication.");
//        diagnosisList.add(diag2);
//
//        // Step 4: Loop through each diagnosis and fill the form
//        for (Map<String, String> diag : diagnosisList) {
//            try {
//                // Select or add diagnosis
//                diagnosisPage.selectDiagnosis(diag.get("diagnosis"));
//
//                // If new diagnosis creation popup appears
//                if (diagnosisPage.isPageDisplayed()) {
//                    diagnosisPage.enterDiagnosisCode("c"+System.currentTimeMillis());
//                    diagnosisPage.enterDiagnosisName(diagnosisPage.finalDiagnosis);
//                    diagnosisPage.enterLocalDescription("Auto-generated local description");
//                    diagnosisPage.enterAttribute("Chronic");
//                    diagnosisPage.clickAddAttribute();
//                    diagnosisPage.clickSave();
//                    diagnosisPage.clickCloseAddDiagnosisPopup();
//                }
//            } catch (Exception e) {
//                System.out.println("⚠️ Error while adding Diagnosis: " + e.getMessage());
//                e.printStackTrace();
//            }
//
//            // Fill remaining details
//            diagnosisPage.selectPerformingDoctor(diag.get("doctor"));
//            diagnosisPage.selectPerformingNurse(diag.get("nurse"));
//            diagnosisPage.enterTreatmentGiven(diag.get("treatment"));
//
//            // Add to list
//            diagnosisPage.clickAddDiagnosis();
//
//            // Reopen section for next iteration if needed
//        }
//
//        // Step 5: Collapse Diagnosis section
//        diagnosisPage.clickDiagnosisToggle();
//    }

    PrescriptionPage prescriptionPage;
    
    @Test(dataProvider = "getDataForLogin", priority = 21)
    public void prescription(HashMap<String, String> input) throws InterruptedException {

        // Step 1: Create Page Object
         prescriptionPage = new PrescriptionPage(driver);

        // Step 2: Open Prescription section
        prescriptionPage.clickPrescriptionToggle();
//        prescriptionPage.addPrescriptionBtne2();
//        // Step 3: Define medicines dynamically
//        List<Map<String, String>> medicineList = new ArrayList<>();
//
//        // Medicine 1
//        Map<String, String> med1 = new HashMap<>();
//        med1.put("medicine", "");
//        med1.put("frequency", "1 - 0 - 1  Twice a day");
//        med1.put("dosage", "3.0");
//        med1.put("unit", "nos");
//        med1.put("when", "After Food");
//        med1.put("duration", "5d");
//        med1.put("quantity", "1");
//        med1.put("route", "hbsd");
//        med1.put("instructions", "Hot Water");
//        med1.put("doctor", "Izaan");
//        med1.put("nurse", "Fddf");
//        medicineList.add(med1);
//
//        // Medicine 2
//        Map<String, String> med2 = new HashMap<>();
//        med2.put("medicine", "");
//        med2.put("frequency", "1 - 1 - 1");
//        med2.put("dosage", "5.0");
//        med2.put("unit", "ml");
//        med2.put("when", "Before Food");
//        med2.put("duration", "2d");
//        med2.put("quantity", "2");
//        med2.put("route", "hbsd");
//        med2.put("instructions", "Milk");
//        med2.put("doctor", "Izaan");
//        med2.put("nurse", "Fddf");
//        medicineList.add(med2);
//
//        // Medicine 3
//        Map<String, String> med3 = new HashMap<>();
//        med3.put("medicine", "");
//        med3.put("frequency", "0 - 0 - 1 Night only");
//        med3.put("dosage", "2.5");
//        med3.put("unit", "ml");
//        med3.put("when", "After Food");
//        med3.put("duration", "3d");
//        med3.put("quantity", "1");
//        med3.put("route", "hbsd");
//        med3.put("instructions", "Hot Water");
//        med3.put("doctor", "Izaan");
//        med3.put("nurse", "Fddf");
//        medicineList.add(med3);
//
//        // Medicine 4
//        Map<String, String> med4 = new HashMap<>();
//        med4.put("medicine", "");
//        med4.put("frequency", "1 - 1 - 1 - 1 Four times a day");
//        med4.put("dosage", "1.5");
//        med4.put("unit", "nos");
//        med4.put("when", "Before Food");
//        med4.put("duration", "4d");
//        med4.put("quantity", "1");
//        med4.put("route", "hbsd");
//        med4.put("instructions", "Milk");
//        med4.put("doctor", "Izaan");
//        med4.put("nurse", "Fddf");
//        medicineList.add(med4);
//
//        // Step 4: Loop through medicines and fill the form
//        for (Map<String, String> med : medicineList) {
//            try {
//                // Select or add medicine
//                prescriptionPage.selectMedicineName(med.get("medicine"));
//           
//                // If new medicine creation popup appears
//                if (prescriptionPage.isAddMedicinePopupDisplayed()) {
//                    prescriptionPage.enterMedicineName(prescriptionPage.finalMedicine);
////                    prescriptionPage.enterMedicineCode("M"+"235");
//                    prescriptionPage.selectMedicineType("Schedule A1");
//                    prescriptionPage.selectMedicineCategory("SALTS");
//                    prescriptionPage.selectManufacturer("	CALTEN");
//                    prescriptionPage.selectGenericName("METFORMIN HCL");
////                    METFORMIN HCL
//                    prescriptionPage.selectRack("ajhj");
//                    prescriptionPage.enterUnits("10");
//                    prescriptionPage.selectGST("0");
//                    prescriptionPage.checkIsVaccine();
//                    
//                    prescriptionPage.clickSaveButton();
//                    prescriptionPage.clickCloseButton();
//                    prescriptionPage.selectMedicineName2(prescriptionPage.finalMedicine+" /"+" METFORMIN HCL");
//                  
//                }
//            } catch (Exception e) {
//                System.out.println("⚠️ Error while adding Medicine: " + e.getMessage());
//                e.printStackTrace();
//            }
//
////             Fill prescription details
//            prescriptionPage.selectUnit(med.get("unit"));
//            prescriptionPage.selectDosage(med.get("dosage"));
//            prescriptionPage.selectFrequency(med.get("frequency"));
//            prescriptionPage.selectWhenToTaken(med.get("when"));
//            prescriptionPage.selectDuration(med.get("duration"));
//            prescriptionPage.enterQuantity(med.get("quantity"));
//            prescriptionPage.selectRoute(med.get("route"));
//            prescriptionPage.selectInstructions(med.get("instructions"));
//            prescriptionPage.enterNotes("Monitor for side effects.");
//            prescriptionPage.selectPerformingDoctor(med.get("doctor"));
//            prescriptionPage.selectPerformingNurse(med.get("nurse"));
//
//            // Add Medicine to prescription list
//            prescriptionPage.clickAddMedicine();
//        }
//
//        // Step 5: Save Prescription
//        prescriptionPage.clickAddPrescriptionList();
//
//        // Step 6: Collapse Prescription section
//        prescriptionPage.clickPrescriptionToggle();
    }
    
        


  @Test(dataProvider = "getDataForLogin", priority = 22)
  public void vaccinelist(HashMap<String, String> input) throws InterruptedException {
	// Initialize once
	  VaccinationTableActions vaccinationActions = new VaccinationTableActions(driver);
	  VaccinePage vaccinePage = new VaccinePage(driver);
	  // Navigate to the vaccination page
//	  driver.get("https://your-vaccination-page-url");
	  vaccinationActions.vaccinetoggle();
	  vaccinationActions.clickConfirmButton();
	  // Click edit for Birth stage
//	  if (vaccinationActions.clickEditOnVaccinationStage("Birth")) {
	  List<Map<String, String>> vaccineList = new ArrayList<>();

      // Vaccine 1
      Map<String, String> vac1 = new HashMap<>();
      vac1.put("armu", "Birth");
      vac1.put("vaccine", "OPV 0");
      vac1.put("medicine", "excel medicine g");
      vac1.put("givenDate", "08/20/2025");
      vac1.put("batch", "BATCH123");
      vac1.put("expDate", "12/31/2028");
      vac1.put("height", "70");
      vac1.put("weight", "9");
      vac1.put("head", "40");
      vac1.put("notes", "Patient responded well, no side effects.");
      vaccineList.add(vac1);

      // Vaccine 2
      Map<String, String> vac2 = new HashMap<>();
      vac2.put("armu", "Birth");
      vac2.put("vaccine", "BCG");
      vac2.put("medicine", "SYNFLORIX");
      vac2.put("givenDate", "08/21/2025");
      vac2.put("batch", "BATCH456");
      vac2.put("expDate", "12/31/2027");
      vac2.put("height", "71");
      vac2.put("weight", "9.2");
      vac2.put("head", "41");
      vac2.put("notes", "No fever, mild swelling observed.");
      vaccineList.add(vac2);
      
//      Map<String, String> vac3 = new HashMap<>();
//      vac3.put("armu", "Birth");
//      vac3.put("vaccine", "hfdivgmtb");
//      vac3.put("medicine", "Actiza TT");
//      vac3.put("givenDate", "08/21/2025");
//      vac3.put("batch", "BATCH456");
//      vac3.put("expDate", "12/31/2027");
//      vac3.put("height", "71");
//      vac3.put("weight", "9.2");
//      vac3.put("head", "41");
//      vac3.put("notes", "No fever, mild swelling observed.");
//      vaccineList.add(vac3);
      // Step 5: Loop through vaccines and fill form
      for (Map<String, String> vac : vaccineList) {

          // Click edit for specific vaccine
          if (vaccinationActions.clickVaccineIfBirthPresent(vac.get("armu"),vac.get("vaccine"))) {

              vaccinePage.selectMedicineName(vac.get("medicine"));
              vaccinePage.enterGivenDate(vac.get("givenDate"));
              vaccinePage.enterBatch(vac.get("batch"));
              vaccinePage.enterExpDate(vac.get("expDate"));
              vaccinePage.enterHeight(vac.get("height"));
              vaccinePage.enterWeight(vac.get("weight"));
              vaccinePage.enterHeadCircumference(vac.get("head"));
              vaccinePage.enterNotes(vac.get("notes"));

              vaccinePage.clickSave();
              
          }
    
          
          else {
        	  
        	  
              System.out.println("❌ Vaccine '" + vac.get("vaccine") + "' not found in the table.");
          }
      }
      
	  vaccinationActions.vaccinetoggle();
  }
//  
@Test(dataProvider = "getDataForLogin", priority = 23)
public void brandList(HashMap<String, String> input) throws InterruptedException {

    // Step 1: Create Page Object
    BrandListPage brandListPage = new BrandListPage(driver);
//    assert brandListPage.isBrandListPageLoaded();
    brandListPage.toggleBrandListSection();
    brandListPage.toggleAddComboVaccine();
    // Step 2: Select dropdown values
    brandListPage.selectMedicine("hfd");
    
    brandListPage.changeVaccines2(Arrays.asList("BCG-Bacillus Calmette Guerin - Tuberculosis", "DTP-Diphtheria, tetanus, whole cell Pertussis", "OPV-Oral poliovirus vaccine","TT-Tetanus toxoid"));


    // Step 3: Click Save
//    brandListPage.clickSave();

    // Step 4: Verify added row count
    int count = brandListPage.getAddedVaccineCount();
    System.out.println("✅ Total brands added: " + count);

    // Step 5: Collapse/Expand section if needed
    // (If you later add a toggle method like in NurseNotesPage)
    // brandListPage.toggleBrandListSection();
    brandListPage.toggleBrandListSection();
}
////////  }
@Test(dataProvider = "getDataForLogin", priority = 24)
public void nurseNotes(HashMap<String, String> input) throws InterruptedException {

	    // Step 1: Create Page Object
	    NurseNotesPage nurseNotesPage = new NurseNotesPage(driver);
	    nurseNotesPage.toggleNurseNotesSection();

	    // Step 2: Select dropdown values
	    nurseNotesPage.selectNurse("Fddf");
	    nurseNotesPage.selectShift("Morning Shift");
	    nurseNotesPage.setDate("08/18/2025 10:55 AM");
	    nurseNotesPage.selectPainLevel("xx");
	    
	    // Step 3: Enter notes
	    nurseNotesPage.enterNotes("Patient showing moderate symptoms. Monitor regularly.");

	    // Step 4: Click Add button
	    nurseNotesPage.clickAddNurseNotes();
	    nurseNotesPage.toggleNurseNotesSection();
	}


//@Test(dataProvider = "getDataForLogin",priority = 25)
//public void instruction(HashMap<String, String> input) {
//  // Step 1: Search patient
//	InstructionPage instructionPage = new InstructionPage(driver);
//	
//	instructionPage.selectInstruction("Avoid Fast Food");
//	instructionPage.selectDoctor("Izaan");
//	instructionPage.selectNurse("Fddf");
//	instructionPage.enterNotes("Give therapy twice a week.");
//	instructionPage.clickAdd();
//
//	if(instructionPage.isSaveMessageDisplayed()) {
//	    System.out.println("✅ Instruction saved successfully");
//	}
//	instructionPage.clickInstructionToggle();
//	
//	
//}
AdmissionReferralPage admissionPage;
@Test(dataProvider = "getDataForLogin",priority = 26)
public void testAddReferralAdmission(HashMap<String, String> input) {
	
		admissionPage = new AdmissionReferralPage(driver);
  // Step 1: Search patient
	 admissionPage.toggleTaskOrderSection();
admissionPage.referadmission();
   // Fill Reason for Admission
   admissionPage.enterReasonForAdmission("Patient requires immediate care");

   // Select Hospital Type
   admissionPage.selectHospitalType("Inhouse"); // or "External"

   // Select Admission Mode
   admissionPage.selectAdmissionMode("Immediate"); // Elective / Immediate / Emergency

   // Select Preferred Admission Period
   admissionPage.selectAdmissionPeriod("today"); // today / 2days / week / 15days / month / 2months / custom

   // Select Insurance
   admissionPage.selectInsurance("Yes"); // Yes / No

   // Select Specific Doctor
   admissionPage.selectSpecificDoctor("Izaan");

   // Click Add Referral
   admissionPage.clickAddReferral1();

   // Optional: Reset the form
   // admissionPage.clickReset();
	
	
}


@Test(dataProvider = "getDataForLogin",priority = 27)
public void testAddreferappointment(HashMap<String, String> input) {
	
	AdmissionReferralPage	admissionPage = new AdmissionReferralPage(driver);
  // Step 1: Search patient
//	 admissionPage.toggleTaskOrderSection();
	 admissionPage.referappointment();

   // Fill Reason for Admission
   admissionPage.enterReasonForAdmission("Patient requires immediate care");

   // Select Hospital Type
   admissionPage.selectHospitalType("Inhouse"); // or "External"

   // Select Admission Mode
   admissionPage.selectAdmissionMode("Immediate"); // Elective / Immediate / Emergency

   // Select Preferred Admission Period
   admissionPage.selectAppointmentPeriod("today"); // today / 2days / week / 15days / month / 2months / custom

   // Select Insurance
//   admissionPage.selectInsurance("Yes"); // Yes / No

   // Select Specific Doctor
   admissionPage.selectSpecificDoctor("Izaan");

   // Click Add Referral
   admissionPage.clickAddReferral2();

   // Optional: Reset the form
   // admissionPage.clickReset();
	
	
}
//@Test(dataProvider = "getDataForLogin",priority = 28)
//public void councelling(HashMap<String, String> input) {
//	
//	 CounsellingPage counsellingPage = new CounsellingPage(driver);
//
//   // Step 1: Go to Counselling tab
//   counsellingPage.clickCounsellingTab();
//
//   // Step 2: Fill Form
//   counsellingPage.selectCounsellingName("Family Theraphy");
//   counsellingPage.selectCounsellorName("Fddf");
////   counsellingPage.selectPerformingDoctor("Izaan");
//   counsellingPage.selectPerformingNurse("Fddf");
//   counsellingPage.selectDuration("10 Minutes");
//   counsellingPage.enterNotes("Patient requires counselling session");
//
//   // Step 3: Click Add Counselling
//   counsellingPage.clickAddCounselling();
//
//	
//	
//}
//
//@Test(dataProvider = "getDataForLogin",priority = 29)
//public void testAddTherapy(HashMap<String, String> input) {
//	
//	PatientTherapyPage therapyPage = new PatientTherapyPage(driver);
//	
//	therapyPage.clickTherapyTab();
//	
//  therapyPage.selectTherapy("fdfs");
//
//  // Select Therapist
//  therapyPage.selectTherapists("Dr. Izaan", "Dr. Jaha", "Fddf");
//
//  // Enter Improvement Marks
//  therapyPage.enterImprovementMarks("8");
//
//  // Select Duration
//  therapyPage.selectDuration("30 Minutes");
//
//  // Select Performing Doctor
////  therapyPage.selectPerformingDoctor("Izaan");
//
//  // Select Performing Nurse
//  therapyPage.selectPerformingNurse("Fddf");
//
//  // Enter Notes
//  therapyPage.enterNotes("Patient responded positively to therapy session.");
//
//  // Click Add Therapy
//  therapyPage.clickAddTherapy();
//
//	
//	
//}
////
//@Test(dataProvider = "getDataForLogin",priority = 30)
//public void testAddInjection(HashMap<String, String> input) {
//	InjectionPage  injectionPage = new InjectionPage(driver);
//  injectionPage.openInjectionTab();
//  injectionPage.selectInjection("Injection");
////  injectionPage.selectPerformingDoctor("Izaan");
//  injectionPage.selectPerformingNurse("Fddf");
//  injectionPage.enterNotes("Patient given injection without complications.");
//  injectionPage.clickAddInjection();
//
//	
//	
//}
//@Test(dataProvider = "getDataForLogin",priority = 31)
//public void testAddVaccine(HashMap<String, String> input) {
//	
//  VaccinationPage vaccinationPage = new VaccinationPage(driver);
//  vaccinationPage.clickVaccinationTab();
//  vaccinationPage.selectVaccine("Rotavirus 3");
////  vaccinationPage.selectPerformingDoctor("Izaan");
//  vaccinationPage.selectPerformingNurse("Fddf");
//  vaccinationPage.enterPlannedDate("08/22/2025");
//  vaccinationPage.enterNotes("Patient requires immunization as per schedule");
//  vaccinationPage.clickAddVaccine();
//
//  admissionPage.toggleTaskOrderSection();
//	
//}


@Test(dataProvider = "getDataForLogin", priority = 32)
public void treatmentplanpage(HashMap<String, String> input) throws InterruptedException, TimeoutException {

  // Step 1: Create Page Object
  TreatmentPlanPage planPage = new TreatmentPlanPage(driver);
  planPage.clickTreatmentPlanTab();
  // Step 2: Define multiple treatment plans dynamically
  List<Map<String, String>> treatmentPlans = new ArrayList<>();

  // Treatment Plan 1
  Map<String, String> plan1 = new HashMap<>();
  plan1.put("planName", "mnm");
  plan1.put("nextVisit", "08/28/2025");
  plan1.put("startDate", "08/26/2025");
  plan1.put("endDate", "09/26/2025");
  plan1.put("physician", "Dr. Izaan");
  plan1.put("status", "New");
  plan1.put("notes", "Patient advised rest.");
  treatmentPlans.add(plan1);

//  Map<String, String> plan2 = new HashMap<>();
//  plan2.put("planName", "ssss");
//  plan2.put("nextVisit", "09/05/2025");
//  plan2.put("startDate", "08/30/2025");
//  plan2.put("endDate", "10/01/2025");
//  plan2.put("physician", "Dr. Izaan");
//  plan2.put("status", "New");
//  plan2.put("notes", "Continue medication and monitor progress.");
//  treatmentPlans.add(plan2);

  // Step 3: Loop through each plan and fill the form
  for (Map<String, String> plan : treatmentPlans) {
  
      planPage.clickAddTreatmentPlan();
      planPage.selectTreatmentPlan(plan.get("planName"));
      planPage.setNextVisitDate(plan.get("nextVisit"));
      planPage.setActualStartDate(plan.get("startDate"));
      planPage.setActualEndDate(plan.get("endDate"));
//      planPage.selectPhysician(plan.get("physician"));
      planPage.selectTreatmentStatus(plan.get("status"));
      planPage.enterNotes(plan.get("notes"));
      planPage.clickSave();
  }
//  planPage.clickTreatmentPlanTab();
}

@Test(dataProvider = "getDataForLogin",priority = 33)
public void testEditLastVisit2(HashMap<String, String> input) {
  // Step 1: Search patient
	EMR	emrPage = new EMR(driver);

  emrPage.clickCaseSheetWrapper();
  emrPage.clickDoctorName("Dr. Izaan");
  // Step 4: Click Edit in last visit
//  emrPage.clickEditLastVisit();
}
//@Test(dataProvider = "getDataForLogin", priority = 34)
//public void treatmentpage(HashMap<String, String> input) throws InterruptedException, TimeoutException {
//
//TreatmentPage planPage2 = new TreatmentPage(driver);
//planPage2.toggleTaskOrderSection();
//planPage2.treatmentsectionbutton();
//
//List<Map<String, String>> treatmentPlans = new ArrayList<>();
//HashMap<String, String> input1 = new HashMap<>();
//input1.put("planName", "mnm");
//input1.put("doctor", "Izaan");
//input1.put("nurse", "Fddf");
//input1.put("nextVisit", "2d");
//input1.put("notes", "Follow up after 2 days");
//treatmentPlans.add(input1);
//
//
////HashMap<String, String> input2 = new HashMap<>();
////input2.put("planName", "ssss");
////input2.put("doctor", "Izaan");
////input2.put("nurse", "Fddf");
////input2.put("nextVisit", "1w");
////input2.put("notes", "Weekly review scheduled");
////treatmentPlans.add(input2);
//// Actions
//for (Map<String, String> plan : treatmentPlans) {
//planPage2.selectTreatmentPlan(plan.get("planName"));
//planPage2.selectPerformingDoctor(plan.get("doctor"));
//planPage2.selectPerformingNurse(plan.get("nurse"));
//planPage2.setNextVisit(plan.get("nextVisit"));
//planPage2.enterNotes(plan.get("notes"));
//planPage2.clickAddTreatmentPlan();
//
//}
//planPage2.toggleTaskOrderSection();
//}

  
  @Test(dataProvider = "getDataForLogin", priority = 35)
  public void opassesment(HashMap<String, String> input) throws InterruptedException, TimeoutException {
  
  	    // Step 1: Create Page Object
	  OpAssessmentTemplatePage assessmentPage = new OpAssessmentTemplatePage(driver);
	  assessmentPage.toggle();
	  int index = 1;

      // Select a summary title
      String[] titles = {"Demo", "gf"};
//	  String[] titles = {"NEW IP Assessment"};
      for (String title : titles) {
    	
          assessmentPage.selectSummaryTitle(title);

          assessmentPage.getSaveButton(index).click();        
    
         assessmentPage.waitForPopupToDisappear("Saved Successfully");
       
//         clickEditOnTemplate("gf");
      }
      
   
  	}
  @Test(dataProvider = "getDataForLogin", priority = 36)
  public void opassesmenttable(HashMap<String, String> input) throws InterruptedException, TimeoutException {
  
	// Step 1: Create Page Object
	  OpAssessmentTemplatePage assessmentPage = new OpAssessmentTemplatePage(driver);
//	  assessmentPage.clickEditOnTemplate("NEW IP Assessment");
//	  // Step 2: Define template-specific data
	  Map<String, Map<String, Object>> templateData = new HashMap<>();
	  Map<String, Object> newip = new HashMap<>();
	  newip.put("allergies", new String[]{""});
//	  newip.put("vitals", Map.of(
//
//	      "height", "170"
//	   
//	  ));
//	  templateData.put("NEW IP Assessment", newip);
//	  // Data for "Demo"
	  Map<String, Object> demoData = new HashMap<>();
	  demoData.put("allergies", new String[]{"Milk", "Perfume", "Buckwheat", "Penicillin"});
	  demoData.put("vitals", Map.of(
	      "weight", "65",
	      "height", "170",
	      "bpSys", "120",
	      "news", "Normal"
	  ));
	  templateData.put("Demo", demoData);

	  // Data for "gf"
//	  Map<String, Object> gfData = new HashMap<>();
//	  gfData.put("allergies", new String[]{"", ""});
//	  gfData.put("vitals", Map.of(
//	      "weight", "70",
//	      "height", "175",
//	      "bpSys", "110",
//	      "news", "Normal"
//	  ));
//	  templateData.put("gf", gfData);

	  // Step 3: Loop through templates and fill data
	  for (String template : templateData.keySet()) {
	      assessmentPage.clickEditOnTemplate(template);

	      // Allergies
	      String[] allergies = (String[]) templateData.get(template).get("allergies");
	      for (String allergy : allergies) {
	          assessmentPage.selectAllergies(allergy);
	      }

	      // Vitals
	      Map<String, String> vitals = (Map<String, String>) templateData.get(template).get("vitals");
	      assessmentPage.enterWeight(vitals.get("weight"));
	      assessmentPage.enterHeight(vitals.get("height"));
	      assessmentPage.enterBpSys(vitals.get("bpSys"));
	      assessmentPage.enterNews(vitals.get("news"));

	      // Save and go back
	      assessmentPage.saveTransaction();
	      assessmentPage.clickBackButton();
	      
	  }

	  
	
    

  
  }
    @DataProvider
    public Object[][] getDataForLogin() throws IOException {
        List<HashMap<String, String>> data = getJsonDataToMap(
            System.getProperty("user.dir") + "//src//main//java//ezion//Resources//AppointMent.json"
        );
        return new Object[][] { { data.get(0) } };
    }

}
