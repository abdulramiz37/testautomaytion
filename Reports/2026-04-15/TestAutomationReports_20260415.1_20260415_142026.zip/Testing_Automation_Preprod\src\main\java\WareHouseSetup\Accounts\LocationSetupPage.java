package WareHouseSetup.Accounts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import EzionAbstractionComponents.Abstraction;

public class LocationSetupPage extends Abstraction {

    public LocationSetupPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement locationNameInput;

    @FindBy(xpath = "//input[@formcontrolname='locationLandmark']")
    private WebElement locationLandmarkInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='inChargeId']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement locationInChargeDropdown;

    @FindBy(xpath = "//button[text()='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//input[@value='Cancel']")
    private WebElement cancelButton;

    @FindBy(xpath = "//a[text()='Location Setup']")
    private WebElement userType;

    @FindBy(xpath = "//a[text()=' Add Location ']")
    private WebElement adduserType;
     
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}
    // Clicks and enters values
    public void enterLocationName(String name) {
        waitForVisibility(locationNameInput).sendKeys(name);
    }

    public void enterLocationLandmark(String landmark) {
        waitForVisibility(locationLandmarkInput).sendKeys(landmark);
    }

    public void selectInChargeFromDropdown(String name) {
        // Click on dropdown to open the list
        waitForClickability(locationInChargeDropdown).click();

        // Build dynamic XPath for the option using the provided name
        By optionLocator = By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + name + "']");

        // Wait and click on the matching option
        waitForClickability(optionLocator).click();
    }


    public void clickSave() {
        waitForClickability(saveButton).click();
    }

    public void clickCancel() {
        waitForClickability(cancelButton).click();
    }

    // Combined Method
    public void fillLocationSetupForm(String name, String landmark, String inChargeName) {
    	clickbuttonapproval();
        enterLocationName(name);
        enterLocationLandmark(landmark);
        selectInChargeFromDropdown(inChargeName);
        clickSave();
    }

}
