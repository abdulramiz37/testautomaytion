package PharmacySalesPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class PatientDetails extends Abstraction{
	public PatientDetails(WebDriver driver) {
		super(driver);
        PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//input[@id='1']") 
	private WebElement internalDrRadio;

	@FindBy(xpath = "//input[@id='2']")
	private WebElement externalDrRadio;

	// Internal Doctor dropdown
	@FindBy(xpath = "//label[normalize-space()='Internal Dr']/following::div[contains(@class,'ngx-select__toggle')][1]")
	private WebElement internalDoctorDropdown;

	// Referral dropdown
	@FindBy(xpath = "//label[normalize-space()='Referral']/following::div[contains(@class,'ngx-select__toggle')][1]")
	private WebElement referralDropdown;

	// Bill Type dropdown
	@FindBy(xpath = "//ngx-select[@formcontrolname='billModeType']//div[contains(@class,'ngx-select__toggle')]")
	private WebElement billTypeDropdown;

	@FindBy(xpath = "//span[normalize-space(text())='Add']")
	private WebElement addTab;

	// ================= Methods =================

	public void selectPrescriptionByInternalDr() {
	    waitForClickability(internalDrRadio).click();
	}
	public void isPatientDetailsDisplayed() {
		addTab.click();
	}

	@FindBy(xpath = "//img[@title='Weight']")
	private WebElement weightIcon;

	public void clickWeightIcon() {
	    weightIcon.click();
	}

	public void selectPrescriptionByExternalDr() {
	    waitForClickability(externalDrRadio).click();
	}
	public void selectInternalDoctor(String doctorName) {
	    internalDoctorDropdown.click();
	    WebElement option = driver.findElement(
	        By.xpath("//ul[@role='menu']//li[@role='menuitem']//span[normalize-space()='" + doctorName + "']")
	    );
	    waitForClickability(option).click();
	}
	
	public void medicine(String medicineName) {
		  By dynamicMedicineCard = By.xpath("//h4[text()='" + medicineName + "']");
		  By dynamicMedicineCard1 = By.xpath("//*[normalize-space(text())='Medicine Details");
		  By dynamicMedicineCard2 = By.xpath("//*[normalize-space(text())='Product Name / Generic Name']/ancestor::div[1]//mat-select");
		  By dynamicMedicineCard3 = By.xpath("//input[@placeholder='Search']");
//		  waitForClickability(driver.findElement(dynamicMedicineCard1)).click();
//	      waitForClickability(driver.findElement(dynamicMedicineCard2)).click();
	      waitForClickability(driver.findElement(dynamicMedicineCard3)).sendKeys(medicineName);
	      waitForClickability(driver.findElement(dynamicMedicineCard)).click();
	      
	}
	@FindBy(xpath = "//input[@formcontrolname='quantity']")
	private WebElement quantityInput;
	public void enterQuantity(String qty) {
	    WebElement input = waitForClickability(quantityInput);
	    input.clear();
	    input.sendKeys(qty);
	}

	public void selectReferral(String referralName) {
//	    referralDropdown.click();
		clickWithJavaScript(referralDropdown);
	    WebElement option = driver.findElement(
	        By.xpath("//ul[@role='menu']//li[@role='menuitem']//span[normalize-space()='" + referralName + "']")
	    );
	    clickWithJavaScript(option);
	}

	public void selectBillType(String billType) {
		clickWithJavaScript(billTypeDropdown);
	    WebElement option = driver.findElement(
	        By.xpath("//ul[@role='menu']//li[@role='menuitem']//span[normalize-space()='" + billType + "']")
	    );
	    clickWithJavaScript(option);
	}
	@FindBy(xpath = "//input[@type='button' and @value='Add']")
	private WebElement addButton;
	public void clickAddButton() {
	    waitForClickability(addButton).click();
	}
	// Save button
	@FindBy(xpath = "//input[@type='button' and @value='Save']")
	private WebElement saveButton;

	// Hold Bill button
	@FindBy(xpath = "//input[@type='button' and @value='Hold Bill']")
	private WebElement holdBillButton;

	// Cancel button
	@FindBy(xpath = "//input[@type='button' and @value='Cancel']")
	private WebElement cancelButton;

	// Reset button
	@FindBy(xpath = "//input[@type='button' and @value='Reset']")
	private WebElement resetButton;
	public void clickSaveButton() {
		clickWithJavaScript(saveButton);
	}
	@FindBy(xpath = "//input[@type='button' and @value='Yes']")
	private WebElement yesButton;
	public void yesButton() {
		clickWithJavaScript(yesButton);
	}
	// Batch Number


	public void clickHoldBillButton() {
	    waitForClickability(holdBillButton).click();
	}

	public void clickCancelButton() {
	    waitForClickability(cancelButton).click();
	}

	public void clickResetButton() {
	    waitForClickability(resetButton).click();
	}

}
