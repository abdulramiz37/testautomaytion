package PrakashSirAppointmentBooking.CaseSheet;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class ChiefComplaintsPage extends Abstraction{

	public ChiefComplaintsPage(WebDriver driver) {
		super(driver);
	       PageFactory.initElements(driver, this);
	}
	   @FindBy(xpath = "//label[text()='Chief Complaints']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
	    private WebElement chiefComplaintsDropdown;

	    // Chief Complaints options list
	    @FindBy(xpath = "//ul[contains(@class,'ngx-select__choices')]/li/a/span")
	    private WebElement chiefComplaintsOption;

	    // Period input
	    @FindBy(xpath = "//input[@formcontrolname='extraOption']")
	    private WebElement periodInput;

	    // Present History textarea
	    @FindBy(xpath = "//textarea[@formcontrolname='presentHistory']")
	    private WebElement presentHistoryTextarea;

	    // Performing Doctor dropdown
	    @FindBy(xpath = "(//label[normalize-space()='Performing Doctor']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')])[1]")
	    private WebElement performingDoctorDropdown;

	    // Performing Doctor options
	    @FindBy(xpath = "//label[normalize-space()='Performing Doctor']/following-sibling::ngx-select//ul/li/a/span)")
	    private WebElement performingDoctorOption;

	    // Performing Nurse dropdown
	    @FindBy(xpath = "(//label[normalize-space()='Performing Nurse']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')])[1]")
	    private WebElement performingNurseDropdown;

	    // Performing Nurse options
	    @FindBy(xpath = "//label[normalize-space()='Performing Nurse']/following-sibling::ngx-select//ul/li/a/span")
	    private WebElement performingNurseOption;

	    // Add button
	    @FindBy(xpath = "//button[@nbtooltip='Add']")
	    private WebElement addButton;

	    // Reset button
	    @FindBy(xpath = "//button[@nbtooltip='Reset']")
	    private WebElement resetButton;

	    // Notes textarea
	    @FindBy(xpath = "//textarea[@formcontrolname='pastHistory']")
	    private WebElement notesTextarea;
	    
	 // ===== Locator =====
	    @FindBy(xpath = "//h4[normalize-space(text())='Chief Complaints']/following::img[contains(@class,'openclose')][1]")
	    private WebElement chiefComplaintsAddIcon;

	    // ===== Method =====
	    public void clickChiefComplaintsAddIcon() {
	    	clickWithJavaScript(chiefComplaintsAddIcon);
	    }
	    
	    @FindBy(xpath = "//input[@placeholder='Select' and contains(@class,'ngx-select__search')]")
	    private WebElement chiefComplaintsDropdown2; 
	    public String finalComplaint;   // accessible outside

	    public void selectChiefComplaint(String complaintName) {
	        clickChiefComplaintsAddIcon();
	        chiefComplaintsDropdown.click();

	        finalComplaint = complaintName;

	        if (complaintName == null || complaintName.trim().isEmpty()) {
	            int length = 6;
	            String alphabet = "abcdefghijklmnopqrstuvwxyz";
	            StringBuilder sb = new StringBuilder();
	            java.util.Random random = new java.util.Random();
	            for (int i = 0; i < length; i++) {
	                sb.append(alphabet.charAt(random.nextInt(alphabet.length())));
	            }
	            finalComplaint = sb.toString();
	        }

	        chiefComplaintsDropdown2.sendKeys(finalComplaint);

	        List<WebElement> complaintOptions = driver.findElements(
	            By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + finalComplaint + "']")
	        );

	        if (!complaintOptions.isEmpty()) {
	            complaintOptions.get(0).click();
	            System.out.println("Chief Complaint Selected from dropdown: " + finalComplaint);
	        } else {
	            addNewComplaintBtn.click();
	            System.out.println("New Chief Complaint Added: " + finalComplaint);
	        }
	    }



	    public void enterPeriod(String period) {
	        periodInput.clear();
	        periodInput.sendKeys(period);
	    }

	    public void enterPresentHistory(String history) {
	        presentHistoryTextarea.clear();
	        presentHistoryTextarea.sendKeys(history);
	    }

	    public void selectPerformingDoctor(String doctorName) {
	        performingDoctorDropdown.click();
	        driver.findElement(
	            org.openqa.selenium.By.xpath("//label[normalize-space()='Performing Doctor']/following-sibling::ngx-select//span[normalize-space()='" + doctorName + "']")
	        ).click();
	    }

	    public void selectPerformingNurse(String nurseName) {
	        performingNurseDropdown.click();
	        driver.findElement(
	            org.openqa.selenium.By.xpath("//label[normalize-space()='Performing Nurse']/following-sibling::ngx-select//span[normalize-space()='" + nurseName + "']")
	        ).click();
	    }

	    public void clickAddButton() {
	        addButton.click();
	    }

	    public void clickResetButton() {
	        resetButton.click();
	    }

	    public void enterNotes(String notes) {
	        notesTextarea.clear();
	        notesTextarea.sendKeys(notes);
	    }
	   //add method 
	    @FindBy(xpath = "//input[@formcontrolname='name']")
	    private WebElement complaintInput;

	    // Department dropdown (ngx-select)
	    @FindBy(xpath = "//ngx-select[@formcontrolname='departmentId']//input")
	    private WebElement departmentDropdown;

	    // Active checkbox
	    @FindBy(xpath = "//input[@formcontrolname='isActive']")
	    private WebElement activeCheckbox;

	    // Attribute input
	    @FindBy(xpath = "//input[@formcontrolname='attribute']")
	    private WebElement attributeInput;

	    // Buttons
	    @FindBy(xpath = "//input[@value='Add Attribute']")
	    private WebElement addAttributeBtn;

	    @FindBy(xpath = "//input[@value='Reset']")
	    private WebElement resetBtn;

	    @FindBy(xpath = "//input[@value='Save']")
	    private WebElement saveBtn;

	    @FindBy(xpath = "//input[@value='Cancel']")
	    private WebElement cancelBtn;

	    // -------------------- METHODS --------------------
	    @FindBy(xpath = "//button[contains(@class,'add-btn-icon') and contains(.,'Add New Complaint')]")
	    private WebElement addNewComplaintBtn;

	    // ---------- METHODS ----------
	    @FindBy(xpath = "//span[normalize-space(text())='Add Chief Complaint']")
	    private WebElement addChiefComplaintBtn;
	    // check presence of "Add New Complaint"
	    public boolean isAddNewComplaintPresent() {
	        try {
	            return addNewComplaintBtn.isDisplayed();
	        } catch (NoSuchElementException e) {
	            return false;
	        }
	    }
	    public void clickAddChiefComplaint() {
	        waitForVisibility(addChiefComplaintBtn).click();
	    }

	    // click on "Add New Complaint"
	    public void clickAddNewComplaint() {
	        clickWithJavaScript(addNewComplaintBtn); // using your Abstraction helper for safe click
	    }
	    // Set Complaint Name
	    public void enterComplaint(String complaint) {
	        complaintInput.clear();
	        complaintInput.sendKeys(complaint);
	    }
	    @FindBy(xpath = "//div[contains(@class,'lightbox-close')]")
	    private WebElement closeLightboxDiv;
	    public void clickCloseLightbox() {
	        closeLightboxDiv.click();
	    }

	    // Select Department (type & enter)
	    public void selectDepartments(String[] deptNames) {
	        for (String deptName : deptNames) {
	        	clickAddChiefComplaint();
	            waitForVisibility(departmentDropdown).clear();
	            waitForVisibility(departmentDropdown).sendKeys(deptName);
	            waitForVisibility(departmentDropdown).sendKeys(Keys.ENTER);
	        }
	    }


	    // Toggle Active checkbox
	    public void setActive(boolean status) {
	        if (activeCheckbox.isSelected() != status) {
	            activeCheckbox.click();
	        }
	    }

	    // Enter Attribute
	    public void enterAttribute(String attribute) {
	    	attributeInput.click();
	        attributeInput.clear();
	        attributeInput.sendKeys(attribute);
	    }

	    // Click Add Attribute
	    public void clickAddAttribute() {
	        addAttributeBtn.click();
	    }

	    // Click Reset
	    public void clickReset() {
	        resetBtn.click();
	    }

	    // Click Save
	    public void clickSave() {
	        saveBtn.click();
	    }

	    // Click Cancel
	    public void clickCancel() {
	        cancelBtn.click();
	    }
	}

