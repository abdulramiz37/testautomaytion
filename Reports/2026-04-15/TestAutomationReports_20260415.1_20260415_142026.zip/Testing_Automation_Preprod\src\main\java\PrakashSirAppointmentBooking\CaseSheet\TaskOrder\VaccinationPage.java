package PrakashSirAppointmentBooking.CaseSheet.TaskOrder;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class VaccinationPage extends Abstraction {

    WebDriver driver;

    public VaccinationPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // 🔹 Tabs
    @FindBy(xpath = "//a[normalize-space()='Vaccination']")
    private WebElement vaccinationTab;

    // 🔹 Vaccination Form Fields
    @FindBy(xpath = "//ngx-select[@formcontrolname='vaccineId']")
    private WebElement vaccinesNameDropdown;

    @FindBy(xpath = "//label[normalize-space()='Performing Doctor']/following::div[contains(@class,'ngx-select__toggle')][1]")
    private WebElement performingDoctorDropdown;

    @FindBy(xpath = "//label[normalize-space()='Performing Nurse']/following::div[contains(@class,'ngx-select__toggle')][1]")
    private WebElement performingNurseDropdown;

    @FindBy(xpath = "//input[@placeholder='MM/DD/YYYY' and @formcontrolname='planned_Date']")
    private WebElement plannedDateField;

    @FindBy(xpath = "//textarea[@formcontrolname='notes']")
    private WebElement notesField;

    // 🔹 Buttons
    @FindBy(xpath = "//input[@value='Add Vaccine']")
    private WebElement addVaccineBtn;

    @FindBy(xpath = "//input[@value='Reset']")
    private WebElement resetBtn;

    // 🔹 Success/Error Popups
    @FindBy(xpath = "//div[@class='succesfull-info-popup']/span[contains(text(),'Immunization Saved Successfully')]")
    private WebElement vaccinationSavedMsg;

    @FindBy(xpath = "//div[@class='succesfull-info-popup']/span[contains(text(),'Immunization Updated Successfully')]")
    private WebElement vaccinationUpdatedMsg;

    @FindBy(xpath = "//div[@class='succesfull-info-popup']/span[contains(text(),'Immunization Deleted Successfully')]")
    private WebElement vaccinationDeletedMsg;

    // 🔹 Vaccination History (first row)
    @FindBy(xpath = "//div[@class='order-summary']//p[contains(@class,'prime-clr') and text()='Vaccination History']/following::div[1]/p/b")
    private WebElement vaccinationHistoryName;

    // ================== METHODS ==================

    // Tabs
    public void clickVaccinationTab() {
        vaccinationTab.click();
    }

    // Generic Dropdown Selection
    private void selectDropdownValue(WebElement dropdown, String value) {
        dropdown.click();
        WebElement option = driver.findElement(
            By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'" 
                     + value.toLowerCase() + "')]")
        );
        option.click();
    }

    public void selectVaccine(String vaccineName) {
        selectDropdownValue(vaccinesNameDropdown, vaccineName);
    }

    public void selectPerformingDoctor(String doctor) {
        selectDropdownValue(performingDoctorDropdown, doctor);
    }

    public void selectPerformingNurse(String nurse) {
        selectDropdownValue(performingNurseDropdown, nurse);
    }

    // Planned Date
    public void enterPlannedDate(String date) {
        plannedDateField.clear();
        plannedDateField.sendKeys(date);
    }

    // Notes
    public void enterNotes(String notes) {
        notesField.clear();
        notesField.sendKeys(notes);
    }

    // Actions
    public void clickAddVaccine() {
        addVaccineBtn.click();
    }

    public void clickReset() {
        resetBtn.click();
    }

    // Validations
    public boolean isVaccinationSaved() {
        return vaccinationSavedMsg.isDisplayed();
    }

    public boolean isVaccinationUpdated() {
        return vaccinationUpdatedMsg.isDisplayed();
    }

    public boolean isVaccinationDeleted() {
        return vaccinationDeletedMsg.isDisplayed();
    }

    // Vaccination History
    public String getVaccinationHistoryName() {
        return vaccinationHistoryName.getText().trim();
    }

}
