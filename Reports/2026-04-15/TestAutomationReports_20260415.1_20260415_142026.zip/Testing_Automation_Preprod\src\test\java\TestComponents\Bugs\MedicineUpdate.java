

	package TestComponents.Bugs;

	import java.io.BufferedReader;
	import java.io.FileReader;
	import java.util.ArrayList;
	import java.util.HashMap;
	import java.util.List;

	import org.testng.annotations.DataProvider;
	import org.testng.annotations.Test;

	import EzionpageObjects.UserIdPage;
	import PharmacyFlowObjects.PharmacyStore.MedicinePage;
	import abdulTest.BaseTest;
	import ezion.Resources.EnvUtil;

	public class MedicineUpdate extends BaseTest {
	    UserIdPage data;

	    @Test(priority = 1)
	    public void getMedicineData1() throws InterruptedException {

	        data = login.login(EnvUtil.get("USER_ID"));
	        data.enterMobileNumber(EnvUtil.get("PERSON_ID"));
	        data.enterPassword(EnvUtil.get("PASSWORD"));
	        data.clickContinue();
//	        data.openMasterSetup();
	    }

	    @Test(priority =2, dataProvider = "getMedicineData", groups = "negative")
	    public void getMedicineData(HashMap<String, String> input) throws InterruptedException {
	    	
	        MedicinePage medicinePage = new MedicinePage(driver);
	        data.openMasterSetup();
	        
	        medicinePage.enterMedicineName(input.get("medicineName"));
	        medicinePage.clickEdit();

//	        medicinePage.save();
	        // Fill additional fields

	        medicinePage.selectVaccineCheckbox();

	        medicinePage.updatebutton();

	       
	    }

	    @DataProvider(name = "getMedicineData")
	    public static Object[][] getMedicineData() throws Exception {
	        String filePath = "C:\\Users\\ezobgvmuser\\Downloads\\Vaccine_generic 1 2(Sheet1).csv\\";

	        List<HashMap<String, String>> finalData = new ArrayList<>();

	        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
	            String line;
	            String[] headers = null;

	            int rowNum = 0;
	            while ((line = br.readLine()) != null) {
	                String[] values = line.split(",");

	                if (rowNum == 0) {
	                    headers = values; // first row is header
	                } else {
	                    HashMap<String, String> row = new HashMap<>();
	                    for (int i = 0; i < headers.length && i < values.length; i++) {
	                        row.put(headers[i].trim(), values[i].trim());
	                    }

	                    // Map Google Sheet columns → Test fields
	                    HashMap<String, String> mapped = new HashMap<>();
	                    mapped.put("medicineName", row.get("Name"));
	     

	                    finalData.add(mapped);
	                    // Login data
	                  

	                }
	                rowNum++;
	            }
	        }

	        Object[][] obj = new Object[finalData.size()][1];
	        for (int i = 0; i < finalData.size(); i++) {
	            obj[i][0] = finalData.get(i);
	        }
	        return obj;
	    }
	

}
