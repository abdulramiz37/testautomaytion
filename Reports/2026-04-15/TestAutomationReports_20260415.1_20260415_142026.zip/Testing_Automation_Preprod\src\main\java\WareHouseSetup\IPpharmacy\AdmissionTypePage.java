package WareHouseSetup.IPpharmacy;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class AdmissionTypePage extends Abstraction{

    WebDriver driver;

    public AdmissionTypePage(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // 🔹 Locators using @FindBy (XPath only)

    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement admissionTypeNameInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='category']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement categoryDropdown;

    @FindBy(xpath = "//input[@formcontrolname='isDefault']")
    private WebElement setDefaultCheckbox;

    @FindBy(xpath = "//input[@formcontrolname='isActive']")
    private WebElement activeCheckbox;

    @FindBy(xpath = "//input[@type='button' and @value='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
    private WebElement cancelButton;
    
    @FindBy(xpath = "//a[text()=' Admission Type ']")
    private WebElement userType;

    @FindBy(xpath = "//a[text()=' Add AdmissionType ']")
    private WebElement adduserType;

    // 🔹 Methods
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}
    // Enter Admission Type Name
    public void enterAdmissionTypeName(String name) {
        admissionTypeNameInput.clear();
        admissionTypeNameInput.sendKeys(name);
    }

    // Select Category (pass option text)
 // AdmissionTypePage.java (only dropdown method shown updated)

 // Select Category from dropdown (using <ul><li><span>)
 public void selectCategory(String categoryName) {
     categoryDropdown.click();
     WebElement option = driver.findElement(
         By.xpath("//ul[@role='menu']//span[normalize-space()='" + categoryName + "']")
     );
     option.click();
 }


    // Set Default Checkbox
    public void setDefault(boolean value) {
        if (setDefaultCheckbox.isSelected() != value) {
            setDefaultCheckbox.click();
        }
    }

    // Active Checkbox
    public void setActive(boolean value) {
        if (activeCheckbox.isSelected() != value) {
            activeCheckbox.click();
        }
    }

    // Save button
    public void clickSave() {
        saveButton.click();
    }

    // Cancel button
    public void clickCancel() {
        cancelButton.click();
    }
}

