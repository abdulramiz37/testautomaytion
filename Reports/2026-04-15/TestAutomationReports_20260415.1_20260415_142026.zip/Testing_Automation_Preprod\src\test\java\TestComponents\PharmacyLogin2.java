package TestComponents;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EzionpageObjects.UserIdPage;
import PharmacyFlowObjects.*;
import PharmacyFlowObjects.PharmacyStore.*;
import abdulTest.BaseTest;

public class PharmacyLogin2 extends BaseTest {

    UserIdPage data;
    RolesManagementPage rolesPage;
    MasterSetupUpdate masterSetup;
    StorePageUpdate storePage;
    SupplierPageUpdate supplierPage;
    StorageShelfPageUpdate shelfPage;
    MedicinePageUpdate medicinePage;
    CustomerPageUpdate customerPage;
    PharmacyLocationPageUpdate pharmacyLocationPage;
    HMSLocationPageUpdate hmsLocationPage;

    HashMap<String, String> currentInput;

    // ---------------- LOGIN ----------------
    @Test(dataProvider = "getData", priority = 1)
    public void PharmacyLogin2_ShouldLoginSuccessfullyForUser(HashMap<String, String> input) throws InterruptedException {
        this.currentInput = input;
        data = login.login(input.get("userId"));
        data.enterMobileNumber(input.get("personId"));
        data.enterPassword(input.get("password"));
        data.clickContinue();
        data.navigateSalesWithRetry();
        System.out.println("✅ Login successful for user: " + input.get("userId"));
    }

    // ---------------- ROLE MANAGEMENT ----------------
    @Test(priority = 2)
    public void PharmacyLogin2_ShouldAssignRolesToUser() {
        rolesPage = new RolesManagementPage(driver);
         data.openRolesManagement();
        rolesPage.selectRoleAndSection(currentInput.get("role"
        		), currentInput.get("section"));
        rolesPage.expandSection(currentInput.get("section"));
        rolesPage.selectUserAndSave(currentInput.get("userName"));
        rolesPage.selectRoleAndSectioninventory(currentInput.get("section2"));
        rolesPage.Save();
        System.out.println("✅ Roles assigned successfully");
    }

    // ---------------- MASTER SETUP (WAREHOUSE) ----------------
    @Test(priority = 3)
    public void PharmacyLogin2_ShouldCreateWarehouseForMasterSetup() {
        masterSetup = new MasterSetupUpdate(driver);
        data.openMasterSetup1();
        masterSetup.createWarehouse(
                currentInput.get("warehouseCode"),
                currentInput.get("warehouseName"),
                currentInput.get("warehouseShortName"),
                currentInput.get("country")
        );
        masterSetup.enterWarehousePincode("444001");
        masterSetup.clickSave();
        System.out.println("✅ Warehouse created successfully");
    }

    // ---------------- STORE CREATION ----------------
    @Test(priority = 4)
    public void PharmacyLogin2_ShouldCreateStoreForWarehouse() {
        storePage = new StorePageUpdate(driver);
        storePage.openMasterSetup();
        storePage.createStore(currentInput.get("storename"));
        storePage.save();
        System.out.println("✅ Store created successfully");
    }

    // ---------------- SUPPLIER CREATION ----------------
    @Test(priority = 5)
    public void PharmacyLogin2_ShouldCreateSupplierForStore() {
        supplierPage = new SupplierPageUpdate(driver);
        supplierPage.openMasterSetup();

        supplierPage.enterSupplierInfo("ABC Pharma");
        supplierPage.selectSupplierType("Pharmacy");
        supplierPage.enterCreditDays("30");
        supplierPage.enterGSTN("27ABCDE1234F1Z5");
        supplierPage.enterDrugLicense("DL12345678");
        supplierPage.enterPAN("ABCDE1234F");

        supplierPage.enterMobile("9876543210");
        supplierPage.enterAlternateMobile("9123456780");
        supplierPage.enterWorkPhone("0221234567");
        supplierPage.enterEmail("abcpharma@example.com");
        supplierPage.enterAddress("123 Main Street");
        supplierPage.enterArea("Downtown");
        supplierPage.enterPincode("400001");
        supplierPage.enterCity("Mumbai");
        supplierPage.enterContactName("Rahul Sharma");
        supplierPage.selectDistrict("Adilabad");

        supplierPage.enterBankName("State Bank of India");
        supplierPage.enterIFSC("SBIN0001234");
        supplierPage.enterAccountNumber("123456789012");
        supplierPage.enterBranchName("Fort Branch");

        supplierPage.toggleIsActive(true);
        supplierPage.clickSave();
        System.out.println("✅ Supplier created successfully");
        supplierPage.hoverByTextAttach("Export","/ancestor::div[1]//img[@class='hd-export']");
        supplierPage.clickByText("Excel");
        supplierPage.robotEnter();
    }

    // ---------------- STORAGE SHELF CREATION ----------------
    @Test(priority = 6)
    public void PharmacyLogin2_ShouldCreateStorageShelfForSupplier() {
        shelfPage = new StorageShelfPageUpdate(driver);
        shelfPage.openMasterSetup();
        shelfPage.createStorageShelf(currentInput.get("shelfName"));
        shelfPage.save();
        System.out.println("✅ Storage Shelf created successfully");
    }

    // ---------------- MEDICINE ADDITION ----------------
    @Test(priority = 7)
    public void PharmacyLogin2_ShouldAddMedicineToShelf() throws InterruptedException {
    	   MedicinePage medicinePage = new MedicinePage(driver);
	        medicinePage.addmedicine();
//	    for(int i=0;i<=10;i++) {
//	            MedicinePage medicinePage = new MedicinePage(driver);

	            // Add Medicine with manual values
	            medicinePage.addMedicine(
	                "",   // medicineName
	                "Schedule A1",            // scheduleText
	                "CAPSULE",       // categoryText
	                "Orlistat", // compositionText
	                "3 M HEALTH CARE",    // manufacturerText
	                "100"           // quantity
	            );

	            // Fill additional fields manually
	            medicinePage.enterMinQty("1");
	            medicinePage.enterMaxQty("200");
	            medicinePage.enterReorderQty("20");
	            medicinePage.enterReorderLevel("5");
	            medicinePage.enterHSNCode("30049099");
	            medicinePage.selectGST("0");
	            medicinePage.selectDiscountRequired("Yes");
	            medicinePage.enterDescription("Used for fever and mild pain relief");
	            medicinePage.enterDiscount("5");
	             medicinePage.selectVaccineCheckbox(); // Uncomment if required
	            medicinePage.enterAttribute("OTC");
	            medicinePage.enterCostPrice("8.50");
	            medicinePage.enterMRP("12.00");
	            medicinePage.enterSellPrice("11.00");
	            medicinePage.enterNoOfStrips("10");
	            medicinePage.enterFreeStrips("1");

	            // Save medicine
	            medicinePage.save();
//	
    }

    // ---------------- CUSTOMER CREATION ----------------
    @Test(priority = 8)
    public void PharmacyLogin2_ShouldAddCustomerToPharmacy() {
        customerPage = new CustomerPageUpdate(driver);
        customerPage.openMasterSetup();
        customerPage.addCustomer(currentInput.get("customerName"), currentInput.get("customerPhone"));
        customerPage.save();
        System.out.println("✅ Customer added successfully");
    }

    // ---------------- PHARMACY LOCATION CREATION ----------------
    @Test(priority = 9)
    public void PharmacyLogin2_ShouldAddPharmacyLocationToSystem() {
        pharmacyLocationPage = new PharmacyLocationPageUpdate(driver);
        pharmacyLocationPage.addPharmacyLocation(
                currentInput.get("pharmacyLocationName"),
                currentInput.get("pharmacyMobile"),
                currentInput.get("pharmacyEmail"),
                currentInput.get("pharmacyGSTN"),
                currentInput.get("pharmacyDLNO"),
                currentInput.get("salesWarehouse"),
                currentInput.get("purchaseWarehouse")
        );
        pharmacyLocationPage.useDefaultAddressCheckmark();
        pharmacyLocationPage.saveAndReturnToHMSPage();
        System.out.println("✅ Pharmacy location created successfully");
    }

    // ---------------- HOSPITAL LOCATION CREATION ----------------
    @Test(priority = 10)
    public void PharmacyLogin2_ShouldAddHospitalLocationToSystem() {
        hmsLocationPage = new HMSLocationPageUpdate(driver);
        hmsLocationPage.addHospitalLocation(
                currentInput.get("hospitalLocationName"),
                currentInput.get("hospitalMobile"),
                currentInput.get("hospitalEmail")
        );
        hmsLocationPage.save();
        System.out.println("✅ Hospital location created successfully");
    }

    // ---------------- DATA PROVIDER ----------------
    @DataProvider
    public Object[][] getData() throws IOException {
        List<HashMap<String, String>> data = getJsonDataToMap(
                System.getProperty("user.dir") + "//src//main//java//ezion//Resources//PharmacyCredentials.json"
        );
        return new Object[][]{{data.get(0)}};
    }
}
