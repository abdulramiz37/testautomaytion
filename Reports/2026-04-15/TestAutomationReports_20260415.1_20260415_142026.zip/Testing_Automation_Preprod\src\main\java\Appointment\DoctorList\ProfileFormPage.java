package Appointment.DoctorList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class ProfileFormPage extends Abstraction {

    WebDriver driver;

    public ProfileFormPage(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // --- Locators ---
    @FindBy(xpath = "//label[text()='About']/following-sibling::textarea")
    private WebElement aboutField;

    @FindBy(xpath = "//label[text()='Work Experience']/following-sibling::textarea")
    private WebElement workExperienceField;

    @FindBy(xpath = "//label[text()='Qualification']/following-sibling::textarea")
    private WebElement qualificationField;

    @FindBy(xpath = "//label[text()='Education']/following-sibling::textarea")
    private WebElement educationField;

    @FindBy(xpath = "//label[text()='Memberships']/following-sibling::textarea")
    private WebElement membershipsField;

    @FindBy(xpath = "//label[text()='Awards']/following-sibling::textarea")
    private WebElement awardsField;

    @FindBy(xpath = "//label[text()='Specialities']/following-sibling::textarea")
    private WebElement specialitiesField;

    @FindBy(xpath = "//label[text()='Service Availed']/following-sibling::textarea")
    private WebElement serviceAvailedField;

    @FindBy(xpath = "//label[text()='Registration']/following-sibling::textarea")
    private WebElement registrationField;

    @FindBy(xpath = "(//input[@value='Save'])[6]")
    private WebElement saveButton;

    // --- Methods ---
    @FindBy(xpath = "//span[text()='Profile']")
    private WebElement userType;

     
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
    }
    public void enterAbout(String text) {
    	clickbuttonapproval();
        aboutField.clear();
        aboutField.sendKeys(text);
    }

    public void enterWorkExperience(String text) {
        workExperienceField.clear();
        workExperienceField.sendKeys(text);
    }

    public void enterQualification(String text) {
        qualificationField.clear();
        qualificationField.sendKeys(text);
    }

    public void enterEducation(String text) {
        educationField.clear();
        educationField.sendKeys(text);
    }

    public void enterMemberships(String text) {
        membershipsField.clear();
        membershipsField.sendKeys(text);
    }

    public void enterAwards(String text) {
        awardsField.clear();
        awardsField.sendKeys(text);
    }

    public void enterSpecialities(String text) {
        specialitiesField.clear();
        specialitiesField.sendKeys(text);
    }

    public void enterServiceAvailed(String text) {
        serviceAvailedField.clear();
        serviceAvailedField.sendKeys(text);
    }

    public void enterRegistration(String text) {
        registrationField.clear();
        registrationField.sendKeys(text);
    }

    public void clickSaveButton() {
        saveButton.click();
    }
}

