package WareHouseSetup.IPpharmacy;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class FloorPage extends Abstraction {

    private WebDriver driver;

    // ✅ Constructor
    public FloorPage(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // ==================== Locators ====================

    // Building Name Dropdown
    @FindBy(xpath = "//label[contains(normalize-space(),'Building Name')]/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement buildingNameDropdown;

    // Floor Name Input
    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement floorNameInput;

    // Save Button
    @FindBy(xpath = "//input[@type='button' and @value='Save']")
    private WebElement saveButton;

    // Cancel Button
    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
    private WebElement cancelButton;


    // ==================== Methods ====================
    @FindBy(xpath = "//a[text()=' Floor ']")
    private WebElement userType;

    @FindBy(xpath = "//a[text()=' Add Floor ']")
    private WebElement adduserType;
    
    
    // 🔹 Methods
    
    
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}
    // Select Building Name
    public void selectBuildingName(String building) {
        buildingNameDropdown.click();
        WebElement option = driver.findElement(
            By.xpath("//ul[@role='menu']//span[normalize-space()='" + building + "']"));
        option.click();
    }

    // Enter Floor Name
    public void enterFloorName(String floor) {
        floorNameInput.clear();
        floorNameInput.sendKeys(floor);
    }

    // Click Save
    public void clickSave() {
        saveButton.click();
    }

    // Click Cancel
    public void clickCancel() {
        cancelButton.click();
    }
}
