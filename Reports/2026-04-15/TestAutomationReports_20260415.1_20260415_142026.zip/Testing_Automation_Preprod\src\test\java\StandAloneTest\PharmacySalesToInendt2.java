	package StandAloneTest;

	import java.time.Duration;

	import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
	import org.openqa.selenium.support.ui.*;
	import org.testng.annotations.*;

public class PharmacySalesToInendt2 {


	

		WebDriver driver;
		WebDriverWait wait;

		@BeforeClass
		public void setup() {
			driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			driver.manage().window().maximize();
			driver.get("https://apps.ezovion.com/auth/login");
		}

		@Test
		public void loginTest() throws InterruptedException {
			driver.findElement(By.xpath("//div[@class=\"form-control-group\"]//input")).sendKeys("50107299");
			driver.findElement(By.xpath("//button[@size=\"large\"]")).click();

			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
			driver.findElement(By.xpath("//input[@placeholder=\"Mobile No\"]")).sendKeys("7766554433");
			driver.findElement(By.xpath("//input[@placeholder=\"Password\"]")).sendKeys("12345");

			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@status=\"primary\"]")));
			Thread.sleep(2000);
			driver.findElement(By.xpath("//button[@status=\"primary\"]")).click();
		}

		@Test(dependsOnMethods = "loginTest")
		public void addOpeningStock() throws InterruptedException {
			for (int i = 0; i < 5; i++) {
				try {
					Thread.sleep(3000);
					WebElement adminTab = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Admin']")));
					adminTab.click();
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Roles Management']"))).click();
					break;
				} catch (Exception e) {
					if (i == 4) throw e;
				}
			}

			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Pharmacy']"))).click();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[@title='Stock'])[1]"))).click();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[@title='Opening Stock'])[1]"))).click();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()='Add Opening Stock']"))).click();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Pharamacy Loaction'])[1]"))).click();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Select ']"))).click();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Medidine Ezovion']"))).click();

			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='batchNumber']"))).sendKeys("456");
			WebElement expiry = driver.findElement(By.xpath("//input[@formcontrolname='expiryDate']"));
			((JavascriptExecutor) driver).executeScript("arguments[0].value='2025-07'; arguments[0].dispatchEvent(new Event('input'));", expiry);

			driver.findElement(By.xpath("//input[@formcontrolname='pricePerStrips']")).sendKeys("4");
			driver.findElement(By.xpath("//input[@formcontrolname='mrpPerStrip']")).sendKeys("4");
			driver.findElement(By.xpath("//input[@formcontrolname='sellPriceStrip']")).sendKeys("4");
			driver.findElement(By.xpath("//input[@formcontrolname='qtyInStrips']")).sendKeys("4");
			driver.findElement(By.xpath("//input[@formcontrolname='qtyInUnits']")).sendKeys("4");
			driver.findElement(By.xpath("//input[@value='Save']")).click();
		}


		@AfterClass
		public void tearDown() {
			if (driver != null) {
				driver.quit();
			}
		}
	}


