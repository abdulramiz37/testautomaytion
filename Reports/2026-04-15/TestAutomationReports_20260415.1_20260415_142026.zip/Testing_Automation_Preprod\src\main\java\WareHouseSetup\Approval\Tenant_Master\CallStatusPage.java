package WareHouseSetup.Approval.Tenant_Master;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class CallStatusPage extends Abstraction {

	public CallStatusPage(WebDriver driver) {
		super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "(//input[@formcontrolname='reasonName'])[2]")
	private WebElement callStatusNameInput;

	@FindBy(xpath = "(//input[@formcontrolname='reasonCode'])[2]")
	private WebElement callStatusCodeInput;

	@FindBy(xpath = "(//textarea[@formcontrolname='reasonDescription'])[2]")
	private WebElement callStatusDescriptionTextarea;

	@FindBy(xpath = "(//input[@formcontrolname='isActive']/following-sibling::span[@class='checkmark'])[2]")
	private WebElement isActiveCheckmark;

	@FindBy(xpath = "(//input[@type='button' and @value='Save'])[2]")
	private WebElement saveButton;

	@FindBy(xpath = "//input[@type='button' and @value='Cancel']")
	private WebElement cancelButton;
	
    @FindBy(xpath = "(//a[text()=' Add Call Status '])[2]")
    private WebElement addcall;
    
    @FindBy(xpath = "//span[text()='Call Status']")
    private WebElement callbutton;
    // ----------- Methods -----------

	public void clickbuttonapproval() {
		waitForClickability(callbutton).click();
		waitForClickability(addcall).click();
	}
	public void enterCallStatusName(String name) {
	    waitForVisibility(callStatusNameInput).clear();
	    callStatusNameInput.sendKeys(name);
	}

	public void enterCallStatusCode(String code) {
	    waitForVisibility(callStatusCodeInput).clear();
	    callStatusCodeInput.sendKeys(code);
	}

	public void enterCallStatusDescription(String description) {
	    waitForVisibility(callStatusDescriptionTextarea).clear();
	    callStatusDescriptionTextarea.sendKeys(description);
	}

	public void setIsActive(boolean shouldBeActive) {
	    boolean currentlyChecked = isCallStatusActive();
	    if (shouldBeActive != currentlyChecked) {
	        waitForClickability(isActiveCheckmark).click();
	    }
	}

	private boolean isCallStatusActive() {
	    return driver.findElement(By.xpath("//input[@formcontrolname='isActive']")).isSelected();
	}

	public void clickSave() {
	    waitForClickability(saveButton).click();
	}

	public void clickCancel() {
	    waitForClickability(cancelButton).click();
	}
	public void fillCallStatusForm(String name, String code, String description, boolean isActive) {
	    enterCallStatusName(name);
	    enterCallStatusCode(code);
	    enterCallStatusDescription(description);
	    setIsActive(isActive);
	    clickSave();
	}


}
