package PharmacyFlowObjects;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import EzionAbstractionComponents.Abstraction;
import PharmacyFlowObjects.PharmacyStore.StorePage;
import PharmacyFlowObjects.PharmacyStore.StorePageUpdate;

public class MasterSetupUpdate extends Abstraction {

    public MasterSetupUpdate(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    // --- Web Elements ---
    @FindBy(xpath = "//a[text()=' Warehouse ']")
    private WebElement warehouseTab;

    @FindBy(xpath = "//a[text()=' Add Warehouse ']")
    private WebElement addWarehouseButton;

    @FindBy(xpath = "//input[@formcontrolname='warehousecode']")
    private WebElement warehouseCodeInput;

    @FindBy(xpath = "//input[@formcontrolname='warehousename']")
    private WebElement warehouseNameInput;

    @FindBy(xpath = "//input[@formcontrolname='warehouseshortname']")
    private WebElement warehouseShortNameInput;

    @FindBy(xpath = "//div[@class='ngx-select dropdown']")
    private WebElement countryDropdown;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;

    // --- Red error message spans (exact matching based on shared HTML) ---
    @FindBy(xpath = "//input[@formcontrolname='warehousecode']/following-sibling::span[@style='color: red; font-size: smaller;']")
    private WebElement codeError;

    @FindBy(xpath = "//input[@formcontrolname='warehousename']/following-sibling::span[@style='color: red; font-size: smaller;']")
    private WebElement nameError;

    @FindBy(xpath = "//input[@formcontrolname='warehouseshortname']/following-sibling::span[@style='color: red; font-size: smaller;']")
    private WebElement shortNameError;

    private WebElement getSpanByTextCountry(String text) {
        String xpath = String.format("//span[text()='%s']", text);
        return driver.findElement(By.xpath(xpath));
    }

    public void navigateToAddWarehouse() {
        waitForClickability(warehouseTab).click();
        waitForClickability(addWarehouseButton).click();
    }

    private boolean isCodeExists() {
        try {
            return waitForVisibility(codeError, 2).isDisplayed() &&
                   codeError.getText().toLowerCase().contains("already exists");
        } catch (Exception e) {
            return false;
        }
    }

    private boolean isNameExists() {
        try {
            return waitForVisibility(nameError, 2).isDisplayed() &&
                   nameError.getText().toLowerCase().contains("already exists");
        } catch (Exception e) {
            return false;
        }
    }

    private boolean isShortNameExists() {
        try {
            return waitForVisibility(shortNameError, 2).isDisplayed() &&
                   shortNameError.getText().toLowerCase().contains("already exists");
        } catch (Exception e) {
            return false;
        }
    }

    private void fillForm(String code, String name, String shortName, String country) {
        waitForVisibility(warehouseCodeInput).clear();
        warehouseCodeInput.sendKeys(code);

        waitForVisibility(warehouseNameInput).clear();
        warehouseNameInput.sendKeys(name);

        waitForVisibility(warehouseShortNameInput).clear();
        warehouseShortNameInput.sendKeys(shortName);

        waitForClickability(countryDropdown).click();
        waitForClickability(getSpanByTextCountry(country), 0).click();
    }
    @FindBy(xpath = "//input[@formcontrolname='warehousePincode']")
    private WebElement warehousePincodeField;

    // 🔹 Method
    public void enterWarehousePincode(String pincode) {
        warehousePincodeField.clear();
        warehousePincodeField.sendKeys(pincode);
    }
    public void createWarehouse(String code, String baseName, String baseShortName, String country) {
        navigateToAddWarehouse();

        String finalCode = code;
        String finalName = baseName;
        String finalShortName = baseShortName;
        int counter = 1;

        while (true) {
            fillForm(finalCode, finalName, finalShortName, country);
//            clickSave();

            boolean exists = false;

            if (isCodeExists()) {
                counter++;
                finalCode = code + "-" + counter;
                exists = true;
            }
            if (isNameExists()) {
//                counter++;
                finalName = baseName + "-" + counter;
                exists = true;
            }
            if (isShortNameExists()) {
//                counter++;
                finalShortName = baseShortName + "-" + counter;
                exists = true;
            }

            if (!exists) break;
        }
    }

    public void clickSave() {
        waitForClickability(saveButton).click();
    }

    public StorePageUpdate backbutton() {
        waitForPharmacyPageWithBackClick();
        return new StorePageUpdate(driver);
    }
}
