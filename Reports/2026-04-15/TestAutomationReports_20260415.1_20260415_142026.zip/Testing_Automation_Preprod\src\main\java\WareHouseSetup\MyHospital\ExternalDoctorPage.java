package WareHouseSetup.MyHospital;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class ExternalDoctorPage extends Abstraction{

	public ExternalDoctorPage(WebDriver driver) {
		super(driver);
	    this.driver = driver;
        PageFactory.initElements(driver, this);
	}
	  @FindBy(xpath = "//a[text()=' External Doctor ']")
	    private WebElement internalDoctorTab;

	    @FindBy(xpath = "//a[text()=' Add Physician ']")
	    private WebElement addPhysician;

	    // ======== LOCATORS ========

	    @FindBy(xpath = "//input[@formcontrolname='name']")
	    private WebElement physicianNameInput;

	    @FindBy(xpath = "//input[@formcontrolname='lastName']")
	    private WebElement lastNameInput;

	    @FindBy(xpath = "//input[@formcontrolname='displayName']")
	    private WebElement displayNameInput;

	    @FindBy(xpath = "//ngx-select[@formcontrolname='gender']")
	    private WebElement genderDropdown;

	    @FindBy(xpath = "//input[@formcontrolname='dob']")
	    private WebElement dobInput;

	    @FindBy(xpath = "//input[@formcontrolname='age']")
	    private WebElement ageInput;

	    @FindBy(xpath = "//input[@formcontrolname='email']")
	    private WebElement emailInput;

	    @FindBy(xpath = "//input[@formcontrolname='mobile']")
	    private WebElement mobileInput;

	    @FindBy(xpath = "//input[@formcontrolname='altMobile']")
	    private WebElement altMobileInput;

	    @FindBy(xpath = "//input[@formcontrolname='workPhone']")
	    private WebElement workPhoneInput;

	    @FindBy(xpath = "//input[@formcontrolname='panNo']")
	    private WebElement panInput;

	    @FindBy(xpath = "//ngx-select[@formcontrolname='departmentId']")
	    private WebElement departmentDropdown;

	    @FindBy(xpath = "//ngx-select[@formcontrolname='jobCategoryId']")
	    private WebElement jobCategoryDropdown;

	    @FindBy(xpath = "//ngx-select[@formcontrolname='jobType']")
	    private WebElement jobTypeDropdown;

	    @FindBy(xpath = "//ngx-select[@formcontrolname='academicRank']")
	    private WebElement academicRankDropdown;


	    @FindBy(xpath = "//input[@value='Save']")
	    private WebElement saveButton;
	    // ======== ACTION METHODS ========

	    public void selectFromDropdownByVisibleText(String visibleText) {
	        WebElement option = driver.findElement(By.xpath("//span[contains(text(),'" + visibleText + "')]"));
	        waitForClickability(option).click();
	    }

	    public void clickAddPhysicianButton() {
	        waitForClickability(internalDoctorTab).click();
	        waitForClickability(addPhysician).click();
	    }

	    public void selectPrefix(String prefixText) {
	        WebElement prefixDropdown = driver.findElement(By.xpath("//ngx-select[@placeholder='Select']"));
	        waitForClickability(prefixDropdown).click();
	        selectFromDropdownByVisibleText(prefixText);
	    }

	    public void enterPhysicianName(String name) {
	        waitForVisibility(physicianNameInput).clear();
	        physicianNameInput.sendKeys(name);
	    }

	    public void enterLastName(String lastName) {
	        waitForVisibility(lastNameInput).clear();
	        lastNameInput.sendKeys(lastName);
	    }

	    public void enterDisplayName(String displayName) {
	        waitForVisibility(displayNameInput).clear();
	        displayNameInput.sendKeys(displayName);
	    }

	    public void selectGender(String genderText) {
	        waitForClickability(genderDropdown).click();
	        selectFromDropdownByVisibleText(genderText);
	    }

	    public void enterDOB(String date) {
	        waitForVisibility(dobInput).clear();
	        js.executeScript(
	                "arguments[0].value='" + date + "';" +
	                "arguments[0].dispatchEvent(new Event('input'));" +
	                "arguments[0].dispatchEvent(new Event('change'));",
	                dobInput
	            );
	    }

	    public void enterAge(String age) {
	        waitForVisibility(ageInput).clear();
	        ageInput.sendKeys(age);
	    }

	    public void enterEmail(String email) {
	        waitForVisibility(emailInput).clear();
	        emailInput.sendKeys(email);
	    }

	    public void enterMobileNumber(String mobile) {
	        waitForVisibility(mobileInput).clear();
	        mobileInput.sendKeys(mobile);
	    }

	    public void enterAlternateMobile(String altMobile) {
	        waitForVisibility(altMobileInput).clear();
	        altMobileInput.sendKeys(altMobile);
	    }

	    public void enterWorkPhone(String workPhone) {
	        waitForVisibility(workPhoneInput).clear();
	        workPhoneInput.sendKeys(workPhone);
	    }

	    public void enterPanCardNumber(String pan) {
	        waitForVisibility(panInput).clear();
	        panInput.sendKeys(pan.toUpperCase());
	    }

	    public void selectDepartment(String departmentText) {
	        waitForClickability(departmentDropdown).click();
	        selectFromDropdownByVisibleText(departmentText);
	    }

	    public void selectJobCategory(String jobCategoryText) {
	        waitForClickability(jobCategoryDropdown).click();
	        selectFromDropdownByVisibleText(jobCategoryText);
	    }

	    public void selectJobType(String jobTypeText) {
	        waitForClickability(jobTypeDropdown).click();
	        selectFromDropdownByVisibleText(jobTypeText);
	    }

	    public void selectAcademicRank(String rankText) {
	        waitForClickability(academicRankDropdown).click();
	        selectFromDropdownByVisibleText(rankText);
	    }

	    public void addPhysician(
	        String prefix, String physicianName, String lastName, String displayName,
	        String gender, String dob, String age, String email,
	        String mobile, String altMobile, String workPhone, String panCard,
	        String department, String jobCategory, String jobType, String academicRank
	    ) {
	    	
	        clickAddPhysicianButton();
//	        selectPrefix(prefix);
	        enterPhysicianName(physicianName);
	        enterLastName(lastName);
	        enterDisplayName(displayName);
	        selectGender(gender);
	        enterDOB(dob);
//	        enterAge(age);
	        enterEmail(email);
	        enterMobileNumber(mobile);
//	        enterAlternateMobile(altMobile);
	        enterWorkPhone(workPhone);
//	        enterPanCardNumber(panCard);
	        selectDepartment(department);
//	        selectJobCategory(jobCategory);
//	        selectJobType(jobType);
	        selectAcademicRank(academicRank);
	    }
	    
	    public void clickSaveButton() {
	        waitForClickability(saveButton).click();
	    }
}
