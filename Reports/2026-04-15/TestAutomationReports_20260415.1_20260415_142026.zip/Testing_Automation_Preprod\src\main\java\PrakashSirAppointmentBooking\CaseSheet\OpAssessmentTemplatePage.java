package PrakashSirAppointmentBooking.CaseSheet;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeoutException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import EzionAbstractionComponents.Abstraction;

public class OpAssessmentTemplatePage extends Abstraction {

    WebDriver driver;

    public OpAssessmentTemplatePage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // ================= Locators =================

    // --- Section Header / Buttons ---
    @FindBy(xpath = "//h4[normalize-space(text())='OP Assessment']/following::img[contains(@class,'openclose')][1]")
    private WebElement opassesmentToggleIcon;
    
    @FindBy(xpath = "//a[@role='button' and normalize-space()='Add']")
    private WebElement addButton;

    @FindBy(xpath = "//input[@type='button' and @value='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//div[contains(@class,'lightbox-close')]/i[@class='fa fa-times']")
    private WebElement closePopupBtn;

    // --- Table ---
    @FindBy(xpath = "//table//tr[1]//td[2]")
    private WebElement firstTemplateName;

    @FindBy(xpath = "//table//tr[1]//td[@class='action-table']//a")
    private WebElement firstTemplateEditIcon;

    // --- Popup Window ---
    @FindBy(xpath = "//b[normalize-space()='Assessment Template']")
    private WebElement popupTitle;

    @FindBy(xpath = "//ngx-select[@id='certId']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement summaryTitleDropdown;

    // --- Dropdown Option (Dynamic) ---
    private String summaryOptionXpath = 
        "//div[contains(@class,'ngx-select__dropdown')]//span[normalize-space(text())='%s']";

    // --- Toast Messages ---
    @FindBy(xpath = "//div[contains(@class,'succesfull-info-popup')]/span[contains(text(),'Saved Successfully')]")
    private WebElement successMessage;

    @FindBy(xpath = "//div[contains(@class,'succesfull-info-popup')]/span[contains(text(),'Not Saved Successfully')]")
    private WebElement errorMessage;

    @FindBy(xpath = "//input[@type='button' and contains(@class,'btn-primary') and @value='Save Transaction']")
    WebElement saveTransactionButton;

 // Locator
    public void waitForPopupToDisappear(String message) throws TimeoutException {
        By popupLocator = By.xpath(
            "//div[contains(@class,'succesfull-info-popup')]//span[normalize-space(text())='" + message + "']"
        );

        // Step 1: Wait for popup to appear
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(popupLocator));

        // Step 2: Wait for popup to disappear
        wait.until(ExpectedConditions.invisibilityOfElementLocated(popupLocator));
    }



    // ================= Actions =================

    // --- Buttons ---
    
    public void toggle() {
        clickWithJavaScript(opassesmentToggleIcon);
    }
    public void clickAddButton() {
        clickWithJavaScript(addButton);
    }

    public WebElement getSaveButton(int index) {
        return driver.findElement(By.xpath("(//input[@type='button' and @value='Save'])[" + index + "]"));
    }

    public void closePopup() {
        closePopupBtn.click();
    }

    // --- Table ---
    public String getFirstTemplateName() {
        return firstTemplateName.getText();
    }

    public void clickFirstTemplateEdit() {
        firstTemplateEditIcon.click();
    }

    // --- Popup ---
    public boolean isPopupDisplayed() {
        return popupTitle.isDisplayed();
    }

    public void openSummaryDropdown() {
        summaryTitleDropdown.click();
    }

    public void saveTransaction() {
    	saveTransactionButton.click();
    }
    public void selectSummaryTitle(String title) throws InterruptedException {
        // Always open dropdown before selecting
    	clickAddButton();
    	isPopupDisplayed();
        openSummaryDropdown();

        WebElement option = driver.findElement(By.xpath(
            "//ul[@role='menu']//li[@role='menuitem']/a/span[contains(text(),'" + title + "')]"
        ));

        // Use JS click in case of intercept/hidden element
        clickWithJavaScript(option);
      
    }



    // --- Toasts ---
    public boolean isSuccessMessageDisplayed() {
        return successMessage.isDisplayed();
    }

    public boolean isErrorMessageDisplayed() {
        return errorMessage.isDisplayed();
    }
    
    public boolean clickEditOnTemplate(String targetTemplateName) {
        boolean isFound = false;
        int attempts = 0;

        while (attempts < 2 && !isFound) { // retry once if stale element occurs
            try {
                List<WebElement> rows = waitForPresenceOfAll(
                    By.xpath("//table[@class='table table-hover']/tbody/tr"));

                for (WebElement row : rows) {
                    try {
                        String templateName = row.findElement(By.xpath("./td[2]")).getText().trim();

                        if (templateName.equalsIgnoreCase(targetTemplateName)) {
                            WebElement editIcon = row.findElement(
                                By.xpath("./td[3]//img[contains(@src,'edit.png')]"));

                            // Wait until clickable before clicking
                            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
                            wait.until(ExpectedConditions.elementToBeClickable(editIcon));

                            clickWithJavaScript(editIcon);

                            System.out.println("✅ Clicked Edit for Template: " + templateName);
                            isFound = true;
                            break;
                        }
                    } catch (NoSuchElementException e) {
                        System.out.println("⚠️ Row skipped because of missing element");
                    }
                }
            } catch (StaleElementReferenceException e) {
                System.out.println("⚠️ Stale element detected, retrying...");
                attempts++;
            }
        }

        if (!isFound) {
            System.out.println("❌ Template not found: " + targetTemplateName);
        }

        return isFound;
    }

    
    public void selectAllergies(String... allergyNames) {
        waitForVisibility(saveTransactionButton);

        for (String allergyName : allergyNames) {
            WebElement checkbox = driver.findElement(By.xpath(
                "//h3[normalize-space()='Allergy']/ancestor::div[contains(@class,'selection-body')]//input[@type='checkbox' and @value='" + allergyName + "']"
            ));

            if (!checkbox.isSelected()) {
                clickWithJavaScript(checkbox);
                System.out.println("✅ Selected allergy: " + allergyName);
            } else {
                System.out.println("ℹ️ Allergy already selected: " + allergyName);
            }
        }
    }
    @FindBy(xpath = "//label[normalize-space()='Weight']/following::input[1]")
    private WebElement weightInput;

    @FindBy(xpath = "//label[normalize-space()='Height']/following::input[1]")
    private WebElement heightInput;

    @FindBy(xpath = "//label[normalize-space()='BP (Sys)']/following::input[1]")
    private WebElement bpSysInput;

    @FindBy(xpath = "//label[normalize-space()='News']/following::input[1]")
    private WebElement newsInput;

    // ---------- Methods ----------
    @FindBy(xpath = "//input[@type='button' and @value='Back' and contains(@class, 'btn-reset')]")
    private WebElement backButton;


    public void enterWeight(String weight) {
        weightInput.clear();
        weightInput.sendKeys(weight);
    }

    public void enterHeight(String height) {
        heightInput.clear();
        heightInput.sendKeys(height);
    }

    public void enterBpSys(String bp) {
        bpSysInput.clear();
        bpSysInput.sendKeys(bp);
    }

    public void enterNews(String news) {
        newsInput.clear();
        newsInput.sendKeys(news);
    }
    public void clickBackButton() {
        backButton.click();
    }


    // Generic method to unselect an allergy
    public void unselectAllergy(String allergyName) {
        WebElement checkbox = driver.findElement(By.xpath(
            "//h3[normalize-space()='Allergy']/ancestor::div[contains(@class,'selection-body')]//input[@type='checkbox' and @value='" + allergyName + "']"
        ));

        if (checkbox.isSelected()) {
            waitForClickability(checkbox).click();
            System.out.println("❌ Unselected allergy: " + allergyName);
        } else {
            System.out.println("ℹ️ Allergy already unselected: " + allergyName);
        }
    }

}
