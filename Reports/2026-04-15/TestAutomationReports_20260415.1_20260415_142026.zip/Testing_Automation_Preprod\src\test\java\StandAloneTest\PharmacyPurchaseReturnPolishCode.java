package StandAloneTest;



	import java.time.Duration;
	import org.openqa.selenium.By;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.WebDriverWait;
	import org.testng.annotations.AfterMethod;
	import org.testng.annotations.Test;
	import java.util.List;
	import java.util.NoSuchElementException;
import java.util.concurrent.TimeoutException;

	public class PharmacyPurchaseReturnPolishCode {

	    WebDriver driver;
	    WebDriverWait wait;
	    JavascriptExecutor js;

	    @Test
	    public void Return() {
	        driver = new ChromeDriver();
	        wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	        js = (JavascriptExecutor) driver;

	        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	        driver.manage().window().maximize();
	        driver.get("https://apps.ezovion.com/auth/login");

	        // Login
	        wait.until(ExpectedConditions.visibilityOfElementLocated(
	            By.xpath("//div[@class=\"form-control-group\"]//input"))).sendKeys("50107299");
	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//button[@size=\"large\"]"))).click();

	        wait.until(ExpectedConditions.visibilityOfElementLocated(
	            By.xpath("//input[@placeholder=\"Mobile No\"]"))).sendKeys("7766554433");
	        driver.findElement(By.xpath("//input[@placeholder=\"Password\"]")).sendKeys("12345");
	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//button[@status=\"primary\"]"))).click();

	        // Navigate to Admin > Roles Management
	        for (int i = 0; i < 5; i++) {
	            try {
	                WebElement adminTab = wait.until(ExpectedConditions.elementToBeClickable(
	                    By.xpath("//span[text()='Pharmacy']")));
	                adminTab.click();
	                wait.until(ExpectedConditions.elementToBeClickable(
	        	            By.xpath("(//span[text()='Purchase'])[1]"))).click();
	                break;
	            } catch (Exception e) {
	                System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
	                if (i == 4) throw e;
	            }
	        }

	        // Navigate to Pharmacy Purchase
	
	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("(//span[text()='Purchase'])[2]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("(//a[text()=' Add Purchase '])[1]"))).click();

	        // Select Pharmacy Location and Supplier
	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("(//span[text()='Select'])[1]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("(//span[text()='Pharamacy Loaction'])[1]"))).click();

	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("(//span[text()='Select'])[1]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("(//span[text()='supplier name'])[2]"))).click();

	        // Generate unique invoice number


	        int invoiceNo = 52;
	        while (true) {
	            WebElement invNoField = wait.until(ExpectedConditions.visibilityOfElementLocated(
	                By.xpath("//input[@formcontrolname='invNo']")));
	            invNoField.clear();
	            invNoField.sendKeys(String.valueOf(invoiceNo));

	            // Wait for the validation message to either appear or not
	            // Define the locator once
	            By validationMsgLocator = By.xpath("//*[contains(text(), 'Invoice No Already Exists')]");

	            try {
	                // Wait up to 3 seconds for the validation message to appear
	                WebDriverWait shortWait = new WebDriverWait(driver, Duration.ofSeconds(3));
	                shortWait.until(ExpectedConditions.visibilityOfElementLocated(validationMsgLocator));

	                // If message appears, increment invoice number
	                System.out.println("❌ Invoice No " + invoiceNo + " already exists.");
	                invoiceNo++;
	            } catch (org.openqa.selenium.TimeoutException e) {
	                // If message does NOT appear in 3 seconds, it's unique
	                System.out.println("✅ Unique Invoice No: " + invoiceNo);
	                break;
	            }
	        }


	        // Fill invoice details


	        WebElement invDate = wait.until(ExpectedConditions.visibilityOfElementLocated(
	            By.xpath("//input[@formcontrolname='invDate']")));
	        js.executeScript(
	            "arguments[0].value='06/12/2025'; arguments[0].dispatchEvent(new Event('input'));", 
	            invDate);

	        WebElement invDueDate = wait.until(ExpectedConditions.visibilityOfElementLocated(
	            By.xpath("//input[@formcontrolname='invDueDate']")));
	        js.executeScript(
	            "arguments[0].value='06/12/2025'; arguments[0].dispatchEvent(new Event('input'));", 
	            invDueDate);

	        // Search and add item
	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("(//span[text()='Search'])[1]"))).click();
	        WebElement syrupItem = wait.until(ExpectedConditions.visibilityOfElementLocated(
	            By.xpath("//span[text()='syrup14 ']")));
	        js.executeScript("arguments[0].click();", syrupItem);

	        // Fill item details
	        WebElement batchNumberField = wait.until(ExpectedConditions.visibilityOfElementLocated(
	            By.xpath("//input[@formcontrolname='BatchNumber']")));
	        batchNumberField.sendKeys("4");
	        wait.until(ExpectedConditions.attributeToBe(batchNumberField, "value", "4"));

	        WebElement expiryDateInput = wait.until(ExpectedConditions.visibilityOfElementLocated(
	            By.xpath("//input[@formcontrolname='expiryDate']")));
	        js.executeScript(
	            "const input = arguments[0];" +
	            "const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;" +
	            "nativeInputValueSetter.call(input, '2027-07');" +
	            "input.dispatchEvent(new Event('input', { bubbles: true }));" +
	            "input.dispatchEvent(new Event('change', { bubbles: true }));",
	            expiryDateInput);
	        wait.until(ExpectedConditions.attributeToBe(expiryDateInput, "value", "2027-07"));
	     // Check if the element is not visible
	        List<WebElement> lastProductElements = driver.findElements(By.xpath("//div[@class='last-product pt-2']"));
	        if (lastProductElements.isEmpty() || !lastProductElements.get(0).isDisplayed()) {
	            // Only fill these fields if the element is not visible
	            wait.until(ExpectedConditions.visibilityOfElementLocated(
	                By.xpath("//input[@formcontrolname='noOfStrips']"))).sendKeys("4");
	            wait.until(ExpectedConditions.visibilityOfElementLocated(
	                By.xpath("//input[@formcontrolname='freeStrips']"))).sendKeys("5");
	            wait.until(ExpectedConditions.visibilityOfElementLocated(
	                By.xpath("//input[@formcontrolname='mrpPerStrip']"))).sendKeys("25");
	            wait.until(ExpectedConditions.visibilityOfElementLocated(
	                By.xpath("//input[@formcontrolname='pricePerStrip']"))).sendKeys("25");
	        }
	        wait.until(ExpectedConditions.visibilityOfElementLocated(
	        	    By.xpath("//div[@class='view-section']")));
	        // Continue with the rest of your code
	        String amt=null;
	        for (int i = 0; i < 11; i++) {
	            // Optional: Perform action that updates the amount here

	            // Wait until the element is visible and has updated text (not "-")
	            wait.until(new ExpectedCondition<Boolean>() {
	                public Boolean apply(WebDriver driver) {
	                    WebElement element = driver.findElement(By.xpath("//label[text()='Payable Amt']/following-sibling::p"));
	                    String text = element.getText().trim();
	                    return !text.equals("-");
	                }
	            });

	            // After the value is valid, fetch it again to print
	            WebElement amountElement = driver.findElement(By.xpath("//label[text()='Payable Amt']/following-sibling::p"));
	             amt = amountElement.getText().trim();
	            System.out.println("Amount " + (i + 1) + ": " + amt);
	            break;
	        }
//
//	     System.out.println("Extracted amount: " + amountText);
	     wait.until(ExpectedConditions.visibilityOfElementLocated(
		            By.xpath("(//input[@formcontrolname='invValue'])[1]"))).sendKeys(amt);
	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//input[@value='Add']"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//input[@value='Save']"))).click();

	        	// Wait for Yes button to be visible and click it
	        	wait.until(ExpectedConditions.visibilityOfElementLocated(
	        	    By.xpath("//input[@value='Yes']"))).click();

	        	// Wait for Approve button to be visible and click it
	        	wait.until(ExpectedConditions.visibilityOfElementLocated(
	        	    By.xpath("//input[@value='Approve']"))).click();
	        // Find GRN number for the created invoice
	        	
	        	 String expectedUrl = "https://apps.ezovion.com/pages/masters/purchase_mst";
	             wait.until(ExpectedConditions.urlToBe(expectedUrl));
	             wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(
	 	                By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[2]/tr")));
	             System.out.println("Page loaded successfully: " + driver.getCurrentUrl());
	        String grnNo = null;
	        boolean matchFound = false;
	        System.out.println("Invoice Number: " + invoiceNo);

	        while (!matchFound) {
	            List<WebElement> rows = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(
	                By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[2]/tr")));

	            for (WebElement row : rows) {
	                try {
	                	WebElement invoiceElement = wait.until(ExpectedConditions.visibilityOf(
	                		    row.findElement(By.xpath(".//td[5]"))));
	                		String currentInvoiceNumber = invoiceElement.getText().trim();
	                    if (currentInvoiceNumber.equals(String.valueOf(invoiceNo))) {
	                        grnNo = row.findElement(By.xpath(".//td[2]")).getText().trim();
	                        System.out.println("Found GRN No: " + grnNo);
	                        matchFound = true;
	                        break;
	                    }
	                } catch (NoSuchElementException e) {
	                    continue;
	                }
	            }

	            if (!matchFound) {
	                try {
	                    WebElement nextPageButton = wait.until(ExpectedConditions.elementToBeClickable(
	                        By.xpath("(//i[@class='fas fa-chevron-right'])[1]")));
	                    js.executeScript("arguments[0].click();", nextPageButton);
	                    wait.until(ExpectedConditions.stalenessOf(rows.get(0)));
	                } catch (NoSuchElementException e) {
	                    System.out.println("Next Page button not found. End of pages.");
	                    break;
	                }
	            }
	        }
	    

	        // Create purchase return
	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("(//span[text()='Purchase Return'])[1]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("(//a[text()=' Add Purchase Return'])[1]"))).click();
	        wait.until(ExpectedConditions.urlToBe("https://apps.ezovion.com/pages/masters/purchase_return"));
	        // Select location and supplier
	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("(//span[text()='Pharamacy Loaction'])[1]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(
		            By.xpath("(//span[text()='Pharamacy Loaction'])[1]"))).click();
	         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click(); 
	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("(//span[text()='supplier name'])[2]"))).click();

	        // Select invoice
	        String invoiceRange = invoiceNo + " - " + grnNo;
	        WebElement option = wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//span[text()='" + invoiceRange + "']")));
	        js.executeScript("arguments[0].click();", option);

	        // Select return reason and item
	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//span[text()='Damaged Items']"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//span[text()='syrup14']"))).click();

	        // Set return quantity and remarks
	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//input[@formcontrolname='quantity']"))).sendKeys("1");
	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//input[@value='Add']"))).click();
	        wait.until(ExpectedConditions.visibilityOfElementLocated(
	            By.xpath("//textarea[@formcontrolname='returnRemarks']"))).sendKeys("damaged not usable");

	        // Save return
	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//input[@value='Save']"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//input[@value='Yes']"))).click();

	        wait.until(ExpectedConditions.urlToBe("https://apps.ezovion.com/pages/masters/purchase_return"));   
	        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(
	                By.xpath("//table[@class='table table-hover table-style']/tbody/tr")));
	        // Find and approve the return
	        String expectedInvoiceNo = String.valueOf(invoiceNo);
	        boolean matchFound2 = false;

	        while (!matchFound2) {
	            List<WebElement> rows1 = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(
	                By.xpath("//table[@class='table table-hover table-style']/tbody/tr")));

	            for (WebElement row : rows1) {
	                String invoiceNo2 = wait.until(ExpectedConditions.visibilityOf(
	                    row.findElement(By.xpath("./td[4]/h4")))).getText().trim();

	                if (invoiceNo2.equals(expectedInvoiceNo)) {
	                    WebElement editButton = row.findElement(By.xpath(".//img[contains(@src,'edit.png')]"));
	                    editButton.click();
	                    System.out.println("✅ Clicked Edit for Invoice No: " + invoiceNo2);
	                    matchFound2 = true;
	                    break;
	                }
	            }

	            if (!matchFound2) {
	                try {
	                    WebElement nextPageButton = wait.until(ExpectedConditions.elementToBeClickable(
	                        By.xpath("(//i[@class='fas fa-chevron-right'])[1]")));
	                    js.executeScript("arguments[0].click();", nextPageButton);
	                    wait.until(ExpectedConditions.stalenessOf(rows1.get(0)));
	                } catch (NoSuchElementException e) {
	                    System.out.println("No more pages or 'Next Page' button not found.");
	                    break;
	                }
	            }
	        }

	        // Final approval
	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//input[@value='Update & Approval']"))).click();
	    }


	}

