package StandAloneTest;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import EzionpageObjects.UserIdPage;
import WareHouseSetup.Approval.Approval;
import abdulTest.BaseTest;

public class ApprovalStandaloneTest extends BaseTest {

    @Test
    public static void main (String [] args) throws InterruptedException {
   	 WebDriver driver;
       driver = new ChromeDriver();
       WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

       driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
       driver.manage().window().maximize();
       driver.get("https://apps.ezovion.com/auth/login");

       driver.findElement(By.xpath("//div[@class=\"form-control-group\"]//input")).sendKeys("50107299");
       driver.findElement(By.xpath("//button[@size=\"large\"]")).click();

       wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
       driver.findElement(By.xpath("//input[@placeholder=\"Mobile No\"]")).sendKeys("7766554433");
       driver.findElement(By.xpath("//input[@placeholder=\"Password\"]")).sendKeys("12345");

       wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@status=\"primary\"]"))).click();

       for (int i = 0; i < 5; i++) {
           try {
               WebElement adminTab = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Admin']")));
               adminTab.click();
               wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Roles Management']"))).click();
               break;
           } catch (Exception e) {
               System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
               if (i == 4) throw e;
           }
       }
       wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Masters']"))).click();
       wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Master Set-up']"))).click();
        // Step 2: Assert login success
    

        // Step 3: Navigate to Approval Manager
        Approval approvalPage = new Approval(driver);
        approvalPage.clickbuttonapproval();

        // Step 4: Select dropdown values
        approvalPage.selectUserName("Abdul Ramiz");
        approvalPage.selectAccountType("Inventory");
        approvalPage.selectAccountSubType("Inventory Purchase");

        // Step 5: Save
        approvalPage.clickSave();

        // You can add a confirmation assertion here if there's a toast/message
        System.out.println("✅ User role setup completed successfully.");
    }
}
