


	package StandAloneTest;

	import java.time.Duration;
	import java.util.List;
	import java.util.NoSuchElementException;

	import org.openqa.selenium.By;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.edge.EdgeDriver;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.WebDriverWait;
	import org.testng.annotations.Test;

	@Test
	public class SalesReturnPagePolishCode {
	    public void PPLE() {
	        WebDriver driver = new EdgeDriver();
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	        driver.get("https://apps.ezovion.com/auth/login");
	        driver.manage().window().maximize();

	        // Login process
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class=\"form-control-group\"]//input")))
	            .sendKeys("50107299");
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@size=\"large\"]"))).click();
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")))
	            .sendKeys("7766554433");
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Password\"]")))
	            .sendKeys("12345");
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@status=\"primary\"]"))).click();

	        // Navigate to Admin > Roles Management
	        for (int i = 0; i < 5; i++) {
	            try {
	                WebElement adminTab = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Admin']")));
	                adminTab.click();
	                wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Roles Management']"))).click();
	                break;
	            } catch (Exception e) {
	                System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
	                if (i == 4) throw e;
	            }
	        }

	        // Navigate to Pharmacy > Sales
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Pharmacy']"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Sales'])[1]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Sales'])[2]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Counter Sales ']"))).click();

	        // Fill customer details
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='mobilenumber']")))
	            .sendKeys("9876543210");
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@role='combobox']")))
	            .sendKeys("abdul ramiz");
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn btn-primary ng-star-inserted']")))
	            .click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//strong[text()='abdul ramiz']"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Select Doctor']"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Dr.  Ramiz']"))).click();

	        // Add medicine
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h4[text()='Medidine Ezovion']"))).click();
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='quantity']")))
	            .sendKeys("4");
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Add']"))).click();

	        // Save and confirm
	        WebElement saveButton = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@value='Save']")));
	        JavascriptExecutor js = (JavascriptExecutor) driver;
	        js.executeScript("arguments[0].scrollIntoView(true);", saveButton);
	        js.executeScript("arguments[0].click();", saveButton);

	        WebElement yesButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Yes']")));
	        js.executeScript("arguments[0].click();", yesButton);

	        // Get bill number
	        String targetBillNo = wait.until(ExpectedConditions.visibilityOfElementLocated(
	            By.xpath("(//b[@class='headerfont'])[3]"))).getText();

	        // Navigate back to sales
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Sales'])[2]"))).click();

	        // Find the bill for return
	        boolean matchFound = false;
	        while (!matchFound) {
	            List<WebElement> rows = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(
	                By.cssSelector("table.table-style tbody tr")));

	            for (WebElement row : rows) {
	                try {
	                    WebElement billNoElement = row.findElement(By.cssSelector("td:nth-child(2) h4"));
	                    String currentBillNo = billNoElement.getText().trim();

	                    if (currentBillNo.equals(targetBillNo)) {
	                        WebElement salesReturnBtn = wait.until(ExpectedConditions.elementToBeClickable(
	                            row.findElement(By.cssSelector("li a[title='Go Sales Return'] img"))));
	                        salesReturnBtn.click();
	                        matchFound = true;
	                        break;
	                    }
	                } catch (Exception e) {
	                    System.err.println("Error processing row: " + e.getMessage());
	                }
	            }

	            if (!matchFound) {
	                try {
	                    WebElement nextPageButton = wait.until(ExpectedConditions.elementToBeClickable(
	                        By.xpath("(//i[@class='fas fa-chevron-right'])[1]")));
	                    
	                    if (nextPageButton.isEnabled()) {
	                        js.executeScript("arguments[0].click();", nextPageButton);
	                        // Wait for table to refresh
	                        wait.until(ExpectedConditions.stalenessOf(rows.get(0)));
	                    } else {
	                        break;
	                    }
	                } catch (NoSuchElementException e) {
	                    System.out.println("Next Page button not found. End of pages.");
	                    break;
	                }
	            }
	        }

	        // Process sales return
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Search Medicine']"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//h4[contains(normalize-space(), 'Medidine Ezovion')]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[@class=\"checkmark\"])[1]"))).click();
	        wait.until(ExpectedConditions.visibilityOfElementLocated(
	            By.xpath("//input[@formcontrolname=\"discount_percentage\"]"))).sendKeys("10");
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value=\"Add\"]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='custom-checkbox']"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class=\"phar-tot-grands1\"]"))).click();

	        // Save with retry logic
	        for (int i = 0; i < 3; i++) {
	            try {
	                wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();
	                wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Yes']"))).click();
	                System.out.println("Clicked Save and Yes in iteration: " + i);
	                break;
	            } catch (Exception e) {
	                System.out.println("Exception in iteration " + i + ": " + e.getMessage());
	                if (i == 4) throw e;
	            }
	        }

	    }
	
}
