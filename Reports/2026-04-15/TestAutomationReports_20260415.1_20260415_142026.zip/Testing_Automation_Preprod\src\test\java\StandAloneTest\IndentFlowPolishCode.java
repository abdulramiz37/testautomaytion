package StandAloneTest;



	import java.time.Duration;
	import java.util.List;
	import java.util.NoSuchElementException;
	import org.openqa.selenium.By;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.edge.EdgeDriver;
	import org.openqa.selenium.Keys;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.WebDriverWait;
	import org.testng.annotations.Test;

	@Test
	public class IndentFlowPolishCode {

	    
	    public void PPLE() {
	        String currentIndentNo = "";
	        WebDriver driver = new EdgeDriver();
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	        driver.get("https://apps.ezovion.com/auth/login");
	        driver.manage().window().maximize();
	        
	        // Login
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class=\"form-control-group\"]//input"))).sendKeys("50107299");
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@size=\"large\"]"))).click();
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]"))).sendKeys("7766554433");
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Password\"]"))).sendKeys("12345");
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@status=\"primary\"]"))).click();
	        
	        // Navigate to Admin > Roles Management
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Admin']"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Roles Management']"))).click();
	        
	        // Navigate to Pharmacy > Indent > Internal Indent > Indent Request
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Pharmacy']"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Indent'])[1]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Internal Indent'])[1]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[text()=' Indent Request '])[1]"))).click();
	        
	        // Fill out indent form
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Pharamacy Loaction'])[1]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Fddf'])[1]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Dddd'])[1]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Search Medicine'])[1]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//h4[text()='Medidine Ezovion'])[1]"))).click();
	        
	        // Add medicine
	        WebElement quantityInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='indentQuantity']")));
	        quantityInput.sendKeys("5");
	        
	        WebElement addButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@value='Add'])[1]")));
	        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", addButton);
	        
	        // Save indent
	        WebElement saveButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@value='Save'])[1]")));
	        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", saveButton);
	        
	        // Find and edit new indent
	        boolean isFound = false;
	        while (!isFound) {
	            List<WebElement> freshRows = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//table[@class='table table-hover table-style']/tbody/tr")));
	            
	            for (int i = 1; i <= freshRows.size(); i++) {
	                currentIndentNo = driver.findElement(By.xpath("//table[@class='table table-hover table-style']/tbody/tr[" + i + "]/td[2]")).getText().trim();
	                String currentStatus = driver.findElement(By.xpath("//table[@class='table table-hover table-style']/tbody/tr[" + i + "]/td[6]")).getText().trim();
	                
	                if (currentStatus.equalsIgnoreCase("NEW")) {
	                    WebElement editButton = wait.until(ExpectedConditions.elementToBeClickable(
	                        By.xpath("//table[@class='table table-hover table-style']/tbody/tr[" + i + "]/td[7]/li[1]/a")));
	                    editButton.click();
	                    isFound = true;
	                    break;
	                }
	            }
	            
	            if (!isFound) {
	                try {
	                    WebElement nextButton = driver.findElement(By.xpath("(//i[@class='fas fa-chevron-right'])[1]"));
	                    if (nextButton.isEnabled()) {
	                        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextButton);
//	                        wait.until(ExpectedConditions.stalenessOf(freshRows.get(0)));
	                    } else {
	                        break;
	                    }
	                } catch (NoSuchElementException e) {
	                    break;
	                }
	            }
	        }
	        
	        // Send request
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@value='Send Request'])[1]"))).click();
	        
	        // Navigate to Indent Approval
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Indent Approval'])[1]"))).click();
	        
	        // Find and update approval
	        boolean isFound2 = false;
	        while (!isFound2) {
	            List<WebElement> rows = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[4]/tr")));
	            
	            for (int i = 1; i <= rows.size(); i++) {
	                String indentNo2 = driver.findElement(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[4]/tr[" + i + "]/td[2]")).getText().trim();
	                String status = driver.findElement(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[4]/tr[" + i + "]/td[7]/span")).getText().trim();
	                
	                if (currentIndentNo.equals(indentNo2) && status.equals("WAITING FOR APPROVAL")) {
	                    WebElement editButton = wait.until(ExpectedConditions.elementToBeClickable(
	                        By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[4]/tr[" + i + "]/td[9]/li[1]/a")));
	                    editButton.click();
	                    isFound2 = true;
	                    break;
	                }
	            }
	            
	            if (!isFound2) {
	                try {
	                    WebElement nextPageButton = driver.findElement(By.xpath("(//i[@class='fas fa-chevron-right'])[2]"));
	                    if (!nextPageButton.getAttribute("class").contains("disabled")) {
	                        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextPageButton);
//	                        wait.until(ExpectedConditions.stalenessOf(rows.get(0)));
	                    } else {
	                        break;
	                    }
	                } catch (NoSuchElementException e) {
	                    break;
	                }
	            }
	        }
	        
	        // Update approval
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@value='Update'])[1]"))).click();
	        
	        // Find and receive
	        boolean isFound3 = false;
	        while (!isFound3) {
	            List<WebElement> rows2 = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[4]/tr")));
	            
	            for (int i = 1; i <= rows2.size(); i++) {
	                String indentNo3 = driver.findElement(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[4]/tr[" + i + "]/td[2]")).getText().trim();
	                
	                if (currentIndentNo.equals(indentNo3)) {
	                    WebElement receiveButton = wait.until(ExpectedConditions.elementToBeClickable(
	                        By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[4]/tr[" + i + "]/td[9]/li[2]/a")));
	                    receiveButton.click();
	                    isFound3 = true;
	                    break;
	                }
	            }
	            
	            if (!isFound3) {
	                try {
	                    WebElement nextPageButton = driver.findElement(By.xpath("(//i[@class='fas fa-chevron-right'])[2]"));
	                    if (!nextPageButton.getAttribute("class").contains("disabled")) {
	                        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextPageButton);
//	                        wait.until(ExpectedConditions.stalenessOf(rows2.get(0)));
	                    } else {
	                        break;
	                    }
	                } catch (NoSuchElementException e) {
	                    break;
	                }
	            }
	        }
	        
	        // Complete receiving process
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='lightbox-close']"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[10]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Fddf']"))).click();
	        
	        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@inputmode='numeric']")));
	        input.sendKeys(Keys.CONTROL + "a");
	        input.sendKeys(Keys.DELETE);
	        input.sendKeys("2");
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();
	        
	        // Final receive
	        boolean isFound4 = false;
	        while (!isFound4) {
	            List<WebElement> rows3 = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[6]/tr")));
	            
	            for (int i = 1; i <= rows3.size(); i++) {
	                try {
	                    WebElement receiveIcon = driver.findElement(By.xpath("//a[@title='Go To Receive']/img[contains(@src, 'phar.png') and contains(@style, 'opacity: 1')]"));
	                    receiveIcon.click();
	                    isFound4 = true;
	                    break;
	                } catch (NoSuchElementException e) {
	                    // Continue to next row
	                }
	            }
	            
	            if (!isFound4) {
	                try {
	                    WebElement nextPageButton = driver.findElement(By.xpath("(//i[@class='fas fa-chevron-right'])[2]"));
	                    if (!nextPageButton.getAttribute("class").contains("disabled")) {
	                        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextPageButton);
//	                        wait.until(ExpectedConditions.stalenessOf(rows3.get(0)));
	                    } else {
	                        break;
	                    }
	                } catch (NoSuchElementException e) {
	                    break;
	                }
	            }
	        }
	        
	        // Final select and save
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[14]"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Fddf']"))).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();
	        
	        driver.quit();
	    }
	
}
