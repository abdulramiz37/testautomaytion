package PharmacyFlowObjects.PharmacyStore;

import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.*;
import EzionAbstractionComponents.Abstraction;

public class CustomerPage extends Abstraction {

    WebDriver driver;

    public CustomerPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // ==== LOCATORS ====
    @FindBy(xpath = "//a[text()=' Customer']")
    private WebElement customerTab;

    @FindBy(xpath = "//a[text()=' Add Customer ']")
    private WebElement addCustomerButton;

    @FindBy(xpath = "(//input[@type='radio' and @value='Customer'])")
    private WebElement customerRadio;

    @FindBy(xpath = "(//input[@type='radio' and @value='Internal Department'])")
    private WebElement internalDeptRadio;

    @FindBy(xpath = "(//input[@type='text'])[3]")
    private WebElement customerNameInput;

    @FindBy(xpath = "(//input[@type='text'])[4]")
    private WebElement phoneNumberInput;

    @FindBy(xpath = "(//input[@type='text'])[5]")
    private WebElement emailInput;

    @FindBy(xpath = "(//input[@type='text'])[6]")
    private WebElement creditLimitInput;

    @FindBy(xpath = "//input[@formcontrolname='doorNo']")
    private WebElement doorNoInput;

    @FindBy(xpath = "//input[@formcontrolname='street']")
    private WebElement streetInput;

    @FindBy(xpath = "//input[@formcontrolname='city']")
    private WebElement cityInput;

    @FindBy(xpath = "//input[@formcontrolname='landmark']")
    private WebElement landmarkInput;

    @FindBy(xpath = "//input[@formcontrolname='pincode']")
    private WebElement pincodeInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='district']")
    private WebElement districtSelect;

    @FindBy(xpath = "//ngx-select[@formcontrolname='state']")
    private WebElement stateSelect;

    @FindBy(xpath = "//ngx-select[@formcontrolname='country']")
    private WebElement countrySelect;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//span[contains(text(),'Name Already Exists..')]")
    private WebElement duplicateerrorMessge;
  
    @FindBy(xpath = "//p[contains(text(),'Incorrect Name')]")
    WebElement incorrectNameMessage;

    @FindBy(xpath = "//p[contains(text(),'Incorrect Mobile Number')]")
    WebElement incorrectMobileNumberMessage;

    @FindBy(xpath = "//p[contains(text(),'Incorrect Credit Limit')]")
    WebElement incorrectCreditLimitMessage;

    @FindBy(xpath = "//p[contains(text(),'Incorrect Pincode')]")
    WebElement incorrectPincodeMessage;

    // ==== ACTION METHODS ====
  
    public String duplicateErrorMessage() {
    	return duplicateerrorMessge.getText();
    }

    public String isIncorrectNameMessageDisplayed() {
        return incorrectNameMessage.getText();
    }

    public String isIncorrectMobileNumberMessageDisplayed() {
        return incorrectMobileNumberMessage.getText();
    }

    public String isIncorrectCreditLimitMessageDisplayed() {
        return incorrectCreditLimitMessage.getText();
    }

    public String isIncorrectPincodeMessageDisplayed() {
        return incorrectPincodeMessage.getText();
    }

    public void clickCustomerTab() {
        waitForClickability(customerTab).click();
    }

    public void clickAddCustomer() {
        waitForClickability(addCustomerButton).click();
    }

    public void selectCustomerType(String type) {
        if (type.equalsIgnoreCase("Customer")) {
            waitForClickability(customerRadio).click();
        } else if (type.equalsIgnoreCase("Internal Department")) {
            waitForClickability(internalDeptRadio).click();
        }
    }

    public void enterCustomerName(String name) {
        waitForClickability(customerNameInput).clear();
        customerNameInput.sendKeys(name);
    }

    public void enterPhoneNumber(String phone) {
        waitForClickability(phoneNumberInput).clear();
        phoneNumberInput.sendKeys(phone);
    }

    public void enterEmail(String email) {
        waitForClickability(emailInput).clear();
        emailInput.sendKeys(email);
    }

    public void enterCreditLimit(String amount) {
        waitForClickability(creditLimitInput).clear();
        creditLimitInput.sendKeys(amount);
    }

    public void enterDoorNo(String doorNo) {
        waitForClickability(doorNoInput).clear();
        doorNoInput.sendKeys(doorNo);
    }

    public void enterStreet(String street) {
        waitForClickability(streetInput).clear();
        streetInput.sendKeys(street);
    }

    public void enterCity(String city) {
        waitForClickability(cityInput).clear();
        cityInput.sendKeys(city);
    }

    public void enterLandmark(String landmark) {
        waitForClickability(landmarkInput).clear();
        landmarkInput.sendKeys(landmark);
    }

    public void enterPincode(String pincode) {
        waitForClickability(pincodeInput).clear();
        pincodeInput.sendKeys(pincode);
    }

 

   

    public void clickSaveButton() {
        waitForClickability(saveButton).click();
    }

    // ==== COMPLETE FLOW ====

    public void addCustomer(String name, String phone, String email, String credit, String door, String street, String city, String landmark, String pincode,String districtName) {
        clickCustomerTab();
        clickAddCustomer();
        selectCustomerType("Customer");
        enterCustomerName(name);
        enterPhoneNumber(phone);
        enterEmail(email);
        enterCreditLimit(credit);
        enterDoorNo(door);
        enterStreet(street);
        enterCity(city);
        enterLandmark(landmark);
        enterPincode(pincode);
 
        selectDistrictOption(districtName);
    }

    public PharmacyLocationPage save() {
        clickSaveButton();
        return new PharmacyLocationPage(driver);
    }

    // ==== UTILITY: ngx-select dropdown clicker ====

    public void selectDistrictOption(String districtName) {
    	waitForClickability(districtSelect).click();;
        String xpath = "//a[contains(@class, 'ngx-select__item')]/span[text()='" + districtName + "']";
        WebElement option = driver.findElement(By.xpath(xpath));
        waitForClickability(option).click();
    }
}
