package Registration;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class PatientList extends Abstraction{

	public PatientList(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
	}
	
    @FindBy(xpath = "//span[text()='Patient List']")
    private WebElement adduserType;
    
    public void patientlist() {
    adduserType.click();
    }
	public void findPatientByMobile(String targetMobileNumber) {
	    boolean isPatientFound = false;
	    int clickCount = 0; // keep outside the loop so it persists

	    while (!isPatientFound) {
	        List<WebElement> rows = driver.findElements(
	            By.xpath("//tr[.//i[contains(@class,'fa-phone')]]")
	        );

	        for (int i = 0; i < rows.size(); i++) {
	            try {
	                WebElement row = rows.get(i);

	                // Phone container with <i class="fa fa-phone">
	                WebElement phoneContainer = row.findElement(
	                    By.xpath(".//p[contains(@class,'mb-0')][i[@class='fa fa-phone']]")
	                );

	                String fullText = phoneContainer.getText(); // includes number
	                String mobileNumber = fullText.replaceAll("[^0-9]", "").trim();
	                System.out.println("📱 Found: " + mobileNumber);

	                if (mobileNumber.equals(targetMobileNumber)) {
	                    // Open actions menu
	                    WebElement actionsMenu = row.findElement(
	                        By.xpath(".//button[@class='btn btn-link p-0 action-menu-toggle']")
	                    );
	                    waitForClickability(actionsMenu).click();

	                    // Get serial number
	                    WebElement serialNumber = row.findElement(By.xpath(".//td[1]"));
	                    String serialText = serialNumber.getText().trim();
	                    int num = Integer.parseInt(serialText.replaceAll("[^0-9]", ""));

	                    // Map to serviceIndex
	                    int serviceIndex;
	                    if (num <= 10) {
	                        serviceIndex = num;
	                    } else if (num % 10 == 0) {
	                        serviceIndex = 10;
	                    } else {
	                        serviceIndex = num % 10;
	                    }

	                    // Click Service action
	                    WebElement serviceAction = driver.findElement(
	                        By.xpath("(//span[contains(text(),'Service')]/ancestor::a)[" + serviceIndex + "]")
	                    );
	                    serviceAction.click();

	                    System.out.println("✅ Clicked Actions for Patient with Mobile: " + mobileNumber);
	                    isPatientFound = true;
	                    break;
	                }
	            } catch (NoSuchElementException e) {
	                System.out.println("⚠️ Skipping stale/missing row at index " + i);
	            }
	        }

	        // If not found, go to next page
	        if (!isPatientFound) {
	            if (clickCount >= 14) {
	                System.out.println("⛔ Stopped after 14 pages. Patient not found.");
	                break;
	            }

	            try {
	                WebElement nextButton = driver.findElement(
	                    By.xpath("//i[contains(@class, 'fa-chevron-right')]/ancestor::a")
	                );

	                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextButton);
	                clickCount++;
	                System.out.println("➡️ Moving to next page... (Click " + clickCount + ")");
	                Thread.sleep(1500); // allow time for table reload
	            } catch (NoSuchElementException e) {
	                System.out.println("❌ Next page button not found. Ending search.");
	                break;
	            } catch (InterruptedException e) {
	                Thread.currentThread().interrupt();
	            }
	        }
	    }
	}
	
	public void findPatientByMobile(String targetMobileNumber, String menuOption) {
	    boolean isPatientFound = false;
	    int clickCount = 0; // persist across pages

	    while (!isPatientFound) {
	        List<WebElement> rows = driver.findElements(
	            By.xpath("//tr[.//i[contains(@class,'fa-phone')]]")
	        );

	        for (int i = 0; i < rows.size(); i++) {
	            try {
	                WebElement row = rows.get(i);

	                // Phone container
	                WebElement phoneContainer = row.findElement(
	                    By.xpath(".//p[contains(@class,'mb-0')][i[@class='fa fa-phone']]")
	                );

	                String fullText = phoneContainer.getText();
	                String mobileNumber = fullText.replaceAll("[^0-9]", "").trim();
	                System.out.println("📱 Found: " + mobileNumber);

	                if (mobileNumber.equals(targetMobileNumber)) {
	                    // Open action menu
	                    WebElement actionsMenu = row.findElement(
	                        By.xpath(".//button[@class='btn btn-link p-0 action-menu-toggle']"));
	                    waitForClickability(actionsMenu).click();

	                    // 🔥 Dynamic menu item (e.g. Service, Admission, Wallet, etc.)
	                    String dynamicXpath = "//ul[contains(@class,'dropdown-menu')]//div[normalize-space()='" + menuOption + "']";
	                    WebElement menuItem = waitForClickability(
	                        driver.findElement(By.xpath(dynamicXpath))
	                    );
	                    menuItem.click();

	                    System.out.println("✅ Clicked '" + menuOption + "' for Patient: " + mobileNumber);
	                    isPatientFound = true;
	                    break;
	                }
	            } catch (NoSuchElementException e) {
	                System.out.println("⚠️ Skipping row " + i + " (stale or missing element)");
	            }
	        }

	        // If not found, move to next page
	        if (!isPatientFound) {
	            if (clickCount >= 14) {
	                System.out.println("⛔ Stopped after 14 pages. Patient not found.");
	                break;
	            }
	            try {
	                WebElement nextButton = driver.findElement(
	                    By.xpath("//i[contains(@class, 'fa-chevron-right')]/ancestor::a")
	                );
	                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextButton);
	                clickCount++;
	                System.out.println("➡️ Moving to next page... (Click " + clickCount + ")");
	                Thread.sleep(1500);
	            } catch (NoSuchElementException e) {
	                System.out.println("❌ Next button not found. Ending search.");
	                break;
	            } catch (InterruptedException e) {
	                Thread.currentThread().interrupt();
	            }
	        }
	    }
	}



}
