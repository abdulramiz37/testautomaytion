package PharmacyFlowObjects.PharmacyStore;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.*;

import EzionAbstractionComponents.Abstraction;

public class CustomerPageUpdate extends Abstraction {

    WebDriver driver;
    WebDriverWait wait;

    public CustomerPageUpdate(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
      
    }

    // Web elements using PageFactory
    @FindBy(xpath = "//a[text()=' Customer']")
    private WebElement customerTab;

    @FindBy(xpath = "//a[text()=' Add Customer ']")
    private WebElement addCustomerButton;

    @FindBy(xpath = "(//input[@type='text'])[3]")
    private WebElement customerNameInput;

    @FindBy(xpath = "(//input[@type='text'])[4]")
    private WebElement phoneNumberInput;

    
    
    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;
 
    // Actions
    public void clickCustomerTab() {
    	waitForClickability(customerTab).click();
    }

    public void clickAddCustomer() {
    	waitForClickability(addCustomerButton).click();
    }

    public void enterCustomerName(String name) {
        waitForClickability(customerNameInput);

        String uniqueName = name;

        int attempt = 0;
        while (true) {
            waitForVisibility(customerNameInput).clear();
            customerNameInput.sendKeys(uniqueName);

            try {
                new WebDriverWait(driver, Duration.ofSeconds(0))
                    .until(ExpectedConditions.invisibilityOfElementLocated(
                        By.xpath("//span[contains(text(),'Name Already Exists..')]")));
                break; // Found a unique name
            } catch (TimeoutException e) {
                attempt++;
                uniqueName = name + getCharacterSuffix(attempt);
            }
        }
    }
    private String getCharacterSuffix(int number) {
        StringBuilder suffix = new StringBuilder();
        while (number > 0) {
            number--; // Convert to 0-based
            suffix.insert(0, (char) ('A' + (number % 26)));
            number /= 26;
        }
        return suffix.toString();
    }


    public void enterPhoneNumber(String phone) {
    	waitForClickability(phoneNumberInput).sendKeys(phone);
    }
 

    public void clickSaveButton() {
    	waitForClickability(saveButton).click();
    }

    public void addCustomer(String name, String phone) {
        clickCustomerTab();
        clickAddCustomer();
        enterCustomerName(name);
        enterPhoneNumber(phone);
     
        
    }
    public PharmacyLocationPageUpdate save() {
    	clickSaveButton();
    	 waitForPharmacyPageWithBackClick();
    	 PharmacyLocationPageUpdate pharmacylocationpage = new PharmacyLocationPageUpdate(driver);
    	return pharmacylocationpage;
    }
}
