package PharmacyPurchaseReturn;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class GRNVerificationPage extends Abstraction {

    @FindBy(xpath = "(//table[contains(@class, 'table-hover')]/tbody)[2]/tr")
    private List<WebElement> tableRows;

    @FindBy(xpath = "(//i[@class='fas fa-chevron-right'])[1]")
    private WebElement nextPageButton;

    private String grnNo = null;

    public GRNVerificationPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    public String getGRNNumber(String invoiceNo) {
//        String expectedUrl = "https://apps.ezovion.com/pages/masters/purchase_mst";
    	 String expectedUrl = "https://ezopreprodstrgfrontend.z29.web.core.windows.net/pages/masters/purchase_mst";
    	
//        waitForUrl(expectedUrl);
        waitForVisibility(tableRows.get(0));

        System.out.println("Page loaded successfully: " + driver.getCurrentUrl());
        System.out.println("Invoice Number: " + invoiceNo);

        boolean matchFound = false;

        while (!matchFound) {
            List<WebElement> rows = waitForPresenceOfAll(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[2]/tr"));

            for (WebElement row : rows) {
                try {
                    WebElement invoiceElement = waitForVisibility(row.findElement(By.xpath(".//td[5]")));
                    String currentInvoiceNumber = invoiceElement.getText().trim();
                    if (currentInvoiceNumber.equals(invoiceNo)) {
                        grnNo = row.findElement(By.xpath(".//td[2]")).getText().trim();
                        System.out.println("Found GRN No: " + grnNo);
                        matchFound = true;
                        break;
                    }
                } catch (NoSuchElementException e) {
                    continue;
                }
            }

            if (!matchFound) {
                try {
                    WebElement nextButton = waitForClickability(nextPageButton);
                    clickWithJavaScript(nextButton);
                } catch (NoSuchElementException e) {
                    System.out.println("Next Page button not found. End of pages.");
                    break;
                }
            }
        }
System.out.println(grnNo);
        return grnNo;
    }

    public String getStoredGRNNo() {
        return grnNo;
    }
}
