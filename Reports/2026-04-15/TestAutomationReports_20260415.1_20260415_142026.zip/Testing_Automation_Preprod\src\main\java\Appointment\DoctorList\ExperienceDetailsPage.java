package Appointment.DoctorList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class ExperienceDetailsPage extends Abstraction{

    WebDriver driver;

    public ExperienceDetailsPage(WebDriver driver) {
    	super(driver);
    
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//input[@formcontrolname='hospitalName']")
    private WebElement hospitalNameInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='designationId']/div")
    private WebElement designationDropdown;

    @FindBy(xpath = "//input[@formcontrolname='startDate']")
    private WebElement startDateInput;

    @FindBy(xpath = "//input[@formcontrolname='endDate']")
    private WebElement endDateInput;

    @FindBy(xpath = "//input[@formcontrolname='experienceInYear']")
    private WebElement experienceInYearsField;

    @FindBy(xpath = "//input[@type='button' and @value='Add']")
    private WebElement addExperienceButton;

    @FindBy(xpath = "(//input[@type='button' and @value='Save and Continue'])[4]")
    private WebElement saveAndContinueButton;
    
    
    public void enterHospitalName(String hospitalName) {
        hospitalNameInput.clear();
        hospitalNameInput.sendKeys(hospitalName);
    }

    public void selectDesignation(String designation) {
        designationDropdown.click();
        WebElement optionXpath =   driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[text()='" + designation + "']"));
  
        		optionXpath.click();
    }

    public void enterStartDate(String startDate) {
        startDateInput.clear();
        startDateInput.sendKeys(startDate);
        startDateInput.sendKeys(Keys.TAB); // To trigger blur if needed
    }

    public void enterEndDate(String endDate) {
        endDateInput.clear();
        endDateInput.sendKeys(endDate);
        endDateInput.sendKeys(Keys.TAB);
    }

    public String getCalculatedExperience() {
        return experienceInYearsField.getAttribute("value");
    }

    public void clickAddExperience() {
        addExperienceButton.click();
    }

    public void clickSaveAndContinue() {
        saveAndContinueButton.click();
    }

    public void fillExperienceDetailsForm(String hospital, String designation, String startDate, String endDate) {
        enterHospitalName(hospital);
        selectDesignation(designation);
        enterStartDate(startDate);
        enterEndDate(endDate);
    
    }
}

    


