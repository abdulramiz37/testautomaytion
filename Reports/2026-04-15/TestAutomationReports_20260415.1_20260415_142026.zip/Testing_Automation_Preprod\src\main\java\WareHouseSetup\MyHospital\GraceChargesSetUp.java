package WareHouseSetup.MyHospital;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;
import java.util.List;

public class GraceChargesSetUp extends Abstraction {
    WebDriver driver;

    public GraceChargesSetUp(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // ================== LOCATORS ==================

    // Navigation
    @FindBy(xpath = "//a[text()=' Grace Charges Set-Up ']")
    private WebElement graceChargesSetUpLink;

    // Main filters
    @FindBy(xpath = "//input[@formcontrolname='wardNameFilter']")
    private WebElement nameFilterInput;

    @FindBy(xpath = "//input[@formcontrolname='serviceNameFilter']")
    private WebElement serviceNameFilterInput;

    // Department dropdown
    @FindBy(xpath = "//label[contains(text(),'Department')]/following::ngx-select[1]/div")
    private WebElement departmentDropdown;

    // Doctor dropdown
    @FindBy(xpath = "//label[contains(text(),'Doctor')]/following::ngx-select[1]/div")
    private WebElement doctorDropdown;

    // Validity inputs
    @FindBy(xpath = "//input[@formcontrolname='subVisitValidityDays']")
    private WebElement subVisitValidityInput;

    @FindBy(xpath = "//input[@formcontrolname='validitySecondVisitDays']")
    private WebElement secondVisitValidityInput;

    @FindBy(xpath = "//input[@formcontrolname='validityThirdVisitDays']")
    private WebElement thirdVisitValidityInput;

    // Timing Info
    @FindBy(xpath = "//span[@class='material-icons text-info' and text()='info']")
    private WebElement timingInfoIcon;

    // Table rows
    @FindBy(xpath = "//tbody[@formarrayname='rows']/tr")
    private List<WebElement> tableRows;

    // ================== TABLE COLUMN METHODS ==================

	  @FindBy(xpath = "//a[text()=' Grace Charges Set-Up ']")
	    private WebElement userType;
  // ================== METHODS ==================
  public void clickbuttonapproval() {
		waitForClickability(userType).click();
//		waitForClickability(adduserType).click();
	}
    // Navigate to Grace Charges Set-Up
    public void navigateToGraceChargesSetUp() {
        waitForClickability(graceChargesSetUpLink).click();
    }

    // Filter methods
    public void filterByName(String name) {
        waitForVisibility(nameFilterInput).clear();
        nameFilterInput.sendKeys(name);
    }

    public void filterByServiceName(String serviceName) {
        waitForVisibility(serviceNameFilterInput).clear();
        serviceNameFilterInput.sendKeys(serviceName);
    }

    // Select Department
    public void selectDepartment(String departmentName) {
        waitForClickability(departmentDropdown).click();
        WebElement option = driver.findElement(
                By.xpath("//ul[@role='menu']//span[normalize-space()='" + departmentName + "']"));
        waitForClickability(option).click();
    }

    // Select Doctor
    public void selectDoctor(String doctorName) {
        waitForClickability(doctorDropdown).click();
        WebElement option = driver.findElement(
                By.xpath("//ul[@role='menu']//span[normalize-space()='" + doctorName + "']"));
        waitForClickability(option).click();
    }

    // Validity methods
    public void enterSubVisitValidity(String days) {
        waitForVisibility(subVisitValidityInput).clear();
        subVisitValidityInput.sendKeys(days);
    }

    public void enterSecondVisitValidity(String days) {
        waitForVisibility(secondVisitValidityInput).clear();
        secondVisitValidityInput.sendKeys(days);
    }

    public void enterThirdVisitValidity(String days) {
        waitForVisibility(thirdVisitValidityInput).clear();
        thirdVisitValidityInput.sendKeys(days);
    }

    // Timing Info
    public void clickTimingInfo() {
        waitForClickability(timingInfoIcon).click();
    }

    // ================== TABLE ROW OPERATIONS ==================

    // Get row by name
    public WebElement getRowByName(String name) {
        return driver.findElement(By.xpath("//tbody//td[text()='" + name + "']/parent::tr"));
    }

    // Select Service for specific row
    public void selectServiceForRow(String rowName, String serviceName) {
        WebElement row = getRowByName(rowName);
        WebElement serviceDropdown = row.findElement(By.xpath(".//ngx-select"));
        waitForClickability(serviceDropdown).click();
        
        WebElement serviceOption = driver.findElement(
            By.xpath("//ul[@role='menu']//span[normalize-space()='" + serviceName + "']"));
        waitForClickability(serviceOption).click();
    }

    // ================== FEE INPUT METHODS FOR SPECIFIC ROW ==================

    // OP Fee
    public void enterOPFee(String rowName, String fee) {
        WebElement row = getRowByName(rowName);
        WebElement input = row.findElement(By.xpath("./td[3]//input"));
        waitForVisibility(input).clear();
        input.sendKeys(fee);
    }

    // IP Fee
    public void enterIPFee(String rowName, String fee) {
        WebElement row = getRowByName(rowName);
        WebElement input = row.findElement(By.xpath("./td[4]//input"));
        waitForVisibility(input).clear();
        input.sendKeys(fee);
    }

    // Morning First Visit Fee
    public void enterMorningFirstVisitFee(String rowName, String fee) {
        WebElement row = getRowByName(rowName);
        WebElement input = row.findElement(By.xpath("./td[5]//input"));
        waitForVisibility(input).clear();
        input.sendKeys(fee);
    }

    // Morning First Sub Visit Fee
    public void enterMorningFirstSubVisitFee(String rowName, String fee) {
        WebElement row = getRowByName(rowName);
        WebElement input = row.findElement(By.xpath("./td[6]//input"));
        waitForVisibility(input).clear();
        input.sendKeys(fee);
    }

    // Morning First Visit Fee To Physician
    public void enterMorningFirstVisitFeeToPhysician(String rowName, String fee) {
        WebElement row = getRowByName(rowName);
        WebElement input = row.findElement(By.xpath("./td[7]//input"));
        waitForVisibility(input).clear();
        input.sendKeys(fee);
    }

    // Morning First Sub Visit Fee To Physician
    public void enterMorningFirstSubVisitFeeToPhysician(String rowName, String fee) {
        WebElement row = getRowByName(rowName);
        WebElement input = row.findElement(By.xpath("./td[8]//input"));
        waitForVisibility(input).clear();
        input.sendKeys(fee);
    }

    // Morning First Outside Lab Report Fee
    public void enterMorningFirstOutsideLabReportFee(String rowName, String fee) {
        WebElement row = getRowByName(rowName);
        WebElement input = row.findElement(By.xpath("./td[9]//input"));
        waitForVisibility(input).clear();
        input.sendKeys(fee);
    }

    // Continue similar methods for all other fee columns...
    // Morning Second Visit Fee
    public void enterMorningSecondVisitFee(String rowName, String fee) {
        WebElement row = getRowByName(rowName);
        WebElement input = row.findElement(By.xpath("./td[10]//input"));
        waitForVisibility(input).clear();
        input.sendKeys(fee);
    }

    // Morning Second Sub Visit Fee
    public void enterMorningSecondSubVisitFee(String rowName, String fee) {
        WebElement row = getRowByName(rowName);
        WebElement input = row.findElement(By.xpath("./td[11]//input"));
        waitForVisibility(input).clear();
        input.sendKeys(fee);
    }

    // Morning Second Visit Fee To Physician
    public void enterMorningSecondVisitFeeToPhysician(String rowName, String fee) {
        WebElement row = getRowByName(rowName);
        WebElement input = row.findElement(By.xpath("./td[12]//input"));
        waitForVisibility(input).clear();
        input.sendKeys(fee);
    }

    // Morning Second Sub Visit Fee To Physician
    public void enterMorningSecondSubVisitFeeToPhysician(String rowName, String fee) {
        WebElement row = getRowByName(rowName);
        WebElement input = row.findElement(By.xpath("./td[13]//input"));
        waitForVisibility(input).clear();
        input.sendKeys(fee);
    }

    // Morning Second Outside Lab Report Fee
 // ================== COMPLETE FEE ENTRY METHODS ==================

 // Morning Second Outside Lab Report Fee
 public void enterMorningSecondOutsideLabReportFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[14]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Morning Third Visit Fee
 public void enterMorningThirdVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[15]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Morning Third Sub Visit Fee
 public void enterMorningThirdSubVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[16]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Morning Third Visit Fee To Physician
 public void enterMorningThirdVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[17]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Morning Third Sub Visit Fee To Physician
 public void enterMorningThirdSubVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[18]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Morning Third Outside Lab Report Fee
 public void enterMorningThirdOutsideLabReportFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[19]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Morning After Third Visit Fee
 public void enterMorningAfterThirdVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[20]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Morning After Third Visit Fee To Physician
 public void enterMorningAfterThirdVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[21]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Morning After Third Outside Lab Report Fee
 public void enterMorningAfterThirdOutsideLabReportFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[22]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // ================== NOON FEE METHODS ==================

 // Noon First Visit Fee
 public void enterNoonFirstVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[23]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Noon First Sub Visit Fee
 public void enterNoonFirstSubVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[24]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Noon First Visit Fee To Physician
 public void enterNoonFirstVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[25]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Noon First Sub Visit Fee To Physician
 public void enterNoonFirstSubVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[26]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Noon First Outside Lab Report Fee
 public void enterNoonFirstOutsideLabReportFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[27]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Noon Second Visit Fee
 public void enterNoonSecondVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[28]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Noon Second Sub Visit Fee
 public void enterNoonSecondSubVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[29]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Noon Second Visit Fee To Physician
 public void enterNoonSecondVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[30]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Noon Second Sub Visit Fee To Physician
 public void enterNoonSecondSubVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[31]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Noon Second Outside Lab Report Fee
 public void enterNoonSecondOutsideLabReportFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[32]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Noon Third Visit Fee
 public void enterNoonThirdVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[33]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Noon Third Sub Visit Fee
 public void enterNoonThirdSubVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[34]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Noon Third Visit Fee To Physician
 public void enterNoonThirdVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[35]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Noon Third Sub Visit Fee To Physician
 public void enterNoonThirdSubVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[36]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Noon Third Outside Lab Report Fee
 public void enterNoonThirdOutsideLabReportFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[37]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Noon After Third Visit Fee
 public void enterNoonAfterThirdVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[38]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Noon After Third Visit Fee To Physician
 public void enterNoonAfterThirdVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[39]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Noon After Third Outside Lab Report Fee
 public void enterNoonAfterThirdOutsideLabReportFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[40]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // ================== EVENING FEE METHODS ==================

 // Evening First Visit Fee
 public void enterEveningFirstVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[41]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Evening First Sub Visit Fee
 public void enterEveningFirstSubVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[42]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Evening First Visit Fee To Physician
 public void enterEveningFirstVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[43]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Evening First Sub Visit Fee To Physician
 public void enterEveningFirstSubVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[44]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Evening First Outside Lab Report Fee
 public void enterEveningFirstOutsideLabReportFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[45]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Evening Second Visit Fee
 public void enterEveningSecondVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[46]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Evening Second Sub Visit Fee
 public void enterEveningSecondSubVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[47]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Evening Second Visit Fee To Physician
 public void enterEveningSecondVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[48]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Evening Second Sub Visit Fee To Physician
 public void enterEveningSecondSubVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[49]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Evening Second Outside Lab Report Fee
 public void enterEveningSecondOutsideLabReportFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[50]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Evening Third Visit Fee
 public void enterEveningThirdVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[51]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Evening Third Sub Visit Fee
 public void enterEveningThirdSubVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[52]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Evening Third Visit Fee To Physician
 public void enterEveningThirdVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[53]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Evening Third Sub Visit Fee To Physician
 public void enterEveningThirdSubVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[54]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Evening Third Outside Lab Report Fee
 public void enterEveningThirdOutsideLabReportFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[55]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Evening After Third Visit Fee
 public void enterEveningAfterThirdVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[56]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Evening After Third Visit Fee To Physician
 public void enterEveningAfterThirdVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[57]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Evening After Third Outside Lab Report Fee
 public void enterEveningAfterThirdOutsideLabReportFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[58]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // ================== NIGHT FEE METHODS ==================

 // Night First Visit Fee
 public void enterNightFirstVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[59]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Night First Sub Visit Fee
 public void enterNightFirstSubVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[60]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Night First Visit Fee To Physician
 public void enterNightFirstVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[61]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Night First Sub Visit Fee To Physician
 public void enterNightFirstSubVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[62]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Night First Outside Lab Report Fee
 public void enterNightFirstOutsideLabReportFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[63]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Night Second Visit Fee
 public void enterNightSecondVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[64]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Night Second Sub Visit Fee
 public void enterNightSecondSubVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[65]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Night Second Visit Fee To Physician
 public void enterNightSecondVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[66]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Night Second Sub Visit Fee To Physician
 public void enterNightSecondSubVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[67]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Night Second Outside Lab Report Fee
 public void enterNightSecondOutsideLabReportFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[68]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Night Third Visit Fee
 public void enterNightThirdVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[69]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Night Third Sub Visit Fee
 public void enterNightThirdSubVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[70]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Night Third Visit Fee To Physician
 public void enterNightThirdVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[71]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Night Third Sub Visit Fee To Physician
 public void enterNightThirdSubVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[72]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Night Third Outside Lab Report Fee
 public void enterNightThirdOutsideLabReportFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[73]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Night After Third Visit Fee
 public void enterNightAfterThirdVisitFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[74]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Night After Third Visit Fee To Physician
 public void enterNightAfterThirdVisitFeeToPhysician(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[75]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

 // Night After Third Outside Lab Report Fee
 public void enterNightAfterThirdOutsideLabReportFee(String rowName, String fee) {
     WebElement row = getRowByName(rowName);
     WebElement input = row.findElement(By.xpath("./td[76]//input"));
     waitForVisibility(input).clear();
     input.sendKeys(fee);
 }

    // Generic method for any fee column by index
    public void enterFeeByColumnIndex(String rowName, int columnIndex, String fee) {
        WebElement row = getRowByName(rowName);
        WebElement input = row.findElement(By.xpath("./td[" + columnIndex + "]//input"));
        waitForVisibility(input).clear();
        input.sendKeys(fee);
    }

    // ================== BULK OPERATIONS ==================

    // Enter fees for all time slots for a specific row
    public void enterAllFeesForRow(String rowName, String opFee, String ipFee, String morningFee) {
        enterOPFee(rowName, opFee);
        enterIPFee(rowName, ipFee);
        enterMorningFirstVisitFee(rowName, morningFee);
        // Add more fee entries as needed
    }

    // Verify row exists
    public boolean isRowPresent(String rowName) {
        try {
            return getRowByName(rowName).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    // Get current fee value
    public String getFeeValue(String rowName, int columnIndex) {
        WebElement row = getRowByName(rowName);
        WebElement input = row.findElement(By.xpath("./td[" + columnIndex + "]//input"));
        return input.getAttribute("value");
    }
}