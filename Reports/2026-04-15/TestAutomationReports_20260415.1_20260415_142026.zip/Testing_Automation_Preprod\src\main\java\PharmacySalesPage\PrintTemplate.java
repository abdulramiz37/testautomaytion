package PharmacySalesPage;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class PrintTemplate extends Abstraction{

	public PrintTemplate(WebDriver driver) {
		super(driver);
		   PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//div[contains(@class,'ngx-select__toggle')]")
	WebElement dropdownToggle;

	public void openDropdown() {
	    waitForClickability(dropdownToggle).click();
	    System.out.println("✅ Dropdown opened");
	}

	public void selectSalesBillTemplate(String templateName) {
	    // Wait for dropdown options
	    List<WebElement> options = waitForPresenceOfAll(
	        By.cssSelector("ul.ngx-select__choices li a span")
	    );

	    boolean found = false;
	    for (WebElement option : options) {
	        String text = option.getText().trim();
	        System.out.println("🔎 Found option: " + text);

	        switch (templateName.toLowerCase()) {
	            case "sales bill template":
	                if (text.equalsIgnoreCase("Sales bill template")) {
	                    option.click();
	                    found = true;
	                }
	                break;

	            case "sales_thermal_print":
	                if (text.equalsIgnoreCase("Sales_Thermal_Print")) {
	                    option.click();
	                    found = true;
	                }
	                break;

	            case "4inch_sales_thermal_print":
	                if (text.equalsIgnoreCase("4Inch_Sales_Thermal_Print")) {
	                    option.click();
	                    found = true;
	                }
	                break;

	            case "sales bill template 2":
	                if (text.equalsIgnoreCase("Sales Bill Template 2")) {
	                    option.click();
	                    found = true;
	                }
	                break;

	            case "sales bill - 3":
	                if (text.equalsIgnoreCase("Sales Bill - 3")) {
	                    option.click();
	                    found = true;
	                }
	                break;

	            default:
	                throw new IllegalArgumentException("❌ Invalid dropdown option: " + templateName);
	        }

	        if (found) {
	            System.out.println("✅ Selected option: " + text);
	            break;
	        }
	    }

	    if (!found) {
	        System.out.println("⚠️ Option not found in dropdown: " + templateName);
	    }
	}

}
