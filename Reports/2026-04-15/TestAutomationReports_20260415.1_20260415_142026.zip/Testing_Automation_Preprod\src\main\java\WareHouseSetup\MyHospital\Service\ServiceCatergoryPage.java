package WareHouseSetup.MyHospital.Service;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class ServiceCatergoryPage extends Abstraction {

    public ServiceCatergoryPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }
    @FindBy(xpath = "//span[text()='Service Category']")
    private WebElement serviceTab;

    @FindBy(xpath = "//a[contains(@class,'btn-plus') and .//img[@alt='add']]")
    private WebElement addServiceBtn;

    @FindBy(xpath = "(//input[@formcontrolname='name'])[2]")
    private WebElement serviceCategoryNameInput;

    @FindBy(xpath = "//input[@formcontrolname='code']")
    private WebElement codeInput;

    @FindBy(xpath = "//input[@formcontrolname='sortOrderNo']")
    private WebElement sortOrderNoInput;

    @FindBy(xpath = "//input[@formcontrolname='newIsActive']")
    private WebElement isActiveCheckbox;

    @FindBy(xpath = "//input[@type='button' and @value='Save' and contains(@class,'btn-primary')]")
    private WebElement saveButton;

    @FindBy(xpath = "//input[@type='button' and @value='Cancel' and contains(@class,'btn-clear')]")
    private WebElement cancelButton;

    public void openServiceForm() {
    	clickWithJavaScript(serviceTab);
    	clickWithJavaScript(addServiceBtn);
    }
    public void fillServiceCategoryForm(String name, String code, String sortOrder, boolean isActive) {
        waitForVisibility(serviceCategoryNameInput).sendKeys(name);
        waitForVisibility(codeInput).sendKeys(code);
        waitForVisibility(sortOrderNoInput).sendKeys(sortOrder);

        if (isActiveCheckbox.isSelected() != isActive) {
            isActiveCheckbox.click();
        }
    }

    public void clickSaveButton() {
        waitForClickability(saveButton).click();
    }

    public void clickCancelButton() {
        waitForClickability(cancelButton).click();
    }

}
