package WareHouseSetup.IPpharmacy;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class DischargeReasonPage extends Abstraction {

    WebDriver driver;

    public DischargeReasonPage(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // 🔹 Locators (XPath only)

    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement nameInput;

    @FindBy(xpath = "//span[@class='checkmark']")
    private WebElement isActiveCheckbox;

    @FindBy(xpath = "//input[@type='button' and @value='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
    private WebElement cancelButton;

    @FindBy(xpath = "//a[text()=' Discharge Type ']")
    private WebElement userType;

    @FindBy(xpath = "//a[text()=' Add Discharge Reason ']")
    private WebElement adduserType;
    // 🔹 Methods
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}
    // Enter Name
    public void enterName(String name) {
        nameInput.clear();
        nameInput.sendKeys(name);
    }

    // Set IsActive checkbox
    public void setIsActive(boolean value) {
        if (isActiveCheckbox.isSelected() != value) {
            isActiveCheckbox.click();
        }
    }

    // Click Save
    public void clickSave() {
        saveButton.click();
    }

    // Click Cancel
    public void clickCancel() {
        cancelButton.click();
    }
}

