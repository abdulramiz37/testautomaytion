package PrakashSirAppointmentBooking.CaseSheet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import EzionAbstractionComponents.Abstraction;

import java.util.List;

public class NurseNotesPage extends Abstraction {

    WebDriver driver;

    public NurseNotesPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // --- Section Toggle ---
    @FindBy(xpath = "//h4[normalize-space(text())='Nurse Notes']/following::img[contains(@class,'openclose')][1]")
    private WebElement nurseNotesToggleIcon;

    // --- Dropdowns ---
    @FindBy(xpath = "//ngx-select[@formcontrolname='nurseId']")
    private WebElement nurseNameDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='shiftId']")
    private WebElement shiftDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='painLevel']")
    private WebElement painLevelDropdown;

    // --- Input Fields ---
    @FindBy(xpath = "//input[@formcontrolname='dateTime']")
    private WebElement dateInput;

    @FindBy(xpath = "//textarea[@formcontrolname='notes']")
    private WebElement notesTextarea;

    // --- Buttons ---
    @FindBy(xpath = "//input[@value='Add Nurse Notes']")
    private WebElement addNurseNotesBtn;

    @FindBy(xpath = "//input[@value='Reset']")
    private WebElement resetBtn;

    // --- Table Actions ---
    @FindBy(xpath = "//table[contains(@class,'table-style')]//tr[1]//a[@title='Edit']")
    private WebElement firstRowEditBtn;

    @FindBy(xpath = "//table[contains(@class,'table-style')]//tr[1]//a[@title='Delete']")
    private WebElement firstRowDeleteBtn;

    // --- Success Messages ---
    @FindBy(xpath = "//div[contains(text(),'Nurse Notes Saved Successfully')]")
    private WebElement savedSuccessMsg;

    @FindBy(xpath = "//div[contains(text(),'Nurse Notes Updated Successfully')]")
    private WebElement updatedSuccessMsg;

    @FindBy(xpath = "//div[contains(text(),'Nurse Notes Deleted Successfully')]")
    private WebElement deletedSuccessMsg;

    // --- Actions ---

    public void toggleNurseNotesSection() {
        clickWithJavaScript(nurseNotesToggleIcon);
    }

    public void selectNurse(String nurseName) {
        nurseNameDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + nurseName + "']"));
        option.click();
    }

    public void selectShift(String shift) {
        shiftDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + shift + "']"));
        option.click();
    }

    public void selectPainLevel(String painLevel) {
        painLevelDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + painLevel + "']"));
        option.click();
    }

    public void setDate(String dateTime) {
        dateInput.clear();
        dateInput.sendKeys(dateTime);
    }

    public void enterNotes(String notes) {
        notesTextarea.clear();
        notesTextarea.sendKeys(notes);
    }

    public void clickAddNurseNotes() {
        addNurseNotesBtn.click();
    }

    public void clickReset() {
        resetBtn.click();
    }

    public void editFirstNurseNote() {
       firstRowEditBtn.click();
    }

    public void deleteFirstNurseNote() {
      firstRowDeleteBtn.click();
    }

    public String getSavedSuccessMessage() {
        return savedSuccessMsg.getText();
    }

    public String getUpdatedSuccessMessage() {
        return updatedSuccessMsg.getText();
    }

    public String getDeletedSuccessMessage() {
        return deletedSuccessMsg.getText();
    }

}
