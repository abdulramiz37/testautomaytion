package WareHouseSetup.MyHospital;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class ShiftPage extends Abstraction{

    WebDriver driver;

    public ShiftPage(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // 🔹 Shift Name input
    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement shiftNameInput;

    // 🔹 Start Time input
    @FindBy(xpath = "//input[@formcontrolname='shiftStartTime']")
    private WebElement startTimeInput;

    // 🔹 End Time input
    @FindBy(xpath = "//input[@formcontrolname='shiftEndTime']")
    private WebElement endTimeInput;

    // 🔹 Shift Display Time (read-only)
    @FindBy(xpath = "//input[@formcontrolname='shiftDisplayTime']")
    private WebElement shiftDisplayTimeInput;

    // 🔹 Save button
    @FindBy(xpath = "//input[@type='button' and @value='Save']")
    private WebElement saveButton;

    // 🔹 Cancel button
    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
    private WebElement cancelButton;

    @FindBy(xpath = "//a[text()='Shift Times ']")
    private WebElement userType;

    @FindBy(xpath = "//a[text()=' Add Shift Name ']")
    private WebElement adduserType;
     
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}
    // 🔸 Method to enter shift name
    public void enterShiftName(String shiftName) {
        shiftNameInput.clear();
        shiftNameInput.sendKeys(shiftName);
    }

    // 🔸 Method to enter shift start time (format: HH:MM)
    public void enterStartTime(String startTime) {
        startTimeInput.clear();
        startTimeInput.sendKeys(startTime);
        startTimeInput.sendKeys(Keys.TAB);
    }

    // 🔸 Method to enter shift end time (format: HH:MM)
    public void enterEndTime(String endTime) {
        endTimeInput.clear();
        endTimeInput.sendKeys(endTime);
        endTimeInput.sendKeys(Keys.TAB);
    }

    // 🔸 Method to fetch shift display time (read-only)
    public String getShiftDisplayTime() {
        return shiftDisplayTimeInput.getAttribute("value");
    }

    // 🔸 Click Save
    public void clickSave() {
        saveButton.click();
    }

    // 🔸 Click Cancel
    public void clickCancel() {
        cancelButton.click();
    }

    // 🔸 Fill the complete shift form
    public void fillShiftForm(String shiftName, String startTime, String endTime) {
    	clickbuttonapproval();
        enterShiftName(shiftName);
        enterStartTime(startTime);
        enterEndTime(endTime);
        clickSave();
    }
}

