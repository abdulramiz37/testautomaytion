package WareHouseSetup.MyHospital.Service;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.By;

import EzionAbstractionComponents.Abstraction;

public class AddServiceSubCategoryPage extends Abstraction {

    WebDriver driver;

    public AddServiceSubCategoryPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // ========== Locators ==========
    @FindBy(xpath = "//label[contains(text(),'Service Category')]/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement serviceCategoryDropdown;

    @FindBy(xpath = "(//input[@formcontrolname='name'])[3]")
    private WebElement subCategoryNameInput;

    @FindBy(xpath = "//label[contains(text(),'Account Group')]/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement accountGroupDropdown;

    @FindBy(xpath = "(//input[@formcontrolname='sortOrderNo'])[2]")
    private WebElement sortOrderInput;

    @FindBy(xpath = "//label[contains(text(),'Billing Head')]/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement billingHeadDropdown;

    @FindBy(xpath = "//input[@formcontrolname='IsActive' and @type='checkbox']")
    private WebElement isActiveCheckbox;

    @FindBy(xpath = "//input[@formcontrolname='seperatequeue' and @type='checkbox']")
    private WebElement separateQueueCheckbox;

    @FindBy(xpath = "//input[@formcontrolname='costcentreflag' and @type='checkbox']")
    private WebElement costCentreCheckbox;

    @FindBy(xpath = "(//input[@type='button' and @value='Save'])[3]")
    private WebElement saveButton;

    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
    private WebElement cancelButton;


    @FindBy(xpath = "//span[text()='Service Sub Category']")
    private WebElement serviceTab;

    @FindBy(xpath = "//a[contains(@class,'btn-plus') and .//img[@alt='add']]")
    private WebElement addServiceBtn;
    // ========== Form Fill Method ==========

    public void openServiceForm() {
    	clickWithJavaScript(serviceTab);
    	clickWithJavaScript(addServiceBtn);
    }
    public void setCheckbox(WebElement checkbox, boolean shouldBeChecked) {
        boolean isSelected = checkbox.isSelected();
        if (isSelected != shouldBeChecked) {
            clickWithJavaScript(checkbox);
        }
    }

    public void fillAddServiceSubCategoryForm(
            String serviceCategory,
            String subCategoryName,
            String accountGroup,
            String sortOrder,
            String billingHead,
            boolean isActive,
            boolean separateQueue,
            boolean costCentre
    ) {
    	openServiceForm();
        waitForClickability(serviceCategoryDropdown).click();
        WebElement categoryOption = driver.findElement(By.xpath("//span[contains(text(),'" + serviceCategory + "')]"));
        waitForClickability(categoryOption).click();

        waitForVisibility(subCategoryNameInput).click();
        subCategoryNameInput.sendKeys(subCategoryName);

        waitForClickability(accountGroupDropdown).click();
        WebElement accountOption = driver.findElement(By.xpath("//span[contains(text(),'" + accountGroup + "')]"));
        waitForClickability(accountOption).click();

        waitForVisibility(sortOrderInput).clear();
        sortOrderInput.sendKeys(sortOrder);
//
//        waitForClickability(billingHeadDropdown).click();
//        WebElement billingOption = driver.findElement(By.xpath("//span[contains(text(),'" + billingHead + "')]"));
//        waitForClickability(billingOption).click();

        setCheckbox(isActiveCheckbox, isActive);
        setCheckbox(separateQueueCheckbox, separateQueue);
        setCheckbox(costCentreCheckbox, costCentre);
    }

    // ========== Save Method ==========

    public void clickSave() {
        waitForClickability(saveButton).click();
    }
}
