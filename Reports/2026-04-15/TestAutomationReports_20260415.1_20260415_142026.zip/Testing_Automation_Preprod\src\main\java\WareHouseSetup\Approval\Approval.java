package WareHouseSetup.Approval;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class Approval extends Abstraction{

	public Approval(WebDriver driver) {
		super(driver);
	    this.driver = driver;
	    PageFactory.initElements(driver, this);
	}
	// User Name dropdown
	@FindBy(xpath = "//label[contains(text(), 'User Name')]/following-sibling::ngx-select//div[contains(@class, 'ngx-select__toggle')]")
	private WebElement userNameDropdown;

	// Account Type dropdown
	@FindBy(xpath = "//label[contains(text(), 'Account Type')]/following-sibling::ngx-select//div[contains(@class, 'ngx-select__toggle')]")
	private WebElement accountTypeDropdown;

	// Account Sub Type dropdown
	@FindBy(xpath = "//label[contains(text(), 'Account Sub Type')]/following-sibling::ngx-select//div[contains(@class, 'ngx-select__toggle')]")
	private WebElement accountSubTypeDropdown;

    @FindBy(xpath = "//a[text()=' Add User Role Settings ']")
    private WebElement addapprovalButton;
    
    @FindBy(xpath = "//a[text()='Approval Manager']")
    private WebElement approval;
 
	// Save button
	@FindBy(xpath = "//input[@type='button' and @value='Save']")
	private WebElement saveButton;

	// Reset button
	@FindBy(xpath = "//input[@type='button' and @value='Reset']")
	private WebElement resetButton;

	// Cancel button
	@FindBy(xpath = "//input[@type='button' and @value='Cancel']")
	private WebElement cancelButton;
	
	
	public void clickbuttonapproval() {
		waitForClickability(approval).click();
		waitForClickability(addapprovalButton).click();
	}
	public void selectUserName(String userNameOption) {
	    userNameDropdown.click();
	    WebElement option = driver.findElement(By.xpath("//span[contains(text(), '" + userNameOption + "')]"));
	    option.click();
	}

	public void selectAccountType(String accountTypeOption) {
	    accountTypeDropdown.click();
	    WebElement option = driver.findElement(By.xpath("(//span[contains(text(), '" + accountTypeOption + "')])[2]"));
	    option.click();
	}

	public void selectAccountSubType(String subTypeOption) {
	    accountSubTypeDropdown.click();
	    WebElement option = driver.findElement(By.xpath("//span[contains(text(), '" + subTypeOption + "')]"));
	    option.click();
	}

	public void clickSave() {
	    saveButton.click();
	}

	public void clickReset() {
	    resetButton.click();
	}

	public void clickCancel() {
	    cancelButton.click();
	}

}
