package PrakashSirAppointmentBooking.IpOnboarding;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import EzionAbstractionComponents.Abstraction;

public class Serviceip extends Abstraction{

	public Serviceip(WebDriver driver) {
		super(driver);
		   PageFactory.initElements(driver, this);
	}
	
    @FindBy(xpath = "//span[text()='IP']")
    private WebElement frontendDesk;
    
    @FindBy(xpath = "//span[text()='Admission List']")
    private WebElement appointment;
    
    public void frontdesk() {
        
    	waitForClickability(frontendDesk).click();
//    	waitForClickability(appointment).click();
   
    	
    }
    public void opentheappointmentpage() {
        
//    	waitForClickability(frontendDesk).click();
    	waitForClickability(appointment).click();
   
    	
    }
    @FindBy(xpath = "//input[@type='button' and @value='Enable to Edit']")
    WebElement enableToEditBtn;
    public void clickEnableToEdit() {
        enableToEditBtn.click();
    }
    @FindBy(xpath = "(//div[contains(@class,'mat-select-trigger')])[2]")
    WebElement dropdownTrigger;

    public void selectDropdownValue(String value) {
        // Open dropdown
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", dropdownTrigger);

        // Find option dynamically
        WebElement option = driver.findElement(
            By.xpath(String.format("//mat-option//span[contains(text(),'%s')]", value))
        );

        // Click option using JavaScript
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", option);
    }

    public void findPatientByMobileAndName(String targetMobileNumber, String targetPatientName, String actionName) {
        boolean isPatientFound = false;
        int clickCount = 0; // Stop after 14 page clicks

        while (!isPatientFound) {
            List<WebElement> rows = driver.findElements(By.xpath("//tr[contains(@class,'mat-row')]"));

            for (int i = 0; i < rows.size(); i++) {
                try {
                    WebElement row = rows.get(i);

                    // Extract mobile number
                    WebElement phoneContainer = row.findElement(By.xpath(".//p[span[contains(text(),'phone')]]"));
                    String mobileNumber = phoneContainer.getText().replaceAll("[^0-9]", "").trim();

                    // Extract patient name
                    WebElement patientNameElement = row.findElement(By.xpath(".//td[contains(@class,'mat-column-firstname')]//h4"));
                    String patientName = patientNameElement.getText().trim();

                    System.out.println("🔎 Found Row → Patient: " + patientName + " | Mobile: " + mobileNumber);

                    if (mobileNumber.equals(targetMobileNumber) && patientName.equalsIgnoreCase(targetPatientName)) {
                        // Scroll row into view (centered)
                        ((JavascriptExecutor) driver).executeScript(
                            "arguments[0].scrollIntoView({block: 'center', inline: 'nearest'});", row
                        );

                        // Open actions menu
                        WebElement actionsMenu = row.findElement(By.xpath(".//div[contains(@class,'three-dots')]"));
                        clickWithJavaScript(actionsMenu);

                        WebElement serialNumber = row.findElement(By.xpath(".//td[1]"));
                        String serialText = serialNumber.getText().trim();
                        int num = Integer.parseInt(serialText.replaceAll("[^0-9]", ""));

                        int serviceIndex;
                        if (num <= 10) {
                            serviceIndex = num;
                        } else if (num % 10 == 0) {
                            serviceIndex = 10;
                        } else {
                            serviceIndex = num % 10;
                        }

                        // Select desired action dynamically
                        String dynamicXpath = "(//div[@class='pls-cont' and normalize-space(text())='" + actionName + "']/ancestor::a)[" + serviceIndex + "]";
                        WebElement selectedAction = driver.findElement(By.xpath(dynamicXpath));
                        selectedAction.click();

                        System.out.println("✅ Matched Patient: " + patientName + " (Mobile: " + mobileNumber + ") → Opening: " + actionName);
                        isPatientFound = true;
                        break;
                    }

                } catch (NoSuchElementException e) {
                    System.out.println("⚠️ Skipping missing row at index " + i);
                }
            }

            // If patient not found, go to next page
            if (!isPatientFound) {
                try {
                    if (clickCount >= 14) {
                        System.out.println("⛔ Stopped after 14 clicks. Patient not found.");
                        break;
                    }

                    WebElement nextButton = driver.findElement(By.xpath("//button[@aria-label='Next page']"));
                    String classAttr = nextButton.getAttribute("class");
                    if (classAttr != null && classAttr.contains("disabled")) {
                        System.out.println("❌ Reached last page. Patient not found.");
                        break;
                    }

                    ((JavascriptExecutor) driver).executeScript(
                        "arguments[0].scrollIntoView({block: 'center', inline: 'nearest'});", nextButton
                    );
                    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextButton);

                    clickCount++;
                    System.out.println("➡️ Moving to next page... (Click " + clickCount + ")");
                    // Optional: wait for page to load
                } catch (NoSuchElementException e  ) {
                    System.out.println("❌ Next page button not found or interrupted. Ending search.");
                    break;
                }
            }
        }
    }

    @FindBy(xpath = "//input[@type='button' and @value='Add']")
    WebElement addButton;

    public void selectRandomOptionsFromDropdown() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        Random rand = new Random();

        int randomCount = 10000; // you want 1000 iterations
        System.out.println("🚀 Starting " + randomCount + " random selections...");

        for (int i = 1; i <= randomCount; i++) {
            try {
                // Open dropdown
                WebElement dropdownToggle = driver.findElement(
                    By.xpath("(//div[contains(@class,'ngx-select__toggle')])[17]")
                );
                js.executeScript("arguments[0].click();", dropdownToggle);

                // Small wait for options to appear
                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3));
                List<WebElement> options = wait.until(ExpectedConditions
                    .presenceOfAllElementsLocatedBy(
                        By.xpath("//a[contains(@class,'ngx-select__item dropdown-item')]")
                    )
                );

                if (options.isEmpty()) {
                    System.out.println("⚠️ No options found at iteration " + i);
                    continue;
                }

                // Pick a random option
                WebElement option = options.get(rand.nextInt(options.size()));
                String text = option.getText().trim();

                // Click option + Add
                option.click();
                addButton.click();

                System.out.println("✅ Iteration " + i + ": Selected → " + text);

            } catch (Exception e) {
                System.out.println("❌ Error at iteration " + i + " → " + e.getMessage());
                // continue loop even if one iteration fails
            }
        }

        System.out.println("🎯 Completed " + randomCount + " selections!");
    }

    
    public void clickMoreDropdownItem( String itemName) throws InterruptedException {
        // Open "More"
        driver.findElement(By.xpath("//a[@role='button' and @title='More']")).click();

        // Click the specific item using title
        WebElement element = driver.findElement(
            By.xpath("//a[@role='button' and @title='More']//ul//a[@title='" + itemName + "']")
        );
        element.click();
    }

}
