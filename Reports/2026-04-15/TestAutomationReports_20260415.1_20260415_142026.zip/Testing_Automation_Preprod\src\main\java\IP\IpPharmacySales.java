package IP;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class IpPharmacySales extends Abstraction{

	public IpPharmacySales(WebDriver driver) {
		super(driver);
		 PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "//ul[contains(@class,'tabset')]//li[contains(@class,'tab')]")
	List<WebElement> allTabs;

	public void clickTabByName(String tabName) {
	    for (WebElement tab : allTabs) {
	        if (tab.getText().trim().equalsIgnoreCase(tabName)) {
	            tab.click();
	            break;
	        }
	    }
	}
	public By headerTileByName(String tileName) {
	    return By.xpath(
	        "//div[contains(@class,'pls-img-conte')]//p[normalize-space()='" + tileName + "']/parent::div"
	    );
	}
	public void clickHeaderTile(String tileName) {
	    driver.findElement(headerTileByName(tileName)).click();
	}
//MEDICINE
	
	public By medicineRowByName(String medicineName) {
	    return By.xpath(
	        "//tr[contains(@class,'inner-td')]//h4[normalize-space()='" + medicineName + "']/ancestor::tr"
	    );
	}
	public By medicineCheckboxByName(String medicineName) {
	    return By.xpath(
	        "//tr[contains(@class,'inner-td')]//h4[normalize-space()='" + medicineName + "']/ancestor::tr//input[@type='checkbox']"
	    );
	}
	public By returnQtyInputByName(String medicineName) {
	    return By.xpath(
	        "//tr[contains(@class,'inner-td')]//h4[normalize-space()='" + medicineName + "']/ancestor::tr//input[@type='number']"
	    );
	}
	public void setMedicineCheckbox(String medicineName, boolean shouldSelect) {
	    WebElement checkbox = driver.findElement(medicineCheckboxByName(medicineName));

	    if (checkbox.isSelected() != shouldSelect) {
	        checkbox.click();
	    }
	}

	public void enterReturnQuantity(String medicineName, String quantity) {
	    WebElement qtyInput = driver.findElement(returnQtyInputByName(medicineName));
	    qtyInput.clear();
	    qtyInput.sendKeys(quantity);
	}

	public void selectMedicineAndEnterQty(String medicineName, boolean select, String quantity) {
	    setMedicineCheckbox(medicineName, select);

	    if (select) {
	        enterReturnQuantity(medicineName, quantity);
	    }
	}
	@FindBy(xpath = "//table[.//th[normalize-space()='Bill No.']]//tbody//tr[1]//td[1]//h4")
	private WebElement billNoText;
	
	public String getBillNo() {
	    return billNoText.getText().trim();
	}
	public By emptyCellBeforeBillNo(String billNo) {
	    return By.xpath(
	        "//tr[contains(@class,'expand-row')]//td[normalize-space()='" + billNo + "']/preceding-sibling::td[@colspan='2']"
	    );
	}
	public void clickEmptyCellBeforeBillNo(String billNo) {
	    WebElement emptyCell = driver.findElement(emptyCellBeforeBillNo(billNo));
	    emptyCell.click();
	}
	
	
	@FindBy(xpath = "//input[@type='button' and @value='Create Return Indent']")
	private WebElement createReturnIndentBtn;

	public void savethe() {
		createReturnIndentBtn.click();
	}
	
	public By emptyCellBeforeBillNo() {
	    return By.xpath(
	        "//tr[contains(@class,'expand-row')]//td[normalize-space()='']/preceding-sibling::td[@colspan='2']"
	    );
	}
	public void clickEmptyCellBeforeBillNo() {
	    WebElement emptyCell = driver.findElement(emptyCellBeforeBillNo());
	    emptyCell.click();
	}
	public By actionButton(String buttonText) {
	    return By.xpath("//input[@type='button' and @value='" + buttonText + "']");
	}
	public By enabledActionButton(String buttonText) {
	    return By.xpath("//input[@value='" + buttonText + "' and not(@disabled)]");
	}
	
	public void aooroved(String btn) {
	    WebElement emptyCell = driver.findElement(enabledActionButton(btn));
	    emptyCell.click();
	}
	
	public By actionButtonByStatus(String status) {
	    return By.xpath(
	        "//tr[contains(@class,'expand-row')]//td[normalize-space()='" + status + "']" +
	        "/following-sibling::td[contains(@class,'action-table')]//a[@title='Go to Sales Return']"
	    );
	}

	public void clickActionButtonByStatus(String status) {
	    driver.findElement(actionButtonByStatus(status)).click();
	}

}
