package PharmacyFlowObjects.PharmacyStore;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import EzionAbstractionComponents.Abstraction;

public class StorageShelfPageUpdate extends Abstraction {

    public StorageShelfPageUpdate(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    // --- Locators ---

    @FindBy(xpath = "//a[text()=' Storage Shelf']")
    private WebElement storageShelfTab;

    @FindBy(xpath = "//a[text()=' Add Storage Shelf ']")
    private WebElement addStorageShelfButton;

    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement storageShelfNameInput;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;

    // --- Actions ---

    public void openStorageShelfSection() {
        waitForClickability(storageShelfTab).click();
    }

    public void clickAddStorageShelf() {
        waitForClickability(addStorageShelfButton).click();
    }

    public void enterStorageShelfName(String name) {
        waitForClickability(storageShelfNameInput).click();
//        waitForVisibility(storageShelfNameInput).sendKeys(name);
        int counter = 1;
        String uniqueName = name + counter;

       while (true) {
           waitForVisibility(storageShelfNameInput).clear();
           storageShelfNameInput.sendKeys(uniqueName);

           try {
               new WebDriverWait(driver, Duration.ofSeconds(0))
                   .until(ExpectedConditions.invisibilityOfElementLocated(
                       By.xpath("//span[contains(text(),'Name Already Exists..')]")));
               break;
           } catch (TimeoutException e) {
               counter++;
               uniqueName = name  + "-" + +counter;
           }
       }
    }

    public void clickSaveButton() {
        waitForClickability(saveButton).click();
    }

    public void createStorageShelf(String name) {
        openStorageShelfSection();
        clickAddStorageShelf();
        enterStorageShelfName(name);
       
    }
    public MedicinePageUpdate save() {
    	 clickSaveButton();
    	 waitForPharmacyPageWithBackClick();
    	 MedicinePageUpdate medicine = new MedicinePageUpdate(driver);
    	 return medicine;
    }
}

