package WareHouseSetup.MyHospital;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import EzionAbstractionComponents.Abstraction;



public class VisitModePage extends Abstraction {

    WebDriver driver;

    public VisitModePage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // ================= LOCATORS ================= //

    // Visit Mode Input Field
    @FindBy(css = "input[formcontrolname='name']")
    private WebElement visitModeInput;

    // Validation message span (Name Already Exists..)
    @FindBy(xpath = "//span[contains(text(),'Name Already Exists')]")
    private WebElement nameAlreadyExistsMessage;

    // Is Active Checkbox
    @FindBy(xpath = "//span[@class='checkmark']")
    private WebElement isActiveCheckbox;

    // Save Button
    @FindBy(css = "input[type='button'][value='Save']")
    private WebElement saveButton;

    // Cancel Button
    @FindBy(css = "input[type='button'][value='Cancel']")
    private WebElement cancelButton;

    // ================= METHODS ================= //
    @FindBy(xpath = "//a[text()=' Visit Mode ']")
    private WebElement userType;

    @FindBy(xpath = "//a[text()=' Add Visit Mode ']")
    private WebElement adduserType;
     
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}
    // Enter Visit Mode Name
    public void enterVisitMode(String visitModeName) {
        waitForVisibility(visitModeInput);
        visitModeInput.clear();
        visitModeInput.sendKeys(visitModeName);
    }

    // Check if 'Name Already Exists' is visible
    public boolean isNameAlreadyExistsDisplayed() {
        try {
            waitForVisibility(nameAlreadyExistsMessage);
            return nameAlreadyExistsMessage.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    // Click Is Active checkbox (only if not already selected)
    public void enableIsActive(boolean isActive) {
        if (!isActiveCheckbox.isSelected() != isActive) {
            isActiveCheckbox.click();
        }
    }

    // Click Save Button
    public void clickSave() {
        waitForClickability(saveButton);
        saveButton.click();
    }

    // Click Cancel Button
    public void clickCancel() {
        waitForClickability(cancelButton);
        cancelButton.click();
    }

    // Combined method to fill and submit the form
    public void fillVisitModeForm(String visitModeName, boolean isActive) {
    	clickbuttonapproval();
        enterVisitMode(visitModeName);
        enableIsActive(isActive);
    

        clickSave();
    }
}
