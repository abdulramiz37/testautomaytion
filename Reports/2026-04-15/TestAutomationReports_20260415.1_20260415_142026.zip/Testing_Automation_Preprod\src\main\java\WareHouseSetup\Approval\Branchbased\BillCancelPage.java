package WareHouseSetup.Approval.Branchbased;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class BillCancelPage extends Abstraction{
	public BillCancelPage(WebDriver driver) {
		super(driver);
	    this.driver = driver;
	    PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "(//input[@formcontrolname='reasonName'])[3]")
	private WebElement billCancelNameInput;

	@FindBy(xpath = "(//input[@formcontrolname='reasonCode'])[3]")
	private WebElement billCancelCodeInput;

	@FindBy(xpath = "(//textarea[@formcontrolname='reasonDescription'])[3]")
	private WebElement billCancelDescriptionTextarea;

	@FindBy(xpath = "(//input[@formcontrolname='isActive']/following-sibling::span[@class='checkmark'])[3]")
	private WebElement isActiveCheckbox;

	@FindBy(xpath = "(//input[@type='button' and @value='Save'])[3]")
	private WebElement saveButton;

	@FindBy(xpath = "//input[@type='button' and @value='Cancel']")
	private WebElement cancelButton;

    @FindBy(xpath = "(//a[text()=' Add Bill Cancel '])[3]")
    private WebElement addbillcancel;
    
    @FindBy(xpath = "(//span[text()='Bill Cancel'])[1]")
    private WebElement billCancel;
    
    
    public void clickbuttonapproval() {
		waitForClickability(billCancel).click();
		waitForClickability(addbillcancel).click();
	}
	public void enterBillCancelName(String name) {
	    billCancelNameInput.clear();
	    billCancelNameInput.sendKeys(name);
	}

	public void enterBillCancelCode(String code) {
	    billCancelCodeInput.clear();
	    billCancelCodeInput.sendKeys(code);
	}

	public void enterBillCancelDescription(String description) {
	    billCancelDescriptionTextarea.clear();
	    billCancelDescriptionTextarea.sendKeys(description);
	}

	public void setIsActive(boolean value) {
	    if (value != isActiveCheckbox.isSelected()) {
	        isActiveCheckbox.click();
	    }
	}

	public void clickSave() {
	    saveButton.click();
	}

	public void clickCancel() {
	    cancelButton.click();
	}
	public void fillBalanceForm(String name, String code, String description, boolean isActive) {
	    enterBillCancelName(name);
	    enterBillCancelCode(code);
	    enterBillCancelDescription(description);
	    setIsActive(isActive);
	    clickSave();
	}

}
