package StandAloneTest;

import java.time.Duration;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class TenantBasedMasterPage {
   

    
    public static void main (String [] args) throws InterruptedException {
    	 WebDriver driver;
        driver = new ChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize();
        driver.get("https://apps.ezovion.com/auth/login");

        driver.findElement(By.xpath("//div[@class=\"form-control-group\"]//input")).sendKeys("50107299");
        driver.findElement(By.xpath("//button[@size=\"large\"]")).click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
        driver.findElement(By.xpath("//input[@placeholder=\"Mobile No\"]")).sendKeys("7766554433");
        driver.findElement(By.xpath("//input[@placeholder=\"Password\"]")).sendKeys("12345");

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@status=\"primary\"]"))).click();

        for (int i = 0; i < 5; i++) {
            try {
                WebElement adminTab = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Admin']")));
                adminTab.click();
                wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Roles Management']"))).click();
                break;
            } catch (Exception e) {
                System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
                if (i == 4) throw e;
            }
        }

        // Navigate to Masters > Master Set-up
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Masters']"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Master Set-up']"))).click();

        // Sample test input map
        HashMap<String, String> input = new HashMap<>();
        input.put("CallCategoryName", "Test Category");
        input.put("CallCategoryCode", "CAT001");
        input.put("CallCategoryDescription", "Test Description");

        // Click Approval tab (if any)
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()='Tenant Based Master']"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Add Call Category ']"))).click();
        // Fill Call Category Form
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='reasonName']")))
                .sendKeys(input.get("CallCategoryName"));
        driver.findElement(By.xpath("//input[@formcontrolname='reasonCode']"))
                .sendKeys(input.get("CallCategoryCode"));
        driver.findElement(By.xpath("//textarea[@formcontrolname='reasonDescription']"))
                .sendKeys(input.get("CallCategoryDescription"));
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@formcontrolname='isActive']/following-sibling::span[@class='checkmark']"))).click();
        // Click Save button (assuming it's a button with text 'Save')
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='button' and @value='Save']"))).click();

        // Optional: Validate success toast or message
        WebElement successToast = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//nb-toast//div[contains(text(),'Saved Successfully')]")));
        assert successToast.isDisplayed();

      
    }
}
