package WareHouseSetup.MyHospital;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import EzionAbstractionComponents.Abstraction;

public class PackageTypePage extends Abstraction {

    WebDriver driver;

    public PackageTypePage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Locator for Package Type Name input field
    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement packageTypeNameInput;

    // Locator for 'Active' checkbox
    @FindBy(xpath = "//span[@class='checkmark']")
    private WebElement activeCheckbox;

    // Locator for Save button
    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//a[text()=' Package Type ']")
    private WebElement userType;

    @FindBy(xpath = "//a[text()=' Add Package Type ']")
    private WebElement adduserType;
     
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}
    // Locator for Cancel button
    @FindBy(xpath = "//input[@value='Cancel']")
    private WebElement cancelButton;
    public void clearAndType(WebElement element, String value) {
        element.clear();
        element.sendKeys(value);
    }

    // Method to enter Package Type Name
    public void enterPackageTypeName(String name) {
    	clearAndType(packageTypeNameInput, name);
    }

    // Method to toggle the Active checkbox
    public void setActiveCheckbox(boolean isChecked) {
        if (activeCheckbox.isSelected() != isChecked) {
            activeCheckbox.click();
        }
    }

    // Method to click Save button
    public void clickSave() {
        saveButton.click();
    }

    // Method to click Cancel button
    public void clickCancel() {
        cancelButton.click();
    }

    // Method to fill Package Type form and save
    public void fillAndSubmitPackageTypeForm(String packageTypeName, boolean isActive) {
    	clickbuttonapproval();
        enterPackageTypeName(packageTypeName);
        setActiveCheckbox(isActive);
        clickSave();
    }
}
