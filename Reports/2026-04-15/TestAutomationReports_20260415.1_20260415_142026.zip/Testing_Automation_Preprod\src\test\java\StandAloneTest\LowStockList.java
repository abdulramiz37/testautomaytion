


	package StandAloneTest;

	import java.time.Duration;
	import java.util.List;

	import org.openqa.selenium.By;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.edge.EdgeDriver;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.WebDriverWait;
	import org.testng.annotations.Test;
	@Test
	public class LowStockList {
		public void PPLE() throws InterruptedException {

		WebDriver driver = new EdgeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://apps.ezovion.com/auth/login");
		//driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		

		driver.findElement(By.xpath("//div[@class=\"form-control-group\"]//input")).sendKeys("50107299");
		driver.findElement(By.xpath("//button[@size=\"large\"]")).click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
	        // Wait until the button with text "CONTINUE" is clickable
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
		
	     driver.findElement(By.xpath("//input[@placeholder=\"Mobile No\"]")).sendKeys("7766554433");
		driver.findElement(By.xpath("//input[@placeholder=\"Password\"]")).sendKeys("12345");
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@status=\"primary\"]")));
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//button[@status=\"primary\"]")).click();
		 for (int i = 0; i < 5; i++) { // Try up to 5 times
			    try {
			        
			        Thread.sleep(3000); // wait for any transition

			        WebElement adminTab = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Admin']")));
			        adminTab.click();
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Roles Management']"))).click();
			        break; // Exit loop if successful
			    } catch (Exception e) {
			        System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
			        if (i == 4) {
			            throw e; // Re-throw if max attempts reached
			        }
			    }
			}
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Masters']"))).click();

			// 2. Master Set-up
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Master Set-up']"))).click();

			// 3. Warehouse
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Medicine']"))).click();

			// 2. Click on "Add Medicine"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Add Medicine ']"))).click();

			// 3. Enter medicine name (e.g., "syrup")
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[3]"))).sendKeys("syrup9");
			String baseName = "SyrupEzovion ";
			int counter = 1;
			String supplierName = baseName + counter;
			
			while (true) {
				
				
			
			    // Enter supplier name
			    WebElement nameField = wait.until(ExpectedConditions.visibilityOfElementLocated(
			        By.xpath("(//input[@type='text'])[3]")));
			    nameField.clear();
			  
			    nameField.sendKeys(supplierName);
			    // Click Save
		

			    // Wait briefly to check for error (can use wait for visibility too)
			    Thread.sleep(1000);

			    // Check if error message is visible
			    List<WebElement> errorMessages = driver.findElements(By.xpath(
			        "//span[contains(text(),'Name Already Exists..')]"));

			    if (errorMessages.isEmpty()) {
			        // Name is unique, break the loop
			        System.out.println("Supplier added with name: " + supplierName);
			        break;
			    } else {
			        // Increment and retry
			        counter++;
			        supplierName = baseName + counter;
			       
			       
			        
			    }
			   
			}
			wait.until(webDriver -> ((JavascriptExecutor) webDriver)
				    .executeScript("return document.readyState").equals("complete"));

			// 4. Wait for 4th input to be visible (you can send keys or use if needed)
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[4]"))).click();

			// 5. Click on "Schedule A1"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Schedule A1']"))).click();

			// 6. Wait for 5th input (optional)
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[5]"))).click();

			// 7. Click on "SHOULDER IMBO"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()=' SHOULDER IMBO']"))).click();

			// 8. Wait for 6th input (optional)
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[6]"))).click();

			// 9. Click on "CALTEN"
			
			for (int i = 0; i < 2; i++) {
			    try {
			    	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='	CALTEN']"))).click();
			        break; // Exit the loop if click is successful
			    } catch (Exception e) {
			        System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
			        if (i == 4) {
			            throw e; // Re-throw if all attempts fail
			        }
			        Thread.sleep(1000); // Small delay before retrying
			    }
			}
		

			// 10. Wait for 7th input (optional)
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[7]"))).click();

			// 11. Click on "Bisacodyl Ip: 5"
			for (int i = 0; i < 11; i++) {
			    try {
			        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(
			            By.xpath("//span[text()=' Bisacodyl Ip: 5 ']")));
			        element.click();
			        break; // Exit the loop if click is successful
			    } catch (Exception e) {
			        System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
			        if (i == 11) {
			            throw e; // Re-throw if all attempts fail
			        }
			        Thread.sleep(1000); // Small delay before retrying
			    }
			}


			// 12. Wait for 8th input (optional)
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[8]"))).click();

			// 13. Click on "ajhj"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='ajhj']"))).click();

			// 14. Enter quantity = 1
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='number'])[1]"))).sendKeys("5");
//			maxQty
			//input[@formcontrolname='minQty'].sendkeys("200")
			//input[@formcontrolname='maxQty'].sendkeys("150")
			// 15. Wait for 12th text input (optional sendKeys)
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='minQty']"))).sendKeys("50");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='maxQty']"))).sendKeys("");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[12]"))).click();

			// 16. Click on "0"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='0']"))).click();

			// 17. Click on Save button
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();
			

			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Pharmacy']"))).click();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[@title='Stock'])[1]"))).click();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[@title='Opening Stock'])[1]"))).click();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()='Add Opening Stock']"))).click();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Pharamacy Loaction'])[1]"))).click();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Select ']"))).click();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='" + supplierName + "'])[1]"))).click();

			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='batchNumber']"))).sendKeys("456");
			WebElement expiry = driver.findElement(By.xpath("//input[@formcontrolname='expiryDate']"));
			((JavascriptExecutor) driver).executeScript("arguments[0].value='2025-07'; arguments[0].dispatchEvent(new Event('input'));", expiry);

			driver.findElement(By.xpath("//input[@formcontrolname='pricePerStrips']")).sendKeys("4");
			driver.findElement(By.xpath("//input[@formcontrolname='mrpPerStrip']")).sendKeys("4");
			driver.findElement(By.xpath("//input[@formcontrolname='sellPriceStrip']")).sendKeys("4");
			driver.findElement(By.xpath("//input[@formcontrolname='qtyInStrips']")).sendKeys("4");
			driver.findElement(By.xpath("//input[@formcontrolname='qtyInUnits']")).sendKeys("4");
			driver.findElement(By.xpath("//input[@value='Save']")).click();
		 
		}
	}


