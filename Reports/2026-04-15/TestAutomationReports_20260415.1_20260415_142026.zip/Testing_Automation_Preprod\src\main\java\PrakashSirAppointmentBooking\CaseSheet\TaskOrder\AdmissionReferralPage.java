package PrakashSirAppointmentBooking.CaseSheet.TaskOrder;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class AdmissionReferralPage extends Abstraction {

    WebDriver driver;

    public AdmissionReferralPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // --- Section Toggle ---
    @FindBy(xpath = "//h4[normalize-space(text())='Task Order']/following::img[contains(@class,'openclose')][1]")
    private WebElement taskOrderToggleIcon;

    // --- Text Fields ---
    @FindBy(xpath = "//textarea[@formcontrolname='Reason']")
    private WebElement reasonForAdmissionTextarea;

    // --- Radio Buttons ---
    @FindBy(xpath = "//input[@formcontrolname='Type' and @value='Inhouse']")
    private WebElement hospitalTypeInhouse;

    @FindBy(xpath = "//input[@formcontrolname='Type' and @value='External']")
    private WebElement hospitalTypeExternal;

    @FindBy(xpath = "//input[@formcontrolname='Mode' and @value='Elective']")
    private WebElement modeElective;

    @FindBy(xpath = "//input[@formcontrolname='Mode' and @value='Immediate']")
    private WebElement modeImmediate;

    @FindBy(xpath = "//input[@formcontrolname='Mode' and @value='Emergency']")
    private WebElement modeEmergency;

    @FindBy(xpath = "//input[@formcontrolname='Admissionperiod' and @value='1']")
    private WebElement admissionToday;

    @FindBy(xpath = "//input[@formcontrolname='Admissionperiod' and @value='2']")
    private WebElement admission2Days;

    @FindBy(xpath = "//input[@formcontrolname='Admissionperiod' and @value='3']")
    private WebElement admissionWeek;

    @FindBy(xpath = "//input[@formcontrolname='Admissionperiod' and @value='4']")
    private WebElement admission15Days;

    @FindBy(xpath = "//input[@formcontrolname='Admissionperiod' and @value='5']")
    private WebElement admissionMonth;

    @FindBy(xpath = "//input[@formcontrolname='Admissionperiod' and @value='6']")
    private WebElement admission2Months;

    @FindBy(xpath = "//input[@formcontrolname='Admissionperiod' and @value='7']")
    private WebElement admissionCustom;
    
    @FindBy(xpath = "//input[@formcontrolname='Appointmentperiod' and @value='1']")
    private WebElement appointmentToday;

    @FindBy(xpath = "//input[@formcontrolname='Appointmentperiod' and @value='2']")
    private WebElement appointment2Days;

    @FindBy(xpath = "//input[@formcontrolname='Appointmentperiod' and @value='3']")
    private WebElement appointmentWeek;

    @FindBy(xpath = "//input[@formcontrolname='Appointmentperiod' and @value='4']")
    private WebElement appointment15Days;

    @FindBy(xpath = "//input[@formcontrolname='Appointmentperiod' and @value='5']")
    private WebElement appointmentMonth;

    @FindBy(xpath = "//input[@formcontrolname='Appointmentperiod' and @value='6']")
    private WebElement appointment2Months;

    @FindBy(xpath = "//input[@formcontrolname='Appointmentperiod' and @value='7']")
    private WebElement appointmentCustom;


    @FindBy(xpath = "//input[@formcontrolname='checkBoxControl' and @value='Yes']")
    private WebElement insuranceYes;

    @FindBy(xpath = "//input[@formcontrolname='checkBoxControl' and @value='No']")
    private WebElement insuranceNo;

    // --- Dropdowns ---
    @FindBy(xpath = "//ngx-select[@formcontrolname='Doctor']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement specificDoctorDropdown;

    // --- Buttons ---
    @FindBy(xpath = "//input[@value='Add Refer to Admission']")
    private WebElement addReferralBtn;
    
    @FindBy(xpath = "//input[@value='Add Refer to Appointment']")
    private WebElement addappointment;

    @FindBy(xpath = "//input[@value='Reset']")
    private WebElement resetBtn;
    
    @FindBy(xpath = "//li//a[normalize-space(text())='Refer to Appointment']")
    private WebElement referToAppointmentLink;

    @FindBy(xpath = "//li//a[normalize-space(text())='Refer to Admission']")
    private WebElement referToAdmissionLink;
    // --- Actions ---
    public void toggleTaskOrderSection() {
        clickWithJavaScript(taskOrderToggleIcon);
    }
    public void referadmission() {
        clickWithJavaScript(referToAdmissionLink);
    }
    public void referappointment() {
        clickWithJavaScript(referToAppointmentLink);
    }
    public void enterReasonForAdmission(String reason) {
        reasonForAdmissionTextarea.clear();
        reasonForAdmissionTextarea.sendKeys(reason);
    }

    public void selectHospitalType(String type) {
        if(type.equalsIgnoreCase("Inhouse")) hospitalTypeInhouse.click();
        else hospitalTypeExternal.click();
    }

    public void selectAdmissionMode(String mode) {
        switch(mode.toLowerCase()) {
            case "elective": modeElective.click(); break;
            case "immediate": modeImmediate.click(); break;
            case "emergency": modeEmergency.click(); break;
        }
    }

    public void selectAdmissionPeriod(String period) {
        switch(period.toLowerCase()) {
            case "today": admissionToday.click(); break;
            case "2days": admission2Days.click(); break;
            case "week": admissionWeek.click(); break;
            case "15days": admission15Days.click(); break;
            case "month": admissionMonth.click(); break;
            case "2months": admission2Months.click(); break;
            case "custom": admissionCustom.click(); break;
        }
    }
    public void selectAppointmentPeriod(String period) {
        switch(period.toLowerCase()) {
            case "today": appointmentToday.click(); break;
            case "2days": appointment2Days.click(); break;
            case "week": appointmentWeek.click(); break;
            case "15days": appointment15Days.click(); break;
            case "month": appointmentMonth.click(); break;
            case "2months": appointment2Months.click(); break;
            case "custom": appointmentCustom.click(); break;
        }
    }

    public void selectInsurance(String value) {
        if(value.equalsIgnoreCase("Yes")) insuranceYes.click();
        else insuranceNo.click();
    }

    public void selectSpecificDoctor(String doctor) {
        specificDoctorDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + doctor + "']"));
        option.click();
    }

    public void clickAddReferral2() {
        addappointment.click();
    }
    public void clickAddReferral1() {
    	addReferralBtn.click();
    }

    public void clickReset() {
        resetBtn.click();
    }
}
