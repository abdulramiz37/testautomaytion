package Appointment.DoctorList;




	import java.util.Random;

import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;

	import EzionAbstractionComponents.Abstraction;

	public class Physician extends Abstraction{

		public Physician(WebDriver driver) {
			super(driver);
		    this.driver = driver;
	        PageFactory.initElements(driver, this);
		}
		  @FindBy(xpath = "//span[text()='Appointment']")
		    private WebElement appointment;
		  
		  @FindBy(xpath = "//span[text()='Doctor List']")
		    private WebElement doctorlist;
		//span[text()='Doctor List']
		    @FindBy(xpath = "//a[text()=' Add Physician ']")
		    private WebElement addPhysician;

		    // ======== LOCATORS ========

		    @FindBy(xpath = "//input[@formcontrolname='name']")
		    private WebElement physicianNameInput;

		    @FindBy(xpath = "//input[@formcontrolname='lastName']")
		    private WebElement lastNameInput;

		    @FindBy(xpath = "//input[@formcontrolname='displayName']")
		    private WebElement displayNameInput;

		    @FindBy(xpath = "//ngx-select[@formcontrolname='gender']")
		    private WebElement genderDropdown;

		    @FindBy(xpath = "//input[@formcontrolname='dob']")
		    private WebElement dobInput;

		    @FindBy(xpath = "//input[@formcontrolname='age']")
		    private WebElement ageInput;

		    @FindBy(xpath = "//input[@formcontrolname='email']")
		    private WebElement emailInput;

		    @FindBy(xpath = "//input[@formcontrolname='mobile']")
		    private WebElement mobileInput;

		    @FindBy(xpath = "//input[@formcontrolname='altMobile']")
		    private WebElement altMobileInput;

		    @FindBy(xpath = "//input[@formcontrolname='workPhone']")
		    private WebElement workPhoneInput;

		    @FindBy(xpath = "//input[@formcontrolname='panNo']")
		    private WebElement panInput;

		    @FindBy(xpath = "//ngx-select[@formcontrolname='departmentId']")
		    private WebElement departmentDropdown;

		    @FindBy(xpath = "//ngx-select[@formcontrolname='jobCategoryId']")
		    private WebElement jobCategoryDropdown;

		    @FindBy(xpath = "//ngx-select[@formcontrolname='jobType']")
		    private WebElement jobTypeDropdown;

		    @FindBy(xpath = "//ngx-select[@formcontrolname='academicRank']")
		    private WebElement academicRankDropdown;


		    @FindBy(xpath = "//input[@formcontrolname='streetName']")
		    private WebElement streetNameInput;

		    @FindBy(xpath = "//input[@formcontrolname='address']")
		    private WebElement areaInput;

		    @FindBy(xpath = "//input[@formcontrolname='pincode']")
		    private WebElement pincodeInput;

		    @FindBy(xpath = "//input[@formcontrolname='city']")
		    private WebElement cityInput;

		    @FindBy(xpath = "//ngx-select[@formcontrolname='districtId']//div[contains(@class,'ngx-select__toggle')]")
		    private WebElement districtDropdown;

		    @FindBy(xpath = "//ngx-select[@formcontrolname='stateId']//div[contains(@class,'ngx-select__toggle')]")
		    private WebElement stateDropdown;

		    @FindBy(xpath = "//ngx-select[@formcontrolname='countryId']//div[contains(@class,'ngx-select__toggle')]")
		    private WebElement countryDropdown;

		    @FindBy(xpath = "//label[contains(text(),'Is Active')]/input[@formcontrolname='isActive']")
		    private WebElement isActiveCheckbox;

		    @FindBy(xpath = "//input[@value='Save']")
		    private WebElement saveButton;
		    
		    @FindBy(xpath = "//label[text()=' Default Language ']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
		    private WebElement defaultLanguageDropdown;

		    // Dynamic language option inside dropdown
		    private String languageOptionXpath(String language) {
		        return "//ul[contains(@class,'ngx-select__choices')]//span[text()='" + language + "']";
		    }

		    // Checkbox: Print both English and Regional language
		    @FindBy(xpath = "//label[contains(text(),'Print both English')]")
		    private WebElement printEnglishWithRegionalCheckbox;

		    @FindBy(xpath = "//label[contains(text(), 'Do you want check stock availability in prescription')]")
		    private WebElement stockAvailabilityCheckbox;

		    @FindBy(xpath = "//input[@type='button' and @value='Save and Continue']")
		    private WebElement saveAndContinueButton;

		    // ------------------ Methods ------------------ //
		    // ======== ACTION METHODS ========

		    public void selectFromDropdownByVisibleText(String visibleText) {
		        WebElement option = driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[text()='" + visibleText + "']"));
		        waitForClickability(option).click();
		    }

		    public void clickAddPhysicianButton() throws InterruptedException {
		    	
		        waitForClickability(appointment).click();
		        waitForClickability(doctorlist).click();
		        waitForClickability(addPhysician).click();
		    }

		    public void selectPrefix(String prefixText) {
		        WebElement prefixDropdown = driver.findElement(By.xpath("//ngx-select[@placeholder='Select']"));
		        waitForClickability(prefixDropdown).click();
		        selectFromDropdownByVisibleText(prefixText);
		    }

		    public void enterPhysicianName(String name) {
		        WebElement nameField = waitForVisibility(physicianNameInput);
		        nameField.clear();
		        
		        if (name == null || name.trim().isEmpty()) {
		            name = generateRandomName();
		        }
		        
		        nameField.sendKeys(name);
		    }

		    // Utility method to generate a random string name
		    public String generateRandomName() {
		        int length = new Random().nextInt(6) + 5; // Length between 5 and 10
		        String characters = "abcdefghijklmnopqrstuvwxyz";
		        StringBuilder name = new StringBuilder();
		        Random rand = new Random();

		        for (int i = 0; i < length; i++) {
		            name.append(characters.charAt(rand.nextInt(characters.length())));
		        }

		        return name.toString();
		    }


		    public void enterLastName(String lastName) {
		        waitForVisibility(lastNameInput).clear();
		        lastNameInput.sendKeys(lastName);
		    }

		    public void enterDisplayName(String displayName) {
		        waitForVisibility(displayNameInput).clear();
		        displayNameInput.sendKeys(displayName);
		    }

		    public void selectGender(String genderText) {
		        waitForClickability(genderDropdown).click();
		        selectFromDropdownByVisibleText(genderText);
		    }

		    public void enterDOB(String date) {
		        waitForVisibility(dobInput).clear();
		        js.executeScript(
		                "arguments[0].value='" + date + "';" +
		                "arguments[0].dispatchEvent(new Event('input'));" +
		                "arguments[0].dispatchEvent(new Event('change'));",
		                dobInput
		            );
		    }

		    public void enterAge(String age) {
		        waitForVisibility(ageInput).clear();
		        ageInput.sendKeys(age);
		    }
		    public void enterEmail(String email) {
		        WebElement emailField = waitForVisibility(emailInput);
		        emailField.clear();

		        if (email == null || email.trim().isEmpty()) {
		            email = generateRandomEmail();
		        }

		        emailField.sendKeys(email);
		    }

		    public void enterMobileNumber(String mobile) {
		        WebElement mobileField = waitForVisibility(mobileInput);
		        mobileField.clear();

		        if (mobile == null || mobile.trim().isEmpty()) {
		            mobile = generateRandomMobileNumber();
		        }

		        mobileField.sendKeys(mobile);
		    }

		    // Utility to generate a random email
		    public String generateRandomEmail() {
		        String chars = "abcdefghijklmnopqrstuvwxyz";
		        StringBuilder name = new StringBuilder();
		        Random rand = new Random();

		        for (int i = 0; i < 8; i++) {
		            name.append(chars.charAt(rand.nextInt(chars.length())));
		        }

		        return name.toString() + "@example.com";
		    }

		    // Utility to generate a random 10-digit mobile number (starts with 7-9)
		    public String generateRandomMobileNumber() {
		        Random rand = new Random();
		        StringBuilder number = new StringBuilder();
		        number.append(rand.nextInt(3) + 7); // first digit: 7, 8, or 9

		        for (int i = 0; i < 9; i++) {
		            number.append(rand.nextInt(10));
		        }

		        return number.toString();
		    }

		    public void enterAlternateMobile(String altMobile) {
		        waitForVisibility(altMobileInput).clear();
		        altMobileInput.sendKeys(altMobile);
		    }

		    public void enterWorkPhone(String workPhone) {
		        waitForVisibility(workPhoneInput).clear();
		        workPhoneInput.sendKeys(workPhone);
		    }

		    public void enterPanCardNumber(String pan) {
		        waitForVisibility(panInput).clear();
		        panInput.sendKeys(pan.toUpperCase());
		    }

		    public void selectDepartment(String departmentText) {
		        waitForClickability(departmentDropdown).click();
		        selectFromDropdownByVisibleText(departmentText);
		    }

		    public void selectJobCategory(String jobCategoryText) {
		        waitForClickability(jobCategoryDropdown).click();
		        selectFromDropdownByVisibleText(jobCategoryText);
		    }

		    public void selectJobType(String jobTypeText) {
		        waitForClickability(jobTypeDropdown).click();
		        selectFromDropdownByVisibleText(jobTypeText);
		    }

		    public void selectAcademicRank(String rankText) {
		        waitForClickability(academicRankDropdown).click();
		        selectFromDropdownByVisibleText(rankText);
		    }

		    public void enterStreetName(String street) {
		        waitForVisibility(streetNameInput).clear();
		        streetNameInput.sendKeys(street);
		    }

		    public void enterArea(String area) {
		        waitForVisibility(areaInput).clear();
		        areaInput.sendKeys(area);
		    }

		    public void enterPincode(String pincode) {
		        waitForVisibility(pincodeInput).clear();
		        pincodeInput.sendKeys(pincode);
		    }

		    public void enterCity(String city) {
		        waitForVisibility(cityInput).clear();
		        cityInput.sendKeys(city);
		    }

		    public void selectDistrict(String districtName) {
		        waitForClickability(districtDropdown).click();
		        selectFromDropdownByVisibleText(districtName);
		    }

		    public void selectState(String stateName) {
		        waitForClickability(stateDropdown).click();
		        WebElement stateOption = driver.findElement(By.xpath("//div[contains(@class,'ngx-select__item') and text()='" + stateName + "']"));
		        waitForClickability(stateOption).click();
		    }

		    public void selectCountry(String countryName) {
		        waitForClickability(countryDropdown).click();
		        WebElement countryOption = driver.findElement(By.xpath("//div[contains(@class,'ngx-select__item') and text()='" + countryName + "']"));
		        waitForClickability(countryOption).click();
		    }

		    public void setIsActive(boolean isActive) {
		        if (isActiveCheckbox.isSelected() != isActive) {
		            waitForClickability(isActiveCheckbox).click();
		        }
		    }
		    
		    public void selectDropdownOption(WebElement dropdown, String visibleText) {
		        waitForClickability(dropdown).click();
		        WebElement countryOption = driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[text()='" + visibleText + "']"));
		     
		        countryOption.click();
		    }

		 // "When Appointment Charges will be posted?" dropdown
		    @FindBy(xpath = "//ngx-select[@formcontrolname='initiatedwhen']//div[contains(@class,'ngx-select__toggle')]")
		    private WebElement appointmentChargesDropdown;

		    // "Appointment Booking Type" dropdown
		    @FindBy(xpath = "//ngx-select[@formcontrolname='appointmentBookingType']//div[contains(@class,'ngx-select__toggle')]")
		    private WebElement appointmentBookingTypeDropdown;

		    // "Restricted View See Patient Appointments" dropdown
		    @FindBy(xpath = "//ngx-select[@formcontrolname='restrictedPatientAppointments']//div[contains(@class,'ngx-select__toggle')]")
		    private WebElement restrictedViewDropdown;

		    // "Consultation charge type" dropdown
		    @FindBy(xpath = "//ngx-select[@formcontrolname='consultationChargeType']//div[contains(@class,'ngx-select__toggle')]")
		    private WebElement consultationChargeTypeDropdown;

		    
		    public void selectAppointmentChargesPostedWhen(String optionText) {
		        selectDropdownOption(appointmentChargesDropdown, optionText);
		    }

		    public void selectAppointmentBookingType(String optionText) {
		        selectDropdownOption(appointmentBookingTypeDropdown, optionText);
		    }

		    public void selectRestrictedView(String optionText) {
		        selectDropdownOption(restrictedViewDropdown, optionText);
		    }

		    public void selectConsultationChargeType(String optionText) {
		        selectDropdownOption(consultationChargeTypeDropdown, optionText);
		    }
		    public void clickDefaultLanguageDropdown() {
		        defaultLanguageDropdown.click();
		    }

		    public void selectLanguage(String language) {
		    	clickDefaultLanguageDropdown();
		        WebElement languageOption = driver.findElement(By.xpath(languageOptionXpath(language)));
		        languageOption.click();
		    }

		    public void togglePrintEnglishWithRegionalCheckbox(boolean shouldCheck) {
		        boolean isChecked = printEnglishWithRegionalCheckbox.isSelected();
		        if (shouldCheck != isChecked) {
		            printEnglishWithRegionalCheckbox.click();
		        }
		    }
		    public void setStockAvailability(boolean check) {
		        if (check && !stockAvailabilityCheckbox.isSelected()) {
		            stockAvailabilityCheckbox.click();
		        } else if (!check && stockAvailabilityCheckbox.isSelected()) {
		            stockAvailabilityCheckbox.click();
		        }
		    }

		    
		    
		    public void addPhysician(
		    	    String prefix, String physicianName, String lastName, String displayName,
		    	    String gender, String dob, String age, String email,
		    	    String mobile, String altMobile, String workPhone, String panCard,
		    	    String department, String jobCategory, String jobType, String academicRank,
		    	    String street, String area, String pincode, String city,
		    	    String district, String state, String country,
		    	    boolean isActive,
		    	    String appointmentChargesPostedWhen, String appointmentBookingType,
		    	    String restrictedViewOption, String consultationChargeType ,String language, boolean isActive2
		    ) throws InterruptedException {
		    	
		        clickAddPhysicianButton();
//		        selectPrefix(prefix);
		        enterPhysicianName(physicianName);
		        enterLastName(lastName);
		        enterDisplayName(displayName);
		        selectGender(gender);
		        enterDOB(dob);
//		        enterAge(age);
		        enterEmail(email);
		        enterMobileNumber(mobile);
//		        enterAlternateMobile(altMobile);
		        enterWorkPhone(workPhone);
//		        enterPanCardNumber(panCard);
		        selectDepartment(department);
//		        selectJobCategory(jobCategory);
		        selectJobType(jobType);
		        selectAcademicRank(academicRank);
		        
		        enterStreetName(street);
		        enterArea(area);
		        enterPincode(pincode);
		        enterCity(city);
		        selectDistrict(district);
//		        selectState(state);
//		        selectCountry(country);

		        setIsActive(isActive);

		        // Appointment-related dropdowns
		        selectAppointmentChargesPostedWhen(appointmentChargesPostedWhen);
		        selectAppointmentBookingType(appointmentBookingType);
		        selectRestrictedView(restrictedViewOption);
		        selectConsultationChargeType(consultationChargeType);
		      
		        selectLanguage(language); // or "English", "Gujarati", etc.

		        // Toggle checkbox
		        togglePrintEnglishWithRegionalCheckbox(isActive2);
//		        setStockAvailability(isActive2);
		    }
		    
		    public void clickSaveButton() {
		        waitForClickability(saveButton).click();
		    }
		    public void clickSaveAndContinue() {
		        waitForClickability(saveAndContinueButton).click();
		    }

	}


