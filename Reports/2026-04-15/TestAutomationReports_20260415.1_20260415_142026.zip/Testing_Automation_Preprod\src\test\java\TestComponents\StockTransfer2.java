package TestComponents;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EzionpageObjects.UserIdPage;
import PharmacyIndentFlow.StockTransferPage;
import abdulTest.BaseTest;

public class StockTransfer2 extends BaseTest {

    UserIdPage loginPage;
    StockTransferPage stockTransferPage;
    HashMap<String, String> currentInput;

    @Test(dataProvider = "getData")
    public void StockTransfer2_Login(HashMap<String, String> input) throws InterruptedException {
        this.currentInput = input;
//        loginPage = login.login(input.get("userId"));
//        loginPage.enterMobileNumber(input.get("personId"));
//        loginPage.enterPassword(input.get("password"));
        
        String userId = prop.getProperty("USER_ID");
        String personId = prop.getProperty("PERSON_ID");
        String password = prop.getProperty("PASSWORD");
        String browser = System.getProperty("BROWSER");
        loginPage = login.login(userId);
        loginPage.enterMobileNumber(personId);
        loginPage.enterPassword(password);
        loginPage.clickContinue();
        System.out.println("Browser: " + browser);
//        System.out.println("Base URL: " + baseUrl);
        System.out.println("User ID: " + userId);
        System.out.println("Person ID: " + personId);
        loginPage.clickContinue();
    }

    @Test(dependsOnMethods = "StockTransfer2_Login")
    public void StockTransfer2_NavigateToIndent() {
        loginPage.navigateToIndentWithRetry();
    }

    @Test(dependsOnMethods = "StockTransfer2_NavigateToIndent")
    public void StockTransfer2_ExecuteStockTransfer() {
        stockTransferPage = new StockTransferPage(driver);
        stockTransferPage.completeStockTransferFlow(
//            currentInput.get("issueDate"),
            currentInput.get("transferBy"),
            currentInput.get("destinationLocation"),
            currentInput.get("destinationWarehouse"),
            currentInput.get("transferStatus"),
            currentInput.get("medicineName"),
            currentInput.get("quantity")
        );
    }

    @DataProvider
    public Object[][] getData() throws IOException {
        List<HashMap<String, String>> data = getJsonDataToMap(
            System.getProperty("user.dir") + "//src//main//java//ezion//Resources//StockReturn.json"
        );
        return new Object[][] { { data.get(0) } };
    }
}
