package PharmacySalesPage;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class SearchAndReturnBill extends Abstraction {
	
    public SearchAndReturnBill(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @FindBy(css = "table.table-style tbody tr")
    List<WebElement> billTableRows;

    @FindBy(xpath = "(//i[@class='fas fa-chevron-right'])[1]")
    WebElement nextPageButton;
    
    @FindBy(xpath = "(//b[@class='headerfont'])[3]")
    WebElement billNumber;

    @FindBy(xpath = "(//span[text()='Sales'])[2]")
    WebElement salesMenu;


    
	   public boolean searchAndReturnBill(String targetBillNo) {
	        waitForClickability(salesMenu).click();
	        boolean matchFound = false;

	        while (!matchFound) {
	            List<WebElement> rows = waitForVisibility(billTableRows);

	            for (WebElement row : rows) {
	                try {
	                    String currentBill = row.findElement(By.cssSelector("td:nth-child(2) h4")).getText().trim();
	                    if (currentBill.equals(targetBillNo)) {
	                        WebElement returnBtn = waitForClickability(row.findElement(By.cssSelector("li a[title='Go Sales Return'] img")));
	                        returnBtn.click();
	                        return true;
	                    }
	                } catch (Exception e) {
	                    System.err.println("❌ Error while processing bill row: " + e.getMessage());
	                }
	            }

	            if (nextPageButton.isEnabled()) {
	                js.executeScript("arguments[0].click();", nextPageButton);
	                waitForVisibility(billTableRows);
	            } else {
	                break;
	            }
	        }

	        System.out.println("❌ Target bill not found: " + targetBillNo);
	        return false;
	    }
	   
	   public boolean print(String targetBillNo) {
	        waitForClickability(salesMenu).click();
	        boolean matchFound = false;

	        while (!matchFound) {
	            List<WebElement> rows = waitForVisibility(billTableRows);

	            for (WebElement row : rows) {
	                try {
	                    String currentBill = row.findElement(By.cssSelector("td:nth-child(3) p")).getText().trim();
	                    if (currentBill.equals(targetBillNo)) {
	                        WebElement returnBtn = waitForClickability(row.findElement(By.cssSelector("li a[title='Print'] img")));
	                        returnBtn.click();
	                        return true;
	                    }
	                } catch (Exception e) {
	                    System.err.println("❌ Error while processing bill row: " + e.getMessage());
	                }
	            }

	            if (nextPageButton.isEnabled()) {
	                js.executeScript("arguments[0].click();", nextPageButton);
	                waitForVisibility(billTableRows);
	            } else {
	                break;
	            }
	        }

	        System.out.println("❌ Target bill not found: " + targetBillNo);
	        return false;
	    }
	// Locator for Patient Search input
	   @FindBy(xpath = "(//div[contains(@class,'search-icons-notRequired')]//input[@type='text'])[1]")
	   private WebElement patientSearchInput;

	   // Method to enter patient name in search box
	   public void enterPatientName(String patientName) {
	       patientSearchInput.clear();    // Clear if already filled
	       patientSearchInput.sendKeys(patientName);
	   }
	   
	   @FindBy(xpath = "(//div[contains(@class,'search-icons-notRequired')]//input[@type='text'])[2]")
	   private WebElement mobileSearchInput;
	   public void clickDelete() {
		    try {
		        WebElement deleteBtn = driver.findElement(
		            By.xpath("//span[contains(@class,'ngx-select__toggle-buttons')]//a[contains(@class,'ngx-select__clear')]")
		        );
		        deleteBtn.click();
		        System.out.println("Selection cleared successfully.");
		    } catch (NoSuchElementException e) {
		        System.out.println("Delete button not available.");
		    }
		}

	   // Method to enter patient name in search box
	   public void enterMobileNumber(String mobileNumber) {
		   mobileSearchInput.clear();    // Clear if already filled
		   mobileSearchInput.sendKeys(mobileNumber);
	   }

	   
	   public boolean edit(String targetBillNo) {
	        waitForClickability(salesMenu).click();
	        boolean matchFound = false;

	        while (!matchFound) {
	            List<WebElement> rows = waitForVisibility(billTableRows);

	            for (WebElement row : rows) {
	                try {
	                    String currentBill = row.findElement(By.cssSelector("td:nth-child(3) p")).getText().trim();
	                    if (currentBill.equals(targetBillNo)) {
	                        WebElement returnBtn = waitForClickability(row.findElement(By.cssSelector("li a[title='Edit'] img")));
	                        returnBtn.click();
	                        return true;
	                    }
	                } catch (Exception e) {
	                    System.err.println("❌ Error while processing bill row: " + e.getMessage());
	                }
	            }

	            if (nextPageButton.isEnabled()) {
	                js.executeScript("arguments[0].click();", nextPageButton);
	                waitForVisibility(billTableRows);
	            } else {
	                break;
	            }
	        }

	        System.out.println("❌ Target bill not found: " + targetBillNo);
	        return false;
	    }
	   public SalesReturnPage returnBill() {
		   SalesReturnPage salesReturn = new SalesReturnPage(driver);
		   return salesReturn;
	   }
	   
	   
}
