package WareHouseSetup.IPpharmacy;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class BuildingPage extends Abstraction{

    WebDriver driver;

    // ===== LOCATORS =====
    
    // Building Name input field
    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement buildingNameInput;

    // Save button
    @FindBy(xpath = "//input[@type='button' and @value='Save']")
    private WebElement saveButton;

    // Cancel button
    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
    private WebElement cancelButton;

    // ===== CONSTRUCTOR =====
    public BuildingPage(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    @FindBy(xpath = "//a[text()=' Building ']")
    private WebElement userType;

    @FindBy(xpath = "//a[text()=' Add Building ']")
    private WebElement adduserType;
    // 🔹 Methods
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}
    // ===== METHODS =====
    
    // Enter Building Name
    public void enterBuildingName(String buildingName) {
        buildingNameInput.clear();
        buildingNameInput.sendKeys(buildingName);
    }

    // Click Save
    public void clickSave() {
        saveButton.click();
    }

    // Click Cancel
    public void clickCancel() {
        cancelButton.click();
    }
}
