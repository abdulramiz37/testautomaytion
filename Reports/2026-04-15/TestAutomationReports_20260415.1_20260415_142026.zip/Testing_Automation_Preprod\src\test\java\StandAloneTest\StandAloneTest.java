package StandAloneTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class StandAloneTest {
	public static void main(String []args) throws InterruptedException {
		WebDriver driver = new EdgeDriver();
//		driver.get("https://apps.ezovion.com/auth/login");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://apps.ezovion.com/auth/login");

		driver.manage().window().maximize();
		

		driver.findElement(By.xpath("//div[@class=\"form-control-group\"]//input")).sendKeys("25889229");
		driver.findElement(By.xpath("//button[@size=\"large\"]")).click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
	        // Wait until the button with text "CONTINUE" is clickable
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
		
	     driver.findElement(By.xpath("//input[@placeholder=\"Mobile No\"]")).sendKeys("2588922905");
		driver.findElement(By.xpath("//input[@placeholder=\"Password\"]")).sendKeys("Ezovion@33");
		
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@status=\"primary\"]")));
		 Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@status=\"primary\"]")).click();
//	driver.findElement(By.xpath("//button[@status=\"primary\"]")).click();
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//li[@class=\"alert-message\"]")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Registration']")));

		
	    driver.findElement(By.xpath("//span[text()=\"Registration\"]")).click();
		//span[text()="Registration"]
	    driver.findElement(By.xpath("//span[text()=\"Patient List\"]")).click();
		// Click on the first "three dots" menu
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='three-dots relative'])[1]"))).click();

		// Click on the 4th patient image container
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='pls-img-cont'])[4]"))).click();

		// Click on "Select" input
//		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Select']"))).click();
	 // Click on "Cardiology"
	 // Click on "Cardiology"
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Cardiology']"))).click();

	    // Click on "Dr. Malik"
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Dr. Malik']"))).click();

	    // Wait for and click on the 4th ngx-select dropdown
//	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='ngx-select dropdown'])[4]"))).click();
//	    Thread.sleep(2000);
	    // Click on "APPEARANCE"
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='APPEARANCE']"))).click();

	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@type='text'])[4]"))).sendKeys("45");


	    // Click on "Add"
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Add']"))).click();

	    // Click on the first "Save" button
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@value='Save'])[1]"))).click();
	    Thread.sleep(5000);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='OP Billing']"))).click();
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='OP Bill List']"))).click();

	  //input[@placeholder="Select"]
	  //span[text()="Cardiology"]
	 
	  
	  //span[text()="Rate"]

	    
	    
	  //span[text()="New Registration"]
		//	(//span[text()="Select"])[1]
			//span[text()="Mr."]
			//input[@formcontrolname="firstname"]
			//input[@formcontrolname="middlename"]
			//input[@formcontrolname="lastname"]
			//input[@placeholder="Select"]
			//span[text()="Male"]
			//input[@placeholder="DD/MM/YYYY"]
			//button[@aria-label="Choose month and year"]
			//button[@aria-label="Previous 21 years"]
			//td[@aria-label="1999"]
			//td[@aria-label="May 1999"]
			//td[@aria-label="May 12, 1999"]
			//input[@formcontrolname="mobile"]
			//input[@value="Save"]
	  
	    		
	}
}
