package PrakashSirAppointmentBooking.CaseSheet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

import java.util.ArrayList;
import java.util.List;

public class PrescriptionPage extends Abstraction {

    WebDriver driver;

    public PrescriptionPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // --- Section Toggle ---
    @FindBy(xpath = "//h4[normalize-space(text())='Prescription']/following::img[contains(@class,'openclose')][1]")
    private WebElement prescriptionToggleIcon;

    // --- Dropdowns ---
    @FindBy(xpath = "//label[contains(text(),'Medicine Name')]/following::ngx-select[1]")
    private WebElement medicineNameDropdown;
    
    
    @FindBy(xpath = "//input[@placeholder='Select']")
    private WebElement selectSearchInput2;

    @FindBy(xpath = "//label[contains(text(),'Unit')]/following::ngx-select[1]")
    private WebElement unitDropdown;

    @FindBy(xpath = "//label[contains(text(),'Dosage')]/following::ngx-select[1]")
    private WebElement dosageDropdown;

    @FindBy(xpath = "//label[contains(text(),'Frequency')]/following::ngx-select[1]")
    private WebElement frequencyDropdown;

    @FindBy(xpath = "//label[contains(text(),'When to Taken')]/following::ngx-select[1]")
    private WebElement whenToTakenDropdown;

    @FindBy(xpath = "//label[contains(text(),'Duration')]/following::ngx-select[1]")
    private WebElement durationDropdown;

    @FindBy(xpath = "//label[contains(text(),'Route')]/following::ngx-select[1]")
    private WebElement routeDropdown;

    @FindBy(xpath = "//label[contains(text(),'Instructions')]/following::ngx-select[1]")
    private WebElement instructionsDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='performDoc']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement performingDoctorDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='performNurse']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement performingNurseDropdown;

    // --- Text Fields ---
    @FindBy(xpath = "//input[@formcontrolname='genericName']")
    private WebElement genericName;

    @FindBy(xpath = "//input[@formcontrolname='categoryName']")
    private WebElement medicineCategory;

    @FindBy(xpath = "//input[@formcontrolname='qty']")
    private WebElement quantityInput;

    @FindBy(xpath = "//textarea[@formcontrolname='instructions']")
    private WebElement notesTextarea;

    // --- Frequency Checkboxes ---
    @FindBy(xpath = "//label[normalize-space()='Mor']/span[@class='checkmark']")
    private WebElement morningCheckbox;

    @FindBy(xpath = "//label[normalize-space()='Noon']/span[@class='checkmark']")
    private WebElement noonCheckbox;

    @FindBy(xpath = "//label[normalize-space()='Eve']/span[@class='checkmark']")
    private WebElement eveningCheckbox;

    @FindBy(xpath = "//label[normalize-space()='Night']/span[@class='checkmark']")
    private WebElement nightCheckbox;
    
    @FindBy(xpath = "//input[@formcontrolname='prescribedDate']")
    private WebElement prescribedDateInput;

    // Prescribed Physician dropdown
    @FindBy(xpath = "//ngx-select[@formcontrolname='medPrescribedPhyId']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement prescribedPhysicianDropdown;

    // Prepared Physician dropdown
    @FindBy(xpath = "//ngx-select[@formcontrolname='medPreparedPhyId']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement preparedPhysicianDropdown;
    // --- Buttons ---
    @FindBy(xpath = "//input[@value='Add Medicine']")
    private WebElement addMedicineBtn;

    @FindBy(xpath = "//input[@value='Add This Prescriptions saved list']")
    private WebElement addPrescriptionListBtn;

    @FindBy(xpath = "//input[@value='Cancel']")
    private WebElement cancelBtn;

    @FindBy(xpath = "//input[@value='Reset']")
    private WebElement resetBtn;
    @FindBy(xpath = "//button[normalize-space()='Create Prescription']")
    WebElement addPrescriptionBtn;
    
    @FindBy(xpath = "//button[text()='Add New Medicine']")
    private WebElement addNewMedicineButton;

    @FindBy(xpath = "//li[@nbtooltip='Send To Pharmacy']")
    WebElement sendToPharmacyBtn;

    // Method to click
    public void clickSendToPharmacy() {
    	clickWithJavaScript(sendToPharmacyBtn);
    }
    public void addPrescriptionBtne() {
    	addPrescriptionBtn.click();
//       
    }
    
    @FindBy(xpath = "//button[normalize-space()='Add Prescription']")
    WebElement addPrescriptionBtn2;
    
    public void addPrescriptionBtne2() {
    	addPrescriptionBtn2.click();
//       
    }
    
    @FindBy(xpath = "//li[contains(@class,'tab')]//span[normalize-space(text())='Prescription']")
    WebElement prescriptionTab;

    @FindBy(xpath = "//tr[td[contains(text(),'No Indent Yet Created')]]/td[1]")
    private WebElement noIndentFirstTd;

    public void clickNoIndentFirstTd() {
      
        noIndentFirstTd.click();
    }
    @FindBy(xpath = "//input[@type='button' and @value='Send to pharmacy']")
    private WebElement sendToPharmacyButton;
    
    public void clickSendToPharmacyButton() {
     
        sendToPharmacyButton.click();
    }
    @FindBy(xpath = "//label[normalize-space()='Purpose']/following::div[contains(@class,'ngx-select__toggle')][1]")
    private WebElement purposeDropdown;
    public void clickPurposeDropdown() {
      
        purposeDropdown.click();
    }
    public void selectPurposeOption(String optionText) {
        WebElement option = driver.findElement(By.xpath("//a[contains(@class,'ngx-select__item') and normalize-space()='" + optionText + "']"));
        option.click();
    }
    @FindBy(id = "Priority1")
    private WebElement priorityNormalRadio;

    @FindBy(id = "Priority2")
    
    private WebElement priorityCriticalRadio;
    public void selectPriorityNormal() {
        if (!priorityNormalRadio.isSelected()) {
            priorityNormalRadio.click();
        }
    }

    public void selectPriorityCritical() {
        if (!priorityCriticalRadio.isSelected()) {
            priorityCriticalRadio.click();
        }
    }
    
    @FindBy(xpath = "//input[@type='button' and @value='Sent']")
    private WebElement sentButton;
    
    public void clickSentButton() {
  
        sentButton.click();
    }


    // Method
    public void clickPrescriptionTab() {
        prescriptionTab.click();
    }
    // --- Actions ---
    public void clickPrescriptionToggle() {
        clickWithJavaScript(prescriptionToggleIcon);
//       
    }
    

    public void enterPrescribedDate(String dateValue) {
        prescribedDateInput.clear();
        prescribedDateInput.sendKeys(dateValue);
    }

    // Select Prescribed Physician
    public void selectPrescribedPhysician(String physician) {
        prescribedPhysicianDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[@role='menu']//li[@role='menuitem']/a/span[contains(text(),'" + physician + "')]"
        ));
        option.click();
    }

    public void selectPreparedPhysician(String physician) {
        preparedPhysicianDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[@role='menu']//li[@role='menuitem']/a/span[contains(text(),'" + physician + "')]"
        ));
        option.click();
    }

 // --- Store all generated medicines ---
    private static List<String> generatedMedicines = new ArrayList<>();

    public void addGeneratedMedicine(String medName) {
        generatedMedicines.add(medName);
    }

    public List<String> getGeneratedMedicines() {
        return new ArrayList<>(generatedMedicines); // return a copy to avoid modification outside
    }
    public List<String> getGeneratedMedicines2() {
        return new ArrayList<>(generatedMedicines); // return a copy to avoid modification outside
    }
    public String finalMedicine;   // accessible outside
  
    @FindBy(xpath = "//input[@placeholder='Select' and contains(@class,'ngx-select__search')]")
    private WebElement selectInput;
    public void selectMedicineName2(String medicine) {
        medicineNameDropdown.click();
//        selectInput.sendKeys(medicine);
        WebElement option = driver.findElement(By.xpath(
            "//ul[@role='menu']//li[@role='menuitem']/a/span[contains(text(),'" + medicine + "')]"
        ));
        option.click();
    }

    
    public void selectMedicineName(String medicine) {
        medicineNameDropdown.click();
  

        finalMedicine = medicine;

        // If medicine is null or empty, generate a random medicine name
        if (medicine == null || medicine.trim().isEmpty()) {
            int length = 6;
            String alphabet = "abcdefghijklmnopqrstuvwxyz";
            StringBuilder sb = new StringBuilder();
            java.util.Random random = new java.util.Random();
            for (int i = 0; i < length; i++) {
                sb.append(alphabet.charAt(random.nextInt(alphabet.length())));
            }
            finalMedicine ="hfd"+ sb.toString();
            
        }
//        
        // type in medicine name
      
           
              
                selectSearchInput2.sendKeys(finalMedicine);
              
            
        


//        medicineNameDropdown.click();
        // check if medicine exists in dropdown list
                List<WebElement> medOptions = driver.findElements(
                	    By.xpath(
                	        "//ul[@role='menu']//li[@role='menuitem']/a/span[" +
                	        "contains(" +
                	            "translate(normalize-space(.), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ ', 'abcdefghijklmnopqrstuvwxyz'), " +
                	            "'" + medicine.toLowerCase().replaceAll("\\s+", "") + "'" +
                	        ")]"
                	    )
                	);



        if (!medOptions.isEmpty()) {
            // select existing medicine
            medOptions.get(0).click();
            System.out.println("Medicine Selected from dropdown: " + finalMedicine);
        } else {
            // add new medicine (if button available)
        	addNewMedicineButton.click();
            System.out.println("New Medicine Added: " + finalMedicine);
        }
    }

    public void selectMedicineNameippage(String medicine) {
        medicineNameDropdown.click();
  

        finalMedicine = medicine;

        // If medicine is null or empty, generate a random medicine name
        if (medicine == null || medicine.trim().isEmpty()) {
            int length = 6;
            String alphabet = "abcdefghijklmnopqrstuvwxyz";
            StringBuilder sb = new StringBuilder();
            java.util.Random random = new java.util.Random();
            for (int i = 0; i < length; i++) {
                sb.append(alphabet.charAt(random.nextInt(alphabet.length())));
            }
            finalMedicine ="hfd"+ sb.toString();
            
        }
//        
        // type in medicine name
      
           
              
                selectSearchInput2.sendKeys(finalMedicine);
              
            
        


//        medicineNameDropdown.click();
        // check if medicine exists in dropdown list
                List<WebElement> medOptions = driver.findElements(
                	    By.xpath(
                	        "//ul[@role='menu']//li[@role='menuitem']/a/span[" +
                	        "contains(" +
                	            "translate(normalize-space(.), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ ', 'abcdefghijklmnopqrstuvwxyz'), " +
                	            "'" + medicine.toLowerCase().replaceAll("\\s+", "") + "'" +
                	        ")]"
                	    )
                	);



        if (!medOptions.isEmpty()) {
            // select existing medicine
            medOptions.get(0).click();
            System.out.println("Medicine Selected from dropdown: " + finalMedicine);
        } else {
            // add new medicine (if button available)
        	addMedicineHeader2.click();
            System.out.println("New Medicine Added: " + finalMedicine);
        }
    }

    public void selectMedicineName1(String medicine) {
        medicineNameDropdown.click();
  

        finalMedicine = medicine;

        // If medicine is null or empty, generate a random medicine name
        if (medicine == null || medicine.trim().isEmpty()) {
            int length = 6;
            String alphabet = "abcdefghijklmnopqrstuvwxyz";
            StringBuilder sb = new StringBuilder();
            java.util.Random random = new java.util.Random();
            for (int i = 0; i < length; i++) {
                sb.append(alphabet.charAt(random.nextInt(alphabet.length())));
            }
            finalMedicine ="hfd"+ sb.toString();
            
        }
//        
        // type in medicine name
      
           
              
                selectSearchInput2.sendKeys(finalMedicine);
              
            
        


//        medicineNameDropdown.click();
        // check if medicine exists in dropdown list
                List<WebElement> medOptions = driver.findElements(
                	    By.xpath(
                	        "//ul[@role='menu']//li[@role='menuitem']/a/span[" +
                	        "contains(" +
                	            "translate(normalize-space(.), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ ', 'abcdefghijklmnopqrstuvwxyz'), " +
                	            "'" + medicine.toLowerCase().replaceAll("\\s+", "") + "'" +
                	        ")]"
                	    )
                	);



        if (!medOptions.isEmpty()) {
            // select existing medicine
            medOptions.get(0).click();
            System.out.println("Medicine Selected from dropdown: " + finalMedicine);
        } else if(addMedicineHeader2.isDisplayed()) {
            // add new medicine (if button available)
        	addMedicineHeader2.click();
            System.out.println("New Medicine Added: " + finalMedicine);
        }
        else {
        	addMedicineHeader.click();
        }
    }
    
    @FindBy(xpath = "//button[contains(text(),'Add') and contains(text(),'as new Medicine')]")
    private WebElement addMedicineHeader2;
    public String getGenericName() {
        return genericName.getAttribute("value");
    }

    public String getMedicineCategory() {
        return medicineCategory.getAttribute("value");
    }

    public void selectUnit(String unit) {
        unitDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + unit + "']"));
        option.click();
    }

    public void selectDosage(String dosage) {
        dosageDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + dosage + "']"));
        option.click();
    }

    public void selectFrequency(String frequency) {
        frequencyDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[@role='menu']//li[@role='menuitem']/a/span[contains(text(),'" + frequency + "')]"));
        option.click();
    }

    // ✅ NEW: Unified checkbox method
    public void checkTimes(String... times) {
        for (String time : times) {
            switch (time.toLowerCase()) {
                case "morning":
                    if (!morningCheckbox.isSelected()) morningCheckbox.click();
                    break;
                case "noon":
                    if (!noonCheckbox.isSelected()) noonCheckbox.click();
                    break;
                case "evening":
                    if (!eveningCheckbox.isSelected()) eveningCheckbox.click();
                    break;
                case "night":
                    if (!nightCheckbox.isSelected()) nightCheckbox.click();
                    break;
                default:
                    throw new IllegalArgumentException("Invalid time: " + time);
            }
        }
    }

    public void selectWhenToTaken(String when) {
        whenToTakenDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + when + "']"));
        option.click();
    }

    public void selectDuration(String duration) {
        durationDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + duration + "']"));
        option.click();
    }

    public void enterQuantity(String qty) {
        quantityInput.clear();
        quantityInput.sendKeys(qty);
    }

    public void selectRoute(String route) {
        routeDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + route + "']"));
        option.click();
    }

    public void selectInstructions(String instruction) {
        instructionsDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + instruction + "']"));
        option.click();
    }

    public void enterNotes(String notes) {
        notesTextarea.clear();
        notesTextarea.sendKeys(notes);
    }

    public void selectPerformingDoctor(String doctor) {
        performingDoctorDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + doctor + "']"));
        option.click();
    }

    public void selectPerformingNurse(String nurse) {
        performingNurseDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + nurse + "']"));
        option.click();
    }

    public void clickAddMedicine() {
    		addMedicineBtn.click();
    }
    @FindBy(xpath = "//input[@type='button' and @value='Add Medicine']")
    WebElement addMedicineButton;
//    👉 And the method to click it with JavaScript (for reliability):
//
//    java
//    Copy code
    public void clickAddMedicineButton() {
    	addMedicineButton.click();
    }
    public void clickAddPrescriptionList() {
        addPrescriptionListBtn.click();
    }

    public void clickCancel() {
        cancelBtn.click();
    }

    public void clickReset() {
        resetBtn.click();
    }

    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement txtMedicineName;

    @FindBy(xpath = "//input[@formcontrolname='medicineCode']")
    private WebElement txtMedicineCode;

    @FindBy(xpath = "//ng-select[@formcontrolname='medicineType']")
    private WebElement dropdownMedicineType;

    @FindBy(xpath = "//ng-select[@formcontrolname='medicineCategory']")
    private WebElement dropdownMedicineCategory;

    @FindBy(xpath = "//ng-select[@formcontrolname='manufactName']")
    private WebElement dropdownManufacturer;

    @FindBy(xpath = "//ng-select[@formcontrolname='genericName']//input[@role='combobox']")
    private WebElement dropdownGenericName;


    // ------------ Stock Details -------------
    @FindBy(xpath = "//ng-select[@formcontrolname='rack']")
    private WebElement dropdownRack;

    @FindBy(xpath = "//input[@formcontrolname='units']")
    private WebElement txtUnits;

    @FindBy(xpath = "//input[@formcontrolname='minQty']")
    private WebElement txtMinQty;

    @FindBy(xpath = "//input[@formcontrolname='maxQty']")
    private WebElement txtMaxQty;

    @FindBy(xpath = "//input[@formcontrolname='ReorderQty']")
    private WebElement txtReorderQty;

    @FindBy(xpath = "//input[@formcontrolname='Reorder Level']")
    private WebElement txtReorderLevel;

    @FindBy(xpath = "//ng-select[@formcontrolname='stockUnit']")
    private WebElement dropdownStockUnit;


    // ------------ Pricing & Taxation -------------
    @FindBy(xpath = "//input[@formcontrolname='hsnCode']")
    private WebElement txtHSNCode;

    @FindBy(xpath = "//ng-select[@formcontrolname='gst']")
    private WebElement dropdownGST;

    @FindBy(xpath = "//ng-select[@formcontrolname='discrequired']")
    private WebElement dropdownDiscountRequired;

    @FindBy(xpath = "//ng-select[@formcontrolname='disctype']")
    private WebElement dropdownDiscountType;

    @FindBy(xpath = "//input[@formcontrolname='discpercentage']")
    private WebElement txtDiscountPercentage;


    // ------------ Description -------------
    @FindBy(xpath = "//textarea[@formcontrolname='medDescription']")
    private WebElement txtDescription;

    @FindBy(xpath = "//input[@value='vaccineFlag']")
    private WebElement chkIsVaccine;


    // ------------ Other Attributes -------------
    @FindBy(xpath = "//input[@formcontrolname='attribute']")
    private WebElement txtAttribute;

    @FindBy(xpath = "//input[@value='Add Attribute']")
    private WebElement btnAddAttribute;

    @FindBy(xpath = "//input[@value='Reset']")
    private WebElement btnResetAttribute;


    // ------------ Price Settings -------------
    @FindBy(xpath = "//input[@formcontrolname='medCP']")
    private WebElement txtCostPrice;

    @FindBy(xpath = "//input[@formcontrolname='medMrp']")
    private WebElement txtMRP;

    @FindBy(xpath = "//input[@formcontrolname='medSellPrice']")
    private WebElement txtSellPrice;


    // ------------ Free Qty Settings -------------
    @FindBy(xpath = "//input[@formcontrolname='medQty']")
    private WebElement txtNoOfStrips;

    @FindBy(xpath = "//div[contains(@class,'header-component-left') and contains(text(),'Add Medicine')]")
    private WebElement addMedicineHeader;

    
    @FindBy(xpath = "//input[@type='button' and @value='Save']")
    private WebElement saveButton;

    public void clickSaveButton() {
    	clickWithJavaScript(saveButton);
    }
    public boolean isAddMedicinePopupDisplayed() {
        return addMedicineHeader.isDisplayed();
    }
    
    public boolean isAddMedicinePopupDisplayed2() {
        return addMedicineHeader2.isDisplayed();
    }
    @FindBy(xpath = "(//div[contains(@class,'lightbox-close')])[4]")
    private WebElement closeButton;
    
    @FindBy(xpath = "(//div[contains(@class,'lightbox-close')])[1]")
    private WebElement closeButton1;

    @FindBy(xpath = "(//div[contains(@class,'lightbox-close')])[25]")
    private WebElement closeButton2;
    // ------------ Methods -------------
    public void clickCloseButton() {
    	waitForClickability(closeButton).click();
    }
    public void clickCloseButton1() {
    	waitForClickability(closeButton1).click();
    } 
    
    public void clickCloseButton2() {
    	waitForClickability(closeButton2).click();
    } 
    public void enterMedicineName(String name) {
    	
        txtMedicineName.clear();
        txtMedicineName.sendKeys(name);
    }

    public void enterMedicineCode(String code) {
        txtMedicineCode.clear();
        txtMedicineCode.sendKeys(code);
    }

    public void selectMedicineType(String type) {
        dropdownMedicineType.click();
        driver.findElement(
            By.xpath("//div[@role='option']//span[text()='" + type + "']")
        ).click();
    }

    public void selectMedicineCategory(String category) {
        dropdownMedicineCategory.click();
        driver.findElement(
            By.xpath("//div[@role='option']//span[text()='" + category + "']")
        ).click();
    }

    public void selectManufacturer(String manufacturer) {
        dropdownManufacturer.click();
        driver.findElement(
            By.xpath("//div[@role='option']//span[text()='" + manufacturer + "']")
        ).click();
    }

    public void selectGenericName(String generic) {
        dropdownGenericName.click();
        dropdownGenericName.click();
        dropdownGenericName.click();
//        dropdownGenericName.sendKeys(generic);s
        driver.findElement(
            By.xpath("//div[@role='option']//span[text()='" + generic + "']")
        ).click();
    }

    public void selectRack(String rack) {
        dropdownRack.click();
        driver.findElement(
            By.xpath("//div[@role='option']//span[text()='" + rack + "']")
        ).click();
    }

    public void enterUnits(String units) {
        txtUnits.clear();
        txtUnits.sendKeys(units);
    }

    public void enterMinQty(String minQty) {
        txtMinQty.clear();
        txtMinQty.sendKeys(minQty);
    }

    public void enterMaxQty(String maxQty) {
        txtMaxQty.clear();
        txtMaxQty.sendKeys(maxQty);
    }

    public void enterReorderQty(String reorderQty) {
        txtReorderQty.clear();
        txtReorderQty.sendKeys(reorderQty);
    }

    public void enterReorderLevel(String reorderLevel) {
        txtReorderLevel.clear();
        txtReorderLevel.sendKeys(reorderLevel);
    }

    public void selectStockUnit(String stockUnit) {
        dropdownStockUnit.click();
        driver.findElement(
            By.xpath("//div[@role='option']//span[text()='" + stockUnit + "']")
        ).click();
    }

    public void enterHSNCode(String hsn) {
        txtHSNCode.clear();
        txtHSNCode.sendKeys(hsn);
    }

    public void selectGST(String gst) {
        dropdownGST.click();
        driver.findElement(
            By.xpath("//div[@role='option']//span[text()='" + gst + "']")
        ).click();
    }

    public void selectDiscountRequired(String option) {
        dropdownDiscountRequired.click();
        driver.findElement(
            By.xpath("//div[@role='option']//span[text()='" + option + "']")
        ).click();
    }

    public void selectDiscountType(String type) {
        dropdownDiscountType.click();
        driver.findElement(
            By.xpath("//div[@role='option']//span[text()='" + type + "']")
        ).click();
    }

    public void enterDiscountPercentage(String percentage) {
        txtDiscountPercentage.clear();
        txtDiscountPercentage.sendKeys(percentage);
    }

    public void enterDescription(String desc) {
        txtDescription.clear();
        txtDescription.sendKeys(desc);
    }

    public void checkIsVaccine() {
  
    	clickWithJavaScript(chkIsVaccine);
        
    }

    public void uncheckIsVaccine() {
        if (chkIsVaccine.isSelected()) {
            chkIsVaccine.click();
        }
    }

    public void enterAttribute(String attribute) {
        txtAttribute.clear();
        txtAttribute.sendKeys(attribute);
    }

    public void clickAddAttribute() {
        btnAddAttribute.click();
    }

    public void clickResetAttribute() {
        btnResetAttribute.click();
    }

    public void enterCostPrice(String costPrice) {
        txtCostPrice.clear();
        txtCostPrice.sendKeys(costPrice);
    }

    public void enterMRP(String mrp) {
        txtMRP.clear();
        txtMRP.sendKeys(mrp);
    }

    public void enterSellPrice(String sellPrice) {
        txtSellPrice.clear();
        txtSellPrice.sendKeys(sellPrice);
    }

    public void enterNoOfStrips(String qty) {
        txtNoOfStrips.clear();
        txtNoOfStrips.sendKeys(qty);
    }

  

}
