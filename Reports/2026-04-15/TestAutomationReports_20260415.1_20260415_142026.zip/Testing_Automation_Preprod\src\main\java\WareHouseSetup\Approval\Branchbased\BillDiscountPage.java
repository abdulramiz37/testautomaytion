package WareHouseSetup.Approval.Branchbased;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class BillDiscountPage extends Abstraction {

    public BillDiscountPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // ----------- Locators -----------

    @FindBy(xpath = "(//input[@formcontrolname='reasonName'])[2]")
    private WebElement billDiscountNameInput;

    @FindBy(xpath = "(//input[@formcontrolname='reasonCode'])[2]")
    private WebElement billDiscountCodeInput;

    @FindBy(xpath = "(//textarea[@formcontrolname='reasonDescription'])[2]")
    private WebElement billDiscountDescriptionTextarea;

    @FindBy(xpath = "(//input[@formcontrolname='isActive']/following-sibling::span[@class='checkmark'])[2]")
    private WebElement isActiveCheckboxSpan;

    @FindBy(xpath = "(//input[@type='button' and @value='Save'])[2]")
    private WebElement saveButton;

    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
    private WebElement cancelButton;

    
    @FindBy(xpath = "(//a[text()=' Add Bill Discount '])[2]")
    private WebElement addbilldiscount;
    
    @FindBy(xpath = "(//span[text()='Bill Discount'])[1]")
    private WebElement billDiscount;
    // ----------- Methods -----------

	public void clickbuttonapproval() {
		waitForClickability(billDiscount).click();
		waitForClickability(addbilldiscount).click();
	}
	
    public void enterBillDiscountName(String name) {
        waitForVisibility(billDiscountNameInput).clear();
        billDiscountNameInput.sendKeys(name);
    }

    public void enterBillDiscountCode(String code) {
        waitForVisibility(billDiscountCodeInput).clear();
        billDiscountCodeInput.sendKeys(code);
    }

    public void enterBillDiscountDescription(String description) {
        waitForVisibility(billDiscountDescriptionTextarea).clear();
        billDiscountDescriptionTextarea.sendKeys(description);
    }

    public void setIsActive(boolean shouldBeActive) {
        boolean currentlyChecked = isBillDiscountActive();
        if (shouldBeActive != currentlyChecked) {
            waitForClickability(isActiveCheckboxSpan).click();
        }
    }

    private boolean isBillDiscountActive() {
        WebElement checkboxInput = driver.findElement(
            org.openqa.selenium.By.xpath("//input[@formcontrolname='isActive']")
        );
        return checkboxInput.isSelected();
    }

    public void clickSave() {
        waitForClickability(saveButton).click();
    }

    public void clickCancel() {
        waitForClickability(cancelButton).click();
    }

    // Combined method to fill the form and save
    public void fillBillDiscountForm(String name, String code, String description, boolean isActive) {
        enterBillDiscountName(name);
        enterBillDiscountCode(code);
        enterBillDiscountDescription(description);
        setIsActive(isActive);
        clickSave();
    }
}
