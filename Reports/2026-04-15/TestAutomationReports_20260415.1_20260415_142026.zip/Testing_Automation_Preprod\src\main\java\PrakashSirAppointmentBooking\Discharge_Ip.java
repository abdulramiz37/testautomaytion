package PrakashSirAppointmentBooking;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class Discharge_Ip extends Abstraction {

    public Discharge_Ip(WebDriver driver) {
       super(driver);
         this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    @FindBy(xpath = "//span[text()='IP']")
    private WebElement ip;
    
    @FindBy(xpath = "//span[text()='Admission List']")
    private WebElement admission;
    
    @FindBy(xpath = "(//a[@href[contains(.,'NewDischargeSummary')]]//div[@class='pls-cont' and normalize-space()='Discharge Summary'])[3]")
    private WebElement dischargeSummaryLabel;

    @FindBy(xpath = "//span[@class='slider']")
    private WebElement sliderElement;

    public void opentheappointmentpage() {
        
    	waitForClickability(ip).click();
     	
    }
    public void opentheadmiison() {
    	waitForClickability(admission).click();
    }
   public void table(String name) {
    String patientName=name;
    List<WebElement> rows = driver.findElements(By.cssSelector("tr.mat-row"));
    
    for (WebElement row : rows) {
        try {
            // Find the patient name element in this row
            WebElement nameElement = row.findElement(By.cssSelector("h4[style*='word-wrap: break-word']"));
            System.out.println(nameElement);
            // If this is the patient we're looking for
            if (nameElement.getText().toLowerCase().contains(patientName.toLowerCase())) {
                // Find and click the action button (three dots)
                WebElement actionButton = row.findElement(By.cssSelector("div.three-dots"));
                actionButton.click();
                System.out.println("Clicked action button for patient: " + patientName);
         break;
            }
        } catch (Exception e) {
            continue;
        }
        
        
    }
    
    System.out.println("Patient '" + patientName + "' not found");
    
  

   }
   public void clickDischargeSummary() {
	    dischargeSummaryLabel.click();
	}
   public void clickSlider() {
	    sliderElement.click();
	}

}

