package Lab;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import EzionAbstractionComponents.Abstraction;

public class Re_TestPage extends Abstraction{
	public Re_TestPage(WebDriver driver) {
		super(driver);
	    PageFactory.initElements(driver, this);
	}

	// PageFactory locator
	@FindBy(xpath = "//input[@type='button' and @value='Generate Work Order']")
	private WebElement generateWorkOrderButton;

	// Method to click the button


	public void clickCheckboxForTest(String testName) {
	    boolean isFound = false;
	    int pageCount = 0;
	    int maxPagesToCheck = 5; // Prevent infinite loops

	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    while (!isFound && pageCount < maxPagesToCheck) {
	        pageCount++;

	        // ✅ Wait for table rows to appear before scanning
	        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
	            By.xpath("//tr[contains(@class,'ng-star-inserted')]")
	        ));

	        List<WebElement> rows = driver.findElements(
	            By.xpath("//tr[contains(@class,'ng-star-inserted')]")
	        );

	        System.out.println("🔍 Found " + rows.size() + " rows on page " + pageCount);

	        for (WebElement row : rows) {
	            try {
	                // ✅ Locate cell containing the test name (case-insensitive)
	                WebElement testNameElement = row.findElement(By.xpath(
	                    ".//td[contains(translate(normalize-space(.), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '" 
	                    + testName.toLowerCase() + "')]"
	                ));

	                String actualTestName = testNameElement.getText().trim();
	                System.out.println("   Found test: " + actualTestName);

	                if (actualTestName.equalsIgnoreCase(testName)) {
	                    WebElement checkbox = row.findElement(By.xpath(".//input[@type='checkbox']"));

	                    // ✅ Wait until clickable and click
	                    wait.until(ExpectedConditions.elementToBeClickable(checkbox));
	                    if (!checkbox.isSelected()) {
	                        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", checkbox);
	                        System.out.println("✅ Clicked checkbox for test: " + testName);
	                    } else {
	                        System.out.println("ℹ️ Checkbox already selected for test: " + testName);
	                    }

	                    isFound = true;
	                    break;
	                }
	            } catch (NoSuchElementException e) {
	                // Ignore rows that don’t match
	            } catch (StaleElementReferenceException e) {
	                System.out.println("⚠️ Row went stale while scanning, retrying...");
	            }
	        }

	        // ✅ Move to next page if not found
	        if (!isFound) {
	            try {
	                WebElement nextButton = driver.findElement(By.xpath(
	                    "//i[contains(@class, 'fa-chevron-right')]/ancestor::a[not(contains(@class,'disabled'))]"
	                ));
	                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", nextButton);
	                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextButton);
	                System.out.println("➡️ Moving to next page...");
	            } catch (NoSuchElementException e) {
	                System.out.println("❌ No more pages available");
	                break;
	            } catch (Exception e) {
	                System.out.println("⚠️ Error navigating to next page: " + e.getMessage());
	                break;
	            }
	        }
	    }

	    if (!isFound) {
	        System.out.println("❌ Test '" + testName + "' not found after checking " + pageCount + " pages");
	        throw new NoSuchElementException("Test '" + testName + "' not found in the list");
	    }
	}

	public void clickGenerateWorkOrder() {
	    waitForClickability(generateWorkOrderButton).click();
	    System.out.println("✅ Clicked 'Generate Work Order' button");
	}
	
	// Requested By - Employee radio button
	@FindBy(xpath = "//input[@name='requestedBy' and @value='1']")
	private WebElement requestedByEmployeeRadio;

	// Requested By dropdown
	@FindBy(xpath = "(//ngx-select[@placeholder='Select'])[1]")
	private WebElement requestedByDropdown;

	// Approved By - Employee radio button
	@FindBy(xpath = "//input[@name='approvedBy' and @value='2']")
	private WebElement approvedByEmployeeRadio;

	// Approved By dropdown
	@FindBy(xpath = "(//ngx-select[@placeholder='Select'])[2]")
	private WebElement approvedByDropdown;

	// Generate Work Order button
	@FindBy(xpath = "(//input[@type='button' and @value='Generate Work Order'])[2]")
	private WebElement generateWorkOrderButton2;

	// Method for Requested By
	public void selectRequestedByEmployee(String employeeName) {
	    waitForClickability(requestedByEmployeeRadio).click();
	    waitForClickability(requestedByDropdown).click();
	    WebElement option = driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//a[normalize-space()='" + employeeName + "']"));
	    waitForClickability(option).click();
	    System.out.println("✅ Requested By selected: " + employeeName);
	}

	// Method for Approved By
	public void selectApprovedByEmployee(String employeeName) {
	    waitForClickability(approvedByEmployeeRadio).click();
	    waitForClickability(approvedByDropdown).click();
	    WebElement option = driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')][1]//a[normalize-space()='" + employeeName + "']"));
	    waitForClickability(option).click();
	    System.out.println("✅ Approved By selected: " + employeeName);
	    clickGenerateWorkOrder2();
	}

	// Click Generate Work Order
	public void clickGenerateWorkOrder2() {
	    waitForClickability(generateWorkOrderButton2).click();
	    System.out.println("✅ Clicked Generate Work Order");
	}

}
