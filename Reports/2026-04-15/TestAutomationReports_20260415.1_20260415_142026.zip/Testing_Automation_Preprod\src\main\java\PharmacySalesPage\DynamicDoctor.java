
package PharmacySalesPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class DynamicDoctor extends Abstraction {

    WebDriver driver;

    public DynamicDoctor(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // ===== Physician Details =====

    @FindBy(xpath = "//input[@formcontrolname='name']")
    WebElement physicianNameInput;

    @FindBy(xpath = "//input[@formcontrolname='lastName']")
    WebElement lastNameInput;

    @FindBy(xpath = "//input[@formcontrolname='displayName']")
    WebElement displayNameInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='gender']")
    WebElement genderDropdown;

    @FindBy(xpath = "//input[@formcontrolname='dob']")
    WebElement dobInput;

    @FindBy(xpath = "//input[@formcontrolname='age']")
    WebElement ageInput;

    @FindBy(xpath = "//input[@formcontrolname='email']")
    WebElement emailInput;

    @FindBy(xpath = "//input[@formcontrolname='mobile']")
    WebElement mobileInput;

    @FindBy(xpath = "//input[@formcontrolname='altMobile']")
    WebElement altMobileInput;

    @FindBy(xpath = "//input[@formcontrolname='workPhone']")
    WebElement workPhoneInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='appointmentBookingType']")
    WebElement appointmentBookingDropdown;

    @FindBy(xpath = "//input[@formcontrolname='panNo']")
    WebElement panCardInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='departmentId']")
    WebElement departmentDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='jobType']")
    WebElement jobTypeDropdown;

    // ===== Communication Address =====

    @FindBy(xpath = "//input[@formcontrolname='streetName']")
    WebElement streetInput;

    @FindBy(xpath = "//input[@formcontrolname='address']")
    WebElement areaInput;

    @FindBy(xpath = "//input[@formcontrolname='pincode']")
    WebElement pincodeInput;

    @FindBy(xpath = "//input[@formcontrolname='city']")
    WebElement cityInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='districtId']")
    WebElement districtDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='stateId']")
    WebElement stateDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='countryId']")
    WebElement countryDropdown;

    @FindBy(xpath = "//input[@formcontrolname='isActive']")
    WebElement isActiveCheckbox;

    // ===== Buttons =====
    @FindBy(xpath = "//input[@value='Save']")
    WebElement saveButton;

    @FindBy(xpath = "//input[@value='Clear']")
    WebElement clearButton;

    // ===== Methods =====

    public void enterPhysicianName(String name) {
        physicianNameInput.clear();
        physicianNameInput.sendKeys(name);
    }

    public void enterLastName(String lastName) {
        lastNameInput.clear();
        lastNameInput.sendKeys(lastName);
    }

    public void enterDisplayName(String displayName) {
        displayNameInput.clear();
        displayNameInput.sendKeys(displayName);
    }

    public void selectGender(String gender) {
        genderDropdown.click();
        WebElement option = driver.findElement(
            By.xpath("//ngx-select[@formcontrolname='gender']//span[text()='" + gender + "']"));
        option.click();
    }

    public void enterDOB(String dob) {
        dobInput.clear();
        dobInput.sendKeys(dob);
    }

    public void enterAge(String age) {
        ageInput.clear();
        ageInput.sendKeys(age);
    }

    public void enterEmail(String email) {
        emailInput.clear();
        emailInput.sendKeys(email);
    }

    public void enterMobile(String mobile) {
        mobileInput.clear();
        mobileInput.sendKeys(mobile);
    }

    public void enterAltMobile(String altMobile) {
        altMobileInput.clear();
        altMobileInput.sendKeys(altMobile);
    }

    public void enterWorkPhone(String phone) {
        workPhoneInput.clear();
        workPhoneInput.sendKeys(phone);
    }

    public void selectAppointmentBookingType(String type) {
        appointmentBookingDropdown.click();
        WebElement option = driver.findElement(
            By.xpath("//ngx-select[@formcontrolname='appointmentBookingType']//span[text()='" + type + "']"));
        option.click();
    }

    public void enterPanCard(String pan) {
        panCardInput.clear();
        panCardInput.sendKeys(pan);
    }

    public void selectDepartment(String department) {
        departmentDropdown.click();
        WebElement option = driver.findElement(
            By.xpath("//ngx-select[@formcontrolname='departmentId']//span[text()='" + department + "']"));
        option.click();
    }

    public void selectJobType(String jobType) {
        jobTypeDropdown.click();
        WebElement option = driver.findElement(
            By.xpath("//ngx-select[@formcontrolname='jobType']//span[text()='" + jobType + "']"));
        option.click();
    }

    public void fillCommunicationAddress(String street, String area, String pincode, String city) {
        streetInput.sendKeys(street);
        areaInput.sendKeys(area);
        pincodeInput.sendKeys(pincode);
        cityInput.sendKeys(city);
    }

    public void selectDistrict(String district) {
        districtDropdown.click();
        WebElement option = driver.findElement(
            By.xpath("//ngx-select[@formcontrolname='districtId']//span[text()='" + district + "']"));
        option.click();
    }

    public void selectState(String state) {
        stateDropdown.click();
        WebElement option = driver.findElement(
            By.xpath("//ngx-select[@formcontrolname='stateId']//span[text()='" + state + "']"));
        option.click();
    }

    public void selectCountry(String country) {
        countryDropdown.click();
        WebElement option = driver.findElement(
            By.xpath("//ngx-select[@formcontrolname='countryId']//span[text()='" + country + "']"));
        option.click();
    }

    public void toggleIsActive(boolean status) {
        if (isActiveCheckbox.isSelected() != status) {
            isActiveCheckbox.click();
        }
    }

    public void clickSave() {
        saveButton.click();
    }

    public void clickClear() {
        clearButton.click();
    }
}
