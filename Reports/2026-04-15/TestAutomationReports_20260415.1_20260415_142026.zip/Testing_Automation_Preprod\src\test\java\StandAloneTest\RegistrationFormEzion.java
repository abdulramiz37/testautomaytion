package StandAloneTest;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RegistrationFormEzion {
	public static void main(String []args) throws InterruptedException {
		WebDriver driver = new EdgeDriver();
//		driver.get("https://apps.ezovion.com/auth/login");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://apps.ezovion.com/auth/login");

		driver.manage().window().maximize();
		

		driver.findElement(By.xpath("//div[@class=\"form-control-group\"]//input")).sendKeys("25889229");
		driver.findElement(By.xpath("//button[@size=\"large\"]")).click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
	        // Wait until the button with text "CONTINUE" is clickable
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
		
	     driver.findElement(By.xpath("//input[@placeholder=\"Mobile No\"]")).sendKeys("2588922905");
		driver.findElement(By.xpath("//input[@placeholder=\"Password\"]")).sendKeys("Ezovion@33");
		
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@status=\"primary\"]")));
		 Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@status=\"primary\"]")).click();
//	driver.findElement(By.xpath("//button[@status=\"primary\"]")).click();
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//li[@class=\"alert-message\"]")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Registration']")));

		 driver.findElement(By.xpath("//span[text()=\"Registration\"]")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='New Registration']"))).click();

		// Click on the first "Select"
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]")));

		// Click on "Mr."
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Mr.']"))).click();

		// Enter First Name
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@formcontrolname='firstname']"))).sendKeys("John");

		// Enter Middle Name
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@formcontrolname='middlename']"))).sendKeys("K");

		// Enter Last Name
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@formcontrolname='lastname']"))).sendKeys("Doe");

		// Click on Gender "Select"
//		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Select']"))).click();
//
		// Choose "Male"
//		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Male']"))).click();

		// Enter DOB placeholder field
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='DD/MM/YYYY']"))).click();

		// Open calendar: Click on month/year chooser
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@aria-label='Choose month and year']"))).click();

		// Navigate back 21 years
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@aria-label='Previous 21 years']"))).click();

		// Select year "1999"
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//td[@aria-label='1999']"))).click();

		// Select month "May 1999"
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//td[@aria-label='May 1999']"))).click();

		// Select date "May 12, 1999"
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//td[@aria-label='May 12, 1999']"))).click();

		// Enter Mobile Number
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@formcontrolname='mobile']"))).sendKeys("9876543210");

		// Click on "Save"
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();
		
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Registration']"))).click();

		// Click on "Patient List"
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Patient List']"))).click();

		// Click on the first "three dots" menu
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='three-dots relative'])[1]"))).click();

		// Click on the 4th patient image container
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='pls-img-cont'])[4]"))).click();

		// Click on "Select" input
//		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Select']"))).click();
	 // Click on "Cardiology"
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Cardiology']"))).click();
//	    	Thread.sleep(2000);
	    // Click on "Dr. Malik"
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Dr. Malik']"))).click();
	    
	    // Wait for and click on the 4th ngx-select dropdown
//	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='ngx-select dropdown'])[4]"))).click();
//	    Thread.sleep(2000);
	    // Click on "APPEARANCE"
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='APPEARANCE']"))).click();

	    // Enter value in the 4th input textbox
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@type='text'])[4]"))).sendKeys("45");

	    // Click on "Add"
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Add']"))).click();

	    // Click on the first "Save" button
//	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@value='Save'])[1]"))).click();
	    
	  //input[@placeholder="Select"]
	  //span[text()="Cardiology"]
	 
	  
	  //span[text()="Rate"]

	    
	    

	  
	    		
	}
}
