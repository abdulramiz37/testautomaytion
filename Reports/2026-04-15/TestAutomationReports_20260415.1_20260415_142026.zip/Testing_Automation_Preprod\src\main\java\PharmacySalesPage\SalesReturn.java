package PharmacySalesPage;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeoutException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import EzionAbstractionComponents.Abstraction;

public class SalesReturn extends Abstraction {


    WebDriver driver;

    public SalesReturn(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    public void clickSalesReturnByMobile(String targetMobileNumber) {

        boolean isFound = false;
        int pageClickCount = 0;

        By rowsLocator =
            By.xpath("(//table[contains(@class,'table-hover')]/tbody)[2]/tr");

        By nextBtnLocator =
            By.xpath("(//i[contains(@class,'fa-chevron-right')])[1]/ancestor::a");

        while (!isFound) {

            // ✅ Wait for rows to be present
            List<WebElement> rows = waitForPresenceOfAll(rowsLocator);

            for (int i = 0; i < 10; i++) {
                try {
                    WebElement row = rows.get(i);

                    WebElement mobileElement = row.findElement(
                        By.xpath(".//td[contains(@class,'doctor-notes-td-doc')]//p[contains(@style,'color')]")
                    );

                    String mobileNumber = mobileElement.getText().trim();
                    System.out.println("📱 Found: " + mobileNumber);

                    if (mobileNumber.equals(targetMobileNumber)) {

                        WebElement salesReturnBtn = row.findElement(
                            By.xpath(".//a[@title='Sales Return Adjustment']")
                        );

                        clickWithJavaScript(salesReturnBtn);

                        System.out.println("✅ Clicked Sales Return Adjustment for: " + mobileNumber);
                        isFound = true;
                        break;
                    }

                } catch (NoSuchElementException | StaleElementReferenceException e) {
                    System.out.println("⚠️ Skipping row " + i);
                }
            }

            // ➡️ Move to next page if not found
            if (!isFound) {

                if (pageClickCount >= 14) {
                    System.out.println("⛔ Reached page limit. Mobile not found.");
                    break;
                }

                try {
                    WebElement firstRow = rows.get(0);

                    WebElement nextButton = waitForClickability(nextBtnLocator);
                    clickWithJavaScript(nextButton);

                    pageClickCount++;
                    System.out.println("➡️ Moving to next page... (" + pageClickCount + ")");

                    // 🔥 KEY: wait until old rows are gone (Angular reload)
                    new WebDriverWait(driver, Duration.ofSeconds(30))
                            .until(ExpectedConditions.stalenessOf(firstRow));

                    // 🔥 Wait for new rows
                    waitForPresenceOfAll(rowsLocator);

                } catch (Exception e) {
                    System.out.println("❌ Next page navigation failed.");
                    break;
                }
            }
        }

        if (!isFound) {
            throw new RuntimeException(
                "Mobile number not found in Sales Return table: " + targetMobileNumber
            );
        }
    }
    public By adjustAmountByBillNo(String billNo) {
        return By.xpath(
            "//div[contains(@class,'purchase-table')]//tbody//tr[td[2][normalize-space()='" 
            + billNo + "']]//input[@type='number']"
        );
    }

    public void enterAdjustAmount(String billNo, String amount) {
        WebElement input = driver.findElement(adjustAmountByBillNo(billNo));
        input.clear();
        input.sendKeys(amount);
    }

}
