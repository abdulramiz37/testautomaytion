package TestComponents.PharmacyUpdates;

import java.awt.AWTException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EzionpageObjects.UserIdPage;
import PharmacySalesPage.PatientDetails;
import PharmacySalesPage.SalesPage;
import PharmacySalesPage.SalesReturnPage;
import PharmacySalesPage.SearchAndReturnBill;
import Registration.NewRegistrationPage;
import abdulTest.BaseTest;

public class SalesNewUpdates extends BaseTest{
	 UserIdPage data;
	  NewRegistrationPage registrationPage ;
	  @Test(dataProvider = "getDataForLogin",priority = 1)
	 public void Login(HashMap<String, String> input) throws InterruptedException {
	       // Login
//	       data = login.login(EnvUtil.get("USER_ID"));
//	       data.enterMobileNumber(EnvUtil.get("PERSON_ID"));
//	       data.enterPassword(EnvUtil.get("PASSWORD"));
	//
//	       data.clickContinue();
		   String userId = prop.getProperty("USER_ID");
	       String personId = prop.getProperty("PERSON_ID");
	       String password = prop.getProperty("PASSWORD");
	       String browser = System.getProperty("BROWSER");
	       data = login.login(userId);
	       data.enterMobileNumber(personId);
	       data.enterPassword(password);
	       data.clickContinue();
	       System.out.println("Browser: " + browser);
//	       System.out.println("Base URL: " + baseUrl);
	       System.out.println("User ID: " + userId);
	       System.out.println("Person ID: " + personId);
	       data.clickContinue();
	//   Thread.sleep(8000);
	       }
	   String targetMobileNumber;
	   String targetFirstname;
	   @Test(dataProvider = "getDataForLogin",priority = 2)
	   public void patientName(HashMap<String, String> input) throws InterruptedException {
		   Thread.sleep(3000);	 
	       // Step 1: Search patient
	       registrationPage = new NewRegistrationPage(driver);

	       // Call the fillNewRegistrationForm method with all necessary form values
	       registrationPage.clickbuttonapproval();
	       registrationPage.selectTitle();
	       registrationPage.selectOptionFromNgxDropdown("Mr.");
	       registrationPage.enterFirstName("");
	       targetFirstname=registrationPage.storedFirstName;
	       registrationPage.enterMiddleName("doe");
	       registrationPage.enterLastName("abraham");
	       registrationPage.selectGender();
	       registrationPage.selectOptionFromNgxDropdown("Male");
	       registrationPage.enterDOB("12/12/2024");
	       registrationPage.enterMobileNumber("");
	       targetMobileNumber=registrationPage.lastEnteredMobileNumber;
	       registrationPage.selectNationality("Indian");
//	       targetMobileNumber="7411081113";
	       registrationPage.save();

	//System.out.println(targetMobileNumber);
	   } 
	   
	   public static List<Map<String, String>> collectedMedicineDetails1 = new ArrayList<>();
	   String batchNumber1;
	   String stocks1;

	   @Test(dataProvider = "getDataForLogin", priority = 19)
	   public void salesreturn(HashMap<String, String> input) throws InterruptedException, AWTException {
	       data.navigateSalesWithRetry2();
	       Thread.sleep(5000);
	       String billNo;

	       // Step 2: Sales Page Flow
	       SalesPage salesPage = new SalesPage(driver);
	       salesPage.createSalesFlow3(
	               input.getOrDefault("mobile", targetMobileNumber), 
	               input.getOrDefault("customerName",targetFirstname ), 
	               "Dr.  Izaan"
	       );

	       // Step 3: Add Medicines in Sales
	       List<String> medicines1 = List.of("syrup14", "medicine1syrup");
	       List<String> quantities = new ArrayList<>();
	       List<String> discounts = new ArrayList<>();

	       for (String medicine : medicines1) {
	           salesPage.selectMedicines(List.of(medicine));

	           // Get batch & stock
	           batchNumber1 = salesPage.getBatchNumber();
	           stocks1 = salesPage.getStickQuantity();

	           Map<String, String> details = new HashMap<>();
	           details.put("Medicine", medicine);
	           details.put("Batch", batchNumber1);
	           details.put("Stock", stocks1);

	           salesPage.qty("2");
	           salesPage.addbtn();

	           // add values for return flow
	           quantities.add("2");
	           discounts.add("5");
	           collectedMedicineDetails1.add(details);
	       }

	       // Step 4: Save Bill
	       PatientDetails patientPage = new PatientDetails(driver);
	       patientPage.clickSaveButton();
	       patientPage.yesButton();
	 
	       billNo = salesPage.getBillNumber();
	       System.out.println("✅ Generated Bill No: " + billNo);
	       patientPage.clickBackButton();
	       // Step 5: Search and navigate to Return page
	       SearchAndReturnBill searchBill = salesPage.search();
	       searchBill.searchAndReturnBill(billNo);
	  
	       // Step 6: Execute the Return Flow
	       SalesReturnPage returnPage = new SalesReturnPage(driver);

	       // use the same lists for return flow
	       returnPage.processSalesReturn(medicines1, quantities, discounts);
	       returnPage.savetheSales();
	   }
	   @DataProvider
	   public Object[][] getDataForLogin() throws IOException {
	       List<HashMap<String, String>> data = getJsonDataToMap(
	           System.getProperty("user.dir") + "//src//main//java//ezion//Resources//AppointMent.json"
	       );
	       return new Object[][] { { data.get(0) } };
	   }
}
