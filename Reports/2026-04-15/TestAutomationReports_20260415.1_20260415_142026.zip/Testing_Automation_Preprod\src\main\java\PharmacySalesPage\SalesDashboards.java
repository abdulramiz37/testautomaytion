package PharmacySalesPage;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class SalesDashboards extends Abstraction {

	public SalesDashboards(WebDriver driver) {
		super(driver);
        PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "//a[.//span[normalize-space()='Sales Dashboard']]")
	private WebElement salesDashboardLink;

	public void openSalesDashboard() {
	    salesDashboardLink.click();
	}
	
	@FindBy(xpath = "//a[contains(@class,'btn-family') and contains(text(),'Wanted Medicine')]")
	private WebElement wantedMedicineBtn;
	
	public void clickWantedMedicine() {
	    wantedMedicineBtn.click();
	}
	@FindBy(xpath = "//a[normalize-space()='Add Medicine Shortage Book']")
	private WebElement addMedicineShortageBookBtn;
	
	
	public void clickAddMedicineShortageBook() {
	    addMedicineShortageBookBtn.click();
	}
	@FindBy(xpath = "(//span[normalize-space()='Patient List'])[2]")
	private WebElement patientListTab;

	public void clickPatientList() {
	    patientListTab.click();
	}
	By nextPageBtn = By.xpath("//tbody//tr[td[normalize-space(text()[1])='']]/ancestor::div[1]//i[@class='fas fa-chevron-right']");

	public boolean clickNewBillForPatient(String targetPatientName) {
	    boolean isFound = false;
	    int clickCount = 0;
	    while (!isFound) {
	        // Get all rows in the table
	        List<WebElement> rows = waitForPresenceOfAll(
	            By.xpath("(//table)[2][contains(@class,'table')]/tbody/tr")
	        );

	        for (int i = 0; i < rows.size(); i++) {
	            try {
	                WebElement row = rows.get(i);

	                // Patient Name is in td[3]
	                String mobileNumber = row.findElement(By.xpath("./td[5]")).getText().trim();

	                if (mobileNumber.equalsIgnoreCase(targetPatientName)) {
	                    // Find the "New Bill" icon inside the last column
	                    WebElement newBillIcon = row.findElement(
	                        By.xpath(".//td[last()]//img[contains(@src,'add_to_queue.png')]")
	                    );

	                    ((JavascriptExecutor) driver).executeScript(
	                        "arguments[0].scrollIntoView(true);", newBillIcon
	                    );
	                    waitForClickability(newBillIcon).click();

	                    System.out.println("✅ Clicked New Bill for Patient: " + mobileNumber);
	                    isFound = true;
	                    break;
	                }
	            } catch (NoSuchElementException e) {
	                System.out.println("⚠️ Skipping row " + i + " due to missing elements");
	            }
	        }

	           // counter for next page clicks

	     // If not found → try next page
	     if (!isFound) {
	         try {
	             WebElement nextPage = driver.findElement(By.xpath("//tbody//tr[td[normalize-space(text()[1])='']]/ancestor::div[1]//i[@class='fas fa-chevron-right']"));

	             // Check if the <a> itself is disabled
	             String classAttr = nextPage.getAttribute("class");
	             if (classAttr != null && classAttr.contains("disabled")) {
	                 System.out.println("❌ Reached last page. Patient not found.");
	                 break;
	             }

	             // Stop after 14 clicks
	             if (clickCount >= 20) {
	                 System.out.println("⛔ Stopped after 14 clicks. Patient not found.");
	                 break;
	             }

	             // Scroll and click next page
	             ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", nextPage);
	             ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextPage);

	             clickCount++;
	             System.out.println("➡️ Moving to next page... (Click " + clickCount + ")");
	         } catch (NoSuchElementException e) {
	             System.out.println("❌ Next page button not found. Ending search.");
	             break;
	         }
	     }


	    }

	    return isFound;
	}

	
	public boolean checkforunbilledlist(String targetPatientName) {
	    boolean isFound = false;

	    while (!isFound) {
	        // Get all rows in the table
	        List<WebElement> rows = waitForPresenceOfAll(
	            By.xpath("(//table[contains(@class,'table')])[2]/tbody/tr")
	        );

	        for (int i = 0; i < rows.size(); i++) {
	            try {
	                WebElement row = rows.get(i);

	                // Patient Name is in td[3]
	                String mobileNumber = row.findElement(By.xpath("./td[4]")).getText().trim();

	                if (mobileNumber.equalsIgnoreCase(targetPatientName)) {
	                    // Find the "New Bill" icon inside the last column
	                    WebElement newBillIcon = row.findElement(
	                        By.xpath(".//td[last()]//img[contains(@src,'edit.png')]")
	                    );

	                    ((JavascriptExecutor) driver).executeScript(
	                        "arguments[0].scrollIntoView(true);", newBillIcon
	                    );
	                    waitForClickability(newBillIcon).click();

	                    System.out.println("✅ Clicked New Bill for Patient: " + mobileNumber);
	                    isFound = true;
	                    break;
	                }
	            } catch (NoSuchElementException e) {
	                System.out.println("⚠️ Skipping row " + i + " due to missing elements");
	            }
	        }

	        // If not found → try next page
	        if (!isFound) {
	            try {
	                WebElement nextPage = driver.findElement(By.xpath("(//div[@class='pagi-block pagi-block-right']//a)[2]"));

	                // Check if the <a> itself is disabled
	                String classAttr = nextPage.getAttribute("class");
	                if (classAttr != null && classAttr.contains("disabled")) {
	                    System.out.println("❌ Reached last page. Patient not found.");
	                    break;
	                }

	                // Scroll and click next page
	                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", nextPage);
	                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextPage);

	                System.out.println("➡️ Moving to next page...");
	            } catch (NoSuchElementException e) {
	                System.out.println("❌ Next page button not found. Ending search.");
	                break;
	            }
	        }

	    }

	    return isFound;
	}

	
	public boolean checkForArchiveOrNewBill(String targetPatientName, String actionType) {
	    boolean isFound = false;

	    while (!isFound) {
	        // Get all rows in the table
	        List<WebElement> rows = waitForPresenceOfAll(
	            By.xpath("(//table[contains(@class,'table')])[3]/tbody/tr")
	        );

	        for (int i = 0; i < rows.size(); i++) {
	            try {
	                WebElement row = rows.get(i);
	                int clickCount = 0;
	                // Patient Name → based on td[5]/p
	                String patientName = row.findElement(By.xpath("./td[5]/p")).getText().trim();

	                if (patientName.equalsIgnoreCase(targetPatientName)) {
	                    WebElement targetIcon = null;

	                    if (actionType.equalsIgnoreCase("NewBill")) {
	                        // Locate New Bill icon
	                        targetIcon = row.findElement(
	                            By.xpath(".//td[last()]//img[contains(@src,'add_to_queue.png')]")
	                        );
	                    } else if (actionType.equalsIgnoreCase("Archive")) {
	                        // Locate Archive / UnArchive icon
	                        targetIcon = row.findElement(
	                            By.xpath(".//td[last()]//img[contains(@src,'archive.png')]")
	                        );
	                    }

	                    if (targetIcon != null) {
	                        ((JavascriptExecutor) driver).executeScript(
	                            "arguments[0].scrollIntoView(true);", targetIcon
	                        );
	                        waitForClickability(targetIcon).click();

	                        System.out.println("✅ Clicked " + actionType + " for Patient: " + patientName);
	                        isFound = true;
	                        break;
	                    }
	                }
	            } catch (NoSuchElementException e) {
	                System.out.println("⚠️ Skipping row " + i + " due to missing elements");
	            }
	        }

	        // If not found → go next page
	        if (!isFound) {
	            try {
	                WebElement nextPage = driver.findElement(
	                    By.xpath("(//div[@class='pagi-block pagi-block-right']//a)[1]")
	                );

	                String classAttr = nextPage.getAttribute("class");
	                if (classAttr != null && classAttr.contains("disabled")) {
	                    System.out.println("❌ Reached last page. Patient not found.");
	                    break;
	                }

	                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", nextPage);
	                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextPage);

	                System.out.println("➡️ Moving to next page...");
	            } catch (NoSuchElementException e) {
	                System.out.println("❌ Next page button not found. Ending search.");
	                break;
	            }
	        }
	    }

	    return isFound;
	}


	By nextPageBtn2 = By.xpath("(//div[contains(@class,'pagi-block-right')]//i[contains(@class,'fa-chevron-right')])[2]");

	public boolean clickfornewipbill(String targetPatientMobile) {
	    boolean isFound = false;
	    int clickCount = 0;

	    while (!isFound) {
	        // Get all <li> patient blocks
	        List<WebElement> patientCards = waitForPresenceOfAll(
	            By.xpath("//div[@class='ph-bills-hold-lists']//li[.//div[contains(@class,'ph-bills-hold-desc')]]")
	        );

	        for (WebElement card : patientCards) {
	            try {
	                String mobileNumber = card.findElement(
	                    By.xpath(".//div[contains(@class,'ph-bills-hold-desc')]/p[3]")
	                ).getText().split("/")[0].trim();

	                System.out.println(mobileNumber);

	                if (mobileNumber.equalsIgnoreCase(targetPatientMobile)) {
	                    // Scroll the card to the center of viewport
	                    ((JavascriptExecutor) driver).executeScript(
	                        "arguments[0].scrollIntoView({block: 'center', inline: 'nearest'});", card
	                    );

	                    // Hover over the card to make icon visible
	                    Actions actions = new Actions(driver);
	                    actions.moveToElement(card)
	                           .pause(Duration.ofSeconds(2))
	                           .perform();

	                    // Locate the New Bill icon
	                    WebElement newBillIcon = card.findElement(
	                        By.xpath(".//div[contains(@class,'ph-bills-hold-right')]//img[contains(@src,'add_to_queue.png')]")
	                    );

	                    // Scroll icon to center (extra safety)
	                    ((JavascriptExecutor) driver).executeScript(
	                        "arguments[0].scrollIntoView({block: 'center', inline: 'nearest'});", newBillIcon
	                    );

	                    // Wait until clickable, then click
	                    waitForClickability(newBillIcon).click();

	                    System.out.println("✅ Clicked New Bill for Patient Mobile: " + mobileNumber);
	                    isFound = true;
	                    break;
	                }

	            } catch (NoSuchElementException e) {
	                System.out.println("⚠️ Skipping card due to missing elements");
	            }
	        }

	        // If not found → try next page
	        if (!isFound) {
	            try {
	                if (clickCount >= 14) {
	                    System.out.println("⛔ Stopped after 14 clicks. Patient not found.");
	                    break;
	                }

	                WebElement nextPage = driver.findElement(nextPageBtn2);
	                String classAttr = nextPage.getAttribute("class");
	                if (classAttr != null && classAttr.contains("disabled")) {
	                    System.out.println("❌ Reached last page. Patient not found.");
	                    break;
	                }

	                // Scroll next page button into view and click
	                ((JavascriptExecutor) driver).executeScript(
	                    "arguments[0].scrollIntoView({block: 'center', inline: 'nearest'});", nextPage
	                );
	                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextPage);

	                clickCount++;
	                System.out.println("➡️ Moving to next page... (Click " + clickCount + ")");
	   
	            } catch (NoSuchElementException  e) {
	                System.out.println("❌ Next page button not found or interrupted. Ending search.");
	                break;
	            }
	        }
	    }

	    return isFound;
	}

	By nextPageBtn222 = By.xpath("//div[contains(@class,'pagi-block-right')]//i[contains(@class,'fa-chevron-right')]");

	public boolean clickfornewipbill2(String targetPatientMobile) {
	    boolean isFound = false;
	    int clickCount = 0;

	    while (!isFound) {
	        List<WebElement> patientCards = waitForPresenceOfAll(
	            By.xpath("//ul//li[.//div[contains(@class,'ph-bills-hold-desc')]]")
	        );

	        for (WebElement card : patientCards) {
	            try {
	                String mobileNumber = card.findElement(
	                    By.xpath(".//div[contains(@class,'ph-bills-hold-desc')]/p[3]")
	                ).getText().split("/")[0].trim();

	                System.out.println("📱 Found Mobile: " + mobileNumber);

	                if (mobileNumber.equalsIgnoreCase(targetPatientMobile)) {
	                    ((JavascriptExecutor) driver).executeScript(
	                        "arguments[0].scrollIntoView({block: 'center'});", card
	                    );

	                    new Actions(driver)
	                        .moveToElement(card)
	                        .pause(Duration.ofSeconds(1))
	                        .perform();

	                    WebElement newBillIcon = card.findElement(
	                        By.xpath(".//div[contains(@class,'ph-bills-hold-right')]//img[contains(@src,'add_to_queue.png')]")
	                    );

	                    waitForClickability(newBillIcon).click();

	                    System.out.println("✅ Clicked 'New Bill' for patient mobile: " + mobileNumber);
	                    isFound = true;
	                    break;
	                }

	            } catch (NoSuchElementException e) {
	                System.out.println("⚠️ Skipping card due to missing elements");
	            }
	        }

	        if (!isFound) {
	            try {
	                if (clickCount >= 14) {
	                    System.out.println("⛔ Stopped after 14 page checks. Patient not found.");
	                    break;
	                }

	                WebElement nextPage = driver.findElement(nextPageBtn222);
	                String classAttr = nextPage.getAttribute("class");
	                if (classAttr != null && classAttr.contains("disabled")) {
	                    System.out.println("❌ Reached last page. Patient not found.");
	                    break;
	                }

	                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", nextPage);
	                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextPage);

	                clickCount++;
	                System.out.println("➡️ Moving to next page... (" + clickCount + ")");

	            } catch (NoSuchElementException e) {
	                System.out.println("❌ Next page button not found. Ending search.");
	                break;
	            }
	        }
	    }

	    return isFound;
	}

	By nextPageBtn22 = By.xpath("(//div[contains(@class,'pagi-block-right')]//i[contains(@class,'fa-chevron-right')])[2]");

	public boolean clickForNewIpBill2(String targetPatientMobile, String actionType) {
	    boolean isFound = false;
	    int clickCount = 0;

	    while (!isFound) {
	        // Get all <li> patient blocks
	        List<WebElement> patientCards = waitForPresenceOfAll(
	            By.xpath("//div[@class='ph-bills-hold-lists']//li[.//div[contains(@class,'ph-bills-hold-desc')]]")
	        );

	        for (WebElement card : patientCards) {
	            try {
	                String mobileNumber = card.findElement(
	                    By.xpath(".//div[contains(@class,'ph-bills-hold-desc')]/p[3]")
	                ).getText().split("/")[0].trim();

	                System.out.println("📞 Found mobile: " + mobileNumber);

	                if (mobileNumber.equalsIgnoreCase(targetPatientMobile)) {
	                    // Scroll the card to the center of viewport
	                    ((JavascriptExecutor) driver).executeScript(
	                        "arguments[0].scrollIntoView({block: 'center', inline: 'nearest'});", card
	                    );

	                    // Hover to make icons visible
	                    Actions actions = new Actions(driver);
	                    actions.moveToElement(card).pause(Duration.ofSeconds(2)).perform();

	                    WebElement targetIcon = null;

	                    // Choose icon dynamically based on actionType
	                    if (actionType.equalsIgnoreCase("NewBill")) {
	                        targetIcon = card.findElement(
	                            By.xpath(".//div[contains(@class,'ph-bills-hold-right')]//img[contains(@src,'add_to_queue.png')]")
	                        );
	                    } else if (actionType.equalsIgnoreCase("Archive")) {
	                        targetIcon = card.findElement(
	                            By.xpath(".//div[contains(@class,'ph-bills-hold-right')]//img[contains(@src,'archive.png')]")
	                        );
	                    } else {
	                        System.out.println("⚠️ Unknown actionType: " + actionType);
	                        return false;
	                    }

	                    // Scroll icon to center (extra safety)
	                    ((JavascriptExecutor) driver).executeScript(
	                        "arguments[0].scrollIntoView({block: 'center', inline: 'nearest'});", targetIcon
	                    );

	                    // Wait until clickable, then click
	                    waitForClickability(targetIcon).click();

	                    System.out.println("✅ Clicked " + actionType + " icon for Patient Mobile: " + mobileNumber);
	                    isFound = true;
	                    break;
	                }

	            } catch (NoSuchElementException e) {
	                System.out.println("⚠️ Skipping card due to missing elements");
	            }
	        }

	        // If not found → try next page
	        if (!isFound) {
	            try {
	                if (clickCount >= 14) {
	                    System.out.println("⛔ Stopped after 14 clicks. Patient not found.");
	                    break;
	                }

	                WebElement nextPage = driver.findElement(nextPageBtn2);
	                String classAttr = nextPage.getAttribute("class");
	                if (classAttr != null && classAttr.contains("disabled")) {
	                    System.out.println("❌ Reached last page. Patient not found.");
	                    break;
	                }

	                ((JavascriptExecutor) driver).executeScript(
	                    "arguments[0].scrollIntoView({block: 'center', inline: 'nearest'});", nextPage
	                );
	                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextPage);

	                clickCount++;
	                System.out.println("➡️ Moving to next page... (Click " + clickCount + ")");

	            } catch (NoSuchElementException e) {
	                System.out.println("❌ Next page button not found or interrupted. Ending search.");
	                break;
	            }
	        }
	    }

	    return isFound;
	}

	public boolean selectAlternativeForMedicine(String targetMedicineCode, String partialText) {
	    boolean isFound = false;
	    int clickCount = 0; // ✅ counter for pagination

	    while (!isFound) {
	        // Step 1: Get all rows of the medicine table
	        List<WebElement> medicineRows = waitForPresenceOfAll(
	            By.xpath("(//tbody/tr[td[@class='doctor-notes-td-doc']])[1]")
	        );

	        for (WebElement row : medicineRows) {
	            try {
	                // Step 2: Extract the <h4> (medicine code)
	                String medicineCode = row.findElement(By.xpath(".//td[@class='doctor-notes-td-doc']/h4"))
	                                         .getText().trim();
	                System.out.println("🔎 Found medicine code: " + medicineCode);

	                // Step 3: Compare with target
	                if (medicineCode.equalsIgnoreCase(targetMedicineCode)) {
	                    // Step 4: Find and click dropdown
	                    WebElement dropdown = row.findElement(By.xpath(".//mat-select"));
	                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", dropdown);
	                    waitForClickability(dropdown).click();

	                    // Step 5: Select the option by partial match
	                    WebElement option = driver.findElement(By.xpath(
	                        String.format("//span[@class='mat-option-text'][contains(normalize-space(),'%s')]", partialText)
	                    ));
	                    waitForClickability(option).click();

	                    System.out.println("✅ Selected alternative containing '" + partialText + "' for medicine code: " + medicineCode);
	                    isFound = true;
	                    break;
	                }
	            } catch (NoSuchElementException e) {
	                System.out.println("⚠️ Skipping row due to missing elements");
	            }
	        }

	        // Step 6: Handle pagination if not found
	        if (!isFound) {
	            try {
	                WebElement nextPage = driver.findElement(
	                    By.xpath("(//div[@class='pagi-block pagi-block-right']//a)[1]")
	                );

	                String classAttr = nextPage.getAttribute("class");
	                if (classAttr != null && classAttr.contains("disabled")) {
	                    System.out.println("❌ Reached last page. Medicine not found.");
	                    break;
	                }

	                // ✅ stop after 14 clicks
	                if (clickCount >= 14) {
	                    System.out.println("⛔ Stopped after 14 clicks. Medicine not found.");
	                    break;
	                }

	                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", nextPage);
	                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextPage);

	                clickCount++;
	                System.out.println("➡️ Moving to next page... (Click " + clickCount + ")");
	            } catch (NoSuchElementException e) {
	                System.out.println("❌ Next page button not found. Ending search.");
	                break;
	            }
	        }
	    }

	    return isFound;
	}

    @FindBy(xpath = "//input[@type='button' and @value='Submit' and contains(@class,'btn-violet')]")
    private WebElement submitButton;

    // Method to click Submit
    public void clickSubmit() {
        submitButton.click();
        System.out.println("✅ Clicked Submit button");
    }
    
    @FindBy(xpath = "(//div[@class='lightbox-close'])[4]")
    WebElement closeLightboxBtn;
    public void clickCloseLightbox() {
        closeLightboxBtn.click();
        
        Actions act = new Actions(driver);
        act.sendKeys(Keys.ESCAPE).perform();
    }
    @FindBy(xpath = "//input[@formcontrolname='commondiscountpercentage']")
    WebElement commonDiscountPercentageInput;
    public void enterCommonDiscountPercentage(String value) {
        commonDiscountPercentageInput.clear();
        commonDiscountPercentageInput.sendKeys(value);
    }

    @FindBy(xpath = "//label[contains(.,'Full Credit Bill')]//input[@type='checkbox']")
    WebElement fullCreditBillCheckbox;
    public void selectFullCreditBill() {
     
        	clickWithJavaScript(fullCreditBillCheckbox);
        
    }

}
