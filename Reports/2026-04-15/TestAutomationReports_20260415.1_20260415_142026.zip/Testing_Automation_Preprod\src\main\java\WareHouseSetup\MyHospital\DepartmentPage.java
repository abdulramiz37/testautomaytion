package WareHouseSetup.MyHospital;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class DepartmentPage extends Abstraction {

    WebDriver driver;

    public DepartmentPage(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // 🔹 Department Name input field
    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement departmentNameInput;

    // 🔹 Assign Branch dropdown input (ngx-select)
    @FindBy(xpath = "//ngx-select[@formcontrolname='assignedBranches']//input[@type='text']")
    private WebElement assignBranchInput;

    @FindBy(xpath = "//label[contains(text(), 'Is Clinical')]/span[@class='checkmark']")
    private WebElement isClinicalCheckmark;

    // ✅ Proper locator for Is Active checkbox
    @FindBy(xpath = "//label[contains(text(), 'Is Active')]/input[@formcontrolname='isActive']")
    private WebElement isActiveCheckbox;

    // 🔹 Save button
    @FindBy(xpath = "//input[@type='button' and @value='Save']")
    private WebElement saveButton;

    // 🔹 Cancel button
    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
    private WebElement cancelButton;

    @FindBy(xpath = "//a[text()=' Manual Date Picker Settings ']")
    private WebElement userType;

    @FindBy(xpath = "//a[text()=' Create ']")
    private WebElement adduserType;
     
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}
    // 🔹 Method to enter department name
    public void enterDepartmentName(String name) {
        departmentNameInput.clear();
        departmentNameInput.sendKeys(name);
    }

    // 🔹 Method to select branch (type and press Enter or select by auto-suggestion)
    public void selectBranch(String branchName) {
        assignBranchInput.clear();
        assignBranchInput.sendKeys(branchName);
        assignBranchInput.sendKeys(org.openqa.selenium.Keys.ENTER);
    }

    // 🔹 Method to toggle 'Is Clinical' checkbox
    public void setIsClinical(boolean value) {
        if (isClinicalCheckmark.isSelected() != value) {
        	isClinicalCheckmark.click();
        }
    }

    // 🔹 Method to toggle 'Is Active' checkbox
    public void setIsActive(boolean value) {
        if (isActiveCheckbox.isSelected() != value) {
            isActiveCheckbox.click();
        }
    }

    // 🔹 Click Save button
    public void clickSave() {
        saveButton.click();
    }

    // 🔹 Click Cancel button
    public void clickCancel() {
        cancelButton.click();
    }

    // 🔹 Method to fill and submit the Department form
    public void fillDepartmentForm(String deptName, String branchName, boolean isClinical, boolean isActive) {
    	clickbuttonapproval();
        enterDepartmentName(deptName);
//        selectBranch(branchName);
        setIsClinical(isClinical);
        setIsActive(isActive);
        clickSave();
    }
}

