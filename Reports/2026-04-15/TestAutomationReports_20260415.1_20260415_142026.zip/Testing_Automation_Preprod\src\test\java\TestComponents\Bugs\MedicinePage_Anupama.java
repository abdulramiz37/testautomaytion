package TestComponents.Bugs;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EzionpageObjects.UserIdPage;
import PharmacyFlowObjects.PharmacyStore.MedicinePage;
import abdulTest.BaseTest;
import ezion.Resources.EnvUtil;

public class MedicinePage_Anupama extends BaseTest {
    UserIdPage data;

    @Test(priority = 1)
    public void getMedicineData1() throws InterruptedException {

        data = login.login(EnvUtil.get("USER_ID"));
        data.enterMobileNumber(EnvUtil.get("PERSON_ID"));
        data.enterPassword(EnvUtil.get("PASSWORD"));
        data.clickContinue();
//        data.openMasterSetup();
    }

    @Test(priority =2, dataProvider = "getMedicineData", groups = "negative")
    public void getMedicineData(HashMap<String, String> input) throws InterruptedException {
    	
        MedicinePage medicinePage = new MedicinePage(driver);
        data.openMasterSetup();
        medicinePage.addMedicine(
            input.get("medicineName"),
            input.get("scheduleText"),
            input.get("categoryText"),
           
            input.get("compositionText"),
            input.get("manufacturerText"),
            input.get("quantity")
        );
//        medicinePage.save();
        // Fill additional fields
        medicinePage.enterMinQty(input.get("minQty"));
        medicinePage.enterMaxQty(input.get("maxQty"));
//        medicinePage.enterReorderQty(input.get("reorderQty"));
//        medicinePage.enterReorderLevel(input.get("reordevrLeel"));
        medicinePage.enterHSNCode(input.get("hsnCode"));
        medicinePage.selectGST(input.get("gst"));
//
        medicinePage.enterDescription(input.get("description"));
        medicinePage.selectVaccineCheckbox();
//        medicinePage.enterDiscount(input.get("discount"));

        medicinePage.enterCostPrice(input.get("costPrice"));
        medicinePage.save();

       
    }

    @DataProvider(name = "getMedicineData")
    public static Object[][] getMedicineData() throws Exception {
        String filePath = "C:\\Users\\ezobgvmuser\\Downloads\\Vaccine_generic 1 2(Sheet1).csv\\";

        List<HashMap<String, String>> finalData = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            String[] headers = null;

            int rowNum = 0;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");

                if (rowNum == 0) {
                    headers = values; // first row is header
                } else {
                    HashMap<String, String> row = new HashMap<>();
                    for (int i = 0; i < headers.length && i < values.length; i++) {
                        row.put(headers[i].trim(), values[i].trim());
                    }

                    // Map Google Sheet columns → Test fields
                    HashMap<String, String> mapped = new HashMap<>();
                    mapped.put("medicineName", row.get("Name"));
                    mapped.put("scheduleText", row.get("MedicineType"));
                    mapped.put("categoryText", row.get("MedicineCategoryName"));
                    mapped.put("compositionText", row.get("GenericName"));
                    mapped.put("manufacturerText", row.get("MedicineManufacturerName"));
                    mapped.put("quantity", row.get("Units"));
                    mapped.put("minQty", row.get("MinQty"));
                    mapped.put("maxQty", row.get("MaxQty"));
                    mapped.put("hsnCode", row.get("HsnCode"));
                    mapped.put("gst", row.get("Gst"));
//                    mapped.put("discountRequired", "N");
                    mapped.put("description", "Auto test medicine");
                    mapped.put("discount", "0");
//                    mapped.put("isVaccine", row.get("IsVaccine"));
                    mapped.put("attribute", row.get("RackName"));
                    mapped.put("costPrice", row.get("Price"));
                    mapped.put("mrp", row.get("Price"));
                    mapped.put("sellPrice", row.get("Price"));

                    finalData.add(mapped);
                    // Login data
                  

                }
                rowNum++;
            }
        }

        Object[][] obj = new Object[finalData.size()][1];
        for (int i = 0; i < finalData.size(); i++) {
            obj[i][0] = finalData.get(i);
        }
        return obj;
    }
}
