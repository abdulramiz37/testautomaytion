package TestComponents;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EzionpageObjects.UserIdPage;
import PrakashSirAppointmentBooking.AppointmentBooking;
import abdulTest.BaseTest;

public class AppointMentBooking extends BaseTest {

    @Test(dataProvider = "getDataForLogin")
    public void Login(HashMap<String, String> input) throws InterruptedException {
        // Login
        UserIdPage data = login.login(input.get("userId"));
        data.enterMobileNumber(input.get("personId"));
        data.selectOptionByName("Pondicherry");
        data.enterPassword(input.get("password"));
        data.clickContinue();
        AppointmentBooking appointmentBooking = new AppointmentBooking(driver);
        appointmentBooking.opentheappointmentpage();
   

            // Loop 20 times for Appointment Booking
            for (int i = 0; i < 1; i++) {
               System.out.println(i);
                appointmentBooking.clickDoctorByName(input.get("doctorName"));
                appointmentBooking.selectTitle(input.get("title"));
                appointmentBooking.enterPatientName(input.get("patientName"));
                appointmentBooking.selectGender(input.get("gender"));
                appointmentBooking.enterDateOfBirth(input.get("dob"));
                appointmentBooking.selectMobileCountryCode(input.get("mobileCountryCode"));
                appointmentBooking.enterMobileNumber(input.get("mobileNumber"));
                appointmentBooking.enterPincode(input.get("pincode"));
//              appointmentBooking.selectArea(input.get("area"));
                appointmentBooking.selectCity(input.get("city"));
                appointmentBooking.enterAddress1(input.get("address1"));
                appointmentBooking.enterAddress2(input.get("address2"));
                appointmentBooking.enterAadhar(input.get("aadhar"));
                appointmentBooking.selectAnySlotAndConfirm();
                appointmentBooking.selectCheckIn();
//
//                // Vitals Section
                appointmentBooking.enterTemperature(input.get("temperature"));
                appointmentBooking.enterWeight(input.get("weight"));
                appointmentBooking.enterHeight(input.get("height"));
                appointmentBooking.enterBSRandom(input.get("bsRandom"));
                appointmentBooking.enterBSFasting(input.get("bsFasting"));
                appointmentBooking.enterBSPP(input.get("bsPP"));
                appointmentBooking.enterBPSys(input.get("bpSys"));
                appointmentBooking.enterBPDia(input.get("bpDia"));
                appointmentBooking.enterPulse(input.get("pulse"));
                appointmentBooking.enterSpO2(input.get("spo2"));
                appointmentBooking.enterRespRate(input.get("respRate"));
                appointmentBooking.enterHeartRate(input.get("heartRate"));

                appointmentBooking.selectChiefComplaint(input.get("chiefComplaint"));
                appointmentBooking.enterNoOfDays(input.get("noOfDays"));
                appointmentBooking.selectCheckIn2();
                appointmentBooking.save();
//              appointmentBooking.selectCheckOut();
//                appointmentBooking.cancelButton();
            }
        }


    @DataProvider
    public Object[][] getDataForLogin() throws IOException {
        List<HashMap<String, String>> data = getJsonDataToMap(
            System.getProperty("user.dir") + "//src//main//java//ezion//Resources//AppointMent.json"
        );
        return new Object[][] { { data.get(0) } };
    }
}
