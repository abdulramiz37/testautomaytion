package WareHouseSetup.Approval.Tenant_Master;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;

	import EzionAbstractionComponents.Abstraction;

	public class Tenant_Based_Master extends Abstraction {

	    public Tenant_Based_Master(WebDriver driver) {
	        super(driver);
	        this.driver = driver;
	        PageFactory.initElements(driver, this);
	    }

	    // --- Locators ---

	    @FindBy(xpath = "//input[@formcontrolname='reasonName']")
	    private WebElement callCategoryNameInput;

	    @FindBy(xpath = "//input[@formcontrolname='reasonCode']")
	    private WebElement callCategoryCodeInput;

	    @FindBy(xpath = "//textarea[@formcontrolname='reasonDescription']")
	    private WebElement callCategoryDescriptionTextarea;

	    @FindBy(xpath = "//input[@formcontrolname='isActive']/following-sibling::span[@class='checkmark']")
	    private WebElement isActiveCheckmark;

	    @FindBy(xpath = "//input[@type='button' and @value='Save']")
	    private WebElement saveButton;

	    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
	    private WebElement cancelButton;

		  @FindBy(xpath = "//a[text()=' Add Call Category ']")
		    private WebElement addtenant;
		    
		    @FindBy(xpath = "//a[text()='Tenant Based Master']")
		    private WebElement Tenantbutton;
	    // --- Action Methods ---

		public void clickbuttonapproval() {
			waitForClickability(Tenantbutton).click();
			waitForClickability(addtenant).click();
		}
	    public void enterCallCategoryName(String name) {
	        waitForVisibility(callCategoryNameInput).clear();
	        callCategoryNameInput.sendKeys(name);
	    }

	    public void enterCallCategoryCode(String code) {
	        waitForVisibility(callCategoryCodeInput).clear();
	        callCategoryCodeInput.sendKeys(code);
	    }

	    public void enterCallCategoryDescription(String description) {
	        waitForVisibility(callCategoryDescriptionTextarea).clear();
	        callCategoryDescriptionTextarea.sendKeys(description);
	    }

	    public void setIsActive(boolean shouldBeActive) {
	        WebElement checkbox = waitForVisibility(isActiveCheckmark);
	        boolean currentlyChecked = callCategoryCheckboxIsSelected();
	        if (shouldBeActive != currentlyChecked) {
	            waitForClickability(checkbox).click();
	        }
	    }

	    private boolean callCategoryCheckboxIsSelected() {
	        return driver.findElement(
	            org.openqa.selenium.By.xpath("//input[@formcontrolname='isActive']")
	        ).isSelected();
	    }

	    public void clickSave() {
	        waitForClickability(saveButton).click();
	    }

	    public void clickCancel() {
	        waitForClickability(cancelButton).click();
	    }

	    // Combined fill method
	    public void fillCallCategoryForm(String name, String code, String description, boolean isActive) {
	        enterCallCategoryName(name);
	        enterCallCategoryCode(code);
	        enterCallCategoryDescription(description);
	        setIsActive(isActive);
	        clickSave();
	    }
	}