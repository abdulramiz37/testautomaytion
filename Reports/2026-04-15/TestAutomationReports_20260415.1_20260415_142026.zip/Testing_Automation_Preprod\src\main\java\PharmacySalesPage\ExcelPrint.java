package PharmacySalesPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class ExcelPrint extends Abstraction{

	public ExcelPrint(WebDriver driver) {
		super(driver);
		  PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//*[local-name()='svg']//*[name()='g' and @data-name='cloud-download']")
	WebElement cloudDownloadIcon;

	public void clickCloudDownload() {
	    waitForClickability(cloudDownloadIcon).click();
	    System.out.println("✅ Clicked on Cloud Download icon");
	}
	@FindBy(xpath = "//span[normalize-space()='CSV']")
	WebElement csvExportOption;

	@FindBy(xpath = "//span[normalize-space()='Excel']")
	WebElement excelExportOption;

	public void clickExportOption(String option) {
	    WebElement target = null;

	    if (option.equalsIgnoreCase("CSV")) {
	        target = csvExportOption;
	    } else if (option.equalsIgnoreCase("Excel")) {
	        target = excelExportOption;
	    }

	    if (target != null) {
	        waitForClickability(target).click();
	        System.out.println("✅ Clicked on Export option: " + option);
	    } else {
	        throw new IllegalArgumentException("❌ Invalid option: " + option + ". Use CSV or Excel.");
	    }
	}


}
