package Appointment;

	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.WebDriverWait;

import EzionAbstractionComponents.Abstraction;

import java.time.Duration;
	import java.util.List;

	public class PaymentPage extends Abstraction{
	    
	    private WebDriver driver;
	    private WebDriverWait wait;
	    
	    // Constructor
	    public PaymentPage(WebDriver driver) {
	    	super(driver);
	        this.driver = driver;
	        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	        PageFactory.initElements(driver, this);
	    }
	    
	    // =================== XPATH LOCATORS ===================
	    
	    // Cash payment
	    @FindBy(xpath = "//tr[.//td[text()='Cash']]//input[@formcontrolname='cashamount']")
	    private WebElement cashAmountInput;
	    
	    // Card payment row
	    @FindBy(xpath = "//tr[.//td[text()='Card']]")
	    private WebElement cardPaymentRow;
	    
	    @FindBy(xpath = "//tr[.//td[text()='Card']]//input[@formcontrolname='cardamount']")
	    private WebElement cardAmountInput;
	    
	    @FindBy(xpath = "//tr[.//td[text()='Card']]//ngx-select[@formcontrolname='cardTypeID']")
	    private WebElement cardTypeSelect;
	    
	    @FindBy(xpath = "//tr[.//td[text()='Card']]//ngx-select[@formcontrolname='cardBankID']")
	    private WebElement cardBankSelect;
	    
	    @FindBy(xpath = "//tr[.//td[text()='Card']]//input[@formcontrolname='cardreferenceNo']")
	    private WebElement cardReferenceInput;
	    
	    // Online/UPI payment row
	    @FindBy(xpath = "//tr[.//td[text()='Online']]")
	    private WebElement onlinePaymentRow;
	    
	    @FindBy(xpath = "//tr[.//td[text()='Online']]//input[@formcontrolname='onlineamount']")
	    private WebElement onlineAmountInput;
	    
	    @FindBy(xpath = "//tr[.//td[text()='Online']]//ngx-select[@formcontrolname='uPIPaymentID']")
	    private WebElement upiSelect;
	    
	    @FindBy(xpath = "//tr[.//td[text()='Online']]//input[@formcontrolname='onlinereferenceNo']")
	    private WebElement onlineReferenceInput;
	    
	    // Credit payment
	    @FindBy(xpath = "//tr[.//td[text()='Credit']]//input[@formcontrolname='creditamount']")
	    private WebElement creditAmountInput;
	    
	    // Insurance/Payer row
	    @FindBy(xpath = "//tr[contains(.,'Payer (Limit')]")
	    private WebElement insurancePaymentRow;
	    
	    @FindBy(xpath = "//tr[contains(.,'Payer (Limit')]//input[@formcontrolname='insuranceamount']")
	    private WebElement insuranceAmountInput;
	    
	    @FindBy(xpath = "//tr[contains(.,'Payer (Limit')]//ngx-select[@formcontrolname='insuranceID']")
	    private WebElement payerSelect;
	    
	    @FindBy(xpath = "//tr[contains(.,'Payer (Limit')]//input[@formcontrolname='insurancereferenceNo']")
	    private WebElement insuranceReferenceInput;
	    
	    @FindBy(xpath = "//tr[contains(.,'Payer (Limit')]//b")
	    private WebElement payerLimit;
	    
	    // Wallet row
	    @FindBy(xpath = "//tr[contains(.,'Wallet (Balance')]")
	    private WebElement walletPaymentRow;
	    
	    @FindBy(xpath = "//tr[contains(.,'Wallet (Balance')]//input[@formcontrolname='walleamount']")
	    private WebElement walletAmountInput;
	    
	    @FindBy(xpath = "//tr[contains(.,'Wallet')]//input[@formcontrolname='walleamount']")
	    private WebElement wallet;
	    
	    @FindBy(xpath = "//tr[contains(.,'Wallet (Balance')]//ngx-select[@formcontrolname='walletType']")
	    private WebElement walletTypeSelect;
	    
	    @FindBy(xpath = "//tr[contains(.,'Wallet (Balance')]//b")
	    private WebElement walletBalance;
	    
	    // Net Banking row
	    @FindBy(xpath = "//tr[.//td[text()='Net Banking']]")
	    private WebElement netBankingRow;
	    
	    @FindBy(xpath = "//tr[.//td[text()='Net Banking']]//input[@formcontrolname='netbankingamount']")
	    private WebElement netBankingAmountInput;
	    
	    @FindBy(xpath = "//tr[.//td[text()='Net Banking']]//ngx-select[@formcontrolname='bankId']")
	    private WebElement netBankingSelect;
	    
	    @FindBy(xpath = "//tr[.//td[text()='NEFT']]//ngx-select[@formcontrolname='bankId']")
	    private WebElement NEFT;
	    
	    @FindBy(xpath = "//tr[.//td[text()='NEFT']]//input[@formcontrolname='netbankingreferenceNo']")
	    private WebElement NEFT2;
	    
	    @FindBy(xpath = "//tr[.//td[text()='NEFT']]//input[@formcontrolname='netbankingamount']")
	    private WebElement NEFT3;
	    @FindBy(xpath = "//tr[.//td[text()='Net Banking']]//input[@formcontrolname='netbankingreferenceNo']")
	    private WebElement netBankingReferenceInput;
	    
	    // Generic XPaths for dropdown options
	    private final String DROPDOWN_OPTIONS_XPATH = "//div[contains(@class,'ngx-select__dropdown')]//span[contains(@class,'ngx-select__option')]";
	    private final String DROPDOWN_OPEN_XPATH = "//div[contains(@class,'ngx-select__dropdown') and contains(@class,'open')]";
	    
	    @FindBy(xpath = "//input[@formcontrolname='chequereferenceNo']")
	    private WebElement chequenumber;
	   
	    @FindBy(xpath = "//input[@formcontrolname='chequeamount']")
	    private WebElement chequeamount;
	    // =================== HELPER METHODS ===================
	    
	    private void waitForElement(WebElement element) {
	        wait.until(ExpectedConditions.elementToBeClickable(element));
	    }
	    
	    private void waitForElementVisible(WebElement element) {
	        wait.until(ExpectedConditions.visibilityOf(element));
	    }
	    
	    // Method to select from custom ngx-select dropdown using XPath
	    public void selectFromDropdown(WebElement dropdown, String optionText) {
	   
	            waitForElement(dropdown);
	            dropdown.click();
	            

	    	 
	    	        WebElement option = driver.findElement(
	    	            By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + optionText + "']")
	    	        );
	    	        waitForClickability(option).click();
	    	    
	            
	    }
	    
	    // Alternative method for dropdown selection
	    private void selectFromDropdownAlternative(WebElement dropdown, String optionText) {
	        dropdown.click();
	        
	        // Find all options and select matching one
	        List<WebElement> options = driver.findElements(
	            By.xpath("//div[contains(@class,'ngx-select__dropdown')]//span")
	        );
	        
	        for (WebElement option : options) {
	            if (option.getText().trim().equals(optionText)) {
	                option.click();
	                break;
	            }
	        }
	    }
	    
	    // Method to get input value
	    private String getInputValue(WebElement element) {
	        waitForElementVisible(element);
	        return element.getAttribute("value");
	    }
	    
	    // Method to set input value
	    private void setInputValue(WebElement element, String value) {
	        waitForElement(element);
	        element.clear();
	        element.sendKeys(value);
	    }
	    
	    // Method to check if payment row is present
	    public boolean isPaymentTypePresent(String paymentType) {
	        try {
	            switch (paymentType.toLowerCase()) {
	                case "cash":
	                    return cashAmountInput.isDisplayed();
	                case "card":
	                    return cardPaymentRow.isDisplayed();
	                case "online":
	                    return onlinePaymentRow.isDisplayed();
	                case "credit":
	                    return creditAmountInput.isDisplayed();
	                case "insurance":
	                    return insurancePaymentRow.isDisplayed();
	                case "wallet":
	                    return walletPaymentRow.isDisplayed();
	                case "netbanking":
	                    return netBankingRow.isDisplayed();
	                default:
	                    return false;
	            }
	        } catch (Exception e) {
	            return false;
	        }
	    }
	    
	    // =================== PAYMENT METHODS ===================
	    
	    // Cash payment methods
	    public void enterCashAmount(String amount) {
	    	cashAmountInput.clear();
	        setInputValue(cashAmountInput, amount);
	    }
	    
	    public String getCashAmount() {
	        return getInputValue(cashAmountInput);
	    }
	    
	    // Card payment methods
	    public void enterCardPayment(String cardType, String bankName, String referenceNo, String amount) {
	        selectCardType(cardType);
	        selectCardBank(bankName);
	        enterCardReference(referenceNo);
	        enterCardAmount(amount);
	    }
	    public void enterCardPayment2(String cardType, String referenceNo, String amount) {
	        selectCardType(cardType);
//	        selectCardBank(bankName);
	        enterCardReference(referenceNo);
	        enterCardAmount(amount);
	    }
	    public void selectCardType(String cardType) {
	        selectFromDropdown(cardTypeSelect, cardType);
	    }
	    
	    public void selectCardBank(String bankName) {
	        selectFromDropdown(cardBankSelect, bankName);
	    }
	    
	    public void enterCardReference(String referenceNo) {
	        setInputValue(cardReferenceInput, referenceNo);
	    }
	    
	    public void enterCardAmount(String amount) {
	        setInputValue(cardAmountInput, amount);
	    }
	    
	    public String getCardAmount() {
	        return getInputValue(cardAmountInput);
	    }
	    
	    // Online/UPI payment methods
	    public void enterOnlinePayment(String upiType, String referenceNo, String amount) {
	        selectUPIType(upiType);
	        enterOnlineReference(referenceNo);
	        enterOnlineAmount(amount);
	    }
	    
	    public void selectUPIType(String upiType) {
	        selectFromDropdown(upiSelect, upiType);
	    }
	    
	    public void enterOnlineReference(String referenceNo) {
	        setInputValue(onlineReferenceInput, referenceNo);
	    }
	    
	    public void enterOnlineAmount(String amount) {
	        setInputValue(onlineAmountInput, amount);
	    }
	    
	    public String getOnlineAmount() {
	        return getInputValue(onlineAmountInput);
	    }
	    
	    // Credit payment methods
	    public void enterCreditAmount(String amount) {
	        setInputValue(creditAmountInput, amount);
	    }
	    
	    public String getCreditAmount() {
	        return getInputValue(creditAmountInput);
	    }
	    
	    // Insurance/Payer methods
	    public void enterInsurancePayment( String referenceNo, String amount) {
//	        selectPayer(payerName);
	        enterInsuranceReference(referenceNo);
	        enterInsuranceAmount(amount);
	    }
	    
	    public void selectPayer(String payerName) {
	        selectFromDropdown(payerSelect, payerName);
	    }
	    
	    public void enterInsuranceReference(String referenceNo) {
	        setInputValue(insuranceReferenceInput, referenceNo);
	    }
	    
	    public void enterInsuranceAmount(String amount) {
	        setInputValue(insuranceAmountInput, amount);
	    }
	    
	    public String getInsuranceAmount() {
	        return getInputValue(insuranceAmountInput);
	    }
	    
	    public String getPayerLimit() {
	        waitForElementVisible(payerLimit);
	        return payerLimit.getText();
	    }
	    
	    // Wallet methods
	    public void enterWalletPayment(String walletType, String amount) {
	        selectWalletType(walletType);
	        enterWalletAmount(amount);
	    }
	    
	    public void selectWalletType(String walletType) {
	        selectFromDropdown(walletTypeSelect, walletType);
	    }
	    
	    public void enterWalletAmount(String amount) {
	        setInputValue(walletAmountInput, amount);
	    }
	    
	    public void enterWalletAmount2(String amount) {
	        setInputValue(wallet, amount);
	    }
	    public String getWalletAmount() {
	        return getInputValue(walletAmountInput);
	    }
	    
	    public String getWalletBalance() {
	        waitForElementVisible(walletBalance);
	        return walletBalance.getText();
	    }
	    
	    // Net Banking methods
	    public void enterNetBankingPayment(String bankName, String referenceNo, String amount) {
	        selectNetBankingBank(bankName);
	        enterNetBankingReference(referenceNo);
	        enterNetBankingAmount(amount);
	    }
	    
	    public void selectNetBankingBank(String bankName) {
	        selectFromDropdown(NEFT, bankName);
	    }
	    
	    public void enterNetBankingReference(String referenceNo) {
	        setInputValue(NEFT2, referenceNo);
	    }
	    
	    public void enterNetBankingAmount(String amount) {
	        setInputValue(NEFT3, amount);
	    }
	    
	    public String getNetBankingAmount() {
	        return getInputValue(NEFT3);
	    }
	    
	    
	    public void chequedd( String referenceNo, String amount) {
//	        selectNetBankingBank(bankName);
	    	chequenumber.click();
	    	chequenumber.sendKeys(referenceNo);
	    	chequeamount.click();
	    	chequeamount.sendKeys(amount);
	    }
	    

	    
	    public void enterNetBankingReference2(String referenceNo) {
	        setInputValue(chequenumber, referenceNo);
	    }
	    
	    public void cheqamount(String amount) {
	        setInputValue(chequeamount, amount);
	    }
	    

	    
	    // Validation methods
	    public boolean isPaymentFieldEnabled(String paymentType) {
	        try {
	            switch (paymentType.toLowerCase()) {
	                case "cash":
	                    return cashAmountInput.isEnabled();
	                case "card":
	                    return cardAmountInput.isEnabled() && 
	                           cardTypeSelect.isEnabled() && 
	                           cardBankSelect.isEnabled();
	                case "online":
	                    return onlineAmountInput.isEnabled() && 
	                           upiSelect.isEnabled();
	                case "credit":
	                    return creditAmountInput.isEnabled();
	                case "insurance":
	                    return insuranceAmountInput.isEnabled() && 
	                           payerSelect.isEnabled();
	                case "wallet":
	                    return walletAmountInput.isEnabled() && 
	                           walletTypeSelect.isEnabled();
	                case "netbanking":
	                    return netBankingAmountInput.isEnabled() && 
	                           netBankingSelect.isEnabled();
	                default:
	                    return false;
	            }
	        } catch (Exception e) {
	            return false;
	        }
	    }
	    
	    // Method to check if field has specific attribute
	    public boolean hasAttribute(WebElement element, String attribute, String value) {
	        String attrValue = element.getAttribute(attribute);
	        return attrValue != null && attrValue.contains(value);
	    }
	    
	    // Method to get all payment types available
	    public List<String> getAllPaymentTypes() {
	        return driver.findElements(By.xpath("//tbody//tr/td[1]"))
	            .stream()
	            .map(WebElement::getText)
	            .map(text -> text.contains("(") ? text.substring(0, text.indexOf("(")).trim() : text.trim())
	            .toList();
	    }
	    
	    // Clear all payment methods
	    public void clearAllPayments() {
	        List<WebElement> allInputs = driver.findElements(
	            By.xpath("//tbody//input[@type='text']")
	        );
	        
	        for (WebElement input : allInputs) {
	            try {
	                input.clear();
	            } catch (Exception e) {
	                // Ignore if can't clear
	            }
	        }
	    }
	    
	    // Get total amount from all payment methods
	    public double getTotalPaymentAmount() {
	        double total = 0;
	        
	        // Get all amount inputs
	        List<WebElement> amountInputs = driver.findElements(
	            By.xpath("//tbody//tr//input[contains(@formcontrolname,'amount')]")
	        );
	        
	        for (WebElement input : amountInputs) {
	            try {
	                String value = input.getAttribute("value");
	                if (!value.isEmpty()) {
	                    total += Double.parseDouble(value);
	                }
	            } catch (NumberFormatException e) {
	                // Skip invalid numbers
	            }
	        }
	        
	        return total;
	    }
	}

