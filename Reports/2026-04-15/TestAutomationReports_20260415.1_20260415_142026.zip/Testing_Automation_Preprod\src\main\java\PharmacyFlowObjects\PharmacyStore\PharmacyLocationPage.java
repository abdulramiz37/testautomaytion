package PharmacyFlowObjects.PharmacyStore;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.*;
import EzionAbstractionComponents.Abstraction;

public class PharmacyLocationPage extends Abstraction {

    WebDriver driver;
    WebDriverWait wait;

    public PharmacyLocationPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    // ---------- Navigation ----------
    @FindBy(xpath = "//a[text()=' Pharmacy Location ']")
    private WebElement pharmacyLocationTab;

    @FindBy(xpath = "//a[text()=' Add Pharmacy Location']")
    private WebElement addPharmacyLocationBtn;

    // ---------- Form Fields ----------
    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement locationNameInput;

    @FindBy(xpath = "//input[@formcontrolname='mobileno']")
    private WebElement mobileNumberInput;

    @FindBy(xpath = "//input[@formcontrolname='email']")
    private WebElement emailInput;

    @FindBy(xpath = "//input[@formcontrolname='gstn']")
    private WebElement gstnInput;

    @FindBy(xpath = "//input[@formcontrolname='dlno']")
    private WebElement dlnoInput;






    // ---------- Sales Section ----------

    @FindBy(xpath = "(//label[contains(text(),'Sales')]/span[@class='checkmark'])[1]")
    private WebElement salesCheckmark;

    @FindBy(xpath = "(//ngx-select[@formcontrolname='salesWarehouse']//div[contains(@class,'ngx-select__toggle')])[1]")
    private WebElement salesWarehouseDropdown;

    // ---------- Purchase Section ----------
    @FindBy(xpath = "(//label[contains(text(),'Purchase')]/span[@class='checkmark'])[1]")
    private WebElement purchaseCheckmark;

    @FindBy(xpath = "(//ngx-select[@formcontrolname='purchaseWarehouse']//div[contains(@class,'ngx-select__toggle')])[1]")
    private WebElement purchaseWarehouseDropdown;

    // ---------- Address Checkboxes ----------
    @FindBy(xpath = "//label[contains(text(),'Use This Location Address Into Pharmacy Sales And Purchase')]/span[@class='checkmark']")
    private WebElement useThisLocationCheckmark;

    @FindBy(xpath = "//label[contains(text(),'Use Default Common Address Into Pharmacy Sales And Purchase')]/span[@class='checkmark']")
    private WebElement useDefaultAddressCheckmark;

    // ---------- Buttons ----------
    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//input[@value='Cancel']")
    private WebElement cancelButton;

    // ---------- Optional Checkmark ----------
    @FindBy(xpath = "(//span[@class='checkmark'])[4]")
    private WebElement checkMark;

 // ---------- Communication Address Fields ----------

    @FindBy(xpath = "//input[@formcontrolname='doorNo']")
    private WebElement doorNoInput;

    @FindBy(xpath = "//input[@formcontrolname='address1']")
    private WebElement address1Input;

    @FindBy(xpath = "//input[@formcontrolname='address2']")
    private WebElement address2Input;

    @FindBy(xpath = "//input[@formcontrolname='city']")
    private WebElement cityInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='district']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement districtDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='state']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement stateDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='country']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement countryDropdown;

    @FindBy(xpath = "//input[@formcontrolname='landmark']")
    private WebElement landmarkInput;

    @FindBy(xpath = "//input[@formcontrolname='pincode']")
    private WebElement pincodeInput;

 // ---------- Report Details Fields ----------

    @FindBy(xpath = "//input[@formcontrolname='reportLine1']")
    private WebElement reportLine1Input;

    @FindBy(xpath = "//input[@formcontrolname='reportLine2']")
    private WebElement reportLine2Input;

    @FindBy(xpath = "//input[@formcontrolname='reportLine3']")
    private WebElement reportLine3Input;

    @FindBy(xpath = "//input[@formcontrolname='reportLine4']")
    private WebElement reportLine4Input;

    @FindBy(xpath = "//input[@formcontrolname='reportLine5']")
    private WebElement reportLine5Input;

    @FindBy(xpath = "//input[@formcontrolname='reportMessage']")
    private WebElement reportMessageInput;

    
    // ---------- Error ----------
    
    @FindBy(xpath = "//span[contains(text(),'Name Already Exists..')]")
    private WebElement errorMessage;
 
    // ---------- Actions ----------
    
    public String duplicateErrorMessage() {
    	return errorMessage.getText();
    }
    public void selectWarehouse(String warehouseName) {
        String xpath = String.format("//a[contains(@class,'ngx-select__item')]//span[normalize-space(text())='%s']", warehouseName);
        WebElement option = waitForClickability(By.xpath(xpath));
        option.click();
    }

    public void selectWarehouseCommunication(String name) {
        String xpath = String.format("//a[contains(@class,'ngx-select__item')]//span[normalize-space(text())='%s']", name);
        WebElement option = waitForClickability(By.xpath(xpath));
        option.click();
    }

    
    public void clickPharmacyLocationTab() {
        waitForClickability(pharmacyLocationTab).click();
    }

    public void clickAddPharmacyLocation() {
        waitForClickability(addPharmacyLocationBtn).click();
    }

    public void enterLocationName(String name) {
    
        
        int counter = 1;
      String  uniqueName = name ;

           waitForVisibility(locationNameInput).clear();
           locationNameInput.sendKeys(uniqueName);

    
    }

    public void enterMobileNumber(String mobile) {
        waitForVisibility(mobileNumberInput).clear();
        mobileNumberInput.sendKeys(mobile);
    }

    public void enterEmail(String email) {
        waitForVisibility(emailInput).clear();
        emailInput.sendKeys(email);
    }

    public void enterGSTN(String gstn) {
        waitForVisibility(gstnInput).clear();
        gstnInput.sendKeys(gstn);
    }

    public void enterDLNO(String dlno) {
        waitForVisibility(dlnoInput).clear();
        dlnoInput.sendKeys(dlno);
    }

    public void selectSalesCheckbox() {
        if (!salesCheckmark.isSelected()) {
            waitForClickability(salesCheckmark).click();
        }
    }

    public void openSalesWarehouseDropdown() {
        waitForClickability(salesWarehouseDropdown).click();
    }

    public void selectPurchaseCheckbox() {
        if (!purchaseCheckmark.isSelected()) {
            waitForClickability(purchaseCheckmark).click();
        }
    }

    public void openPurchaseWarehouseDropdown() {
        waitForClickability(purchaseWarehouseDropdown).click();
    }

    public void selectUseThisLocationCheckbox() {
        if (!useThisLocationCheckmark.isSelected()) {
            waitForClickability(useThisLocationCheckmark).click();
        }
    }

    public void selectUseDefaultAddressCheckbox() {
        if (!useDefaultAddressCheckmark.isSelected()) {
            waitForClickability(useDefaultAddressCheckmark).click();
        }
    }

    public void clickSave() {
        waitForClickability(saveButton).click();
    }

    public void clickCancel() {
        waitForClickability(cancelButton).click();
    }

    public void useDefaultAddressCheckmark() {
    	if (!useDefaultAddressCheckmark.isSelected()) {
        waitForClickability(useDefaultAddressCheckmark).click();
    	}
    }
    public void selectSalesWarehouse(String warehouseName) {
        openSalesWarehouseDropdown();  // dropdown must be visible
        selectWarehouse(warehouseName); // pass e.g. "primary warehouse"
    }

    public void selectPurchaseWarehouse(String warehouseName) {
        openPurchaseWarehouseDropdown();
        selectWarehouse(warehouseName);
    }
    public void enterDoorNo(String value) {
        waitForVisibility(doorNoInput).clear();
        doorNoInput.sendKeys(value);
    }

    public void enterAddress1(String value) {
        waitForVisibility(address1Input).clear();
        address1Input.sendKeys(value);
    }

    public void enterAddress2(String value) {
        waitForVisibility(address2Input).clear();
        address2Input.sendKeys(value);
    }

    public void enterCity(String value) {
        waitForVisibility(cityInput).clear();
        cityInput.sendKeys(value);
    }

    public void openDistrictDropdown() {
        waitForClickability(districtDropdown).click();
    }

    public void openStateDropdown() {
        waitForClickability(stateDropdown).click();
    }

    public void openCountryDropdown() {
        waitForClickability(countryDropdown).click();
    }

    public void selectDistrict(String district) {
        openDistrictDropdown();
        selectWarehouseCommunication(district);
    }

   

    public void enterLandmark(String value) {
        waitForVisibility(landmarkInput).clear();
        landmarkInput.sendKeys(value);
    }

    public void enterPincode(String value) {
        waitForVisibility(pincodeInput).clear();
        pincodeInput.sendKeys(value);
    }
    
    public void enterReportLine1(String line1) {
        waitForVisibility(reportLine1Input).clear();
        reportLine1Input.sendKeys(line1);
    }

    public void enterReportLine2(String line2) {
        waitForVisibility(reportLine2Input).clear();
        reportLine2Input.sendKeys(line2);
    }

    public void enterReportLine3(String line3) {
        waitForVisibility(reportLine3Input).clear();
        reportLine3Input.sendKeys(line3);
    }

    public void enterReportLine4(String line4) {
        waitForVisibility(reportLine4Input).clear();
        reportLine4Input.sendKeys(line4);
    }

    public void enterReportLine5(String line5) {
        waitForVisibility(reportLine5Input).clear();
        reportLine5Input.sendKeys(line5);
    }

    public void enterReportMessage(String message) {
        waitForVisibility(reportMessageInput).clear();
        reportMessageInput.sendKeys(message);
    }


    // ---------- High-Level Methods ----------
    public void addPharmacyLocation(String name, String mobile, String email, String gstn, String dlno, String salesWh, String purchaseWh) {
        clickPharmacyLocationTab();
        clickAddPharmacyLocation();
        enterLocationName(name);
        enterMobileNumber(mobile);
        enterEmail(email);
        enterGSTN(gstn);
        enterDLNO(dlno);
        selectSalesCheckbox();
        selectSalesWarehouse(salesWh);
        selectPurchaseCheckbox();
        selectPurchaseWarehouse(purchaseWh);
       
       
    }
    public void fillCommunicationAddress(String doorNo, String addr1, String addr2, String city,
            String district,
            String landmark, String pincode) {
enterDoorNo(doorNo);
enterAddress1(addr1);
enterAddress2(addr2);
enterCity(city);
selectDistrict(district);
enterLandmark(landmark);
enterPincode(pincode);
}

    public void enterReportDetails(String line1, String line2, String line3, String line4, String line5, String message) {
        enterReportLine1(line1);
        enterReportLine2(line2);
        enterReportLine3(line3);
        enterReportLine4(line4);
        enterReportLine5(line5);
        enterReportMessage(message);
    }


    public HMSLocationPage saveAndReturnToHMSPage() {
        clickSave();
//        waitForPharmacyPageWithBackClick(); // Custom method from Abstraction
        return new HMSLocationPage(driver);
    }
    
    @FindBy(xpath = "//p[contains(text(),'Incorrect Name')]")
    private WebElement incorrectNameMessage;

    public String getIncorrectNameMessage() {
        return waitForVisibility(incorrectNameMessage).getText();
    }

    @FindBy(xpath = "//p[contains(text(),'Incorrect Mobile No')]")
    private WebElement incorrectMobileMessage;

    public String getIncorrectMobileMessage() {
        return waitForVisibility(incorrectMobileMessage).getText();
    }

    @FindBy(xpath = "//p[contains(text(),'Incorrect Email')]")
    private WebElement incorrectEmailMessage;

    public String getIncorrectEmailMessage() {
        return waitForVisibility(incorrectEmailMessage).getText();
    }

    @FindBy(xpath = "//p[contains(text(),'Incorrect City')]")
    private WebElement incorrectCityMessage;

    public String getIncorrectCityMessage() {
        return waitForVisibility(incorrectCityMessage).getText();
    }

    @FindBy(xpath = "//p[contains(text(),'Incorrect Pincode')]")
    private WebElement incorrectPincodeMessage;

    public String getIncorrectPincodeMessage() {
        return waitForVisibility(incorrectPincodeMessage).getText();
    }

    @FindBy(xpath = "//p[contains(text(),'Incorrect Report Line1')]")
    private WebElement incorrectReportLine1Message;

    public String getIncorrectReportLine1Message() {
        return waitForVisibility(incorrectReportLine1Message).getText();
    }

}
