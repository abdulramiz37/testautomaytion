package PharmacyFlowObjects.PharmacyStore;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import EzionAbstractionComponents.Abstraction;

public class StorageShelfPage extends Abstraction {

    public StorageShelfPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    // --- Locators ---

    @FindBy(xpath = "//a[text()=' Storage Shelf']")
    private WebElement storageShelfTab;

    @FindBy(xpath = "//a[text()=' Add Storage Shelf ']")
    private WebElement addStorageShelfButton;

    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement storageShelfNameInput;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;
    @FindBy(xpath = "//span[contains(text(),'Name Already Exists..')]")
    private WebElement duplicateNameError;

    // --- Actions ---

    public void openStorageShelfSection() {
        waitForClickability(storageShelfTab).click();
    }

    public void clickAddStorageShelf() {
        waitForClickability(addStorageShelfButton).click();
    }

    public void enterStorageShelfName(String name) {
        waitForClickability(storageShelfNameInput).click();
        waitForVisibility(storageShelfNameInput).sendKeys(name);
    }

    public void clickSaveButton() {
        waitForClickability(saveButton).click();
    }

    public void createStorageShelf(String name) {
        openStorageShelfSection();
        clickAddStorageShelf();
        enterStorageShelfName(name);
       
    }
    public MedicinePage save() {
    	 clickSaveButton();
//    	 waitForPharmacyPageWithBackClick();
    	 MedicinePage medicine = new MedicinePage(driver);
    	 return medicine;
    }
    
    public String duplicateError() {
    	System.out.println(duplicateNameError.getText());
    	return duplicateNameError.getText();
    }
}

