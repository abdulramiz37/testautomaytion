package PharmacyFlowObjects;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class RolesManagementPage extends Abstraction {
    
    public RolesManagementPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    // --- Web Elements ---
    @FindBy(xpath = "(//i[@class='dropdown-toggle'])[2]")
    private WebElement userRoleDropdown;
    
    @FindBy(xpath = "(//i[@class='dropdown-toggle'])[3]")
    private WebElement thirdDropdown;
    
    @FindBy(xpath = "//table//th[1]")
    private WebElement tableHeader;
    
    @FindBy(xpath = "//input[@placeholder='Select']")
    private WebElement userSelectInput;
    
    @FindBy(xpath = "(//span[@class='checkmark'])[1]")
    private WebElement firstCheckbox;
    
    @FindBy(xpath = "(//input[@value='Save'])[1]")
    private WebElement saveButton1;
    
    @FindBy(xpath = "(//input[@value='Save'])[2]")
    private WebElement saveButton2;
    
    @FindBy(xpath = "//div[@class='error-message ng-star-inserted']")
    WebElement branchSelectionError;

    // --- Generic Method to find span by text ---
    private WebElement getSpanByText(String text) {
        String xpath = String.format("//span[text()='%s']", text);
        return driver.findElement(By.xpath(xpath));
    }
    private WebElement getSpanByText2(String text) {
        String xpath = String.format("(//span[text()='%s'])[2]", text);
        return driver.findElement(By.xpath(xpath));
    }
    private WebElement getSpanByText3(String text) {
        String xpath1 = String.format("(//span[text()='%s'])[2]", text);
        return driver.findElement(By.xpath(xpath1));
    }
    // --- Action Methods ---

    public void selectRoleAndSection(String roleText, String sectionText) {
        waitForClickability(userRoleDropdown).click();
        waitForClickability(getSpanByText(roleText)).click();
        waitForClickability(thirdDropdown).click();
        waitForClickability(getSpanByText2(sectionText)).click();
    }

    public void expandSection(String sectionText) {
        
        for (int i = 0; i < 10; i++) {
            try {
                waitForClickability(getSpanByText2(sectionText)).click();
                waitForClickability(getSpanByText2(sectionText)).click();
                if (waitForVisibility(tableHeader) != null) break;
            } catch (Exception e) {
                System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
            }
        }
    }
    public void selectRoleAndSectioninventory (String sectionText) {
    	  clickWithJavaScript(thirdDropdown);
        waitForClickability(getSpanByText2(sectionText)).click();
    }
    public void selectUserAndSave(String userName) {
        waitForClickability(userSelectInput).click();
        try {
            waitForClickability(getSpanByText3(userName)).click();
        } catch (Exception e) {
            System.out.println("Username '" + userName + "' not found. Skipping click.");
        }

        
        
        waitForClickability(firstCheckbox).click();

        try {
            waitForClickability(saveButton1).click();
        } catch (Exception ignored) {}

        try {
            waitForClickability(saveButton2).click();
        } catch (Exception ignored) {}
    }
    public String getBranchSelectionErrorText() {
    	System.out.println(branchSelectionError.getText());
        return branchSelectionError.getText();
    }
    public void Save() {
      
        waitForClickability(firstCheckbox).click();

        try {
            waitForClickability(saveButton1).click();
        } catch (Exception ignored) {}

        try {
            waitForClickability(saveButton2).click();
        } catch (Exception ignored) {}
    }
}