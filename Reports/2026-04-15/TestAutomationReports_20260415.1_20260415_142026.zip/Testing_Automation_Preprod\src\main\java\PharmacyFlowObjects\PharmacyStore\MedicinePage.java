package PharmacyFlowObjects.PharmacyStore;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.*;

import EzionAbstractionComponents.Abstraction;

import java.time.Duration;
import java.util.Random;

public class MedicinePage extends Abstraction {

    WebDriver driver;
    WebDriverWait wait;

    public MedicinePage(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        PageFactory.initElements(driver, this);
    }

    // --- Web Elements ---

    @FindBy(xpath = "//a[text()=' Medicine']")
    private WebElement medicineMenu;

    @FindBy(xpath = "//a[text()=' Add Medicine ']")
    private WebElement addMedicineBtn;

    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement medicineNameInput;

    @FindBy(xpath = "//ng-select[@formcontrolname='medicineType']//input[@role='combobox']")
    private WebElement scheduleDropdownInput;

    @FindBy(xpath = "//ng-select[@formcontrolname='medicineCategory']//input[@role='combobox']")
    private WebElement categoryDropdownInput;

    @FindBy(xpath = "//ng-select[@formcontrolname='brand']//input[@role='combobox']")
    private WebElement brandDropdownInput;

    @FindBy(xpath = "//ng-select[@formcontrolname='genericName']//input[@role='combobox']")
    private WebElement compositionDropdownInput;

    @FindBy(xpath = "//ng-select[@formcontrolname='manufactName']//input[@role='combobox']")
    private WebElement manufacturerDropdownInput;

    @FindBy(xpath = "//input[@formcontrolname='units']")
    private WebElement quantityInput;

    @FindBy(xpath = "//ng-select[@formcontrolname='rack']//input[@role='combobox']")
    private WebElement rackDropdownInput;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;


    @FindBy(xpath = "//input[@value='Update']")
    private WebElement update;
    // --- Dynamic Span Getter ---
    private WebElement getSpanByText(String text) {
    	 String xpath = String.format(
    		        "//span[contains(@class,'ng-option-label') and " +
    		        "translate(normalize-space(text()), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz')=" +
    		        "translate('%s', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz')]", 
    		        text.trim()
    		    );
        return driver.findElement(By.xpath(xpath));
    }
    // --- Actions ---
    @FindBy(xpath = "//input[@type='text' and @placeholder='Enter Medicine Name']")
    private WebElement medicineInput;

    // Method to enter medicine name
    public void enterMedicineName(String medicineName) {
    	   medicineMenu.click();
        medicineInput.clear();        // Optional: clear existing text
        medicineInput.sendKeys(medicineName);
    }
    
    @FindBy(xpath = "//a[@role='button' and @title='Edit']")
    private WebElement editButton;

    // Method to click Edit
    public void clickEdit() {
        editButton.click();
    }
    
    public void addmedicine() {
    	 medicineMenu.click();
    }
public String uniquename;
    public void addMedicine(String medicineName ,String scheduleText, String categoryText,  
            String compositionText, String manufacturerText, String quantity) throws InterruptedException {
//        medicineMenu.click();
        clickWithJavaScript(addMedicineBtn);
        if (medicineName == null || medicineName.trim().isEmpty()) {
            medicineName = "Medicines" + new Random().nextInt(10000);
        }
        uniquename=medicineName;
        // Now send the value
        waitForClickability(medicineNameInput).sendKeys(medicineName);

        waitForPageLoad();

        scheduleDropdownInput.click();
        scheduleDropdownInput.sendKeys(scheduleText);
        retryClickSpan(scheduleText,4);

        categoryDropdownInput.click();
        categoryDropdownInput.sendKeys(categoryText);
        retryClickSpan(categoryText,4);
//
//        brandDropdownInput.click();
//        retryClickSpan(brandText, 50);

        compositionDropdownInput.click();
        compositionDropdownInput.sendKeys(compositionText);
        retryClickSpan(compositionText, 50);

        manufacturerDropdownInput.click();
        manufacturerDropdownInput.sendKeys(manufacturerText);
        retryClickSpan(manufacturerText,4);

        quantityInput.sendKeys(quantity);

        rackDropdownInput.click();
        
        driver.findElement(By.xpath("//div[@role='option']//span[contains(@class,'ng-option-label')]")).click();

//        saveButton.click();
    }
    @FindBy(xpath = "//input[@type='checkbox' and @value='vaccineFlag']")
    private WebElement vaccineCheckbox;

    // Method to check the checkbox
    public void selectVaccineCheckbox() {
        if(!vaccineCheckbox.isSelected()) {
        	clickWithJavaScript(vaccineCheckbox);
        }
    }
    public CustomerPage save() {
    	clickWithJavaScript(saveButton);
//    	  waitForPharmacyPageWithBackClickOnce2();
    	  CustomerPage customerpage = new CustomerPage(driver);
    	  return customerpage;
    }

    public void updatebutton() {
    	clickWithJavaScript(update);
//    	  waitForPharmacyPageWithBackClickOnce2();
    	
    }
    private void waitForPageLoad() {
        wait.until(webDriver ->
                ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
    }

    private void retryClickSpan(String spanText, int maxAttempts) throws InterruptedException {
        for (int i = 0; i < maxAttempts; i++) {
            try {
            	waitForClickability(getSpanByText(spanText)).click();
                break;
            } catch (Exception e) {
                System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
                if (i == maxAttempts - 1) throw e;
             
            }
        }
    }
    @FindBy(xpath = "//input[@formcontrolname='minQty']")
    private WebElement minQtyInput;

    @FindBy(xpath = "//input[@formcontrolname='maxQty']")
    private WebElement maxQtyInput;

    @FindBy(xpath = "//input[@formcontrolname='ReorderQty']")
    private WebElement reorderQtyInput;

    @FindBy(xpath = "//input[@formcontrolname='Reorder Level']")
    private WebElement reorderLevelInput;

    @FindBy(xpath = "//input[@formcontrolname='hsnCode']")
    private WebElement hsnCodeInput;

    @FindBy(xpath = "//ng-select[@formcontrolname='gst']//input[@role='combobox']")
    private WebElement gstDropdownInput;

    @FindBy(xpath = "//ng-select[@formcontrolname='discrequired']//input[@role='combobox']")
    private WebElement discountRequiredDropdownInput;

    @FindBy(xpath = "//textarea[@formcontrolname='medDescription']")
    private WebElement descriptionTextArea;

    @FindBy(xpath = "//input[@formcontrolname='discpercentage']")
    private WebElement enterdiscount;
    
    @FindBy(xpath = "//input[@formcontrolname='attribute']")
    private WebElement attributeInput;

    @FindBy(xpath = "//input[@value='Add Attribute']")
    private WebElement addAttributeButton;

    @FindBy(xpath = "//input[@formcontrolname='medCP']")
    private WebElement costPriceInput;

    @FindBy(xpath = "//input[@formcontrolname='medMrp']")
    private WebElement mrpInput;

    @FindBy(xpath = "//input[@formcontrolname='medSellPrice']")
    private WebElement sellPriceInput;

    @FindBy(xpath = "//input[@formcontrolname='medQty']")
    private WebElement noOfStripsInput;

    @FindBy(xpath = "//input[@formcontrolname='medFreeQty']")
    private WebElement freeStripsInput;

    @FindBy(xpath = "//input[@formcontrolname='medFormula']")
    private WebElement formulaInput; // usually readonly

    public void enterMinQty(String qty) {
        waitForVisibility(minQtyInput).sendKeys(qty);
    }

    public void enterMaxQty(String qty) {
        waitForVisibility(maxQtyInput).sendKeys(qty);
    }

    public void enterReorderQty(String qty) {
        waitForVisibility(reorderQtyInput).sendKeys(qty);
    }

    public void enterReorderLevel(String level) {
        waitForVisibility(reorderLevelInput).sendKeys(level);
    }

    public void enterHSNCode(String code) {
        waitForVisibility(hsnCodeInput).sendKeys(code);
    }

    public void selectGST(String gstValue) throws InterruptedException {
        gstDropdownInput.click();
        retryClickSpan(gstValue, 5);
    }

    public void selectDiscountRequired(String value) throws InterruptedException {
        discountRequiredDropdownInput.click();
        retryClickSpan(value, 5);
    }
    
    public void enterDiscount(String discount) {
        waitForVisibility(enterdiscount).sendKeys(discount);
    }

    public void enterDescription(String description) {
        waitForVisibility(descriptionTextArea).sendKeys(description);
    }

    public void enterAttribute(String attribute) {
        waitForVisibility(attributeInput).sendKeys(attribute);
        waitForClickability(addAttributeButton).click();
    }

    public void enterCostPrice(String price) {
        waitForVisibility(costPriceInput).sendKeys(price);
    }

    public void enterMRP(String price) {
        WebElement mrp = waitForVisibility(mrpInput);
        mrp.clear();
        mrp.sendKeys(price);
    }
    public void enterSellPrice(String price) {
        WebElement sellPrice = waitForVisibility(sellPriceInput);
        sellPrice.clear();
        sellPrice.sendKeys(price);
    }

    public void enterNoOfStrips(String qty) {
        waitForVisibility(noOfStripsInput).sendKeys(qty);
    }

    public void enterFreeStrips(String qty) {
        waitForVisibility(freeStripsInput).sendKeys(qty);
    }

    
}
