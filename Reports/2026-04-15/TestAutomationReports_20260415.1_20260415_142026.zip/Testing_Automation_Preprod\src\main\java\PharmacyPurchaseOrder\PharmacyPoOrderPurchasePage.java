package PharmacyPurchaseOrder;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

import EzionAbstractionComponents.Abstraction;

public class PharmacyPoOrderPurchasePage extends Abstraction {

    public PharmacyPoOrderPurchasePage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    // ---------- Static Elements ----------
    @FindBy(xpath = "(//span[text()='Select'])[1]")
    WebElement selectDropdown;

    @FindBy(xpath = "//input[@formcontrolname='invNo']")
    WebElement invoiceInput;

    @FindBy(xpath = "//input[@formcontrolname='invDate']")
    WebElement invoiceDateInput;

    @FindBy(xpath = "//input[@formcontrolname='invDueDate']")
    WebElement invoiceDueDateInput;

    @FindBy(xpath = "(//span[text()='Search'])[1]")
    WebElement searchButton;

    @FindBy(xpath = "//input[@formcontrolname='BatchNumber']")
    WebElement batchNumberInput;

    @FindBy(xpath = "//label[text()='Payable Amt']/following-sibling::p")
    WebElement payableAmountLabel;

    @FindBy(xpath = "(//input[@formcontrolname='invValue'])[1]")
    WebElement invoiceValueInput;

    @FindBy(xpath = "//input[@value='Add']")
    WebElement addButton;

    @FindBy(xpath = "//input[@value='Save']")
    WebElement saveButton;

    @FindBy(xpath = "//input[@value='Yes']")
    WebElement yesButton;

    @FindBy(xpath = "//input[@value='Approve']")
    WebElement approveButton;

    // ---------- Dynamic Check ----------
    By duplicateInvoiceText = By.xpath("//*[contains(text(), 'Invoice No Already Exists')]");

    // ---------- Action Methods ----------

    public void selectPharmacyLocation(String locationName) {
        waitForClickability(selectDropdown).click();
        By dynamicLocation = By.xpath("(//span[text()='" + locationName + "'])[1]");
        WebElement locationOption = waitForVisibility(driver.findElement(dynamicLocation));
        locationOption.click();
    }

    public void enterUniqueInvoiceNumber(String invoiceNumberStr) {
        int invoiceNumber;
        try {
            invoiceNumber = Integer.parseInt(invoiceNumberStr.trim());
        } catch (NumberFormatException e) {
            System.out.println("⚠️ Invalid invoice number input. Defaulting to 1.");
            invoiceNumber = 1;
        }

        while (true) {
            String finalInvoice = String.valueOf(invoiceNumber);
            waitForVisibility(invoiceInput).clear();
            invoiceInput.sendKeys(finalInvoice);

            if (driver.findElements(duplicateInvoiceText).isEmpty()) {
                System.out.println("✅ Unique Invoice No: " + finalInvoice);
                break;
            }

            invoiceNumber++;
        }
    }

    public void setInvoiceDates(String date) {
        waitForVisibility(invoiceDateInput);
        js.executeScript("arguments[0].value='" + date + "'; arguments[0].dispatchEvent(new Event('input'));", invoiceDateInput);

        WebElement dueDateInput = waitForVisibility(invoiceDueDateInput);
        js.executeScript("arguments[0].value='" + date + "'; arguments[0].dispatchEvent(new Event('input'));", dueDateInput);
    }

    public void searchAndSelectMedicine(String medicineName) {
        waitForVisibility(searchButton).click();
        By medicineLocator = By.xpath("//span[@class='mat-option-text']/span[contains(text(), '" + medicineName + "')]");
        WebElement medicineElement = waitForVisibility(driver.findElement(medicineLocator));
        clickWithJavaScript(medicineElement);
    }

    public void enterBatchAndExpiry(String batchNo, String expiryDate) {
        waitForVisibility(batchNumberInput).sendKeys(batchNo);

        WebElement expiryInput = waitForVisibility(driver.findElement(By.xpath("//input[@formcontrolname='expiryDate']")));
        js.executeScript(
            "const input = arguments[0];" +
            "const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;" +
            "nativeInputValueSetter.call(input, '" + expiryDate + "');" +
            "input.dispatchEvent(new Event('input', { bubbles: true }));" +
            "input.dispatchEvent(new Event('change', { bubbles: true }));",
            expiryInput
        );
    }

    public void enterPayableAmountAndSubmit() {
        String payableAmt = waitForVisibility(payableAmountLabel).getText().trim();
        waitForVisibility(invoiceValueInput).sendKeys(payableAmt);

        waitForVisibility(addButton).click();
        waitForVisibility(saveButton).click();
        waitForVisibility(yesButton).click();
        waitForVisibility(approveButton).click();
    }
}
