package WareHouseSetup.MyHospital.Service;

import EzionAbstractionComponents.Abstraction;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LabTestPage extends Abstraction {

    WebDriver driver;

    public LabTestPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // WebElement locators

    @FindBy(xpath = "(//input[@formcontrolname='name'])[4]")
    private WebElement testNameInput;

    @FindBy(xpath = "(//label[contains(text(),'Select Category')]/following::div[contains(@class,'ngx-select__toggle')][1])[2]")
    private WebElement categoryDropdown;

    @FindBy(xpath = "(//label[contains(text(),'Select Category')]/following::div[contains(@class,'ngx-select__toggle')][2])[2]")
    private WebElement gst2;

    @FindBy(xpath = "(//input[@formcontrolname='price'])[2]")
    private WebElement priceInput;

    @FindBy(xpath = "(//input[@formcontrolname='srvReqNo'])[2]")
    private WebElement srvReqNoInput;

    @FindBy(xpath = "(//label[contains(text(),'Is Culture Test')])[1]")
    private WebElement cultureTestCheckbox;

    @FindBy(xpath = "(//label[contains(text(),'Is Histopathology')])[1]")
    private WebElement histopathologyCheckbox;

    @FindBy(xpath = "(//label[contains(text(),'Is Editable ')])[2]")
    private WebElement editableCheckbox;

    @FindBy(xpath = "(//label[contains(text(),'Is Active')])[3]")
    private WebElement activeCheckbox;
    
    @FindBy(xpath = "(//label[contains(text(),'Is Active')])[4]")
    private WebElement activeCheckbox2;

    @FindBy(xpath = "//input[@formcontrolname='zeroServiceFlag']")
    private WebElement allowZeroCheckbox;

    @FindBy(xpath = "//ng-select[@formcontrolname='sampleType']//div[contains(@class,'ng-select-container')]")
    private WebElement sampleTypeDropdown;

    @FindBy(xpath = "//ng-select[@formcontrolname='department']//div[contains(@class,'ng-select-container')]")
    private WebElement departmentDropdown;

    @FindBy(xpath = "(//input[@value='Save'])[4]")
    private WebElement saveButton;

    // Actions
    @FindBy(xpath = "//span[text()='Lab Test']")
    private WebElement serviceTab;

    @FindBy(xpath = "//a[contains(@class,'btn-plus') and .//img[@alt='add']]")
    private WebElement addServiceBtn;

 // Unit Dropdown
    @FindBy(xpath = "//ngx-select[@formcontrolname='unitName']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement unitDropdown;

    // Lab Category Dropdown
    @FindBy(xpath = "//ngx-select[@formcontrolname='labCatgryName']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement labCategoryDropdown;

    // Default Value Input
    @FindBy(xpath = "//input[@formcontrolname='defaultValue']")
    private WebElement defaultValueInput;

    // Calculated Value Checkbox
    @FindBy(xpath = "(//label[contains(text(),'Calculated Value ')])[1]")
    private WebElement calculatedValueCheckbox;

    // Lab Test Method Dropdown
    @FindBy(xpath = "//ngx-select[@formcontrolname='labtestmethod']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement labTestMethodDropdown;

    // Lab Test Material Dropdown
    @FindBy(xpath = "//ngx-select[@formcontrolname='labtestmaterial']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement labTestMaterialDropdown;

    // Sample Type Dropdown (duplicate but different context - handled if required separately)
    @FindBy(xpath = "(//ngx-select[@formcontrolname='sampleType']//div[contains(@class,'ngx-select__toggle')])[last()]")
    private WebElement sampleTypeDropdown2;

    // Outside Lab Checkbox
    @FindBy(xpath = "//input[@formcontrolname='outside']")
    private WebElement outsideLabCheckbox;
    
    @FindBy(xpath = "//label[text()='Input Control Type']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement inputControlTypeDropdown;

    @FindBy(xpath = "//label[text()='Input Data Type']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement inputDataTypeDropdown;

    @FindBy(xpath = "//input[@formcontrolname='inputLength']")
    private WebElement inputLengthField;

 // Others section
    @FindBy(xpath = "//input[@formcontrolname='othersMinValue']")
    private WebElement othersMinValueInput;

    @FindBy(xpath = "//input[@formcontrolname='othersMaxValue']")
    private WebElement othersMaxValueInput;

    // Children section
    @FindBy(xpath = "//input[@formcontrolname='childrenMinValue']")
    private WebElement childrenMinValueInput;

    @FindBy(xpath = "//input[@formcontrolname='childrenMaxValue']")
    private WebElement childrenMaxValueInput;

 // Adult Male
    @FindBy(xpath = "//input[@formcontrolname='maleMinValue']")
    private WebElement maleMinValueInput;

    @FindBy(xpath = "//input[@formcontrolname='maleMaxValue']")
    private WebElement maleMaxValueInput;

    // Adult Female
    @FindBy(xpath = "//input[@formcontrolname='femaleMinValue']")
    private WebElement femaleMinValueInput;

    @FindBy(xpath = "//input[@formcontrolname='femaleMaxValue']")
    private WebElement femaleMaxValueInput;

    // ========== Methods ==========

    public void openServiceForm() {
        clickWithJavaScript(serviceTab);
        clickWithJavaScript(addServiceBtn);
    }

    public void enterTestName(String testName) {
        waitForVisibility(testNameInput).clear();
        testNameInput.sendKeys(testName);
    }

    public void selectCategory(String category) {
        waitForClickability(categoryDropdown).click();
        selectDropdownOptionByVisibleText(category);
    }

    public void gst(String gst) {
        waitForClickability(gst2).click();
        selectDropdownOptionByVisibleText(gst);
    }

    public void setPrice(String price) {
        priceInput.clear();
        priceInput.sendKeys(price);
    }

    public void setSrvReqNo(String srvReqNo) {
        srvReqNoInput.clear();
        srvReqNoInput.sendKeys(srvReqNo);
    }

    public void toggleCultureTestCheckbox() {
        cultureTestCheckbox.click();
    }

    public void toggleHistopathologyCheckbox() {
        histopathologyCheckbox.click();
    }

    public void toggleEditableCheckbox() {
        editableCheckbox.click();
    }

    public void toggleActiveCheckbox() {
        activeCheckbox.click();
    }
    public void toggleActiveCheckbox2() {
        activeCheckbox2.click();
    }
    public void toggleAllowZeroCheckbox() {
        allowZeroCheckbox.click();
    }

    public void selectSampleType(String sampleType) {
        waitForClickability(sampleTypeDropdown).click();
        selectDropdownOptionByVisibleText(sampleType);
    }

    public void selectDepartment(String department) {
        waitForClickability(departmentDropdown).click();
        selectDropdownOptionByVisibleText(department);
    }

    public void clickSaveButton() {
    	clickWithJavaScript(saveButton);
    }

    public void selectDropdownOptionByVisibleText(String text) {
        WebElement option = driver.findElement(
            By.xpath("//ul[contains(@class,'ngx-select__choices')]//a[contains(@class,'ngx-select__item')]//span[text()='" + text + "']")
        );
        waitForClickability(option).click();
    }
    public void selectUnit(String unit) {
        waitForClickability(unitDropdown).click();
        selectDropdownOptionByVisibleText(unit);
    }

    public void selectLabCategory(String category) {
        waitForClickability(labCategoryDropdown).click();
        selectDropdownOptionByVisibleText(category);
    }

    public void setDefaultValue(String value) {
        waitForVisibility(defaultValueInput).clear();
        defaultValueInput.sendKeys(value);
    }

    public void clickCalculatedValueCheckbox() {
        waitForClickability(calculatedValueCheckbox).click();
    }

    public void selectLabTestMethod(String method) {
        waitForClickability(labTestMethodDropdown).click();
        selectDropdownOptionByVisibleText(method);
    }

    public void selectLabTestMaterial(String material) {
        waitForClickability(labTestMaterialDropdown).click();
        selectDropdownOptionByVisibleText(material);
    }

    public void selectSampleType2(String sampleType) {
        waitForClickability(sampleTypeDropdown2).click();
        selectDropdownOptionByVisibleText(sampleType);
    }

    public void clickOutsideLabCheckbox() {
        waitForClickability(outsideLabCheckbox).click();
    }
    public void selectInputControlType(String controlType) {
        waitForClickability(inputControlTypeDropdown).click();
        selectDropdownOptionByVisibleText(controlType);
    }

    public void selectInputDataType(String dataType) {
        waitForClickability(inputDataTypeDropdown).click();
        selectDropdownOptionByVisibleText(dataType);
    }

    public void enterInputLength(String length) {
        waitForVisibility(inputLengthField).clear();
        inputLengthField.sendKeys(length);
    }
    public void setOthersMinValue(String value) {
        waitForVisibility(othersMinValueInput).clear();
        othersMinValueInput.sendKeys(value);
    }

    public void setOthersMaxValue(String value) {
        waitForVisibility(othersMaxValueInput).clear();
        othersMaxValueInput.sendKeys(value);
    }

    public void setChildrenMinValue(String value) {
        waitForVisibility(childrenMinValueInput).clear();
        childrenMinValueInput.sendKeys(value);
    }

    public void setChildrenMaxValue(String value) {
        waitForVisibility(childrenMaxValueInput).clear();
        childrenMaxValueInput.sendKeys(value);
    }
    public void setMaleMinValue(String value) {
        waitForVisibility(maleMinValueInput).clear();
        maleMinValueInput.sendKeys(value);
    }

    public void setMaleMaxValue(String value) {
        waitForVisibility(maleMaxValueInput).clear();
        maleMaxValueInput.sendKeys(value);
    }

    public void setFemaleMinValue(String value) {
        waitForVisibility(femaleMinValueInput).clear();
        femaleMinValueInput.sendKeys(value);
    }

    public void setFemaleMaxValue(String value) {
        waitForVisibility(femaleMaxValueInput).clear();
        femaleMaxValueInput.sendKeys(value);
    }

    // ========== Main Form Fill Method ==========
    public void fillLabTestForm(String testName, String category, String gst,String price, String srvReqNo, String unit,String category2,
            String defaultValue, String method, String material, String sampleType,String controlType,String dataType,String length,String othersMin,
            String othersMax, String childrenMin, String childrenMax,String maleMin, String maleMax, String femaleMin, String femaleMax) {
    	
openServiceForm();
        enterTestName(testName);
        selectCategory(category);
        gst(gst);
        setPrice(price);
        setSrvReqNo(srvReqNo);
//        toggleCultureTestCheckbox();
        toggleHistopathologyCheckbox();
        toggleEditableCheckbox();
        toggleActiveCheckbox();
        
        selectUnit(unit);
        selectLabCategory(category2); // Assuming same category used
        setDefaultValue(defaultValue);
//        clickCalculatedValueCheckbox();
        selectLabTestMethod(method);
        selectLabTestMaterial(material);
        selectSampleType2(sampleType);
//        clickOutsideLabCheckbox();
        selectInputControlType(controlType);
        selectInputDataType(dataType);
        enterInputLength(length);
        
        setOthersMinValue(othersMin);
        setOthersMaxValue(othersMax);
        setChildrenMinValue(childrenMin);
        setChildrenMaxValue(childrenMax);
        setMaleMinValue(maleMin);
        setMaleMaxValue(maleMax);
        setFemaleMinValue(femaleMin);
        setFemaleMaxValue(femaleMax);
        toggleActiveCheckbox2();
        clickSaveButton();
        
    }
}
