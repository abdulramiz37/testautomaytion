package TestComponents;



	import java.io.IOException;
	import java.util.HashMap;
	import java.util.List;

	import org.testng.annotations.DataProvider;
	import org.testng.annotations.Test;

	import EzionpageObjects.UserIdPage;
import PharmacyFlowObjects.PharmacyStore.MedicinePageUpdate;
import PharmacyStocks.OpeningStock;
import abdulTest.BaseTest;


public class ExcessStockChecker extends BaseTest {

	    @Test(dataProvider = "getData")
	    public void ExcessStockCheckerTest(HashMap<String, String> input) throws InterruptedException {
	        // Login
	        UserIdPage data = login.login(input.get("userId"));
	        data.enterMobileNumber(input.get("personId"));
	        data.enterPassword(input.get("password"));
	        data.clickContinue();
	        data.openMasterSetup();
	        
	        MedicinePageUpdate medicine = new MedicinePageUpdate(driver);
	        medicine.addMedicine(
	            input.get("baseMedicineName"),
	            input.get("scheduleText"),
	            input.get("categoryText"),
	            input.get("brandText"),
	            input.get("compositionText"),
	            input.get("manufacturerText"),
	            input.get("quantity"),
	            input.get("minQty"),
	            input.get("maxQty"),
	            input.get("rackText")
	        );
String uniqueName=medicine.uniqueName();

	        medicine.save();
	        OpeningStock openingStock = new OpeningStock(driver);
	        openingStock.addOpeningStock(
	            input.get("location"),
	            uniqueName,
	            input.get("batchNumber"),
	            input.get("expiryMonthYear"),
	            input.get("pricePerStrips"),
	            input.get("mrpPerStrip"),
	            input.get("sellPriceStrip"),
	            input.get("qtyInStrips"),
	            input.get("qtyInUnits")
	        );
	        openingStock.highStock(medicine.uniqueName());
	        
	        // Navigate to Indent Page
	     

	        // Go to table page and perform actions

	    }

	    @DataProvider
	    public Object[][] getData() throws IOException {
	        List<HashMap<String, String>> data = getJsonDataToMap(
	            System.getProperty("user.dir") + "//src//main//java//ezion//Resources//StockList.json"
	        );
	        return new Object[][] { { data.get(0) } };
	    }
	}


