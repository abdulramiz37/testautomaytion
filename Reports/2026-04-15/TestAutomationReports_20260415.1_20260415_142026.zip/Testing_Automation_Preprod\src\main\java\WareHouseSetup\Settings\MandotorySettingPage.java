package WareHouseSetup.Settings;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class MandotorySettingPage extends Abstraction {

    WebDriver driver;

    public MandotorySettingPage(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Locator for the ngx-select dropdown field (Page)
    @FindBy(id = "pageName")
    private WebElement pageDropdown;

    // Locator for Save button
    @FindBy(xpath = "//input[@type='button' and @value='Save']")
    private WebElement saveButton;

    // Locator for Cancel button
    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
    private WebElement cancelButton;
    
    @FindBy(xpath = "//a[text()=' Mandatory Setting ']")
    private WebElement mandotory;
  
    public void selectPageOption(String visibleText) {
    	mandotory.click();
        pageDropdown.click(); // open the dropdown
        String optionXpath = String.format("//span[contains(text(),'%s')]", visibleText);
        WebElement option = driver.findElement(By.xpath(optionXpath));
        option.click();
        clickSave();
    }

    // Method to click Save button
    public void clickSave() {
        saveButton.click();
    }

    // Method to click Cancel button
    public void clickCancel() {
        cancelButton.click();
    }
}

