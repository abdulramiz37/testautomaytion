package WareHouseSetup.Accounts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import EzionAbstractionComponents.Abstraction;

public class LedgerDetailsPage extends Abstraction {

    public LedgerDetailsPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    // Locators
    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement ledgerNameInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='accountGroupId']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement accountGroupDropdown;

    @FindBy(xpath = "//input[@formcontrolname='ledgerCode']")
    private WebElement ledgerCodeInput;

    @FindBy(xpath = "//input[@type='button' and @value='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
    private WebElement cancelButton;

    @FindBy(xpath = "//a[text()=' Ledger ']")
    private WebElement userType;

    @FindBy(xpath = "//a[text()=' Add Ledger ']")
    private WebElement adduserType;
     
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}
    // Methods

    public void enterLedgerName(String name) {
        WebElement el = waitForVisibility(ledgerNameInput);
        el.clear();
        el.sendKeys(name);
    }

    public void selectAccountGroup(String groupName) {
        clickWithJavaScript(waitForClickability(accountGroupDropdown));
        WebElement option = waitForClickability(
            By.xpath("//span[normalize-space(text())='" + groupName + "']")
        );
        option.click();
    }

    public void enterLedgerCode(String code) {
        WebElement el = waitForVisibility(ledgerCodeInput);
        el.clear();
        el.sendKeys(code);
    }

    public void clickSave() {
        waitForClickability(saveButton).click();
    }

    public void clickCancel() {
        waitForClickability(cancelButton).click();
    }

    public void fillLedgerForm(String name, String groupName, String code) {
    	clickbuttonapproval();
        enterLedgerName(name);
        selectAccountGroup(groupName);
        enterLedgerCode(code);
        clickSave();
    }
}
