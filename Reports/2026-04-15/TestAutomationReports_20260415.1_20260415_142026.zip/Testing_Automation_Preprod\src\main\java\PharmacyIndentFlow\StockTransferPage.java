package PharmacyIndentFlow;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import EzionAbstractionComponents.Abstraction;

public class StockTransferPage extends Abstraction {

    public StockTransferPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    // Page Elements
    @FindBy(xpath = "(//span[text()='Stock Transfer'])[1]")
    private WebElement stockTransferTab;

    @FindBy(xpath = "(//a[text()=' Add Transfer '])[1]")
    private WebElement addTransferBtn;

    @FindBy(xpath = "//input[@formcontrolname='issueDate']")
    private WebElement issueDateInput;

    @FindBy(xpath = "//label[text()='Transfer by']/following::div[contains(@class,'ngx-select__toggle')][1]")
    private WebElement transferByDropdown;

    @FindBy(xpath = "//label[text()='Destination Location']/following::div[contains(@class,'ngx-select__toggle')][1]")
    private WebElement destinationLocationDropdown;

    @FindBy(xpath = "//label[text()='Destination Warehouse']/following::div[contains(@class,'ngx-select__toggle')][1]")
    private WebElement destinationWarehouseDropdown;

    @FindBy(xpath = "//label[text()='Transfer Status']/following::div[contains(@class,'ngx-select__toggle')][1]")
    private WebElement transferStatusDropdown;

    @FindBy(xpath = "(//span[text()='Search Medicine'])[1]")
    private WebElement searchMedicineBtn;

    @FindBy(xpath = "//input[@formcontrolname='quantity']")
    private WebElement quantityInput;

    @FindBy(xpath = "//input[@value='Add']")
    private WebElement addBtn;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveBtn;

    // Helper
 // 1. Get <span> by exact text
    private WebElement getSpanByText(String text) {
        By locator = By.xpath("//span[text()='" + text + "']");
        return waitForVisibility(driver.findElement(locator));
    }

    // 2. Get <span> by partial text and index
    private WebElement getSpanByPartialText(String partialText, int index) {
        By locator = By.xpath("(//span[contains(text(),'" + partialText + "')])[" + index + "]");
        return waitForVisibility(driver.findElement(locator));
    }

    // 3. Get medicine card by name
    private WebElement getMedicineCard(String medicineName) {
        By locator = By.xpath("//span[@class='mat-option-text'][.//h4[contains(normalize-space(),'" + medicineName + "')]]");
        return waitForClickability(driver.findElement(locator));
    }


    // Main Action Method
    public void completeStockTransferFlow( String transferBy, String destLocation,
                                          String destWarehouse, String transferStatus, String medicineName, String qty) {

        waitForClickability(stockTransferTab).click();
        waitForClickability(addTransferBtn).click();

        waitForVisibility(issueDateInput).sendKeys(todayDate);

        // Transfer by
        waitForClickability(transferByDropdown).click();
        getSpanByText(transferBy).click();

        // Destination Location
        waitForClickability(destinationLocationDropdown).click();
        getSpanByPartialText(destLocation, 2).click();

        // Destination Warehouse
        waitForClickability(destinationWarehouseDropdown).click();
        getSpanByPartialText(destWarehouse, 1).click();

        // Transfer Status
        waitForClickability(transferStatusDropdown).click();
        getSpanByPartialText(transferStatus, 1).click();

        // Add product
        waitForClickability(searchMedicineBtn).click();
        getMedicineCard(medicineName).click();

        // Quantity and add
        waitForVisibility(quantityInput).sendKeys(qty);
        waitForClickability(addBtn).click();

        // Save using JS click
        WebElement save = waitForClickability(saveBtn);
        js.executeScript("arguments[0].click();", save);
    }
}
