package PharmacyIndentFlow;

	

	import java.util.List;

	import org.openqa.selenium.By;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.NoSuchElementException;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.WebDriverWait;

	import EzionAbstractionComponents.Abstraction;

	public class IndentRequestTablePage extends Abstraction {

	    public IndentRequestTablePage(WebDriver driver) {
	        super(driver);
	        PageFactory.initElements(driver, this);
	    }
	    // ------- Helper methods for dynamic table cells -------

	    private WebElement getIndentNumberCell(int rowIndex) {
	        By locator = By.xpath("//table[@class='table table-hover table-style']/tbody/tr[" + rowIndex + "]/td[2]");
	        return waitForVisibility(driver.findElement(locator));
	    }

	    private WebElement getStatusCell(int rowIndex) {
	        By locator = By.xpath("//table[@class='table table-hover table-style']/tbody/tr[" + rowIndex + "]/td[6]");
	        return waitForVisibility(driver.findElement(locator));
	    }

	    private WebElement getEditButton(int rowIndex) {
	        By locator = By.xpath("//table[@class='table table-hover table-style']/tbody/tr[" + rowIndex + "]/td[7]/li[1]/a");
	        return waitForClickability(driver.findElement(locator));
	    }
	    @FindBy(xpath = "(//input[@value='Send Request'])[1]")
	    private WebElement sendRequestButton;

	    @FindBy(xpath = "(//i[@class='fas fa-chevron-right'])[1]")
	    private WebElement nextButton;

	    private By tableRowsLocator = By.xpath("//table[@class='table table-hover table-style']/tbody/tr");

	    public String findAndEditIndentWithStatus(String statusToFind) {
	        String currentIndentNo = null;
	        boolean isFound = false;

	        while (!isFound) {
	            List<WebElement> freshRows = waitForPresenceOfAll(tableRowsLocator);

	            for (int i = 1; i <= freshRows.size(); i++) {
	                String indentNo = getIndentNumberCell(i).getText().trim();
	                String currentStatus = getStatusCell(i).getText().trim();

	                if (currentStatus.equalsIgnoreCase(statusToFind)) {
	                    getEditButton(i).click();
	                    currentIndentNo = indentNo;
	                    isFound = true;
	                    break;
	                }
	            }

	            if (!isFound) {
	                try {
	                    if (nextButton.isEnabled()) {
	                        clickWithJavaScript(nextButton);
	                    } else {
	                        break;
	                    }
	                } catch (NoSuchElementException e) {
	                    break;
	                }
	            }
	        }

	        return currentIndentNo;
	    }

	    public void clickSendRequest() {
	        waitForClickability(sendRequestButton,4).click();
	    }


	

}
