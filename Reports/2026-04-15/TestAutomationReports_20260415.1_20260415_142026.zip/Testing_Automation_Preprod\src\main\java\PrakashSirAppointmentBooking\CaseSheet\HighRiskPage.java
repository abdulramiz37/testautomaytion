package PrakashSirAppointmentBooking.CaseSheet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class HighRiskPage extends Abstraction{

	public HighRiskPage(WebDriver driver) {
		super(driver);
	       PageFactory.initElements(driver, this);
	}
	// Dropdown toggle (to open the High Risk list)
	@FindBy(xpath = "//label[contains(text(),'High Risk')]/following::div[contains(@class,'ngx-select__toggle')][1]")
	private WebElement highRiskDropdown;

	// Identified Date field
	@FindBy(xpath = "//input[@placeholder='DD/MM/YYYY']")
	private WebElement identifiedDateInput;

	// Buttons
	@FindBy(xpath = "//input[@value='Add HighRisk ']")
	private WebElement addHighRiskBtn;

	@FindBy(xpath = "//input[@value='Cancel']")
	private WebElement cancelBtn;

	@FindBy(xpath = "//input[@value='Reset']")
	private WebElement resetBtn;

	// Success messages
	@FindBy(xpath = "//span[contains(text(),'High Risk Saved Successfully')]")
	private WebElement successSaveMsg;

	@FindBy(xpath = "//span[contains(text(),'High Risk Updated Successfully')]")
	private WebElement successUpdateMsg;

	@FindBy(xpath = "//span[contains(text(),'High Risk Deleted Successfully')]")
	private WebElement successDeleteMsg;
	
	@FindBy(xpath = "//h4[normalize-space(text())='High Risk']/following::img[contains(@class,'openclose')][1]")
	private WebElement highRiskToggleIcon;

	public void closethebutton() {
		highRiskToggleIcon.click();
	}
	// Select any High Risk disease dynamically
	public void selectHighRisk(String diseaseName) {
	    highRiskDropdown.click();
	    WebElement option = driver.findElement(By.xpath(
	        "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + diseaseName + "']"
	    ));
	    option.click();
	    clickAddHighRisk();
	}
	public void selectMultipleHighRisks(String[] diseases) {
		clickHighRiskToggle();
	    for (String disease : diseases) {
	        selectHighRisk(disease);
	    }
	}
	public void clickHighRiskToggle() {
	    highRiskToggleIcon.click();
	}


	// Set Identified Date
	public void setIdentifiedDate(String date) {
	    identifiedDateInput.clear();
	    identifiedDateInput.sendKeys(date);
	}

	// Click Add High Risk
	public void clickAddHighRisk() {
	    addHighRiskBtn.click();
	}

	// Click Cancel
	public void clickCancel() {
	    cancelBtn.click();
	}

	// Click Reset
	public void clickReset() {
	    resetBtn.click();
	}

	// Verify Save Success
	public boolean isSaveSuccessDisplayed() {
	    return successSaveMsg.isDisplayed();
	}

	// Verify Update Success
	public boolean isUpdateSuccessDisplayed() {
	    return successUpdateMsg.isDisplayed();
	}

	// Verify Delete Success
	public boolean isDeleteSuccessDisplayed() {
	    return successDeleteMsg.isDisplayed();
	}

}
