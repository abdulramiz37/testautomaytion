package PrakashSirAppointmentBooking;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class EMR extends Abstraction {

	public EMR(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//input[@placeholder='Enter registered patient name / mobile number']")
	private WebElement patientSearchInput;

	public WebElement getPersonByName(String firstWord, int index) {
		String xpath = "(//tbody/tr/td[2][substring-before(normalize-space(.), ' ')='" + firstWord + "'])[" + index
				+ "]";
		return driver.findElement(By.xpath(xpath));
	}

	@FindBy(xpath = "//p[contains(@class,'block-heading-ehr') and contains(text(),'EMR / Accounts')]")
	private WebElement emrAccounts;

	@FindBy(xpath = "//h4[span[contains(@class,'status-visit-type') and normalize-space()='OP'] and contains(text(),'Dr.  John D.')]")
	private WebElement drJohnD;

	@FindBy(css = "div.case-sheet-wrapper-class.ng-star-inserted")
	private WebElement caseSheetWrapper;

	public void clickCaseSheetWrapper() {
		clickWithJavaScript(caseSheetWrapper);
		System.out.println("Clicked on Case Sheet Wrapper");
	}

	@FindBy(xpath = "//li[a/h5[normalize-space()='Dr. John D.']]")
	private WebElement doctorName;

	public void getDoctorName() {
		doctorName.click();
	}

	public void clickDoctorName(String doctorName) {
		String xpath = String.format("//a//h5[contains(normalize-space(.), '%s')]", doctorName);
//	    driver.findElement(By.xpath(xpath)).click();
		clickWithJavaScript(driver.findElement(By.xpath(xpath)));
	}

//	public void getDoctorName2() {
//		clickWithJavaScript(doctorName2);
//	}
	public void enterPatientNameOrMobile(String value) {
		patientSearchInput.clear();
		patientSearchInput.sendKeys(value, Keys.ENTER);
//	    patientSearchInput.sendKeys(value, Keys.ENTER);
	}

	public void clickFirstJohnAbraham(String personname, int number) {
		getPersonByName(personname, number).click();
	}

	public void clickEmrAccounts() {
		emrAccounts.click();
	}

	@FindBy(xpath = "//a[@title='Edit']//img")
	private WebElement editVisitBtn;

	@FindBy(xpath = "//a[@title='Print']//img")
	private WebElement printVisitBtn;

	public void clickEdit() {
		editVisitBtn.click();
	}

	public void clickPrintLastVisit() {
		printVisitBtn.click();
	}

	@FindBy(xpath = "//div[contains(.,'Clinical Assessment')]//a[@title='Click here to Edit Clinical Assessment Details']//img")
	private WebElement clinicalAssessmentEditIcon;

	public void clickClinicalAssessmentEdit() {
		clinicalAssessmentEditIcon.click();
	}

	@FindBy(xpath = "//div[contains(@class,'last-visit-details-right')]//a[@title='Edit']")
	private WebElement editLastVisit;

	public void clickEditLastVisit() {
		editLastVisit.click();
	}

}
