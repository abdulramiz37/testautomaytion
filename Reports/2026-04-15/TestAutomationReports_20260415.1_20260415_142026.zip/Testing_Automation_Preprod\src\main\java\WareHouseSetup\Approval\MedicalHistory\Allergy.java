package WareHouseSetup.Approval.MedicalHistory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class Allergy extends Abstraction {

	public Allergy(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//input[@formcontrolname='name']")
	private WebElement txtAllergyName;

	@FindBy(xpath = "//input[@formcontrolname='attribute']")
	private WebElement txtAttribute;

	@FindBy(xpath = "//input[@type='button' and @value='Add Attribute']")
	private WebElement btnAddAttribute;

	@FindBy(xpath = "//input[@type='button' and @value='Reset']")
	private WebElement btnReset;

	@FindBy(xpath = "//input[@type='button' and @value='Save']")
	private WebElement btnSave;

	@FindBy(xpath = "//input[@type='button' and @value='Cancel']")
	private WebElement btnCancel;

	@FindBy(xpath = "//a[text()=' Allergy ']")
	private WebElement userType;

	@FindBy(xpath = "//a[text()=' Add Allergy ']")
	private WebElement adduserType;

	@FindBy(xpath = "//a[text()=' Medical History']")
	private WebElement medicalpage;

	@FindBy(xpath = "//a[text()=' Add Medical History ']")
	private WebElement addmedicalhistory;

	@FindBy(xpath = "//ngx-select[@formcontrolname='typeId']//div[contains(@class,'ngx-select__toggle')]")
	private WebElement typeDropdown;

	public void clickbuttonapproval() {
		waitForClickability(userType).click();
//		waitForClickability(adduserType).click();
	}

	public void dropdown() {
		waitForClickability(typeDropdown).click();

	}

	public void clickaddmedicalhistory() {
		waitForClickability(medicalpage).click();
//		waitForClickability(addmedicalhistory).click();
	}

	public void enterAllergyName(String allergyName) {
		txtAllergyName.clear();
		txtAllergyName.sendKeys(allergyName);
	}

	public void enterAttribute(String attribute) {
		txtAttribute.clear();
		txtAttribute.sendKeys(attribute);
	}

	public void clickAddAttribute() {
		btnAddAttribute.click();
	}

	public void clickReset() {
		btnReset.click();
	}

	public void clickSave() {
		btnSave.click();
	}

	public void clickCancel() {
		btnCancel.click();
	}

}
