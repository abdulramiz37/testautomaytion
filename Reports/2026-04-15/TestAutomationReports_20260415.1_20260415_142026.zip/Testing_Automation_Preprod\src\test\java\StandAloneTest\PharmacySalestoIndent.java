package StandAloneTest;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
@Test
public class PharmacySalestoIndent {
	
	public void PPLE() throws InterruptedException {

	WebDriver driver = new EdgeDriver();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	driver.get("https://apps.ezovion.com/auth/login");

	driver.manage().window().maximize();
	

	driver.findElement(By.xpath("//div[@class=\"form-control-group\"]//input")).sendKeys("50107299");
	driver.findElement(By.xpath("//button[@size=\"large\"]")).click();
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
        // Wait until the button with text "CONTINUE" is clickable
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
	
     driver.findElement(By.xpath("//input[@placeholder=\"Mobile No\"]")).sendKeys("7766554433");
	driver.findElement(By.xpath("//input[@placeholder=\"Password\"]")).sendKeys("12345");
	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@status=\"primary\"]")));
	 Thread.sleep(2000);
	 driver.findElement(By.xpath("//button[@status=\"primary\"]")).click();
	 for (int i = 0; i < 5; i++) { // Try up to 5 times
		    try {
		        
		        Thread.sleep(3000); // wait for any transition

		        WebElement adminTab = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Admin']")));
		        adminTab.click();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Roles Management']"))).click();
		        break; // Exit loop if successful
		    } catch (Exception e) {
		        System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
		        if (i == 4) {
		            throw e; // Re-throw if max attempts reached
		        }
		    }
		}

	// 1. Click on "Pharmacy"
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Pharmacy']"))).click();

	 // 2. Click on first "Stock"
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[@title='Stock'])[1]"))).click();

	 // 3. Click on first "Opening Stock"
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[@title='Opening Stock'])[1]"))).click();

	 // 4. Click on "Add Opening Stock"
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()='Add Opening Stock']"))).click();

	 // 5. Click on the first "Select" dropdown (assumed to open Pharmacy Location)
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();

	 // 6. Click on "Pharmacy Location"
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Pharamacy Loaction'])[1]"))).click();

	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Select ']"))).click();

	 
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Medidine Ezovion']"))).click();
	 // 7. Enter Batch Number
	 WebElement batchInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='batchNumber']")));
	 batchInput.sendKeys("456");

	 // 8. Enter Month (e.g., July 2025)
	 WebElement expiryDateInput = wait.until(ExpectedConditions.visibilityOfElementLocated(
			    By.xpath("//input[@formcontrolname='expiryDate']")));

			// Use JavaScript to set only the month and year
			((JavascriptExecutor) driver).executeScript(
			    "arguments[0].value='2025-07'; arguments[0].dispatchEvent(new Event('input'));", 
			    expiryDateInput
			);
			//input[@formcontrolname='pricePerStrips']
			//input[@formcontrolname='mrpPerStrip']
			//input[@formcontrolname='sellPriceStrip']
			//input[@formcontrolname='qtyInStrips']
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@formcontrolname='pricePerStrips']"))).sendKeys("4");

			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@formcontrolname='mrpPerStrip']"))).sendKeys("4");

			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@formcontrolname='sellPriceStrip']"))).sendKeys("4");

			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@formcontrolname='qtyInStrips']"))).sendKeys("4");
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@formcontrolname='qtyInUnits']"))).sendKeys("4");


			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();
			 
				
				for (int i = 0; i < 5; i++) {
				    try {
				        // Click the back icon
				    	WebElement element = driver.findElement(By.xpath("//div[@class='fa fa-chevron-left']"));
				    	JavascriptExecutor js1 = (JavascriptExecutor) driver;
				    	js1.executeScript("arguments[0].click();", element);

				        // Wait for Pharmacy heading to be visible
//				        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h4[text()=' Pharmacy']")));
				        
				        // If visible, break the loop
				  
				        break;
				    } catch (Exception e) {
			
				        if (i == 4) {
				            throw e; // Throw if maximum retries are reached
				        }
				    }
				}
			 
//			 (//span[text()='Purchase'])[1]
//			 (//span[text()='Purchase Order'])[1]
//			 (//a[text()=' Add Purchase Order '])[1]
//			 (//span[text()= 'Select'])[1]
				//(//span[text()= 'supplier name'])[1]
//			 (//span[text()= 'Select'])[1]
//			 (//span[text()= 'Fddf'])[1]
				//input[@formcontrolname='plannedDelDate']
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Purchase'])[1]"))).click();

				// 2. Click on "Purchase Order"
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Purchase Order'])[1]"))).click();

				// 3. Click on "Add Purchase Order"
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[text()=' Add Purchase Order '])[1]"))).click();

				// 4. Click on "Select" (first dropdown)
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();

				// 5. Click on "supplier name"
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='supplier name'])[1]"))).click();

				// 6. Click on "Select" (again if needed)
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();

				// 7. Click on "Fddf" option
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Fddf'])[1]"))).click();
				
				// 1. Wait until the element is visible
				WebElement plannedDelDateInput = wait.until(ExpectedConditions.visibilityOfElementLocated(
				    By.xpath("//input[@formcontrolname='plannedDelDate']")));

				// 2. Set MM/DD/YYYY value using JavaScriptExecutor
				((JavascriptExecutor) driver).executeScript(
				    "arguments[0].value='07/12/2025'; arguments[0].dispatchEvent(new Event('input'));", 
				    plannedDelDateInput
				);
				
				
				// 1. Click on the second "Search Medicine" button
				wait.until(ExpectedConditions.elementToBeClickable(
				    By.xpath("(//span[text()='Search Medicine'])[1]"))).click();

				// 2. Wait for the medicine with name "medicine1syrup" to appear (e.g., in a modal or list)
				wait.until(ExpectedConditions.visibilityOfElementLocated(
				    By.xpath("//h4[text()='medicine1syrup']"))).click();  // If it is clickable
				//input[@formcontrolname='oRDEREDNOOFSTRIPSQTY'].sendkeys("4")
				//input[@formcontrolname='costPrice'].sendkeys("5")
				//input[@value='Add']
		 wait.until(ExpectedConditions.visibilityOfElementLocated(
					    By.xpath("//input[@formcontrolname='oRDEREDNOOFSTRIPSQTY']"))).sendKeys("4");

//					(//span[text()='Search Medicine'])[2]
					//h4[text()='medicine1syrup']
	

							
					// 10. Enter Cost Price = 5
					WebElement costPriceInput = wait.until(ExpectedConditions.visibilityOfElementLocated(
					    By.xpath("//input[@formcontrolname='costPrice']")));
					costPriceInput.sendKeys("5");

					// 11. Click on "Add" button
					wait.until(ExpectedConditions.elementToBeClickable(
					    By.xpath("//input[@value='Add']"))).click();

					// 12. Click on "Save" button
					wait.until(ExpectedConditions.elementToBeClickable(
					    By.xpath("//input[@value='Save']"))).click();

					By salesLocator = By.xpath("(//span[text()='Sales'])[1]");
					WebElement salesElement = null;

					for (int i = 0; i < 3; i++) {
					    try {
					        // Find the element
					        salesElement = driver.findElement(salesLocator);
					        
					        // Scroll into view using JavaScriptExecutor
					        JavascriptExecutor js = (JavascriptExecutor) driver;
					        js.executeScript("arguments[0].scrollIntoView(true);", salesElement);

					        // Click using JavaScript
					        js.executeScript("arguments[0].click();", salesElement);

					        break; // success, exit loop
					    } catch (Exception e) {
					        System.out.println("Attempt " + (i+1) + " failed: " + e.getMessage());
					        try {
					            Thread.sleep(1000); // Wait 1 second before retrying
					        } catch (InterruptedException ie) {
					            ie.printStackTrace();
					        }
					    }
					}



					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[text()='Sales'])[2]"))).click();

					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Counter Sales ']"))).click();

					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='mobilenumber']")))
					    .sendKeys("9876543210");

					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@role='combobox']")))
					    .sendKeys("abdul ramiz");

					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn btn-primary ng-star-inserted']")))
					    .click();

					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//strong[text()='abdul ramiz']"))).click();

					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Select Doctor']")))
					    .click();

					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Dr.  Ramiz']")))
					    .click();

//					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Search Medicine']")))
//					    .click();

					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h4[text()='Medidine Ezovion']"))).click();

					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='quantity']")))
					    .sendKeys("4");

					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Add']")))
					    .click();

					WebElement saveButton = driver.findElement(By.xpath("//input[@value='Save']"));
					JavascriptExecutor js = (JavascriptExecutor) driver;

					// Scroll into view
					js.executeScript("arguments[0].scrollIntoView(true);", saveButton);

					// Click using JavaScript
					js.executeScript("arguments[0].click();", saveButton);


					WebElement yesButton = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@value='Yes']")));
					JavascriptExecutor js1 = (JavascriptExecutor) driver;
					js1.executeScript("arguments[0].click();", yesButton);


					
	}
}
