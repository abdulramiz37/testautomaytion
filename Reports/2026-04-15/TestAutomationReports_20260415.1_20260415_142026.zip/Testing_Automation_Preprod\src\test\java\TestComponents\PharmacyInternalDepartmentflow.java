package TestComponents;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EzionpageObjects.UserIdPage;
import PharmacyPurchaseReturn.GRNVerificationPage;
import PharmacyPurchaseReturn.PharmacyPurchasePage;
import PharmacyPurchaseReturn.PurchaseReturnPage;
import PharmacyPurchaseReturn.Supplier_Dues_Page;
import PharmacySalesPage.MedicineShortageBookPage;
import PharmacySalesPage.SalesDashboards;
import PharmacyStocks.InternalDepartmentStock;
import abdulTest.BaseTest;

public class PharmacyInternalDepartmentflow extends BaseTest{
	  UserIdPage data;
	    PharmacyPurchasePage purchasePage;
	    GRNVerificationPage grnPage;
	    PurchaseReturnPage purchaseReturn;

	    String invoiceNo;
	    String grn;
	    HashMap<String, String> currentInput;

	    @Test(dataProvider = "getData",priority =1)
	    public void PharmacyPurchaseReturn2_Login(HashMap<String, String> input) throws InterruptedException {
	        this.currentInput = input;
//	        data = login.login(input.get("userId"));
//	        data.enterMobileNumber(input.get("personId"));
//	        data.enterPassword(input.get("password"));
	        String userId = prop.getProperty("USER_ID");
	        String personId = prop.getProperty("PERSON_ID");
	        String password = prop.getProperty("PASSWORD");
	        String browser = System.getProperty("BROWSER");
	        data = login.login(userId);
	        data.enterMobileNumber(personId);
	        data.enterPassword(password);
	        data.clickContinue();
	        System.out.println("Browser: " + browser);
//	        System.out.println("Base URL: " + baseUrl);
	        System.out.println("User ID: " + userId);
	        System.out.println("Person ID: " + personId);
	        data.clickContinue();
	        data.navigateSalesWithRetrystart();
	    }

	
	    @Test(dataProvider = "getData",priority = 2)
	    public void InternalDepartmentStock_EditMedicine(HashMap<String, String> input) throws InterruptedException {

	        // 📦 Navigate to Internal Department Stock
	        InternalDepartmentStock internalStockPage =
	                new InternalDepartmentStock(driver);

	        internalStockPage.addOpeningStock();

	        // 🎯 Target medicine from JSON
//	        String medicineName = currentInput.get("Medicine1syrup");
	        Thread.sleep(5000);	        // ✏️ Find medicine & click Edit (with pagination)
	        internalStockPage.findMedicineAndClickEdit("Medicine1syrup");

	        System.out.println("✅ Internal Department Stock edit test completed");
	        internalStockPage.stockdameges();
internalStockPage.selectdropdown("Used");
internalStockPage.enterQuantity("1");
internalStockPage.enterNotes("gg");
MedicineShortageBookPage shortageBookPage = new MedicineShortageBookPage(driver);
shortageBookPage.clickSave();
SalesDashboards salesdash= new SalesDashboards(driver);
Thread.sleep(1000);
salesdash.navigateSalesWithRetry3();
//salesdash.openSalesDashboard();
Thread.sleep(1000);
salesdash.clickWantedMedicine();
salesdash.clickAddMedicineShortageBook();
//MedicineShortageBookPage shortageBookPage = new MedicineShortageBookPage(driver);
//shortageBookPage.selectRequestedBy("Abdul Ramiz");
//
//// Requested Date
//shortageBookPage.enterRequestedDate();

// Medicine Name
shortageBookPage.selectMedicine("ubfjhl");

// Others
shortageBookPage.enterOthers("Urgent stock shortage");

// Priority
shortageBookPage.selectPriority("High");

// Emergency Qty
shortageBookPage.enterEmergencyQty("10");

// Remarks
shortageBookPage.enterRemarks("Medicine required urgently for emergency cases");

// Status
shortageBookPage.selectStatus("New");

// Save
shortageBookPage.clickSave();
	    }

	    
	    
	    
	    @DataProvider
	    public Object[][] getData() throws IOException {
	        List<HashMap<String, String>> data = getJsonDataToMap(
	            System.getProperty("user.dir") + "//src//main//java//ezion//Resources//PharmacyPurchaseReturn.json"
	        );
	        return new Object[][] { { data.get(0) } };
	    }
	}