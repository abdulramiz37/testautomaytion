package TestComponents.IP;

import java.awt.AWTException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EzionpageObjects.UserIdPage;
import IP.AdmissionFormPage;
import IP.IpPharmacySales;
import PharmacySalesPage.PatientDetails;
import PharmacySalesPage.SalesDashboards;
import PharmacySalesPage.SalesPage;
import PharmacySalesPage.SalesReturn;
import PrakashSirAppointmentBooking.CaseSheet.PrescriptionPage;
import PrakashSirAppointmentBooking.IpOnboarding.Serviceip;
import Registration.NewRegistrationPage;
import Registration.PatientList;
import WareHouseSetup.IPpharmacy.BedPage;
import WareHouseSetup.IPpharmacy.NursingCounterPage;
import abdulTest.BaseTest;
import ezion.Resources.EnvUtil;

public class IPTest extends BaseTest{
	 UserIdPage data;
	  NewRegistrationPage registrationPage ;

	   @Test(dataProvider = "getDataForLogin",priority = 1)
	   public void Login(HashMap<String, String> input) throws InterruptedException {
	       // Login
	       data = login.login(EnvUtil.get("USER_ID"));
	       data.enterMobileNumber(EnvUtil.get("PERSON_ID"));
	       data.enterPassword(EnvUtil.get("PASSWORD"));

	       data.clickContinue();
	       data.clickContinue();
	       data.clickContinue();
	       data.navigateSalesWithRetrystart();
//	   Thread.sleep(8000);
	       }
	   
	   BedPage bedSetupPage ;
	   
	   @Test(dataProvider = "getDataForLogin", priority = 2)
	    public void testCreateBedSetup(HashMap<String, String> input) {
		   data.openMasterSetup();

	        data.masterSetupOpenOnly();
	         bedSetupPage = new BedPage(driver);
	        bedSetupPage.clickbuttonapproval();
	        bedSetupPage.selectBedCategory("Bed");
	        bedSetupPage.selectBuilding("Main Building - A");
	        bedSetupPage.selectFloor("Second Floor");
	        bedSetupPage.selectRoom("101");
	        bedSetupPage.selectWard("General Ward A");
	        bedSetupPage.selectNursingCounter("Emergency Counter");
	        bedSetupPage.enterBedNumber("");
	        
	        bedSetupPage.setIsActive(true);

	        // Click Save
	        bedSetupPage.clickSave();

	        // Assertion (basic example – check URL or success message)
	        String currentUrl = driver.getCurrentUrl();
//	        Assert.assertTrue(currentUrl.contains("bed-setup"), "Bed setup not saved successfully!");
	    }
	    

	   String targetMobileNumber;
	   String storedFirstName1;
	   @Test(dataProvider = "getDataForLogin",priority = 3)
	   public void patientName(HashMap<String, String> input) throws InterruptedException {
//		   Thread.sleep(3000);	 
	       // Step 1: Search patient
	       registrationPage = new NewRegistrationPage(driver);

	       // Call the fillNewRegistrationForm method with all necessary form values
	       registrationPage.clickbuttonapproval();
	       registrationPage.selectTitle();
	       registrationPage.selectOptionFromNgxDropdown("Mr.");
	       registrationPage.enterFirstName("");
	       registrationPage.enterMiddleName("doe");
	       registrationPage.enterLastName("abraham");
	       registrationPage.selectGender();
	       registrationPage.selectOptionFromNgxDropdown("Male");
	       registrationPage.enterDOB("12/12/2024");
	       registrationPage.enterMobileNumber("");
	       storedFirstName1=registrationPage.storedFirstName;
	       targetMobileNumber=registrationPage.lastEnteredMobileNumber;
	       registrationPage.selectNationality("Indian");
//	       targetMobileNumber="7411081113";
	       registrationPage.save();

	//System.out.println(targetMobileNumber);
	   } 
	   
	   @Test(dataProvider = "getDataForLogin",priority = 4)
	   public void patientlist(HashMap<String, String> input) throws InterruptedException {
	       // Login
//		   Thread.sleep(5000);
		   PatientList patient = new PatientList(driver);
		   System.out.println(targetMobileNumber);
//		   patient.findPatientByMobile(targetMobileNumber);

//	        patient.findPatientByMobile(targetMobileNumber, "Service");
	        patient.findPatientByMobile(targetMobileNumber, "Admission");
//	        patient.findPatientByMobile(targetMobileNumber, "Patient Wallet");
//	        patient.findPatientByMobile(targetMobileNumber, "Edit Patient");
//	        patient.findPatientByMobile(targetMobileNumber, "Certificates");
//	        patient.findPatientByMobile(targetMobileNumber, "Patient Merge");
//	        patient.findPatientByMobile(targetMobileNumber, "Print");
//	        patient.findPatientByMobile(targetMobileNumber, "Cancel Registration");
	       }
	   
	   
	   @Test(dataProvider = "getDataForLogin",priority = 5)
	   public void testFillAdmissionFormAndSave(HashMap<String, String> input) throws InterruptedException {
	       // Login
		   NursingCounterPage nursingPage = new NursingCounterPage(driver);
		   AdmissionFormPage   admissionFormPage = new AdmissionFormPage(driver);
		   
		   admissionFormPage.selectDepartment("General");

	        // Select Physician
		   admissionFormPage.byTextAttach("Select Physician", "/ancestor::div[1]//ngx-select").click();
		   admissionFormPage.byTextAttach("Select Physician", "/ancestor::div[1]//a").click();

	        // Select Admission Type
	        admissionFormPage.selectAdmissionType("Surgery");

	        // Enter Admission Date (format: MM/DD/YYYY HH:MM AM/PM)
//	        admissionFormPage.enterAdmissionDate("");

	        // Select Nursing Counter
	        admissionFormPage.selectNursingCounter("Emergency Counter");

	        // Select Ward
	        admissionFormPage.selectWard("General Ward A");

	        // Enter Locker Number
	        admissionFormPage.enterLockerNumber("L-101");
//	    Thread.sleep(5000);
//	        admissionFormPage.clickBedByNumber("B-17");
	        admissionFormPage.clickBedImageSimpleNoWait(bedSetupPage.lastEnteredbedNumber);
	        // Click Save
	        admissionFormPage.clickSave();

	        // ✅ Assertion (example: verify page URL or success message)
//	        String currentUrl = driver.getCurrentUrl();
//	        Assert.assertTrue(currentUrl.contains("admission"), "Form not submitted successfully!");

	       }
	   @Test(dataProvider = "getDataForLogin", priority = 23)
	   public void getMedicineData2(HashMap<String, String> input) throws InterruptedException {

	   	Serviceip serviceiptest= new Serviceip(driver);
	   	serviceiptest.frontdesk();
	   	serviceiptest.opentheappointmentpage();
//	   	serviceiptest.selectDropdownValue("10");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "Services");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "Advance");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "Nurse Notes");

      	serviceiptest.findPatientByMobileAndName(targetMobileNumber,"Mr. " + storedFirstName1 + " doe abraham", "Doctor Notes");
      	serviceiptest.findPatientByMobileAndName(targetMobileNumber,"Mr. " + storedFirstName1 + " doe abraham", "Doctor Notes");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "Doctor Notes");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "IP Billing");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "OT Booking");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "Blood Request");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "Payer");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "Inventory Sales");
//	      	serviceiptest.frontdesk();

//	   	for(int i=0;i<=10;i++) {
//	   	serviceiptest.selectRandomOptionsFromDropdown();
//	   	System.out.println(i);
//	   	}
	   }

	   //PrescriptionPage prescriptionPage;
	   PrescriptionPage prescriptionPage;
	   @Test(dataProvider = "getDataForLogin", priority = 24)
	   public void prescription23(HashMap<String, String> input) throws InterruptedException {

	     // Step 1: Create Page Object
	      prescriptionPage = new PrescriptionPage(driver);
//	      Thread.sleep(5000);       // Step 2: Open Prescription section
	     prescriptionPage.clickPrescriptionTab();
	     prescriptionPage.addPrescriptionBtne();
	     // Step 3: Define medicines dynamically
	     List<Map<String, String>> medicineList = new ArrayList<>();

	     // Medicine 1
	     Map<String, String> med1 = new HashMap<>();
	     med1.put("medicine", "hfdadpumv");
	     med1.put("frequency", "1 - 0 - 1  Twice a day");
	     med1.put("dosage", "3.0");
	     med1.put("unit", "nos");
	     med1.put("when", "After Food");
	     med1.put("duration", "5d");
	     med1.put("quantity", "1");
	     med1.put("route", "hbsd");
	     med1.put("instructions", "Hot Water");
	     med1.put("doctor", "Dr.  Izaan");
	     med1.put("nurse", "Dr.  Izaan");
	     medicineList.add(med1);

	     // Medicine 2



	     // Step 4: Loop through medicines and fill the form
	     for (Map<String, String> med : medicineList) {
	         try {
	             // Select or add medicine
	             prescriptionPage.selectMedicineNameippage(med.get("medicine"));
	         
	             // If new medicine creation popup appears
	             if (prescriptionPage.isAddMedicinePopupDisplayed()) {
//	                 prescriptionPage.enterMedicineName(prescriptionPage.finalMedicine);
	               

//	                 prescriptionPage.enterMedicineCode("M"+"235");
	                 prescriptionPage.selectMedicineType("Schedule A1");
	                 prescriptionPage.selectMedicineCategory("SALTS");
	                 prescriptionPage.selectManufacturer("	CALTEN");
	                 prescriptionPage.selectGenericName("METFORMIN HCL");
	                 prescriptionPage.selectRack("ajhj");
	                 prescriptionPage.enterUnits("10");
	                 prescriptionPage.selectGST("0");
	                 prescriptionPage.checkIsVaccine();
	                 
	                 prescriptionPage.clickSaveButton();
	                 prescriptionPage.clickCloseButton();
	               
	               
	             }
	         } catch (Exception e) {
	             System.out.println("⚠️ Error while adding Medicine: " + e.getMessage());
	             e.printStackTrace();
	         }
	     
//	          Fill prescription details
//	         prescriptionPage.selectMedicineName2(prescriptionPage.finalMedicine+" /"+" METFORMIN HCL");
	         prescriptionPage.addGeneratedMedicine(prescriptionPage.finalMedicine);
	         prescriptionPage.selectUnit(med.get("unit"));
	         prescriptionPage.selectDosage(med.get("dosage"));
	         prescriptionPage.selectFrequency(med.get("frequency"));
	         prescriptionPage.selectWhenToTaken(med.get("when"));
	         prescriptionPage.selectDuration(med.get("duration"));
	         prescriptionPage.enterQuantity(med.get("quantity"));
	         prescriptionPage.selectRoute(med.get("route"));
	         prescriptionPage.selectInstructions(med.get("instructions"));
	         prescriptionPage.enterNotes("Monitor for side effects.");
	         prescriptionPage.selectPrescribedPhysician(med.get("doctor"));
	         prescriptionPage.selectPreparedPhysician(med.get("nurse"));

	         // Add Medicine to prescription list
	         prescriptionPage.clickAddMedicineButton();
	      
	         prescriptionPage.clickCloseButton2();
	     }

	     // Step 5: Save Prescription

	
	     // Step 6: Collapse Prescription section
	   //  prescriptionPage.clickPrescriptionToggle();
	     System.out.println("Generated Medicines in this test: " + prescriptionPage.getGeneratedMedicines());
	   }

	   
	   @Test(dataProvider = "getDataForLogin",priority = 25)
	   public void useGeneratedMedicines27(HashMap<String, String> input) throws InterruptedException {
		   
		     prescriptionPage.clickNoIndentFirstTd();
		     prescriptionPage.clickSendToPharmacyButton();
		     Thread.sleep(5000);
		     prescriptionPage.clickPurposeDropdown();
		     
		     prescriptionPage.selectPurposeOption("counter");
		     prescriptionPage.selectPriorityNormal();
		     prescriptionPage.clickSentButton();
	   }

	   
	   
	   String firstMedicineName1;
	   @Test(dataProvider = "getDataForLogin",priority = 26)
	   public void useGeneratedMedicines26(HashMap<String, String> input) {
	   List<String> meds = prescriptionPage.getGeneratedMedicines();
	   System.out.println("📌 Medicines created: " + meds);

	   if (!meds.isEmpty()) {
	       // Take the first medicine and store in class-level variable
	       firstMedicineName1 = meds.get(0);
	       System.out.println("✅ First medicine stored: " + firstMedicineName1);

	       // Select it on the page
//	       prescriptionPage.selectMedicineName(firstMedicineName);
	       }
	   }




	   @Test(dataProvider = "getDataForLogin", priority = 27)
	   public void useGeneratedMedicines(HashMap<String, String> input) throws InterruptedException {

	   SalesDashboards salesdash= new SalesDashboards(driver);
	   salesdash.navigateSalesWithRetry3();
	   //salesdash.openSalesDashboard();
	   //System.out.println("📌 targetMobileNumber created: " + targetMobileNumber);
	   //Thread.sleep(5000);
	   salesdash.clickfornewipbill(targetMobileNumber);
//	   Thread.sleep(5000);
	   System.out.println(firstMedicineName1+"       new med");
	   salesdash.selectAlternativeForMedicine(firstMedicineName1, "ubfjhl");
	   salesdash.clickSubmit();
	   salesdash.selectFullCreditBill();
	   PatientDetails patientPage = new PatientDetails(driver);
	    patientPage.clickSaveButton();
	    patientPage.yesButton();
	    patientPage.clickBackButton();


	   }
	   
//	   @Test(dataProvider = "getDataForLogin", priority = 28)
//	   public void useGeneratedMedicines1(HashMap<String, String> input) throws InterruptedException {
//		   SalesPage salesPage = new SalesPage(driver); 
//			 salesPage.excape();

//	   PatientDetails patientPage = new PatientDetails(driver);
//	    patientPage.clickSaveButton();
//	    patientPage.yesButton();
//	   } 


	   @Test(dataProvider = "getDataForLogin", priority = 29)
	   public void prescription25(HashMap<String, String> input) throws InterruptedException {
	   	Serviceip serviceiptest= new Serviceip(driver);
//	   	serviceiptest.frontdesk();
	   	serviceiptest.opentheappointmentpage();
//	   	serviceiptest.selectDropdownValue("10");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "Services");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "Advance");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "Nurse Notes");
	      	serviceiptest.findPatientByMobileAndName(targetMobileNumber,"Mr. " + storedFirstName1 + " doe abraham", "Doctor Notes");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "Doctor Notes");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "IP Billing");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "OT Booking");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "Blood Request");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "Payer");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "Inventory Sales");
	   	
	
	     
	   }
	   
	   String billno;
	   @Test(dataProvider = "getDataForLogin", priority = 30)
	   public void phamacysalesIp(HashMap<String, String> input) throws InterruptedException {
		   IpPharmacySales ipsales= new IpPharmacySales(driver);
		   ipsales.clickHeaderTile("Pharmacy");
		   Thread.sleep(5000);
		  billno= ipsales.getBillNo();
		  System.out.print(billno);
		   ipsales.clickTabByName("Bill wise Detail View");
		   ipsales.clickEmptyCellBeforeBillNo(billno);
		   ipsales.selectMedicineAndEnterQty("UBFJHL", true, "1");

		   ipsales.savethe();
		   ipsales.clickTabByName("Return Indent/Orders");
		   ipsales.clickEmptyCellBeforeBillNo();
		   ipsales.enterReturnQuantity("UBFJHL", "1");
//		   Thread.sleep(5000);
		   ipsales.aooroved("Approve");
		   Thread.sleep(1000);
		   ipsales.clickActionButtonByStatus("Approved");
		   
		   
		   
		   
	   }
//	   
//	   
//
	    @Test(dataProvider = "getDataForLogin", priority = 31)
	    public void salesreturn(HashMap<String, String> input) throws InterruptedException, AWTException {

	        String billNo;

	        // Step 2: Sales Page Flow
	        SalesPage salesPage = new SalesPage(driver);
	        Thread.sleep(5000);
	        salesPage.openSearchMedicineDropdown();
	        // Step 3: Add Medicines in Sales
	        salesPage.selectMedicine("ubfjhl");

	        // Step 4: Save Bill
	        PatientDetails patientPage = new PatientDetails(driver);
	        Thread.sleep(5000);
	        patientPage.clickSaveButton();
	        Thread.sleep(5000);
	        patientPage.yesButton();
	        Thread.sleep(5000);
//	        billNo = salesPage.getBillNumber();
//	        System.out.println("✅ Generated Bill No: " + billNo);
//	        patientPage.clickBackButton();
	    }
	    
	    
	    @Test(dataProvider = "getDataForLogin", priority = 32)
	    public void salesreturnpage(HashMap<String, String> input) throws InterruptedException, AWTException {

	
	        SalesReturn returnPage = new SalesReturn(driver);
//	        Thread.sleep(5000);
	        
	        returnPage.clickSalesReturnByMobile(targetMobileNumber);
	        returnPage.enterAdjustAmount(billno, "1");

			   IpPharmacySales ipsales= new IpPharmacySales(driver);
//			  
//			  
//			   ipsales.clickEmptyCellBeforeBillNo(billno);
//			   ipsales.enterReturnQuantity("UBFJHL", "1");
			   Thread.sleep(5000);
			   
			   ipsales.aooroved("Save");
//			   ipsales.clickActionButtonByStatus("Approved");
	        
	    }
	    @DataProvider
	    public Object[][] getDataForLogin() throws IOException {
	        List<HashMap<String, String>> data = getJsonDataToMap(
	            System.getProperty("user.dir") + "//src//main//java//ezion//Resources//AppointMent.json"
	        );
	        return new Object[][] { { data.get(0) } };
	    }
}
