package PharmacyIndentFlow;



	import org.openqa.selenium.*;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;
	import EzionAbstractionComponents.Abstraction;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import java.util.List;

	public class IndentIssue extends Abstraction {

	    public IndentIssue(WebDriver driver) {
	        super(driver);
	        PageFactory.initElements(driver, this);
	    }

	    // ----------- Locators -----------

	    @FindBy(xpath = "(//i[@class='fas fa-chevron-right'])[2]")
	    private WebElement nextPageButton;

	    @FindBy(xpath = "//div[@class='lightbox-close']")
	    private WebElement closeLightboxBtn;

	    @FindBy(xpath = "(//span[text()='Select'])[10]")
	    private WebElement selectLocationDropdown;

	    @FindBy(xpath = "//span[text()='Fddf']")
	    private WebElement selectLocationOption;

	    @FindBy(xpath = "//input[@inputmode='numeric']")
	    private WebElement quantityInput;

	    @FindBy(xpath = "//input[@value='Save']")
	    private WebElement saveBtn;

	    // ----------- Actions -----------

	    public void findAndClickReceiveButton(String currentIndentNo) {
	        boolean isFound = false;

	        while (!isFound) {
	        	List<WebElement> rows = driver.findElements(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[4]/tr"));


	            for (int i = 1; i <= rows.size(); i++) {
	                WebElement indentCell = driver.findElement(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[4]/tr[" + i + "]/td[2]"));
	                if (indentCell.getText().trim().equals(currentIndentNo)) {
	                    WebElement receiveBtn = driver.findElement(
	                        By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[4]/tr[" + i + "]/td[9]/li[2]/a")
	                    );
	                    waitForClickability(receiveBtn).click();
	                    isFound = true;
	                    break;
	                }
	            }

	            if (!isFound) {
	                try {
	                    if (!nextPageButton.getAttribute("class").contains("disabled")) {
	                        clickWithJavaScript(nextPageButton);
	                    } else {
	                        break;
	                    }
	                } catch (NoSuchElementException e) {
	                    break;
	                }
	            }
	        }
	    }

	    public void completeReceiveFlow(String quantity) {
	        waitForClickability(closeLightboxBtn).click();
	        waitForClickability(selectLocationDropdown).click();
	        waitForClickability(selectLocationOption).click();

	        clearAndType(quantityInput, quantity);
	        waitForClickability(saveBtn).click();
	    }

	    private void clearAndType(WebElement element, String value) {
	        waitForVisibility(element);
	        element.sendKeys(Keys.CONTROL + "a");
	        element.sendKeys(Keys.DELETE);
	        element.sendKeys(value);
	    }
	}



