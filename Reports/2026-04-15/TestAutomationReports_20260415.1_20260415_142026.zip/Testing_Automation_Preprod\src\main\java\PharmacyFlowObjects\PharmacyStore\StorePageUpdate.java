
	package PharmacyFlowObjects.PharmacyStore;

	import org.openqa.selenium.*;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;

	import EzionAbstractionComponents.Abstraction;
	
	public class StorePageUpdate extends Abstraction {

	    public StorePageUpdate(WebDriver driver) {
	        super(driver);
	        PageFactory.initElements(driver, this);
	    }

	    // --- Locators ---
	    @FindBy(xpath = "//a[text()=' Store']")
	    private WebElement storeTab;

	    @FindBy(xpath = "//a[text()=' Add Store Name ']")
	    private WebElement addStoreNameButton;

	    @FindBy(xpath = "//input[@formcontrolname='name']")
	    private WebElement storeNameInput;

	    @FindBy(xpath = "//input[@value='Save']")
	    private WebElement saveButton;

	    // 🔴 Validation message for Store Name Already Exists
	    @FindBy(xpath = "//span[contains(text(),'Store Name')]/following-sibling::ngx-validation-message//div[@style='color: red;'] | //input[@formcontrolname='name']/following-sibling::span[contains(@style,'color: red')]")
	    private WebElement storeNameError;

	    // --- Actions ---
	    public void navigateToAddStore() {
	        waitForClickability(storeTab).click();
	        waitForClickability(addStoreNameButton).click();
	    }

	    public void enterStoreName(String storeName) {
	        waitForVisibility(storeNameInput).clear();
	        storeNameInput.sendKeys(storeName);
	    }

	    public void clickSave() {
	        waitForClickability(saveButton).click();
	    }

	    public boolean isStoreNameAlreadyExists() {
	        try {
	            waitForVisibility(storeNameError, 3);
	            return storeNameError.getText().toLowerCase().contains("already exists");
	        } catch (Exception e) {
	            return false;
	        }
	    }

	    // --- Create store with retry if name exists ---
	    public void createStore(String baseStoreName) {
	        navigateToAddStore();
	        String finalName = baseStoreName;
	        int counter = 1;

	        while (true) {
	            enterStoreName(finalName);
	            clickSave();

	            if (!isStoreNameAlreadyExists()) {
	                break;
	            }

	            finalName = baseStoreName + "-" + counter++;
	            System.out.println("Retrying with store name: " + finalName);
	        }
	    }

	    public SupplierPageUpdate save() {
	        waitForPharmacyPageWithBackClick();
	        return new SupplierPageUpdate(driver);
	    }
	}


