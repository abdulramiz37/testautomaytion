package StandAloneTest;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PharmacyTest {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new EdgeDriver();
//		WebDriver driver = new EdgeDriver();
//		driver.get("https://apps.ezovion.com/auth/login");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://apps.ezovion.com/auth/login");

		driver.manage().window().maximize();
		

		driver.findElement(By.xpath("//div[@class=\"form-control-group\"]//input")).sendKeys("50107299");
		driver.findElement(By.xpath("//button[@size=\"large\"]")).click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
	        // Wait until the button with text "CONTINUE" is clickable
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
		
	     driver.findElement(By.xpath("//input[@placeholder=\"Mobile No\"]")).sendKeys("7766554433");
		driver.findElement(By.xpath("//input[@placeholder=\"Password\"]")).sendKeys("12345");
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@status=\"primary\"]")));
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//button[@status=\"primary\"]")).click();
		 for (int i = 0; i < 5; i++) { // Try up to 5 times
			    try {
			        
			        Thread.sleep(3000); // wait for any transition

			        WebElement adminTab = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Admin']")));
			        adminTab.click();
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Roles Management']"))).click();
			        break; // Exit loop if successful
			    } catch (Exception e) {
			        System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
			        if (i == 4) {
			            throw e; // Re-throw if max attempts reached
			        }
			    }
			}




		// Click on second dropdown icon (e.g., user roles)
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//i[@class='dropdown-toggle'])[2]"))).click();

	//Click on "Administrator" i
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Administrator']"))).click();

		// Click on third dropdown icon (nested section, if applicable)
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//i[@class='dropdown-toggle'])[3]"))).click();
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Pharmacy'])[2]"))).click();
		for (int i = 0; i < 10; i++) { // max 10 attempts to avoid infinite loo wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Pharmacy'])[2]"))).click();p
		    try {
		        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Pharmacy'])[2]"))).click();
		        // wait after click
		        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Pharmacy'])[2]"))).click();
		        // Check if the target element is now visible
		        if (wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table//th[1]"))) != null) {
		            break; // exit loop if element is visible
		        }
		    } catch (Exception e) {
		        System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
		    }
		}
	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Select']"))).click();
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[text()='Abdul Ramiz'])[2]"))).click();
		
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[@class='checkmark'])[1]"))).click();
			
			for (int i = 1; i <= 2; i++) {
			    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@value='Save'])[" + i + "]"))).click();
			}
			WebElement dropdownToggle = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//i[@class='dropdown-toggle'])[3]")));

			// Use JavaScript to click it
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", dropdownToggle);

			for (int i = 0; i < 10; i++) { // max 10 attempts to avoid infinite loop
			    try {
			        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Inventory'])[2]"))).click();
			        Thread.sleep(3000); // wait after click

			        // Check if the target element is now visible
			        if (wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table//th[1]"))) != null) {
			            break; // exit loop if element is visible
			        }
			    } catch (Exception e) {
			        System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
			    }
			}
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[@class='checkmark'])[1]"))).click();
			
			for (int i = 1; i <= 2; i++) {
			    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@value='Save'])[" + i + "]"))).click();
			}
//		//span[text()='Admin']
//		//span[text()='Roles Management']
//		(//i[@class='dropdown-toggle'])[2]
//				(//span[text()='Pharmacy'])[2]
//						//table//th[1]
		//input[@placeholder='Select']
		//span[text()='Abdul Ramiz']
//		(//span[@class='checkmark'])[1]
			//a[@title='Masters']
			//a[@title='Master Set-up']
			//a[text()=' Warehouse ']
			//a[text()=' Add Warehouse ']
			//input[@formcontrolname='warehousecode'].sendkeyes("pwd")
			//input[@formcontrolname='warehousename'].sendkeys("taj nagar old city")
			//input[@formcontrolname='warehouseshortname'].sendkeys("pwr"
			//div[@class='ngx-select dropdown']
			//span[text()='India']
			//input[@value='Save']
			//i[@class='fa fa-chevron-left']
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Masters']"))).click();

			// 2. Master Set-up
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Master Set-up']"))).click();

			// 3. Warehouse
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Warehouse ']"))).click();

			// 4. Add Warehouse
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Add Warehouse ']"))).click();

			// 5. Warehouse Code
			WebElement warehouseCode = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='warehousecode']")));
			warehouseCode.sendKeys("pwd");

			// 6. Warehouse Name
			WebElement warehouseName = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='warehousename']")));
			warehouseName.sendKeys("taj nagar old city");

			// 7. Warehouse Short Name
			WebElement shortName = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='warehouseshortname']")));
			shortName.sendKeys("pwr");

			// 8. Country Dropdown (ngx-select)
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='ngx-select dropdown']"))).click();

			// 9. Select "India"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='India']"))).click();

			// 10. Save button
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();

			// 11. Back button (left chevron)]
			Thread.sleep(2000);
			for (int i = 0; i < 5; i++) {
			    try {
			        // Click the back icon
			    	Thread.sleep(1000);
			        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='back-icon']"))).click();
			    
			        // Wait for Pharmacy heading to be visible
			        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h4[text()=' Pharmacy']")));
			
			        // If visible, break the loop
			        System.out.println("Pharmacy page is visible.");
			        break;
			    } catch (Exception e) {
			        System.out.println("Attempt " + (i + 1) + ": Pharmacy not visible yet.");
			        if (i == 4) {
			            throw e; // Throw if maximum retries are reached
			        }
			    }
			}
			//a[text()=" Store"]
			//a[text()=" Add Store Name "]
			//input[@formcontrolname="name"].sendkeys("new demo")
			//input[@value="Save"]
//			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-chevron-left']"))).click();
			//a[text()=" Supplier"]
//			(//a[@role="button"])[1]
//			(//input[@type="text"])[3].sendkeys("supplier name")
//			(//span[text()='Select'])[1]
//			(//span[text()='Pharmacy'])[2]
//			(//input[@type="text"])[4].sendkeys("2")
//					(//input[@type="text"])[7].sendkeys("976543210")
//			(//input[@type="text"])[9].sendkeys("976543210")
//			(//input[@type="text"])[11].sendkeys("1")
//			(//input[@type="text"])[11].sendkeys("444002")
//			(//input[@type="text"])[14].sendkeys("akola")
//			(//span[text()='Select'])[1]
//			(//span[text()='Chamoli'])[1]
//			input[@value='Save']
			
			// 1. Click "Store"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Store']"))).click();

			// 2. Click "Add Store Name"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Add Store Name ']"))).click();

			// 3. Enter Store Name
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='name']"))).sendKeys("new demo");

			// 4. Click Save
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();

			// 5. Click Back Button
			for (int i = 0; i < 5; i++) {
			    try {
			        			    	  Thread.sleep(1000);
			        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-chevron-left']"))).click();
//			        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-chevron-left']"))).click();
			        // Wait for Pharmacy heading to be visible
			        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h4[text()=' Pharmacy']")));
			        
			        // If visible, break the loop
			        System.out.println("Pharmacy page is visible.");
			        break;
			    } catch (Exception e) {
			        System.out.println("Attempt " + (i + 1) + ": Pharmacy not visible yet.");
			        if (i == 4) {
			            throw e; // Throw if maximum retries are reached
			        }
			    }
			}

			// 6. Click "Supplier"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Supplier']"))).click();

			// 7. Click first expand/collapse button (role="button")
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[@role='button'])[1]"))).click();

			String baseName = "Supplier Name ";
			int counter = 1;
			String supplierName = baseName + counter;
			
			while (true) {
				
				
			
			    // Enter supplier name
			    WebElement nameField = wait.until(ExpectedConditions.visibilityOfElementLocated(
			        By.xpath("(//input[@type='text'])[3]")));
			    nameField.clear();
			  
			    nameField.sendKeys(supplierName);
			    // Click Save
		

			    // Wait briefly to check for error (can use wait for visibility too)
			    Thread.sleep(1000);

			    // Check if error message is visible
			    List<WebElement> errorMessages = driver.findElements(By.xpath(
			        "//span[contains(text(),'Name Already Exists..')]"));

			    if (errorMessages.isEmpty()) {
			        // Name is unique, break the loop
			        System.out.println("Supplier added with name: " + supplierName);
			        break;
			    } else {
			        // Increment and retry
			        counter++;
			        supplierName = baseName + counter;
			       
			       
			        
			    }
			   
			}
			// 9. Click on first "Select"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();

			// 10. Select "Pharmacy" (2nd option)
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Pharmacy'])[2]"))).click();

			// 11. Quantity
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[4]"))).sendKeys("2");

			// 12. Phone
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[7]"))).sendKeys("9876543210");

			// 13. Mobile
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[9]"))).sendKeys("9876543210");

			// 14. State Code
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[11]"))).sendKeys("1 jop");

			// 15. Pincode
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[13]"))).sendKeys("444002");

			// 16. City
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[14]"))).sendKeys("akola");

			// 17. Select State dropdown again
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();

			// 18. Select "Chamoli"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Chamoli'])[1]"))).click();

			// 19. Final Save
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();
			for (int i = 0; i < 5; i++) {
			    try {
			        // Click the back icon
			        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-chevron-left']"))).click();

			        // Wait for Pharmacy heading to be visible
			        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h4[text()=' Pharmacy']")));
			        
			        // If visible, break the loop
			        System.out.println("Pharmacy page is visible.");
			        break;
			    } catch (Exception e) {
			        System.out.println("Attempt " + (i + 1) + ": Pharmacy not visible yet.");
			        if (i == 4) {
			            throw e; // Throw if maximum retries are reached
			        }
			    }
			}
			//a[text()=" Storage Shelf"]
					
			//a[text()=" Add Storage Shelf "].sendkeys("new item")
			//input[@value="Save"]
			
			// 1. Click on "Storage Shelf"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Storage Shelf']"))).click();

			//addd srtoaage shelf
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Add Storage Shelf ']"))).click();
		///click the text
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@formcontrolname='name']"))).click();

			// 3. Enter name (e.g., "new item")
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='name']"))).sendKeys("new item");

			// 4. Click on "Save" button
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();
			
			for (int i = 0; i < 5; i++) {
			    try {
			        // Click the back icon
			        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='back-icon']"))).click();

			        // Wait for Pharmacy heading to be visible
			        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h4[text()=' Pharmacy']")));
			        
			        // If visible, break the loop
			        System.out.println("Pharmacy page is visible.");
			        break;
			    } catch (Exception e) {
			        System.out.println("Attempt " + (i + 1) + ": Pharmacy not visible yet.");
			        if (i == 4) {
			            throw e; // Throw if maximum retries are reached
			        }
			    }
			}
			//a[text()=" Medicine"]
			//a[text()=" Add Medicine "]
//			(//input[@type="text"])[3].sendkeys("syrup")
//			(//input[@type="text"])[4]
			//span[text()="Schedule A1"
//			(//input[@type="text"])[5]
			//span[text()=" SHOULDER IMBO"]
//			(//input[@type="text"])[6]
			//span[text()=" CALTEN"]
//			(//input[@type="text"])[7] 
			//span[text()=" Bisacodyl Ip: 5 "]
//			(//input[@type="text"])[8]
			//span[text()="ajhj"]
//			(//input[@type='number'])[1].sendkeys("1")
//			(//input[@type="text"])[12]
			
			//span[text()="0"]
			//input[@value='Save']
			// 1. Click on "Medicine"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Medicine']"))).click();

			// 2. Click on "Add Medicine"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Add Medicine ']"))).click();

			// 3. Enter medicine name (e.g., "syrup")
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[3]"))).sendKeys("syrup9");
			
			wait.until(webDriver -> ((JavascriptExecutor) webDriver)
				    .executeScript("return document.readyState").equals("complete"));

			// 4. Wait for 4th input to be visible (you can send keys or use if needed)
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[4]"))).click();

			// 5. Click on "Schedule A1"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Schedule A1']"))).click();

			// 6. Wait for 5th input (optional)
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[5]"))).click();

			// 7. Click on "SHOULDER IMBO"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()=' SHOULDER IMBO']"))).click();

			// 8. Wait for 6th input (optional)
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[6]"))).click();

			// 9. Click on "CALTEN"
			
			for (int i = 0; i < 2; i++) {
			    try {
			    	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='	CALTEN']"))).click();
			        break; // Exit the loop if click is successful
			    } catch (Exception e) {
			        System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
			        if (i == 4) {
			            throw e; // Re-throw if all attempts fail
			        }
			        Thread.sleep(1000); // Small delay before retrying
			    }
			}
		

			// 10. Wait for 7th input (optional)
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[7]"))).click();

			// 11. Click on "Bisacodyl Ip: 5"
			for (int i = 0; i < 11; i++) {
			    try {
			        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(
			            By.xpath("//span[text()=' Bisacodyl Ip: 5 ']")));
			        element.click();
			        break; // Exit the loop if click is successful
			    } catch (Exception e) {
			        System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
			        if (i == 11) {
			            throw e; // Re-throw if all attempts fail
			        }
			        Thread.sleep(1000); // Small delay before retrying
			    }
			}


			// 12. Wait for 8th input (optional)
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[8]"))).click();

			// 13. Click on "ajhj"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='ajhj']"))).click();

			// 14. Enter quantity = 1
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='number'])[1]"))).sendKeys("1");

			// 15. Wait for 12th text input (optional sendKeys)
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[12]"))).click();

			// 16. Click on "0"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='0']"))).click();

			// 17. Click on Save button
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();
			
			for (int i = 0; i < 5; i++) {
			    try {
			        // Click the back icon
			    	WebElement element = driver.findElement(By.xpath("//i[@class='fa fa-chevron-left']"));
			    	JavascriptExecutor js1 = (JavascriptExecutor) driver;
			    	js1.executeScript("arguments[0].click();", element);

			        // Wait for Pharmacy heading to be visible
			        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h4[text()=' Pharmacy']")));
			        
			        // If visible, break the loop
			        System.out.println("Pharmacy page is visible.");
			        break;
			    } catch (Exception e) {
			        System.out.println("Attempt " + (i + 1) + ": Pharmacy not visible yet.");
			        if (i == 4) {
			            throw e; // Throw if maximum retries are reached
			        }
			    }
			}
			
			//a[text()=" Customer"]
			//a[text()=" Add Customer "]
//			(//input[@type="text"])[3].sendkeys("abdul")
//			(//input[@type="text"])[4].sendkeys("9876543210")
			//input[@value='Save']
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Customer']"))).click();

			// 2. Click on "Add Customer"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Add Customer ']"))).click();

			// 3. Enter customer name (e.g., "abdul")
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[3]"))).sendKeys("abdul");

			// 4. Enter phone number (e.g., "9876543210")
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[4]"))).sendKeys("9876543210");

			// 5. Click on Save button
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();
			for (int i = 0; i < 5; i++) {
			    try {
			        // Click the back icon
			        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-chevron-left']"))).click();

			        // Wait for Pharmacy heading to be visible
			        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h4[text()=' Pharmacy']")));
			        
			        // If visible, break the loop
			        System.out.println("Pharmacy page is visible.");
			        break;
			    } catch (Exception e) {
			        System.out.println("Attempt " + (i + 1) + ": Pharmacy not visible yet.");
			        if (i == 4) {
			            throw e; // Throw if maximum retries are reached
			        }
			    }
			}
			//a[text()=" Pharmacy Location "]
			//a[text()=" Add Pharmacy Location"]
			//input[@formcontrolname='name'].sendkeys("akola")
			//input[@formcontrolname='mobileno'].sendkeys("9876543210")
			//input[@value='Save']
			
			// 1. Click on "Pharmacy Location"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Pharmacy Location ']"))).click();

			// 2. Click on "Add Pharmacy Location"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Add Pharmacy Location']"))).click();

			// 3. Enter name (e.g., "akola")
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='name']"))).sendKeys("akola");

			// 4. Enter mobile number (e.g., "9876543210")
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='mobileno']"))).sendKeys("9876543210");

			// 5. Click on Save button
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();
			for (int i = 0; i < 5; i++) {
			    try {
			        // Click the back icon
			        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-chevron-left']"))).click();

			        // Wait for Pharmacy heading to be visible
			        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h4[text()=' Pharmacy']")));
			        
			        // If visible, break the loop
			        System.out.println("Pharmacy page is visible.");
			        break;
			    } catch (Exception e) {
			        System.out.println("Attempt " + (i + 1) + ": Pharmacy not visible yet.");
			        if (i == 4) {
			            throw e; // Throw if maximum retries are reached
			        }
			    }
			}
			//a[text()=" HMS Location "]
			//a[text()=" Add Hospital Location"]
			//input[@formcontrolname="locationName"].sendkeys("akole")
			//input[@formcontrolname="mobile"].sendkeys("9876543210")
			//input[@formcontrolname="email"].sendkeys("abdy@gmail.com")
			//input[@value='Save']

			// 1. Click on "HMS Location"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' HMS Location ']"))).click();

			// 2. Click on "Add Hospital Location"
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Add Hospital Location']"))).click();

			// 3. Enter Hospital Location Name
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='locationName']")))
			    .sendKeys("akol");

			// 4. Enter Mobile Number
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='mobile']")))
			    .sendKeys("9876543210");

			// 5. Enter Email
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='email']")))
			    .sendKeys("abdy@gmail.com");
			
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[@class='checkmark'])[2]")))
				    .sendKeys("abdy@gmail.com");
			// 6. Click on Save
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();
			for (int i = 0; i < 5; i++) {
			    try {
			        // Click the back icon
			        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-chevron-left']"))).click();

			        // Wait for Pharmacy heading to be visible
			        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h4[text()=' Pharmacy']")));
			        
			        // If visible, break the loop
			        System.out.println("Pharmacy page is visible.");
			        break;
			    } catch (Exception e) {
			        System.out.println("Attempt " + (i + 1) + ": Pharmacy not visible yet.");
			        if (i == 4) {
			            throw e; // Throw if maximum retries are reached
			        }
			    }
			}
			
	}
}
