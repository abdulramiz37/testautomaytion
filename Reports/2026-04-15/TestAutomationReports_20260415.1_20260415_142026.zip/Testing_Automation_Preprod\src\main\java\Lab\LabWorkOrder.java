package Lab;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class LabWorkOrder extends Abstraction {

	public LabWorkOrder(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	public void clickCheckboxByTestName(String testName) {
		boolean isFound = false;
		int pageCount = 0;
		int maxPagesToCheck = 5; // Prevent infinite loops

		while (!isFound && pageCount < maxPagesToCheck) {
			pageCount++;
			List<WebElement> rows = driver.findElements(By.xpath("//tr[contains(@class,'ng-star-inserted')]"));

			System.out.println("🔍 Found " + rows.size() + " rows on page " + pageCount);

			for (WebElement row : rows) {
				try {
					// More flexible XPath to find the test name
					List<WebElement> testNameElements = row.findElements(By.xpath(
							".//td//*[contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '"
									+ testName.toLowerCase() + "')]"));

					if (!testNameElements.isEmpty()) {
						WebElement testNameElement = testNameElements.get(0);
						String actualTestName = testNameElement.getText().trim();

						System.out.println("   Found test: " + actualTestName);

						if (actualTestName.equalsIgnoreCase(testName)) {
							// Find the checkbox - using more reliable locator
							WebElement checkbox = row.findElement(By.xpath(".//span[contains(@class,'checkmark')]"));

							if (!checkbox.isSelected()) {
								waitForClickability(checkbox).click();
								System.out.println("✅ Clicked checkbox for test: " + testName);
							} else {
								System.out.println("ℹ️ Checkbox already selected for test: " + testName);
							}
							clickUpdateButton();
							isFound = true;
							break;
						}
					}
				} catch (NoSuchElementException e) {
					System.out.println("   No matching element in this row");
				}
			}

			if (!isFound) {
				try {
					WebElement nextButton = driver.findElement(By.xpath(
							"//i[contains(@class, 'fa-chevron-right')]/ancestor::a[not(contains(@class,'disabled'))]"));
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", nextButton);
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextButton);
					System.out.println("➡️ Moving to next page...");

				} catch (NoSuchElementException e) {
					System.out.println("❌ No more pages available");
					break;
				} catch (Exception e) {
					System.out.println("⚠️ Error navigating to next page: " + e.getMessage());
					break;
				}
			}
		}

		if (!isFound) {
			System.out.println("❌ Test '" + testName + "' not found after checking " + pageCount + " pages");
			throw new NoSuchElementException("Test '" + testName + "' not found in the work order");
		}
	}

	@FindBy(xpath = "//input[@type='button' and @value='Update']")
	private WebElement updateButton;

	public void clickUpdateButton() {
		waitForClickability(updateButton).click();
		System.out.println("✅ Clicked the Update button");
	}
	
	public void clickArrowDropdown(int index) {
	    driver.findElement(
	        By.xpath("(//div[contains(@class,'mat-select-arrow-wrapper')])[" + index + "]")
	    ).click();
	}



	@FindBy(xpath = "//textarea[contains(@class,'culture-textarea')]")
	private WebElement notesTextArea;
	public void enterNotes(String notes) {
	    notesTextArea.clear();
	    notesTextArea.sendKeys(notes);
	}

}
