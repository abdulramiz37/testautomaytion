package PrakashSirAppointmentBooking.CaseSheet.TaskOrder;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class TreatmentPage extends Abstraction{

    WebDriver driver;

    public TreatmentPage(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // -------------------- Locators --------------------
    @FindBy(xpath = "//a[normalize-space()='Treatment']")
    private WebElement treatmentsection;
    // Treatment Plan dropdown
    @FindBy(xpath = "//ngx-select[@formcontrolname='treatmentPlanId']//div[contains(@class,'ngx-select__toggle')]")
    WebElement treatmentPlanDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='treatmentPlanId']//ul//li//span")
    WebElement treatmentPlanOptions;

    // Performing Doctor dropdown
    @FindBy(xpath = "//ngx-select[@formcontrolname='performDoc']//div[contains(@class,'ngx-select__toggle')]")
    WebElement performingDoctorDropdown;

    // Performing Nurse dropdown
    @FindBy(xpath = "//ngx-select[@formcontrolname='performNurse']//div[contains(@class,'ngx-select__toggle')]")
    WebElement performingNurseDropdown;

    // Next Visit Date radio buttons
    @FindBy(xpath = "//input[@id='inline1']") // 1 day
    WebElement nextVisit1Day;

    @FindBy(xpath = "//input[@id='inline2']") // 2 days
    WebElement nextVisit2Days;

    @FindBy(xpath = "//input[@id='inline3']") // 1 week
    WebElement nextVisit1Week;

    @FindBy(xpath = "//input[@id='inline4']") // 10 days
    WebElement nextVisit10Days;

    @FindBy(xpath = "//input[@id='inline5']") // 1 month
    WebElement nextVisit1Month;

    @FindBy(xpath = "//input[@value='cus']") // Custom
    WebElement nextVisitCustom;

    // Notes textarea
    @FindBy(xpath = "//textarea[@formcontrolname='nextVisitNotes']")
    WebElement notesTextArea;

    // Add button
    @FindBy(xpath = "//button[.//nb-icon[@icon='plus-square-outline']]")
    WebElement addButton;

    // Reset button
    @FindBy(xpath = "//button[contains(@class,'btn_casereset')]")
    WebElement resetButton;
    
    @FindBy(xpath = "//h4[normalize-space(text())='Task Order']/following::img[contains(@class,'openclose')][1]")
    private WebElement taskOrderToggleIcon;

    // -------------------- Methods --------------------
    public void toggleTaskOrderSection() {
        clickWithJavaScript(taskOrderToggleIcon);
    }
    public void treatmentsectionbutton() {
        clickWithJavaScript(treatmentsection);
    }
    // Treatment Plan
    public void selectTreatmentPlan(String planName) {
        treatmentPlanDropdown.click();
        WebElement option = driver.findElement(By.xpath("//ul//li//span[normalize-space()='" + planName + "']"));
        option.click();
    }

    // Performing Doctor
    public void selectPerformingDoctor(String doctorName) {
        performingDoctorDropdown.click();
        WebElement option = driver.findElement(By.xpath("//ul//li//span[normalize-space()='" + doctorName + "']"));
        option.click();
    }

    // Performing Nurse
    public void selectPerformingNurse(String nurseName) {
        performingNurseDropdown.click();
        WebElement option = driver.findElement(By.xpath("//ul//li//span[normalize-space()='" + nurseName + "']"));
        option.click();
    }

    // Next Visit Date
    public void setNextVisit(String option) {
        switch (option.toLowerCase()) {
            case "1d": nextVisit1Day.click(); break;
            case "2d": nextVisit2Days.click(); break;
            case "1w": nextVisit1Week.click(); break;
            case "10d": nextVisit10Days.click(); break;
            case "1m": nextVisit1Month.click(); break;
            case "cus": nextVisitCustom.click(); break;
            default: throw new IllegalArgumentException("Invalid Next Visit option: " + option);
        }
    }

    // Notes
    public void enterNotes(String notes) {
        notesTextArea.clear();
        notesTextArea.sendKeys(notes);
    }

    // Add button
    public void clickAddTreatmentPlan() {
        addButton.click();
    }

    // Reset button
    public void clickReset() {
        resetButton.click();
    }
}
