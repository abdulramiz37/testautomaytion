package Lab;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class ApprovedListPage extends Abstraction {

	  public ApprovedListPage(WebDriver driver) {
		super(driver);
	    PageFactory.initElements(driver, this);
	}
	  @FindBy(xpath = "//span[text()='Approved List']")
	    private WebElement adduserType;
	     
	    public void clickbuttonapproval() {
//			waitForClickability(userType).click();
			waitForClickability(adduserType).click();
			WebElement refreshButton = driver.findElement(By.xpath("//a[contains(@class,'repeatcls') and contains(normalize-space(.), 'Refresh')]"));
			refreshButton.click();

		}
		public void clickReorderByWorkOrder(String actualWorkOrder)  {
			clickbuttonapproval();
			clickbuttonapproval();
			clickbuttonapproval();
			clickbuttonapproval();
			clickbuttonapproval();
			clickbuttonapproval();
		    boolean isFound = false;

		    while (!isFound) {
		        List<WebElement> rows = driver.findElements(
		            By.xpath("(//tbody)[2]/tr[contains(@class,'ng-star-inserted')]")
		        );
//		        waitForClickability(By.xpath("(//tbody)[2]/tr[contains(@class,'ng-star-inserted')]//td[3]"));
		        for (WebElement row : rows) {
		            try {
		                // Get Work Order from 3rd column
		  
		     WebElement workOrderCell = row.findElement(By.xpath(".//td[3]"));
		     
		                String workOrderText = workOrderCell.getAttribute("textContent").trim();
		                // or use getAttribute("innerText") if you prefer
		                // String workOrderText = workOrderCell.getAttribute("innerText").trim();

//		                String workOrderText = workOrderCell.getText().trim();

		                System.out.println(workOrderText);
		                if (workOrderText.equals(actualWorkOrder)) {
		                    // Bill No is also in 3rd td as per your structure
		                    String billNo = workOrderText;
		                    System.out.println("🧾 Bill No: " + billNo);

		                    // Click Reorder (last <li> in action column)
		                    WebElement reorderBtn = row.findElement(
		                        By.xpath(".//td[contains(@class,'action-table')]//li[last()]/a")
		                    );
		                    waitForClickability(reorderBtn);
		                    Actions actions2 = new Actions(driver);
		                    actions2.doubleClick(reorderBtn).perform();


		                    System.out.println("🔄 Clicked Reorder for Work Order: " + actualWorkOrder);
		                    isFound = true;
		                    break;
		                }
		            } catch (NoSuchElementException ignored) {}
		        }

		        if (!isFound) {
		            try {
		                WebElement nextButton = driver.findElement(
		                    By.xpath("//li[contains(@class,'pagination-next')]/a[contains(.,'Next')]")
		                );
		                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextButton);
		                System.out.println("➡️ Moved to next page...");
		            } catch (NoSuchElementException e) {
		                System.out.println("❌ No more pages. Work Order not found.");
		                break;
		            }
		        }
		    }
		}
}
