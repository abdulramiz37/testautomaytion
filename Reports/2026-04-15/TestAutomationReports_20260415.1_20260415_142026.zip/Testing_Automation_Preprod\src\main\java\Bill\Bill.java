package Bill;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class Bill extends Abstraction {

	public Bill(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }



	    
	
	    
	    // Calendar Dropdown
	    @FindBy(xpath = "//div[contains(@class,'ngx-select__selected')]//span[contains(@class,'ngx-select__selected-single')]//span")
	    private WebElement selectedCalendarValue;
	    
	    // Header Elements
	    @FindBy(xpath = "//h3[@class='col-md-12 pad-top-13 print-page-titles text-center']/span")
	    private WebElement pageTitle;
	    
	    @FindBy(xpath = "//div[@class='printer-hostital-logo p-logo-left']/img")
	    private WebElement hospitalLogo;
	    
	    // Bill Details - Left Section
	    @FindBy(xpath = "//td[contains(text(),'Bill No')]/following-sibling::td/strong")
	    private WebElement billNumber;
	    
	    @FindBy(xpath = "//td[contains(text(),'Bill Date')]/following-sibling::td/strong")
	    private WebElement billDate;
	    
	    @FindBy(xpath = "//td[contains(text(),'UHID')]/following-sibling::td/b")
	    private WebElement uhid;
	    
	    @FindBy(xpath = "//ngx-barcode//div[@class='barcode']")
	    private WebElement barcode;
	    
	    @FindBy(xpath = "//td[contains(text(),'Reg Date')]/following-sibling::td/strong")
	    private WebElement registrationDate;
	    
	    @FindBy(xpath = "//td[contains(text(),'Doctor')]/following-sibling::td/strong")
	    private WebElement doctorName;
	    
	    // Bill Details - Right Section
	    @FindBy(xpath = "//td[contains(text(),'Name')]/following-sibling::td/strong")
	    private WebElement patientName;
	    
	    @FindBy(xpath = "//td[contains(text(),'Referral')]/following-sibling::td/strong")
	    private WebElement referral;
	    
	    @FindBy(xpath = "//td[contains(text(),'Age/Gender')]/following-sibling::td/strong")
	    private WebElement ageGender;
	    
	    @FindBy(xpath = "//td[contains(text(),'DOB')]/following-sibling::td/strong")
	    private WebElement dateOfBirth;
	    
	    @FindBy(xpath = "//td[contains(text(),'Mobile No')]/following-sibling::td/strong")
	    private WebElement mobileNumber;
	    
	    @FindBy(xpath = "//td[contains(text(),'Address')]/following-sibling::td/strong")
	    private WebElement address;
	    
	    // Service/Investigation Charges Table
	    @FindBy(xpath = "//h5[contains(text(),'SERVICE / INVESTIGATION CHARGES')]")
	    private WebElement serviceChargesHeader;
	    
	    @FindBy(xpath = "//table[@class='print-table-wa print-table-padding print-table-bt table table-hover']")
	    private WebElement serviceChargesTable;
	    
	    // Table Headers
	    @FindBy(xpath = "//th[@class='sn_class']")
	    private WebElement serialNumberHeader;
	    
	    @FindBy(xpath = "//th[@class='prict-table-th service text-left white-space'][1]")
	    private WebElement serviceHeader;
	    
	    @FindBy(xpath = "//th[@class='prict-table-th service text-left white-space'][2]")
	    private WebElement serviceTypeHeader;
	    
	    @FindBy(xpath = "//th[contains(text(),'Disc Amt')]")
	    private WebElement discountAmountHeader;
	    
	    @FindBy(xpath = "//th[contains(text(),'Health Card Disc Amt')]")
	    private WebElement healthCardDiscountHeader;
	    
	    @FindBy(xpath = "//th[contains(text(),'Referral Disc Amt')]")
	    private WebElement referralDiscountHeader;
	    
	    @FindBy(xpath = "//th[contains(text(),'Loyalty Disc Amt')]")
	    private WebElement loyaltyDiscountHeader;
	    
	    @FindBy(xpath = "//th[contains(text(),'Net Amt')]")
	    private WebElement netAmountHeader;
	    
	    // Bill Summary Section
	    @FindBy(xpath = "//div[contains(@class,'print-doctor-name-grand-total')]//div[contains(@class,'print-grand-taotal')]")
	    private WebElement grandTotalAmount;
	    
	    @FindBy(xpath = "//div[contains(@class,'print-doctor-name-grand-total')]//div[contains(text(),'Grand Total')]")
	    private WebElement grandTotalLabel;
	    
	    @FindBy(xpath = "//strong[contains(text(),'Amount in Words :')]")
	    private WebElement amountInWordsLabel;
	    
	    @FindBy(xpath = "//strong[contains(text(),'Amount in Words :')]/following-sibling::text()")
	    private WebElement amountInWordsValue;
	    
	    @FindBy(xpath = "//span[contains(text(),'Pay Mode :')]")
	    private WebElement payModeLabel;
	    
	    @FindBy(xpath = "//span[contains(text(),'Pay Mode :')]/following-sibling::span[contains(@class,'text-left')]")
	    private WebElement payModeValue;
	    
	    @FindBy(xpath = "//span[contains(text(),'Pay Mode :')]/following-sibling::span[contains(@class,'text-right')]")
	    private WebElement payModeAmount;
	    
	    // Status and Prepared By Section
	    @FindBy(xpath = "//div[contains(@class,'print-discont-subtotal-bck')]//span[contains(text(),'Status')]")
	    private WebElement statusLabel;
	    
	    @FindBy(xpath = "//div[contains(@class,'print-discont-subtotal-bck')]//span[contains(text(),': Paid')]")
	    private WebElement statusValue;
	    
	    @FindBy(xpath = "//div[contains(@class,'print-discont-subtotal-bck')]//span[contains(text(),'Prepared By')]")
	    private WebElement preparedByLabel;
	    
	    @FindBy(xpath = "//div[contains(@class,'print-discont-subtotal-bck')]//span[contains(text(),': Abdul Ramiz')][1]")
	    private WebElement preparedByValue;
	    
	    @FindBy(xpath = "//div[contains(@class,'print-discont-subtotal-bck')]//span[contains(text(),'Done By')]")
	    private WebElement doneByLabel;
	    
	    @FindBy(xpath = "//div[contains(@class,'print-discont-subtotal-bck')]//span[contains(text(),': Abdul Ramiz')][2]")
	    private WebElement doneByValue;
	    
	    @FindBy(xpath = "//div[contains(@class,'print-discont-subtotal-bck')]//span[contains(text(),'Printed On')]")
	    private WebElement printedOnLabel;
	    
	    @FindBy(xpath = "//div[contains(@class,'print-discont-subtotal-bck')]//span[contains(text(),': 2025/12/06 06:57')]")
	    private WebElement printedOnValue;
	    
	    // Footer Section
	    @FindBy(xpath = "//div[@class='print-footer']")
	    private WebElement footerSection;
	    
	    // Methods
	    
	    public void clickCalendarDropdown() {
	        selectedCalendarValue.click();
	    }
	    
	    public String getPageTitle() {
	        return pageTitle.getText();
	    }
	    
	    public String getBillNumber() {
	        return billNumber.getText();
	    }
	    
	    public String getBillDate() {
	        return billDate.getText();
	    }
	    
	    public String getUHID() {
	        return uhid.getText();
	    }
	    
	    public String getPatientName() {
	        return patientName.getText();
	    }
	    
	    public String getDoctorName() {
	        return doctorName.getText();
	    }
	    
	    public String getAgeGender() {
	        return ageGender.getText();
	    }
	    
	    public String getDateOfBirth() {
	        return dateOfBirth.getText();
	    }
	    
	    public String getMobileNumber() {
	        return mobileNumber.getText();
	    }
	    
	    public String getAddress() {
	        return address.getText();
	    }
	    
	    public String getGrandTotal() {
	        return grandTotalAmount.getText();
	    }
	    
	    public String getAmountInWords() {
	        return amountInWordsValue.getText().trim();
	    }
	    
	    public String getPayMode() {
	        return payModeValue.getText();
	    }
	    
	    public String getPayModeAmount() {
	        return payModeAmount.getText().split(" ")[0]; // Extract just the amount
	    }
	    
	    public String getStatus() {
	        return statusValue.getText().replace(": ", "");
	    }
	    
	    public String getPreparedBy() {
	        return preparedByValue.getText().replace(": ", "");
	    }
	    
	    public String getDoneBy() {
	        return doneByValue.getText().replace(": ", "");
	    }
	    
	    public String getPrintedOn() {
	        return printedOnValue.getText().replace(": ", "");
	    }
	    
	    public boolean isHospitalLogoDisplayed() {
	        return hospitalLogo.isDisplayed();
	    }
	    
	    public boolean isBarcodeDisplayed() {
	        return barcode.isDisplayed();
	    }
	    
	    public boolean isServiceChargesTableDisplayed() {
	        return serviceChargesTable.isDisplayed();
	    }
	    
	    // Method to get specific service row details
	    public String getServiceDetails(int rowNumber, String columnName) {
	        String xpath = "";
	        
	        switch(columnName.toLowerCase()) {
	            case "service":
	                xpath = "//tbody/tr[" + rowNumber + "]/td[2]";
	                break;
	            case "servicetype":
	                xpath = "//tbody/tr[" + rowNumber + "]/td[3]";
	                break;
	            case "discount":
	                xpath = "//tbody/tr[" + rowNumber + "]/td[contains(@class,'text-right')][1]";
	                break;
	            case "netamount":
	                xpath = "//tbody/tr[" + rowNumber + "]/td[last()]";
	                break;
	            default:
	                xpath = "//tbody/tr[" + rowNumber + "]/td[1]";
	        }
	        
	        return driver.findElement(org.openqa.selenium.By.xpath(xpath)).getText();
	    }
	    
	    // Method to get total number of services
	    public int getTotalServicesCount() {
	        return driver.findElements(org.openqa.selenium.By.xpath("//tbody/tr")).size();
	    }
	    
	    // Method to verify if bill is paid
	    public boolean isBillPaid() {
	        return getStatus().equalsIgnoreCase("Paid");
	    }
	    
	    // Method to get complete bill summary
	    public void printBillSummary() {
	        System.out.println("=== IP Bill Summary ===");
	        System.out.println("Bill No: " + getBillNumber());
	        System.out.println("Bill Date: " + getBillDate());
	        System.out.println("UHID: " + getUHID());
	        System.out.println("Patient: " + getPatientName());
	        System.out.println("Age/Gender: " + getAgeGender());
	        System.out.println("Doctor: " + getDoctorName());
	        System.out.println("Grand Total: " + getGrandTotal());
	        System.out.println("Amount in Words: " + getAmountInWords());
	        System.out.println("Pay Mode: " + getPayMode());
	        System.out.println("Status: " + getStatus());
	        System.out.println("Prepared By: " + getPreparedBy());
	        System.out.println("Printed On: " + getPrintedOn());
	    }
	
}
