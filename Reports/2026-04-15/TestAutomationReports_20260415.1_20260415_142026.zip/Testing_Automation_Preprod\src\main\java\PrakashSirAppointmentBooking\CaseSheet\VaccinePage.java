package PrakashSirAppointmentBooking.CaseSheet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class VaccinePage extends Abstraction {

    WebDriver driver;

    public VaccinePage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // --- Section Toggle (if exists) ---
    @FindBy(xpath = "//div[contains(@class,'lightbox-title') and contains(.,'Vaccine Data')]")
    private WebElement vaccinePopupHeader;

    // --- Dropdowns ---
    @FindBy(xpath = "//label[contains(text(),'Medicine Name')]/following::ngx-select[1]")
    private WebElement medicineNameDropdown;

    // --- Date Fields ---
    @FindBy(xpath = "//input[@formcontrolname='givenDate']")
    private WebElement givenDateInput;

    @FindBy(xpath = "//input[@formcontrolname='expDate']")
    private WebElement expDateInput;

    // --- Text Fields ---
    @FindBy(xpath = "//input[@formcontrolname='batch']")
    private WebElement batchInput;

    @FindBy(xpath = "//input[@formcontrolname='height']")
    private WebElement heightInput;

    @FindBy(xpath = "//input[@formcontrolname='weight']")
    private WebElement weightInput;

    @FindBy(xpath = "//input[@formcontrolname='headcircumference']")
    private WebElement headCircumferenceInput;

    @FindBy(xpath = "//textarea[@formcontrolname='notes']")
    private WebElement notesTextarea;

    // --- Buttons ---
    @FindBy(xpath = "//input[@type='button' and @value='Save']")
    private WebElement saveBtn;

    @FindBy(xpath = "//input[@type='button' and @value='Reset']")
    private WebElement resetBtn;

    @FindBy(xpath = "//input[@type='button' and @value='Close']")
    private WebElement closeBtn;

    @FindBy(xpath = "//div[contains(@class,'succesfull-info-popup') and contains(text(),'Vaccine Saved Successfuly')]")
    private WebElement vaccineSavedPopup;
    
    // --- Actions ---
    public void selectMedicineName(String medicine) {
        medicineNameDropdown.click();
        WebElement option = driver.findElement(By.xpath(
                "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + medicine + "']"));
        option.click();
    }

    public void enterGivenDate(String date) {
        givenDateInput.clear();
        givenDateInput.sendKeys(date);
    }

    public void enterBatch(String batch) {
        batchInput.clear();
        batchInput.sendKeys(batch);
    }

    public void enterExpDate(String date) {
        expDateInput.clear();
        expDateInput.sendKeys(date);
    }

    public void enterHeight(String height) {
        heightInput.clear();
        heightInput.sendKeys(height);
    }

    public void enterWeight(String weight) {
        weightInput.clear();
        weightInput.sendKeys(weight);
    }

    public void enterHeadCircumference(String hc) {
        headCircumferenceInput.clear();
        headCircumferenceInput.sendKeys(hc);
    }

    public void enterNotes(String notes) {
        notesTextarea.clear();
        notesTextarea.sendKeys(notes);
    }

    public void clickSave() {
        saveBtn.click();
        waitForInvisibility(vaccineSavedPopup);
    }

    public void clickReset() {
        resetBtn.click();
    }

    public void clickClose() {
        closeBtn.click();
    }
}
