package PharmacySalesPage;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class SalesDashborad_Archivedlist extends Abstraction {

	public SalesDashborad_Archivedlist(WebDriver driver) {
		super(driver);
        PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "//a[@class='tab-link']//span[text()='Archived List']")
	WebElement archivedListTab;
	
	
	public void clickArchivedListTab() {
		clickWithJavaScript(archivedListTab);
	}
	public boolean checkForArchiveOrNewBill(String targetPatientName, String actionType) {
	    boolean isFound = false;

	    while (!isFound) {
	        // Get all rows in the table
	        List<WebElement> rows = waitForPresenceOfAll(
	            By.xpath("(//table[contains(@class,'table')])[2]/tbody/tr")
	        );

	        for (int i = 0; i < rows.size(); i++) {
	            try {
	                WebElement row = rows.get(i);

	                // Patient Name → based on td[5]/p
	                String patientName = row.findElement(By.xpath("./td[2]/p[3]")).getText().trim();

	                if (patientName.equalsIgnoreCase(targetPatientName)) {
	                    WebElement targetIcon = null;

	                    if (actionType.equalsIgnoreCase("NewBill")) {
	                        // Locate New Bill icon
	                        targetIcon = row.findElement(
	                            By.xpath(".//td[last()]//img[contains(@src,'add_to_queue.png')]")
	                        );
	                    } else if (actionType.equalsIgnoreCase("UnArchive")) {
	                        // Locate Archive / UnArchive icon
	                        targetIcon = row.findElement(
	                            By.xpath(".//td[last()]//img[contains(@src,'archive.png')]")
	                        );
	                    }

	                    if (targetIcon != null) {
	                        ((JavascriptExecutor) driver).executeScript(
	                            "arguments[0].scrollIntoView(true);", targetIcon
	                        );
	                        waitForClickability(targetIcon).click();

	                        System.out.println("✅ Clicked " + actionType + " for Patient: " + patientName);
	                        isFound = true;
	                        break;
	                    }
	                }
	            } catch (NoSuchElementException e) {
	                System.out.println("⚠️ Skipping row " + i + " due to missing elements");
	            }
	        }

	        // If not found → go next page
	        if (!isFound) {
	            try {
	                WebElement nextPage = driver.findElement(
	                    By.xpath("(//div[@class='pagi-block pagi-block-right']//a)[1]")
	                );

	                String classAttr = nextPage.getAttribute("class");
	                if (classAttr != null && classAttr.contains("disabled")) {
	                    System.out.println("❌ Reached last page. Patient not found.");
	                    break;
	                }

	                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", nextPage);
	                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextPage);

	                System.out.println("➡️ Moving to next page...");
	            } catch (NoSuchElementException e) {
	                System.out.println("❌ Next page button not found. Ending search.");
	                break;
	            }
	        }
	    }

	    return isFound;
	}

}
