package WareHouseSetup.IPpharmacy;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class BedViewPage extends Abstraction{
    private WebDriver driver;
	 public BedViewPage(WebDriver driver) {
	    	super(driver);
	        this.driver = driver;
	        PageFactory.initElements(driver, this);
	    }
	 
	  @FindBy(xpath = "//a[text()='Bed View ']")
	    private WebElement userType;

	    @FindBy(xpath = "//a[text()=' Add Building ']")
	    private WebElement adduserType;
	    // 🔹 Methods
	    public void clickbuttonapproval() {
			waitForClickability(userType).click();
//			waitForClickability(adduserType).click();
		}
	 
	 public boolean clickOnBed(String bedNo) {
		    boolean isFound = false;

		    while (!isFound) {
		        try {
		            // ✅ Check if bed list is present
		            List<WebElement> bedLists = driver.findElements(
		                By.xpath("//ul[contains(@class,'clearfix') and contains(@class,'ng-star-inserted')]")
		            );
		            if (bedLists.isEmpty()) {
		                System.out.println("❌ Bed table not found on this page.");
		                break;
		            }

		            // ✅ Get all beds on current page
		            List<WebElement> beds = driver.findElements(
		                By.xpath("//ul[contains(@class,'clearfix') and contains(@class,'ng-star-inserted')]/li")
		            );

		            for (WebElement bed : beds) {
		                String bedText = bed.findElement(By.tagName("p")).getText().trim();

		                if (bedText.equalsIgnoreCase(bedNo)) {
		                    WebElement bedIcon = bed.findElement(By.tagName("a"));
		                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", bedIcon);
		                    bedIcon.click();
		                    System.out.println("✅ Clicked bed: " + bedNo);
		                    isFound = true;
		                    break;
		                }
		            }

		            // ✅ If not found, go to next page
		            if (!isFound) {
		                WebElement nextButton = driver.findElement(
		                    By.xpath("//li[contains(@class,'pagination-next')]")
		                );
		                String classAttr = nextButton.getAttribute("class");

		                if (classAttr.contains("disabled")) {
		                    System.out.println("❌ Reached last page. Bed " + bedNo + " not found.");
		                    break;
		                }

		                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextButton);
		             
		            }

		        } catch (Exception e) {
		            System.out.println("⚠️ Error while selecting bed: " + e.getMessage());
		            break;
		        }
		    }

		    return isFound;
		}

}
