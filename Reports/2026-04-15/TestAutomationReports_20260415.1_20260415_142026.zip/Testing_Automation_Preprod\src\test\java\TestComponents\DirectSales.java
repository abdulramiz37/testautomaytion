package TestComponents;



	import java.io.IOException;
	import java.util.HashMap;
	import java.util.List;

	import org.testng.annotations.DataProvider;
	import org.testng.annotations.Test;

	import EzionpageObjects.UserIdPage;
	import PharmacyPurchaseReturn.GRNVerificationPage;
	import PharmacyPurchaseReturn.PharmacyPurchasePage;
	import PharmacyPurchaseReturn.PurchaseReturnPage;
	import PharmacyPurchaseReturn.Supplier_Dues_Page;
	import abdulTest.BaseTest;

	public class DirectSales extends BaseTest {

	    UserIdPage data;
	    PharmacyPurchasePage purchasePage;
	    GRNVerificationPage grnPage;
	    PurchaseReturnPage purchaseReturn;

	    String invoiceNo;
	    String grn;
	    HashMap<String, String> currentInput;

	    @Test(dataProvider = "getData")
	    public void PharmacyPurchaseReturn2_Login(HashMap<String, String> input) throws InterruptedException {
	        this.currentInput = input;
//	        data = login.login(input.get("userId"));
//	        data.enterMobileNumber(input.get("personId"));
//	        data.enterPassword(input.get("password"));
//	        data.clickContinue();
	        String userId = prop.getProperty("USER_ID");
	        String personId = prop.getProperty("PERSON_ID");
	        String password = prop.getProperty("PASSWORD");
	        String browser = System.getProperty("BROWSER");
	        data = login.login(userId);
	        data.enterMobileNumber(personId);
	        data.enterPassword(password);
	        data.clickContinue();
	        System.out.println("Browser: " + browser);
//	        System.out.println("Base URL: " + baseUrl);
	        System.out.println("User ID: " + userId);
	        System.out.println("Person ID: " + personId);
	        data.clickContinue();
	    }

	    @Test(dependsOnMethods = "PharmacyPurchaseReturn2_Login")
	    public void PharmacyPurchaseReturn2_CreatePurchase() {
	        purchasePage = data.purchasePage();
	        purchasePage.createNewPurchase(
	            currentInput.get("location"),
	            currentInput.get("supplier"),
	            currentInput.get("invoiceNumber"),
	            currentInput.get("invDate"),
	            currentInput.get("dueDate"),
	            currentInput.get("expiryDate"),
	            currentInput.get("medicineName"),
	            currentInput.get("batchNo"),
	            currentInput.get("strips"),
	            currentInput.get("freeStrips"),
	            currentInput.get("mrp"),
	            currentInput.get("price")
	        );
	        invoiceNo = purchasePage.getGeneratedInvoiceNo();
	    }

	    @Test(dependsOnMethods = "PharmacyPurchaseReturn2_CreatePurchase")
	    public void PharmacyPurchaseReturn2_GetGRN() {
	        grnPage = purchasePage.save();
	        grnPage.getGRNNumber(invoiceNo);
	        grn = grnPage.getStoredGRNNo();
	        System.out.println("✅ GRN used in next step: " + grn);
	    }
	//
//	    @Test(dependsOnMethods = "PharmacyPurchaseReturn2_GetGRN")
//	    public void PharmacyPurchaseReturn2_CreateReturn() {
//	        purchaseReturn = grnPage.returnPage();
//	        purchaseReturn.createPurchaseReturn(
//	            invoiceNo,
//	            grn,
//	            currentInput.get("location"),
//	            currentInput.get("supplier"),
//	            currentInput.get("medicineName"),
//	            currentInput.get("quantity")
//	           
//	        );
//	        
//	        purchaseReturn.savePurchasePage(currentInput.get("review"));
//	        
	//purchaseReturn.saveDetails(invoiceNo);
//	        System.out.println("✅ Purchase return completed.");
////	        purchaseReturn.saveDetails(invoiceNo);
//	    }
	    
	    @Test(dependsOnMethods = "PharmacyPurchaseReturn2_GetGRN")
	    public void SupplierDues() throws InterruptedException {
	    	
	    	Supplier_Dues_Page poPage = new Supplier_Dues_Page(driver);
	    	poPage.clickAccountsMenu();
	poPage.clickSupplierDuesMenu();
	Thread.sleep(5000);
	    	    String targetSupplierName = "supplier name";
	    	    String targetStatus = "Pending";

	    	    poPage.clickEditFromSecondTabAndUpdate(targetSupplierName);
	    	    poPage.clickSaveButton();
	poPage.clickYesButton();
	poPage.clickSupplierPaymentListMenu();
	    }
	    
	    

	    @DataProvider
	    public Object[][] getData() throws IOException {
	        List<HashMap<String, String>> data = getJsonDataToMap(
	            System.getProperty("user.dir") + "//src//main//java//ezion//Resources//PharmacyPurchaseReturn.json"
	        );
	        return new Object[][] { { data.get(0) } };
	    }
	}


