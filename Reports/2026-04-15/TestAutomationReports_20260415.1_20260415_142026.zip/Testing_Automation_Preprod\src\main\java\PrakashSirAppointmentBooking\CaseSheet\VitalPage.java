package PrakashSirAppointmentBooking.CaseSheet;





	import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.WebDriverWait;

import EzionAbstractionComponents.Abstraction;

import java.time.Duration;

	public class VitalPage extends Abstraction {

	    public VitalPage(WebDriver driver) {
	        super(driver);
	        PageFactory.initElements(driver, this);
	    }

	    // ===== Helper Method =====}

	    // ===== Locators =====
	    @FindBy(xpath = "//input[@formcontrolname='temp']")
	    private WebElement temperatureInput;

	    @FindBy(xpath = "//input[@formcontrolname='spo']")
	    private WebElement spo2Input;

	    @FindBy(xpath = "//input[@formcontrolname='pulse']")
	    private WebElement pulseInput;

	    @FindBy(xpath = "//input[@formcontrolname='heart_Rate']")
	    private WebElement heartRateInput;

	    @FindBy(xpath = "//input[@formcontrolname='resp_Rate']")
	    private WebElement respRateInput;

	    @FindBy(xpath = "//input[@formcontrolname='weight']")
	    private WebElement weightInput;

	    @FindBy(xpath = "//input[@formcontrolname='height']")
	    private WebElement heightInput;

	    @FindBy(xpath = "//input[@formcontrolname='size']")
	    private WebElement sizeInput;

	    @FindBy(xpath = "//input[@formcontrolname='ibw']")
	    private WebElement ibwInput;

	    @FindBy(xpath = "//input[@formcontrolname='bP_Sys']")
	    private WebElement bpSysInput;

	    @FindBy(xpath = "//input[@formcontrolname='bP_Dia']")
	    private WebElement bpDiaInput;

	    @FindBy(xpath = "//input[@formcontrolname='post_sugar']")
	    private WebElement postSugarInput;

	    @FindBy(xpath = "//input[@formcontrolname='pre_sugar']")
	    private WebElement preSugarInput;

	    @FindBy(xpath = "//input[@formcontrolname='random_sugar']")
	    private WebElement randomSugarInput;

	    @FindBy(xpath = "//input[@formcontrolname='waist']")
	    private WebElement waistInput;

	    @FindBy(xpath = "//input[@formcontrolname='bodyFat']")
	    private WebElement bodyFatInput;

	    @FindBy(xpath = "//input[@formcontrolname='visceralFat']")
	    private WebElement visceralFatInput;

	    @FindBy(xpath = "//ngx-select[@formcontrolname='performDoc']//div[contains(@class,'ngx-select__toggle')]")
	    private WebElement performingDoctorDropdown;

	    @FindBy(xpath = "//ngx-select[@formcontrolname='performNurse']//div[contains(@class,'ngx-select__toggle')]")
	    private WebElement performingNurseDropdown;

	
	    
	    @FindBy(xpath = "(//div[contains(@class,'ngx-select__toggle')])[2]")
	    private WebElement dropdownToggle;
	    
	    @FindBy(xpath = "(//div[contains(@class,'ngx-select__toggle')])[3]")
	    private WebElement dropdownToggle2;
	    
	    @FindBy(xpath = "//input[@type='button' and @value='Save']")
	    private WebElement saveButton;

	    // ===== Success / Error Messages =====
	    @FindBy(xpath = "//div[contains(@class,'succesfull-info-popup')]//span[contains(text(),'Patient Vital Saved Successfully')]")
	    private WebElement successMessage;

	    @FindBy(xpath = "//div[contains(@class,'succesfull-info-popup')]//span[contains(text(),'Please Fill Correct Value')]")
	    private WebElement errorMessage;

		@FindBy(xpath = "//h4[normalize-space(text())='Vital']/following::img[contains(@class,'openclose')][1]")
		
		private WebElement highRiskToggleIcon;
		
	    // ===== Methods =====
		public void clickHighRiskToggle() {
			clickWithJavaScript(highRiskToggleIcon);
		}
	    public void enterTemperature(String value) {
	    	clickHighRiskToggle();
	        waitForClickability(temperatureInput);
	        temperatureInput.clear();
	        temperatureInput.sendKeys(value);
	    }

	    public void enterSpO2(String value) {
	        waitForClickability(spo2Input);
	        spo2Input.clear();
	        spo2Input.sendKeys(value);
	    }

	    public void enterPulse(String value) {
	        waitForClickability(pulseInput);
	        pulseInput.clear();
	        pulseInput.sendKeys(value);
	    }

	    public void enterHeartRate(String value) {
	        waitForClickability(heartRateInput);
	        heartRateInput.clear();
	        heartRateInput.sendKeys(value);
	    }

	    public void enterRespRate(String value) {
	        waitForClickability(respRateInput);
	        respRateInput.clear();
	        respRateInput.sendKeys(value);
	    }

	    public void enterWeight(String value) {
	        waitForClickability(weightInput);
	        weightInput.clear();
	        weightInput.sendKeys(value);
	    }

	    public void enterHeight(String value) {
	        waitForClickability(heightInput);
	        heightInput.clear();
	        heightInput.sendKeys(value);
	    }

	    public void enterSize(String value) {
	        waitForClickability(sizeInput);
	        sizeInput.clear();
	        sizeInput.sendKeys(value);
	    }

	    public String getIBW() {
	        waitForClickability(ibwInput);
	        return ibwInput.getAttribute("value");
	    }

	    public void enterBPSys(String value) {
	        waitForClickability(bpSysInput);
	        bpSysInput.clear();
	        bpSysInput.sendKeys(value);
	    }

	    public void enterBPDia(String value) {
	        waitForClickability(bpDiaInput);
	        bpDiaInput.clear();
	        bpDiaInput.sendKeys(value);
	    }

	    public void enterPostSugar(String value) {
	        waitForClickability(postSugarInput);
	        postSugarInput.clear();
	        postSugarInput.sendKeys(value);
	    }

	    public void enterPreSugar(String value) {
	        waitForClickability(preSugarInput);
	        preSugarInput.clear();
	        preSugarInput.sendKeys(value);
	    }

	    public void enterRandomSugar(String value) {
	        waitForClickability(randomSugarInput);
	        randomSugarInput.clear();
	        randomSugarInput.sendKeys(value);
	    }

	    public void enterWaist(String value) {
	        waitForClickability(waistInput);
	        waistInput.clear();
	        waistInput.sendKeys(value);
	    }

	    public void enterBodyFat(String value) {
	        waitForClickability(bodyFatInput);
	        bodyFatInput.clear();
	        bodyFatInput.sendKeys(value);
	    }

	    public void enterVisceralFat(String value) {
	        waitForClickability(visceralFatInput);
	        visceralFatInput.clear();
	        visceralFatInput.sendKeys(value);
	    }

	    public void selectPerformingDoctor() {
	        waitForClickability(performingDoctorDropdown);
	        performingDoctorDropdown.click();
	        // Add dropdown selection logic here
	    }

	    public void selectPerformingNurse() {
	        waitForClickability(performingNurseDropdown);
	        performingNurseDropdown.click();
	        // Add dropdown selection logic here
	    }
	    public void selectWheelChairUsage(String option) {
	        WebElement radioBtn;

	        switch (option.toLowerCase()) {
	            case "yes":
	                radioBtn = driver.findElement(By.xpath("//input[@formcontrolname='wheelChairUsage' and @value='Yes']"));
	                break;
	            case "no":
	                radioBtn = driver.findElement(By.xpath("//input[@formcontrolname='wheelChairUsage' and @value='No']"));
	                break;
	            default:
	                throw new IllegalArgumentException("Invalid option for WheelChair Usage: " + option);
	        }

	        radioBtn.click();
	    }


	    public void clickSave() {
	        waitForClickability(saveButton);
	        saveButton.click();
	    }

	    public boolean isSaveSuccessMessageDisplayed() {
	        waitForClickability(successMessage);
	        return successMessage.isDisplayed();
	    }

	    public boolean isErrorMessageDisplayed() {
	        waitForClickability(errorMessage);
	        return errorMessage.isDisplayed();
	    }
	    


	    public void clickDropdown1(String name) {
	        dropdownToggle.click();
	        selectDropdown(name);
	    }
	    public void clickDropdown2(String name) {
	        dropdownToggle2.click();
	        selectDropdown(name);
	    }
	    
		public void selectDropdown(String name) {
			
		    WebElement option = driver.findElement(By.xpath(
		        "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + name + "']"
		    ));
		    option.click();
		   
		}
	}


