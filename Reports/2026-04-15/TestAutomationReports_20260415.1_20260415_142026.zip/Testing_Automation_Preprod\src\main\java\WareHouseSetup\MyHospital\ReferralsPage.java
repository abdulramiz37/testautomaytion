package WareHouseSetup.MyHospital;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import EzionAbstractionComponents.Abstraction;

import java.util.List;

public class ReferralsPage extends Abstraction {

    public ReferralsPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    // ---------------- Locators ----------------

    @FindBy(xpath = "//ngx-select[@formcontrolname='refType']//div[contains(@class, 'ngx-select__toggle')]")
    private WebElement typeDropdown;

    @FindBy(xpath = "//ul[@class='ngx-select__choices dropdown-menu']//a/span")
    private List<WebElement> dropdownOptions;

    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement nameInput;

    @FindBy(xpath = "//input[@formcontrolname='clinicName']")
    private WebElement clinicNameInput;

    @FindBy(xpath = "//input[@formcontrolname='email']")
    private WebElement emailInput;

    @FindBy(xpath = "//input[@formcontrolname='mobile']")
    private WebElement mobileInput;

    @FindBy(xpath = "//input[@formcontrolname='altMobile']")
    private WebElement altMobileInput;

    @FindBy(xpath = "//textarea[@formcontrolname='address']")
    private WebElement addressTextarea;

    @FindBy(xpath = "//span[@class='checkmark']")
    private WebElement isActiveCheckbox;

    @FindBy(xpath = "//input[@type='button' and @value='Save']")
    private WebElement saveButton;

    // ---------------- Actions ----------------
    @FindBy(xpath = "//a[text()=' Referrals ']")
    private WebElement userType;

    @FindBy(xpath = "//a[text()=' Add Referral ']")
    private WebElement adduserType;
     
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}

 // Overloaded for WebElement
    public void selectDropdownOption(WebElement dropdown, String optionText) {
        waitForClickability(dropdown).click();
        By optionBy = By.xpath("//span[normalize-space(text())='" + optionText + "']");
        waitForClickability(optionBy).click();
    }


    public void enterName(String name) {
        WebElement field = waitForVisibility(nameInput);
        field.clear();
        field.sendKeys(name);
    }

    public void enterClinicName(String clinic) {
        WebElement field = waitForVisibility(clinicNameInput);
        field.clear();
        field.sendKeys(clinic);
    }

    public void enterEmail(String email) {
        WebElement field = waitForVisibility(emailInput);
        field.clear();
        field.sendKeys(email);
    }

    public void enterMobile(String mobile) {
        WebElement field = waitForVisibility(mobileInput);
        field.clear();
        field.sendKeys(mobile);
    }

    public void enterAltMobile(String altMobile) {
        WebElement field = waitForVisibility(altMobileInput);
        field.clear();
        field.sendKeys(altMobile);
    }

    public void enterAddress(String address) {
        WebElement field = waitForVisibility(addressTextarea);
        field.clear();
        field.sendKeys(address);
    }

    public void setIsActive(boolean shouldBeChecked) {
        WebElement checkbox = waitForVisibility(isActiveCheckbox);
        if (!checkbox.isSelected() != shouldBeChecked) {
            waitForClickability(checkbox).click();
        }
    }

    public void clickSave() {
        waitForClickability(saveButton).click();
    }

    public void fillReferralForm(String type, String name, String clinic, String email,
                                 String mobile, String altMobile, String address, boolean isActive) {
    	clickbuttonapproval();
    	  selectDropdownOption(typeDropdown, type);
        enterName(name);
        enterClinicName(clinic);
        enterEmail(email);
        enterMobile(mobile);
        enterAltMobile(altMobile);
        enterAddress(address);
        setIsActive(isActive);
        clickSave();
    }
}
