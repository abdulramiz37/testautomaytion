
package TestComponents;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EzionpageObjects.UserIdPage;
import PharmacyPurchaseReturn.GRNVerificationPage;
import PharmacyPurchaseReturn.PharmacyPurchasePage;
import PharmacyPurchaseReturn.PurchaseReturnPage;
import abdulTest.BaseTest;

public class PharmacyPurchaseReturn extends BaseTest {

    @Test(dataProvider = "getData")
    public void PharmacyPurchaseReturn(HashMap<String, String> input) throws InterruptedException {
        // Login
        UserIdPage data = login.login(input.get("userId"));
        data.enterMobileNumber(input.get("personId"));
        data.enterPassword(input.get("password"));
        data.clickContinue();

        // Create Purchase
        PharmacyPurchasePage purchasePage = data.purchasePage();
        purchasePage.createNewPurchase(
            input.get("location"),
            input.get("supplier"),
            input.get("invoiceNumber"),
            input.get("invDate"),
            input.get("dueDate"),
            input.get("expiryDate"),
            input.get("medicineName"),
            input.get("batchNo"),
            input.get("strips"),
            input.get("freeStrips"),
            input.get("mrp"),
            input.get("price")
        );
        String invoiceNo = purchasePage.getGeneratedInvoiceNo();

        // Get GRN Number
        GRNVerificationPage grnPage = purchasePage.save();
        grnPage.getGRNNumber(invoiceNo);
        String grn = grnPage.getStoredGRNNo();
        System.out.println("✅ GRN used in next step: " + grn);

        // Create Purchase Return
        PurchaseReturnPage purchaseReturn = grnPage.returnPage();
        purchaseReturn.createPurchaseReturn(
        	       invoiceNo,
                   grn,
                   input.get("location"),
                   input.get("supplier"),
                   input.get("medicineName"),
                   input.get("quantity")
        );
        purchaseReturn.savePurchasePage(input.get("review"));
        purchaseReturn.saveDetails(invoiceNo);
    }

    @DataProvider
    public Object[][] getData() throws IOException {
        List<HashMap<String, String>> data = getJsonDataToMap(
            System.getProperty("user.dir") + "//src//main//java//ezion//Resources//PharmacyPurchaseReturn.json"
        );
        return new Object[][] { { data.get(0) } };
    }
}
