package Appointment;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import EzionAbstractionComponents.Abstraction;

public class AppointmentList extends Abstraction {
	public AppointmentList(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
	
	public void findPatientByMobile(String targetMobileNumber, String menuOption) {
	    boolean isPatientFound = false;
	    int clickCount = 0; // To track pagination
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    while (!isPatientFound) {
	        // Wait for patient rows to be visible
	        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(
	            By.xpath("//tr[contains(@class,'appt-row')]")
	        ));

	        List<WebElement> rows = driver.findElements(By.xpath("//tr[contains(@class,'appt-row')]"));
	        System.out.println("🔍 Checking " + rows.size() + " rows on page " + (clickCount + 1));

	        for (int i = 0; i < rows.size(); i++) {
	            try {
	                WebElement row = rows.get(i);

	                // Locate mobile number cell
	                WebElement phoneCell = row.findElement(By.xpath(".//p[img[contains(@src,'phone.png')]]"));
	                String mobileNumber = phoneCell.getText().replaceAll("[^0-9]", "").trim();

	                System.out.println("📱 Found number: " + mobileNumber);

	                if (mobileNumber.equals(targetMobileNumber)) {
	                    // ✅ Extract serial number (first <td>)
	                    WebElement serialCell = row.findElement(By.xpath(".//td[1]"));
	                    String serialText = serialCell.getText().trim();
	                    int num = Integer.parseInt(serialText.replaceAll("[^0-9]", ""));

	                    // ✅ Calculate service index
	                    int serviceIndex = (num <= 10) ? num : (num % 10 == 0 ? 10 : num % 10);

	       
	                        // ✅ Click 3-dots and desired menu
	                        WebElement threeDots = row.findElement(By.xpath(".//div[contains(@class,'three-dots')]"));
	                        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", threeDots);

	                        WebElement menuItem = wait.until(ExpectedConditions.elementToBeClickable(
	                            By.xpath("//div[contains(@class,'patient-lists-properties')]//div[normalize-space()='" + menuOption + "']")
	                        ));
	                        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", menuItem);
	                        System.out.println("✅ Clicked '" + menuOption + "' for " + mobileNumber);
	                    

	                    isPatientFound = true;
	                    break;
	                }
	            } catch (NoSuchElementException e) {
	                System.out.println("⚠️ Row " + i + " skipped (element missing)");
	            } catch (StaleElementReferenceException e) {
	                System.out.println("♻️ Row became stale, refreshing elements...");
	                break; // re-fetch rows in next loop iteration
	            }
	        }

	        // 🔁 Go to next page if not found
	        if (!isPatientFound) {
	            if (clickCount >= 14) {
	                System.out.println("⛔ Stopped after 14 pages. Patient not found.");
	                break;
	            }

	            try {
	                WebElement nextBtn = wait.until(ExpectedConditions.elementToBeClickable(
	                    By.xpath("//i[contains(@class, 'fa-chevron-right')]/ancestor::a")
	                ));
	                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextBtn);
	                clickCount++;
	                System.out.println("➡️ Next page (" + clickCount + ")");
	            } catch ( NoSuchElementException e) {
	                System.out.println("❌ No next button. Stopping.");
	                break;
	            }
	        }
	    }
	}
	@FindBy(xpath = "//button[contains(.,'Edit Profile') and contains(@class,'edit-profile')]")
	private WebElement editProfileButton;
	
	public void clickEditProfileButton() {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    wait.until(ExpectedConditions.elementToBeClickable(editProfileButton));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", editProfileButton);
	    System.out.println("✅ Clicked 'Edit Profile' button successfully.");
	}
	@FindBy(xpath = "//input[@formcontrolname='regDates']")
	private WebElement registrationDateInput;

	public void enterRegistrationDate(String dateValue) {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    wait.until(ExpectedConditions.visibilityOf(registrationDateInput));

	    registrationDateInput.clear();
	    registrationDateInput.sendKeys(dateValue);

	    System.out.println("📅 Entered registration date: " + dateValue);
	}
	@FindBy(xpath = "//input[@type='button' and @value='Update']")
	private WebElement updateButton;
	
	public void clickUpdateButton() {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    wait.until(ExpectedConditions.elementToBeClickable(updateButton));

	    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", updateButton);
	    System.out.println("✅ Clicked 'Update' button successfully using JavaScript.");
	}
    @FindBy(xpath = "(//a[text()='Patient Data Report'])[1]")
    private WebElement addbilldiscount;
    
    @FindBy(xpath = "(//span[text()='Reports'])[1]")
    private WebElement billDiscount;
    // ----------- Methods -----------

	public void clickbuttonapproval() {
		waitForClickability(billDiscount).click();
		waitForClickability(addbilldiscount).click();
	}

}
