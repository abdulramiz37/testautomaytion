package Registration;

import java.text.DateFormatSymbols;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class NewRegistrationPage extends Abstraction {

    public NewRegistrationPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }
    public String storedFirstName; 
    // ------------------------ LOCATORS ------------------------

    @FindBy(xpath = "//label[contains(text(),'Title')]/following-sibling::ngx-select")
    private WebElement titleDropdown;

    @FindBy(xpath = "//input[@formcontrolname='firstname']")
    private WebElement firstNameInput;

    @FindBy(xpath = "//input[@formcontrolname='middlename']")
    private WebElement middleNameInput;

    @FindBy(xpath = "//input[@formcontrolname='lastname']")
    private WebElement lastNameInput;

    @FindBy(xpath = "(//label[contains(text(),'Gender')]/following-sibling::ngx-select//span)[3]")
    private WebElement genderDropdown;

    @FindBy(xpath = "//input[@formcontrolname='dob' and contains(@class, 'date-picker-controls')]")
    private WebElement dobInput;

    @FindBy(xpath = "//input[@formcontrolname='ageYear']")
    private WebElement ageYear;

    @FindBy(xpath = "//input[@formcontrolname='ageMonth']")
    private WebElement ageMonth;

    @FindBy(xpath = "//input[@formcontrolname='ageDay']")
    private WebElement ageDay;

    @FindBy(xpath = "//label[contains(text(),'Birth Place')]/following-sibling::ngx-select")
    private WebElement birthPlaceDropdown;

    @FindBy(xpath = "//input[@formcontrolname='birthTime']")
    private WebElement birthTimeInput;

    @FindBy(xpath = "//input[@formcontrolname='mobile']")
    private WebElement mobileNumberInput;

    @FindBy(xpath = "//input[@formcontrolname='landline']")
    private WebElement altMobileInput;

    @FindBy(xpath = "//input[@formcontrolname='officePhone']")
    private WebElement officePhoneInput;

    @FindBy(xpath = "//input[@formcontrolname='email']")
    private WebElement emailInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='parentOrGuardianTitle']")
    private WebElement relationDropdown;

    @FindBy(xpath = "//input[@formcontrolname='parentOrGuardianName']")
    private WebElement relationNameInput;

    
    @FindBy(xpath = "//label[contains(text(),'Auto-fill Address from Family Member')]/input")
    private WebElement autoFillAddressCheckbox;

    @FindBy(xpath = "//input[@formcontrolname='doorno']")
    private WebElement doorNoStreetInput;

    @FindBy(xpath = "//input[@formcontrolname='address1']")
    private WebElement addressLine1Input;

    @FindBy(xpath = "//input[@formcontrolname='address2']")
    private WebElement addressLine2Input;

    @FindBy(xpath = "//ngx-select[@formcontrolname='city']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement cityDropdown;

    @FindBy(xpath = "//input[@formcontrolname='pincode']")
    private WebElement pincodeInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='cityAreaId']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement areaDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='district']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement districtDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='state']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement stateDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='country']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement countryDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='regionId']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement regionDropdown;

    
    @FindBy(xpath = "//input[@formcontrolname='altContactPersonName']")
    private WebElement emergencyContactNameInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='altRelationship']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement relationshipDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='officePhoneCountryCode']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement countryCodeDropdown;

    @FindBy(xpath = "//input[@formcontrolname='altContactPersonMobile']")
    private WebElement emergencyMobileInput;

    @FindBy(xpath = "//input[@formcontrolname='altContactPersonLandline']")
    private WebElement landlineInput;

    @FindBy(xpath = "//textarea[@formcontrolname='altContactPersonAddress']")
    private WebElement emergencyAddressTextarea;
    
    @FindBy(xpath = "//ngx-select[@formcontrolname='howDoUKnowAboutUs']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement howKnowDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='religionId']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement religionDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='citizenshipId']//input[contains(@class,'ngx-select__search') or contains(@class,'ngx-select__toggle')]")
    private WebElement citizenshipDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='nationalityId']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement nationalityDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='maritalStatus']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement maritalStatusDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='preferredlanguage']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement languageDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='occupationId']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement occupationDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='specialCare']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement specialCareDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='specialCourtesy']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement specialCourtesyDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='genderExtension']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement genderExtensionDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='studyId']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement studyDropdown;

    @FindBy(xpath = "//input[@formcontrolname='tourPassportNumber']")
    private WebElement passportNumberInput;

    @FindBy(xpath = "//input[@formcontrolname='tourNationalIdNumber']")
    private WebElement nationalIdInput;

    @FindBy(xpath = "//input[@formcontrolname='drivingLicenseNumber']")
    private WebElement drivingLicenceInput;

    @FindBy(xpath = "//input[@formcontrolname='refugeeNo']")
    private WebElement refugeeNoInput;

    @FindBy(xpath = "//input[@formcontrolname='panCard']")
    private WebElement panCardInput;

    @FindBy(xpath = "//input[@formcontrolname='aaadhar']")
    private WebElement aadharInput;

    @FindBy(xpath = "//input[@formcontrolname='frroNumber']")
    private WebElement frroInput;

    @FindBy(xpath = "//input[@formcontrolname='nhid']")
    private WebElement abhaNumberInput;

    @FindBy(xpath = "//input[@formcontrolname='abhaAddress']")
    private WebElement abhaAddressInput;

    @FindBy(xpath = "//input[@formcontrolname='tourVisaDate']")
    private WebElement visaIssueDateInput;

    @FindBy(xpath = "//input[@formcontrolname='tourVisaValidityDate']")
    private WebElement visaValidityDateInput;

    @FindBy(xpath = "//input[@formcontrolname='tourDateOfEntry']")
    private WebElement dateOfEntryInput;

    @FindBy(xpath = "//input[@formcontrolname='tourPortOfEntry']")
    private WebElement portOfEntryInput;

    @FindBy(xpath = "//textarea[@formcontrolname='tourResidentialAddress']")
    private WebElement residentialAddressTextarea;

    @FindBy(xpath = "//textarea[@formcontrolname='tourOfficeAddress']")
    private WebElement officeAddressTextarea;

    @FindBy(xpath = "//textarea[@formcontrolname='remarks']")
    private WebElement remarksTextarea;

    @FindBy(xpath = "//input[@formcontrolname='deceasedFlag']")
    private WebElement deceasedCheckbox;

    @FindBy(xpath = "//input[@formcontrolname='isActive']")
    private WebElement isActiveCheckbox;

    @FindBy(xpath = "//span[text()='Registration']")
    private WebElement userType;

    @FindBy(xpath = "//span[text()='New Registration']")
    private WebElement adduserType;
     
    @FindBy(xpath = "//input[@placeholder='DD/MM/YYYY']")
    private WebElement dobField;

    @FindBy(xpath = "//button[@aria-label='Choose month and year']")
    private WebElement monthYearChooser;

    @FindBy(xpath = "//button[@aria-label='Previous 21 years']")
    private WebElement prevYearsButton;

    @FindBy(xpath = "//td[@aria-label='1999']")
    private WebElement year1999;

    @FindBy(xpath = "//td[@aria-label='May 1999']")
    private WebElement monthMay;

    @FindBy(xpath = "//td[@aria-label='May 12, 1999']")
    private WebElement date12May;
    
    @FindBy(xpath = "//input[@type='button' and @value='Save']")
    private WebElement saveButton;
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}
    // ------------------------ METHODS WITH WAITS ------------------------

    public void selectTitle() {
        waitForClickability(titleDropdown).click();
    }

    public void enterFirstName(String firstName) {
        if (firstName == null || firstName.isEmpty()) {
            firstName = generateRandomName();
        }
        storedFirstName = firstName; 
        waitForVisibility(firstNameInput).clear();
        firstNameInput.sendKeys(firstName);
    }

    private String generateRandomName() {
        String[] chars = "abcdefghijklmnopqrstuvwxyz".split("");
        Random random = new Random();

        int length = 5 + random.nextInt(3); // random length between 5–7
        StringBuilder word = new StringBuilder();

        for (int j = 0; j < length; j++) {
            word.append(chars[random.nextInt(chars.length)]);
        }

        return word.toString();
    }


    public void enterMiddleName(String middleName) {
        waitForVisibility(middleNameInput).clear();
        middleNameInput.sendKeys(middleName);
    }

    public void enterLastName(String lastName) {
        waitForVisibility(lastNameInput).clear();
        lastNameInput.sendKeys(lastName);
    }

    public void selectGender() {
    	clickWithJavaScript(genderDropdown);
    }

    public void enterDOB(String dob) {
        waitForVisibility(dobInput).clear();
        dobInput.sendKeys(dob);
    }
    
    public void enterDOB2(String dob) {
        String[] parts = dob.split("-");
        String year = parts[0];      // "1999"
        String month = parts[1];     // "May"
        String day = parts[2];       // "12"

        waitForClickability(dobField).click();
        waitForClickability(monthYearChooser).click();

        // Navigate to the correct year
        while (true) {
            try {
                WebElement desiredYear = driver.findElement(By.xpath("//td[@aria-label='" + year + "']"));
                waitForClickability(desiredYear).click();
                break;
            } catch (NoSuchElementException e) {
                waitForClickability(prevYearsButton).click();
            }
        }

        // Select the month
        String monthLabel = month + " " + year; // e.g., "May 1999"
        WebElement desiredMonth = driver.findElement(By.xpath("//td[@aria-label='" + monthLabel + "']"));
        waitForClickability(desiredMonth).click();

        // Select the date
        String fullDate = month + " " + Integer.parseInt(day) + ", " + year; // e.g., "May 12, 1999"
        WebElement desiredDate = driver.findElement(By.xpath("//td[@aria-label='" + fullDate + "']"));
        waitForClickability(desiredDate).click();
    }

  




    public String getAgeYear() {
        return waitForVisibility(ageYear).getAttribute("value");
    }

    public String getAgeMonth() {
        return waitForVisibility(ageMonth).getAttribute("value");
    }

    public String getAgeDay() {
        return waitForVisibility(ageDay).getAttribute("value");
    }

    public void selectBirthPlace() {
        waitForClickability(birthPlaceDropdown).click();
    }

    public void enterBirthTime(String time) {
        waitForVisibility(birthTimeInput).clear();
        birthTimeInput.sendKeys(time);
    }

//    public void enterMobileNumber(String number) {
//        waitForVisibility(mobileNumberInput).clear();
//        mobileNumberInput.sendKeys(number);
//    }
    
 // ✅ Public variable to store last entered mobile number
    public String lastEnteredMobileNumber;

    public void enterMobileNumber(String mobile) {
        WebElement mobileField = waitForVisibility(mobileNumberInput);
        mobileField.clear();

        if (mobile == null || mobile.trim().isEmpty()) {
            mobile = generateRandomMobileNumber();
        }

        // Store in public variable so it can be accessed later
        lastEnteredMobileNumber = mobile;

        mobileField.sendKeys(mobile);
    }

    public String generateRandomMobileNumber() {
        Random rand = new Random();
        StringBuilder number = new StringBuilder();
        number.append(rand.nextInt(3) + 7); // first digit: 7, 8, or 9

        for (int i = 0; i < 9; i++) {
            number.append(rand.nextInt(10));
        }

        return number.toString();
    }

    public void enterAlternateMobile(String number) {
        waitForVisibility(altMobileInput).clear();
        altMobileInput.sendKeys(number);
    }

    public void enterOfficePhone(String phone) {
        waitForVisibility(officePhoneInput).clear();
        officePhoneInput.sendKeys(phone);
    }

    public void enterEmail(String email) {
        waitForVisibility(emailInput).clear();
        emailInput.sendKeys(email);
    }

    public void selectRelationTitle() {
        waitForClickability(relationDropdown).click();
    }

    public void enterRelationName(String name) {
        waitForVisibility(relationNameInput).clear();
        relationNameInput.sendKeys(name);
    }
    
    public void save() {
    	clickWithJavaScript(saveButton);
//        waitForUrlContains("https://apps.ezovion.com/pages/patientservices/app");
        waitForUrlContains("https://ezopreprodstrgfrontend.z29.web.core.windows.net/pages/patientservices/app");
    }
    
    public void clickAutoFillCheckbox() {
        if (!autoFillAddressCheckbox.isSelected()) {
            autoFillAddressCheckbox.click();
        }
    }

    public void enterDoorNo(String value) {
        doorNoStreetInput.clear();
        doorNoStreetInput.sendKeys(value);
    }

    public void enterAddressLine1(String value) {
        addressLine1Input.clear();
        addressLine1Input.sendKeys(value);
    }

    public void enterAddressLine2(String value) {
        addressLine2Input.clear();
        addressLine2Input.sendKeys(value);
    }

    public void selectCity(String cityName) {
        cityDropdown.click();
        driver.findElement(By.xpath("//div[contains(@class,'ngx-select__item') and text()='" + cityName + "']")).click();
    }

    public void enterPincode(String pincode) {
        pincodeInput.clear();
        pincodeInput.sendKeys(pincode);
    }

    public void selectArea(String areaName) {
        areaDropdown.click();
        driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + areaName + "']")).click();
    }

    public void selectDistrict(String districtName) {
        districtDropdown.click();
        driver.findElement(By.xpath("//div[contains(@class,'ngx-select__item') and text()='" + districtName + "']")).click();
    }

    public void selectState(String stateName) {
        stateDropdown.click();
        driver.findElement(By.xpath("//div[contains(@class,'ngx-select__item') and text()='" + stateName + "']")).click();
    }

    public void selectCountry(String countryName) {
        countryDropdown.click();
        driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + countryName + "']")).click();
    }

    public void selectRegion(String regionName) {
        regionDropdown.click();
        driver.findElement(By.xpath("//div[contains(@class,'ngx-select__item') and text()='" + regionName + "']")).click();
    }

    public void enterEmergencyContactName(String name) {
        emergencyContactNameInput.clear();
        emergencyContactNameInput.sendKeys(name);
    }

    public void selectRelationship(String relationship) {
        relationshipDropdown.click();
        driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + relationship + "']")).click();
    }

    public void selectCountryCode(String code) {
        countryCodeDropdown.click();
        driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + code + "']")).click();
    }

    public void enterEmergencyMobile(String mobile) {
        emergencyMobileInput.clear();
        emergencyMobileInput.sendKeys(mobile);
    }

    public void enterLandline(String landline) {
        landlineInput.clear();
        landlineInput.sendKeys(landline);
    }

    public void enterEmergencyAddress(String address) {
        emergencyAddressTextarea.clear();
        emergencyAddressTextarea.sendKeys(address);
    }
    
 // Selects an option from "How did you know about us?" dropdown
    public void selectHowKnow(String option) {
        howKnowDropdown.click(); // Click to open the dropdown
        driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + option + "']")).click(); // Click the specified option
    }

    // Selects a religion from the Religion dropdown
    public void selectReligion(String religion) {
        religionDropdown.click(); // Click to open the dropdown
        driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + religion + "']")).click(); // Select religion
    }

    // Selects a citizenship option
    public void selectCitizenship(String citizenship) {
        citizenshipDropdown.click(); // Open citizenship dropdown
        driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + citizenship + "']")).click(); // Click the value
    }

    // Selects a nationality
    public void selectNationality(String nationality) {
        nationalityDropdown.click(); // Click to show dropdown
        driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + nationality + "']")).click(); // Select nationality
    }

    // Selects a marital status
    public void selectMaritalStatus(String status) {
        maritalStatusDropdown.click(); // Open status dropdown
        driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + status + "']")).click(); // Select the status
    }

    // Selects a preferred language
    public void selectLanguage(String language) {
        languageDropdown.click(); // Open dropdown
        driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + language + "']")).click(); // Pick language
    }

    // Selects an occupation
    public void selectOccupation(String occupation) {
        occupationDropdown.click(); // Expand dropdown
        driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + occupation + "']")).click(); // Select occupation
    }

    // Selects special care needed
    public void selectSpecialCare(String care) {
        specialCareDropdown.click(); // Open dropdown
        driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + care + "']")).click(); // Choose care option
    }

    // Selects special courtesy
    public void selectSpecialCourtesy(String courtesy) {
        specialCourtesyDropdown.click(); // Show dropdown list
        driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + courtesy + "']")).click(); // Pick courtesy
    }

    // Selects gender extension
    public void selectGenderExtension(String extension) {
        genderExtensionDropdown.click(); // Expand gender extension options
        driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + extension + "']")).click(); // Select value
    }

    // Selects education/study background
    public void selectStudy(String study) {
        studyDropdown.click(); // Open study dropdown
        driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + study + "']")).click(); // Choose study option
    }

    // --- Input methods ---

    public void enterPassportNumber(String text) {
        passportNumberInput.clear();
        passportNumberInput.sendKeys(text);
    }

    public void enterNationalId(String text) {
        nationalIdInput.clear();
        nationalIdInput.sendKeys(text);
    }

    public void enterDrivingLicence(String text) {
        drivingLicenceInput.clear();
        drivingLicenceInput.sendKeys(text.toUpperCase());
    }

    public void enterRefugeeNo(String text) {
        refugeeNoInput.clear();
        refugeeNoInput.sendKeys(text);
    }

    public void enterPanCard(String text) {
        panCardInput.clear();
        panCardInput.sendKeys(text);
    }

    public void enterAadhar(String text) {
        aadharInput.clear();
        aadharInput.sendKeys(text);
    }

    public void enterFrroNumber(String text) {
        frroInput.clear();
        frroInput.sendKeys(text);
    }

    public void enterAbhaNumber(String text) {
        abhaNumberInput.clear();
        abhaNumberInput.sendKeys(text.toUpperCase());
    }

    public void enterAbhaAddress(String text) {
        abhaAddressInput.clear();
        abhaAddressInput.sendKeys(text.toLowerCase());
    }

    public void enterVisaIssueDate(String date) {
        visaIssueDateInput.clear();
        visaIssueDateInput.sendKeys(date);
    }

    public void enterVisaValidityDate(String date) {
        visaValidityDateInput.clear();
        visaValidityDateInput.sendKeys(date);
    }

    public void enterDateOfEntry(String date) {
        dateOfEntryInput.clear();
        dateOfEntryInput.sendKeys(date);
    }

    public void enterPortOfEntry(String port) {
        portOfEntryInput.clear();
        portOfEntryInput.sendKeys(port);
    }

    public void enterResidentialAddress(String address) {
        residentialAddressTextarea.clear();
        residentialAddressTextarea.sendKeys(address);
    }

    public void enterOfficeAddress(String address) {
        officeAddressTextarea.clear();
        officeAddressTextarea.sendKeys(address);
    }

    public void enterRemarks(String remarks) {
        remarksTextarea.clear();
        remarksTextarea.sendKeys(remarks);
    }

    public void setDeceasedFlag(boolean flag) {
        if (deceasedCheckbox.isSelected() != flag) {
            deceasedCheckbox.click();
        }
    }

    public void setIsActiveFlag(boolean flag) {
        if (isActiveCheckbox.isSelected() != flag) {
            isActiveCheckbox.click();
        }

    }
    public void selectOptionFromNgxDropdown(String visibleText) {
        driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + visibleText + "']")).click();
    }
    
    public void refrralmethod(String visibleText) {
        referralDropdown.click();
	    driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + visibleText + "']")).click();
    }
    
    public void employeemethod(String visibleText) {
    	referralEmployeeDropdown.click();
	    driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + visibleText + "']")).click();
    }

    public void fillNewRegistrationForm(
    	    String title, String firstName, String middleName, String lastName, String gender,
    	    String dob, String birthPlace, String birthTime,
    	    String mobileNumber, String altMobile, String officePhone, String email,
    	    String relationTitle, String relationName,
    	    boolean autoFillAddress, String doorNo, String address1, String address2,
    	    String city, String pincode, String area, String district, String state, String country, String region,
    	    String emergencyName, String emergencyRelation, String emergencyCountryCode, String emergencyMobile,
    	    String landline, String emergencyAddress,String ref, String emp,
    	    String howKnow, String religion, String citizenship, String nationality, String maritalStatus,
    	    String language, String occupation, String specialCare, String specialCourtesy, String genderExtension, String study,
    	    String passportNo, String nationalId, String drivingLicense, String refugeeNo,
    	    String panCard, String aadhar, String frro, String abhaNo, String abhaAddress,
    	    String visaIssueDate, String visaValidityDate, String dateOfEntry, String portOfEntry,
    	    String residentialAddress, String officeAddress, String remarks,
    	    boolean isDeceased, boolean isActive
    	) {
    	clickbuttonapproval();
    	    selectTitle();
    	    selectOptionFromNgxDropdown(title);

    	    enterFirstName(firstName);
    	    enterMiddleName(middleName);
    	    enterLastName(lastName);

    	    selectGender();
    	    selectOptionFromNgxDropdown(gender);

    	    enterDOB(dob);

    	    selectBirthPlace();
    	    selectOptionFromNgxDropdown(birthPlace);

    	    enterBirthTime(birthTime);
    	    enterMobileNumber(mobileNumber);
    	    enterAlternateMobile(altMobile);
    	    enterOfficePhone(officePhone);
    	    enterEmail(email);

    	    selectRelationTitle();
    	    selectOptionFromNgxDropdown(relationTitle);
    	    enterRelationName(relationName);

//    	    if (autoFillAddress) clickAutoFillCheckbox();

    	    enterDoorNo(doorNo);
    	    enterAddressLine1(address1);
    	    enterAddressLine2(address2);
   
//    	    selectCity(city);
//    	    enterPincode(pincode);
    	    selectArea(area);
//    	    selectDistrict(district);
//    	    selectState(state);
    	    selectCountry(country);
//    	    selectRegion(region);

    	    enterEmergencyContactName(emergencyName);
    	    selectRelationship(emergencyRelation);
    	    selectCountryCode(emergencyCountryCode);
    	    enterEmergencyMobile(emergencyMobile);
    	    enterLandline(landline);
    	    enterEmergencyAddress(emergencyAddress);
    	    
    	    
     	    refrralmethod(ref);
    	    employeemethod(emp);
    	    
    	    selectHowKnow(howKnow);
    	    selectReligion(religion);
//    	    selectCitizenship(citizenship);
//    	    selectNationality(nationality);
    	    selectMaritalStatus(maritalStatus);
    	    selectLanguage(language);
//    	    selectOccupation(occupation);
    	    selectSpecialCare(specialCare);
    	    selectSpecialCourtesy(specialCourtesy);
//    	    selectGenderExtension(genderExtension);
//    	    selectStudy(study);

    	    enterPassportNumber(passportNo);
    	    enterNationalId(nationalId);
    	    enterDrivingLicence(drivingLicense);
    	    enterRefugeeNo(refugeeNo);
    	    enterPanCard(panCard);
    	    enterAadhar(aadhar);
    	    enterFrroNumber(frro);
    	    enterAbhaNumber(abhaNo);
    	    enterAbhaAddress(abhaAddress);

    	    enterVisaIssueDate(visaIssueDate);
    	    enterVisaValidityDate(visaValidityDate);
    	    enterDateOfEntry(dateOfEntry);
    	    enterPortOfEntry(portOfEntry);

    	    enterResidentialAddress(residentialAddress);
    	    enterOfficeAddress(officeAddress);
    	    enterRemarks(remarks);

    	    setDeceasedFlag(isDeceased);
    	    setIsActiveFlag(isActive);
    	}
    
    // Locators using @FindBy
    // Referral Type dropdown (e.g., Employee, Self)
       @FindBy(xpath = "//ngx-select[@formcontrolname='refMode']//div[contains(@class,'ngx-select__toggle')]")
       public WebElement referralDropdown;

       // Referral Employee dropdown (e.g., Fddf Fgf)
       @FindBy(xpath = "//ngx-select[@formcontrolname='refEmpId']//div[contains(@class,'ngx-select__toggle')]")
       public WebElement referralEmployeeDropdown;

       

    // Method to handle ngx-select dropdowns



}