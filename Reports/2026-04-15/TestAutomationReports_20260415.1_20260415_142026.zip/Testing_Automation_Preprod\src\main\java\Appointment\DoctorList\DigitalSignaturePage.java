package Appointment.DoctorList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class DigitalSignaturePage extends Abstraction {
	public DigitalSignaturePage(WebDriver driver) {
		super(driver);
	    this.driver = driver;
        PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//ngx-select[@formcontrolname='dspage']//input")
	private WebElement selectPagesDropdown;

	@FindBy(xpath = "//input[@formcontrolname='dstitle']")
	private WebElement signatureLabelInput;

	@FindBy(xpath = "//input[@type='file' and @formcontrolname='file']")
	private WebElement fileUploadInput;

	@FindBy(xpath = "//canvas")
	private WebElement signatureCanvas;

	@FindBy(xpath = "//input[@type='button' and @style='background: #000000;']")
	private WebElement colorBlackButton;

	@FindBy(xpath = "//input[@type='button' and @style='background: #3742fa;']")
	private WebElement colorBlueButton;

	@FindBy(xpath = "//input[@type='button' and @style='background: #26bf26;']")
	private WebElement colorGreenButton;

	@FindBy(xpath = "//input[@type='button' and @value='Reset']")
	private WebElement resetButton;

	@FindBy(xpath = "(//input[@type='button' and @value='Save'])[6]")
	private WebElement saveButton;

	
    @FindBy(xpath ="//a[@class='tab-link']//span[normalize-space(.)='Digital Signature']")

    private WebElement userType;


    public void clickButtonApproval() {
    	WebElement container = driver.findElement(By.cssSelector(".scrollable-container"));
    	WebElement targetElement = driver.findElement(By.xpath("//span[text()='Digital Signature']"));

    	JavascriptExecutor js = (JavascriptExecutor) driver;

    	// Scroll the container to bring the target element into view
    	js.executeScript("arguments[0].scrollTop = arguments[1].offsetTop;", container, targetElement);




        // Then click
        waitForClickability(userType).click();
    }


	@FindBy(xpath = "//input[@type='button' and @value='Cancel']")
	private WebElement cancelButton;
	// Select from multi-select dropdown by sending keys
	public void selectPages(String pageName) {
		clickButtonApproval();
	    selectPagesDropdown.click();
	    selectPagesDropdown.sendKeys(pageName);
	    selectPagesDropdown.sendKeys(Keys.ENTER);
	}

	// Enter the Signature Label
	public void enterSignatureLabel(String label) {
//	    signatureLabelInput.clear();
		  waitForClickability(userType).click();
	    waitForClickability(signatureLabelInput).sendKeys(label);
	}

	// Upload file (path must be absolute)
	public void uploadSignatureFile(String filePath) {
	    fileUploadInput.sendKeys(filePath);
	}

	// Draw signature on canvas using JavaScript (optional simulation)
	public void drawSignature(WebDriver driver) {
	    JavascriptExecutor js = (JavascriptExecutor) driver;
	    String script = "var canvas = arguments[0];" +
	                    "var ctx = canvas.getContext('2d');" +
	                    "ctx.beginPath();" +
	                    "ctx.moveTo(20, 20);" +
	                    "ctx.lineTo(150, 100);" +
	                    "ctx.stroke();";
	    js.executeScript(script, signatureCanvas);
	}

	// Select color for signature
	public void chooseSignatureColor(String color) {
	    switch (color.toLowerCase()) {
	        case "black":
	            colorBlackButton.click();
	            break;
	        case "blue":
	            colorBlueButton.click();
	            break;
	        case "green":
	            colorGreenButton.click();
	            break;
	        default:
	            throw new IllegalArgumentException("Unsupported color: " + color);
	    }
	}

	// Reset canvas
	public void resetSignature() {
	    resetButton.click();
	}

	// Save signature
	public void clickSave() {
	    saveButton.click();
	}

	// Cancel the form
	public void clickCancel() {
	    cancelButton.click();
	}

}
