package PharmacyPurchaseOrder;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class PharmacyPurchaseOrderTable extends Abstraction {

    @FindBy(xpath = "//table[@class='table table-hover table-style']/tbody/tr")
    private List<WebElement> tableRows;

    @FindBy(xpath = "(//i[@class='fas fa-chevron-right'])[1]")
    private WebElement nextPageButton;

    @FindBy(xpath = "//input[@value='Sent to Approve']")
    private WebElement sentToApproveButton;

    @FindBy(xpath = "//div[@class='lightbox-close']")
    private WebElement lightboxCloseButton;

    @FindBy(xpath = "(//li[@class='tab ng-star-inserted'])[1]")
    private WebElement tab1;

    @FindBy(xpath = "(//input[@value='Update'])[2]")
    private WebElement updateButton;

    @FindBy(xpath = "(//span[text()='PO Tracking List'])[1]")
    private WebElement poTrackingTab;
    
    // Checkbox - "Click to Change PO Status"
    @FindBy(xpath = "//label[contains(.,'Click to Change PO Status')]/input[@type='checkbox']")
    private WebElement changePOStatusCheckbox;

    // Dropdown - PO Status
    @FindBy(xpath = "//label[text()='PO Status']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement poStatusDropdown;

    // Dropdown - Final Verification By
    @FindBy(xpath = "//label[text()='Final Verification By']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement finalVerificationByDropdown;

    @FindBy(xpath = "//span[normalize-space()='Select']")
    private WebElement finalVerificationByDropdown2;

    // Dropdown - Employee
    @FindBy(xpath = "//label[text()='Employee']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement employeeDropdown;

    // Textarea - Notes
    @FindBy(xpath = "//label[text()='Notes']/following-sibling::textarea")
    private WebElement notesTextarea;

    // Button - Update
    @FindBy(xpath = "//input[@type='button' and @value='Update']")
    private WebElement updateButton2;

    // Button - Cancel
    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
    private WebElement cancelButton;
    public PharmacyPurchaseOrderTable(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    public boolean clickEditOnPurchaseOrder(String targetSupplierName, String targetStatus) {
    	
//    	waitForUrl(("https://apps.ezovion.com/pages/pharmacy/po"));
    
        boolean isFound = false;

        while (!isFound) {
            List<WebElement> rows = waitForPresenceOfAll(
                By.xpath("//table[@class='table table-hover table-style']/tbody/tr"));

            for (int i = 0; i < rows.size(); i++) {
                try {
                    WebElement row = driver.findElements(
                        By.xpath("//table[@class='table table-hover table-style']/tbody/tr")).get(i);

                    String supplierName = row.findElement(By.xpath("./td[4]")).getText().trim();
                    String status = row.findElement(By.xpath("./td[11]/span")).getText().trim();

                    if (supplierName.equalsIgnoreCase(targetSupplierName)
                            && status.equalsIgnoreCase(targetStatus)) {
                    	WebElement editIcon = row.findElement(
                    		    By.xpath("./td[13]//img[contains(@src,'edit.png')]"));

                    		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", editIcon);
                        waitForClickability(editIcon).click();

                        System.out.println("✅ Clicked Edit for Supplier: " + supplierName + ", Status: " + status);
                        isFound = true;
                        break;
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("⚠️ Skipping stale or missing row at index " + i);
                }
            }

            if (!isFound) {
                try {
                    String classAttr = nextPageButton.getAttribute("class");
                    if (classAttr.contains("disabled")) {
                        System.out.println("❌ Reached last page. Entry not found.");
                        break;
                    }
                    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextPageButton);
                } catch (NoSuchElementException e) {
                    System.out.println("❌ Next page button not found. Ending search.");
                    break;
                }
            }
        }

        return isFound;
    }

    public void toggleChangePOStatus(boolean select) {
        if (changePOStatusCheckbox.isSelected() != select) {
        	clickWithJavaScript(changePOStatusCheckbox);
        }
    }

    // Click PO Status dropdown
 // Method: Select PO Status by visible text (e.g., "New")
    public void selectPOStatus(String statusName) {
        // Click to open dropdown
        poStatusDropdown.click();

        // Locate the option dynamically using ul/li
        WebElement option = driver.findElement(By.xpath(
            "//ul[@role='menu']//li[@role='menuitem']//span[normalize-space(text())='" + statusName + "']"
        ));

        option.click();
    }


    // Click Final Verification By dropdown
 // Method: Select Final Verification By (e.g., "Employee", "Vendor")
    public void selectFinalVerificationBy(String optionText) {
        finalVerificationByDropdown.click();

        WebElement option = driver.findElement(By.xpath(
            "//ul[@role='menu']//li[@role='menuitem']//span[normalize-space(text())='" + optionText + "']"
        ));
        option.click();
    }
    
    public void selectFinalVerificationBy2(String optionText) {
        finalVerificationByDropdown2.click();

        WebElement option = driver.findElement(By.xpath(
            "//ul[@role='menu']//li[@role='menuitem']//span[normalize-space(text())='" + optionText + "']"
        ));
        option.click();
    }


    // Method: Select Employee (e.g., "Cb", "John Doe")
    public void selectEmployee(String employeeName) {
        employeeDropdown.click();

        WebElement option = driver.findElement(By.xpath(
            "//ul[@role='menu']//li[@role='menuitem']//span[normalize-space(text())='" + employeeName + "']"
        ));
        option.click();
    }


    // Enter notes
    public void enterNotes(String notes) {
        notesTextarea.clear();
        notesTextarea.sendKeys(notes);
    }

    // Click Update button
    public void clickUpdate() {
    	updateButton2.click();
    }

    // Click Cancel button
    public void clickCancel() {
        cancelButton.click();
    }

    public String clickEditFromSecondTabAndUpdate(String targetSupplierName, String targetStatus) {
        // Switch tab using Actions
//    	waitForUrl(("https://apps.ezovion.com/pages/pharmacy/po"));
        Actions actions = new Actions(driver);


        boolean isFound = false;
        String poNumber = "";

        while (!isFound) {
            List<WebElement> rows = driver.findElements(
                By.xpath("//table[@class='table table-hover table-style']/tbody/tr"));

            for (int i = 0; i < rows.size(); i++) {
                try {
                    WebElement row = rows.get(i);

                    poNumber = row.findElement(By.xpath("./td[3]")).getText().trim();
                    String supplierName = row.findElement(By.xpath("./td[4]")).getText().trim();
                    System.out.println(supplierName);
                    String status = row.findElement(By.xpath("./td[11]")).getText().trim();
                    System.out.println(status);
                    if (supplierName.equalsIgnoreCase(targetSupplierName)
                            && status.equalsIgnoreCase(targetStatus)) {
                        WebElement editIcon = row.findElement(By.xpath("./td[13]//img[contains(@src,'edit.png')]"));
                        waitForClickability(editIcon).click();

                        System.out.println("✅ Clicked Edit for Supplier: " + supplierName + ", Status: " + status);
                        isFound = true;
                        break;
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("⚠️ Skipping stale or missing row at index " + i);
                }
            }

            if (!isFound) {
                try {
                    WebElement nextButton2 = driver.findElement(By.xpath("//a[@role='button']//i[contains(@class,'fa-chevron-right')]"));
                    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextButton2);
                } catch (NoSuchElementException e) {
                    System.out.println("❌ Next page button not found. Ending search.");
                    break;
                }
            }
        }

        // Confirm we're on the right page
//        waitForUrl(("https://apps.ezovion.com/pages/pharmacy/po"));


        // Click Update
//        waitForClickability(updateButton).click();
        return poNumber;
    }
    
    public POTrackingPage poTracking() {
    	  waitForClickability(poTrackingTab).click();
    	  POTrackingPage potrackinPage = new POTrackingPage(driver);
    	  return potrackinPage;
    }
}
