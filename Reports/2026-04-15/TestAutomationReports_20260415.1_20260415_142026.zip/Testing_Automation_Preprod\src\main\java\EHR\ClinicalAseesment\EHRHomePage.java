package EHR.ClinicalAseesment;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class EHRHomePage extends Abstraction {

	public EHRHomePage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public void clickNgxSelect(String fieldName) {

		List<WebElement> dropdowns = driver.findElements(By.xpath("//label[normalize-space()='" + fieldName + "']"
				+ "/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]"));

		for (WebElement dropdown : dropdowns) {
			try {
				if (dropdown.isDisplayed() && dropdown.isEnabled()) {
					dropdown.click();
					return; // stop after successful click
				}
			} catch (Exception e) {
				// ignore and try next element
			}
		}

		throw new RuntimeException("Ngx-select dropdown not found or not clickable for label '" + fieldName + "'");
	}

	public void clickByText(String text) {
		driver.findElement(By.xpath("//*[normalize-space(text())='" + text + "']")).click();
	}

	public void clickActionByCategory(String categoryName, String actionTitle) {

		WebElement actionBtn = driver.findElement(By.xpath(
				"//tbody//tr[td[normalize-space()='" + categoryName + "']]" + "//a[@title='" + actionTitle + "']"));

		actionBtn.click();
	}

}
