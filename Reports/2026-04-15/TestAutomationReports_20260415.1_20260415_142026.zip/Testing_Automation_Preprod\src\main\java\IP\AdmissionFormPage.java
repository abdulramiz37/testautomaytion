package IP;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class AdmissionFormPage extends Abstraction{

    WebDriver driver;

    public AdmissionFormPage(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // ----------- LOCATORS ------------

    // Department Dropdown
    @FindBy(xpath = "//label[text()='Select Department']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement departmentDropdown;

    // Physician Dropdown
    @FindBy(xpath = "//label[text()='Select Physician']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement physicianDropdown;

    // Admission Type Dropdown
    @FindBy(xpath = "//label[text()='Select Admission Type']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement admissionTypeDropdown;

    // Admission Date Input
    @FindBy(xpath = "//input[@formcontrolname='admissionDate']")
    private WebElement admissionDateInput;

    // Nursing Counter Dropdown
    @FindBy(xpath = "//label[text()='Nursing Counter']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement nursingCounterDropdown;

    // Ward Dropdown
    @FindBy(xpath = "//label[text()='Ward']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement wardDropdown;

    // Locker Number Input
    @FindBy(xpath = "//input[@formcontrolname='lockerNo']")
    private WebElement lockerNumberInput;

    // Buttons
    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//input[@value='Save and Continue']")
    private WebElement saveAndContinueButton;

    @FindBy(xpath = "//input[@value='Cancel']")
    private WebElement cancelButton;

    @FindBy(xpath = "//ul[@class='clearfix']//li[@class='bedCleaningCustom']")
    private List<WebElement> bedList;

 // Get all bed numbers
    public List<String> getAllBedNumbers() {
        return bedList.stream()
                .map(e -> e.getText().trim())
                .collect(Collectors.toList());
    }

    // Click bed by number
    public void clickBedByNumber(String targetBed) {
        for (WebElement bed : bedList) {
            String number = bed.findElement(By.xpath(".//p")).getText().trim();
            if (number.equalsIgnoreCase(targetBed)) {
                bed.findElement(By.xpath(".//a")).click();
                break;
            }
        }
    }

    public void clickBedByNumberDynamic(String targetBed) {
        WebElement bed = driver.findElement(By.xpath("//ul[@class='clearfix']//li[@class='bedCleaningCustom']//p[normalize-space()='" + targetBed + "']/preceding-sibling::a"));
        clickWithJavaScript(bed);
    }
    
    public void clickBedImageByNumberDynamic(String targetBed) {
        WebElement img = driver.findElement(By.xpath(
            "//li[@class='bedCleaningCustom'][.//p[normalize-space()='" + targetBed + "']]//a/img"
        ));
        img.click();
    }
    public void clickBedImageSimpleNoWait(String targetBed) {
        WebElement img = driver.findElement(By.xpath(
            "//li[contains(@class,'bedCleaningCustom')][.//p[normalize-space()='" + targetBed + "']]//a/img"
        ));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", img);
    }

    public void selectDepartment(String deptName) {
        departmentDropdown.click();
        WebElement option = driver.findElement(By.xpath("//ul[@role='menu']//span[normalize-space()='" + deptName + "']"));
        option.click();
    }

    public void selectPhysician(String physicianName) {
        physicianDropdown.click();
        WebElement option = driver.findElement(By.xpath("//ul[@role='menu']//span[normalize-space()='" + physicianName + "']"));
        option.click();
    }

    public void selectAdmissionType(String admissionType) {
        admissionTypeDropdown.click();
        WebElement option = driver.findElement(By.xpath("//ul[@role='menu']//span[normalize-space()='" + admissionType + "']"));
        option.click();
    }

    public void enterAdmissionDate(String dateValue) {
        if (dateValue == null || dateValue.isEmpty()) {
            // Format example: "10/04/2025 10:08 AM"
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm a");
            dateValue = formatter.format(new Date());
        }

        waitForVisibility(admissionDateInput).clear();
        admissionDateInput.sendKeys(dateValue);
    }


    public void selectNursingCounter(String counterName) {
        nursingCounterDropdown.click();
        WebElement option = driver.findElement(By.xpath("//ul[@role='menu']//span[normalize-space()='" + counterName + "']"));
        option.click();
    }

    public void selectWard(String wardName) {
        wardDropdown.click();
        WebElement option = driver.findElement(By.xpath("//ul[@role='menu']//span[normalize-space()='" + wardName + "']"));
        option.click();
    }

    public void enterLockerNumber(String lockerNo) {
        lockerNumberInput.clear();
        lockerNumberInput.sendKeys(lockerNo);
    }

    public void clickSave() {
        saveButton.click();
    }

    public void clickSaveAndContinue() {
        saveAndContinueButton.click();
    }

    public void clickCancel() {
        cancelButton.click();
    }
}
