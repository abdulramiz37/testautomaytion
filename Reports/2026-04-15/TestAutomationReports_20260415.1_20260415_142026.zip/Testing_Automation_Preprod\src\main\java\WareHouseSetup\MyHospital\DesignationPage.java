package WareHouseSetup.MyHospital;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import EzionAbstractionComponents.Abstraction;

public class DesignationPage extends Abstraction {

    WebDriver driver;

    public DesignationPage(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // === Locators ===

    // Designation Name input field
    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement designationNameInput;

    // Is Active checkbox
    @FindBy(xpath = "//label[contains(text(), 'Is Active')]")
    private WebElement isActiveCheckbox;

    // Save button
    @FindBy(xpath = "//input[@type='button' and @value='Save']")
    private WebElement saveButton;

    // Cancel button
    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
    private WebElement cancelButton;

    @FindBy(xpath = "//a[text()=' Designations ']")
    private WebElement userType;

    @FindBy(xpath = "//a[text()=' Add Designation ']")
    private WebElement adduserType;
     
   
    
    // === Methods ===

    /**
     * Enter designation name in the input field.
     */
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}
    public void enterDesignationName(String name) {
        designationNameInput.clear();
        designationNameInput.sendKeys(name);
    }

    /**
     * Check or uncheck the "Is Active" checkbox.
     */
    public void setIsActive(boolean active) {
        if (isActiveCheckbox.isSelected() != active) {
            isActiveCheckbox.click();
        }
    }

    /**
     * Click the Save button.
     */
    public void clickSave() {
        saveButton.click();
    }

    /**
     * Click the Cancel button.
     */
    public void clickCancel() {
        cancelButton.click();
    }
    public void fillDesignationForm(String designationName, boolean isActive) {
    	clickbuttonapproval();
        designationNameInput.clear();
        designationNameInput.sendKeys(designationName);

        if (isActiveCheckbox.isSelected() != isActive) {
            isActiveCheckbox.click();
        }

        saveButton.click();
    }
}
