package PharmacyPurchaseOrder;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class POTrackingPage extends Abstraction {

    private final String expectedUrl = "https://apps.ezovion.com/pages/pharmacy/po-tracking-report";

    @FindBy(xpath = "//div[@class='mat-select-arrow ng-tns-c363-148']")
    WebElement dropdownArrow;

    @FindBy(xpath = "(//mat-option[@role='option'])[2]")
    WebElement secondOption;

    @FindBy(xpath = "//table[contains(@class,'table-hover')]/tbody/tr")
    private List<WebElement> tableRows;
    
   

    @FindBy(xpath = "(//span[text()='Select'])[1]")
    WebElement selectDropdown;

    @FindBy(xpath = "(//span[text()='Pharamacy Loaction'])[1]")
    WebElement pharmacyLocation;

    public POTrackingPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    public void goexpectedUrl() {
   
        waitForUrl(expectedUrl);
        System.out.println("yes its found");
    }

    public boolean verifyPOTrackingLoaded() {
        String expectedUrl = "https://apps.ezovion.com/pages/pharmacy/po-tracking-report";

        for (int attempt = 1; attempt <= 5; attempt++) {
            try {
                // Wait for URL match
                waitForUrl(expectedUrl);

                // Wait for at least one row in the table to be visible
                waitForPresenceOfAll(By.xpath("//table[contains(@class,'table-hover')]/tbody/tr"));
                	System.out.println("success");
                return true; // ✅ Successfully verified
            } catch (Exception e) {
                System.out.println("⚠️ Attempt " + attempt + " failed: " + e.getMessage());

                if (attempt == 5) {
                    System.out.println("❌ PO Tracking page verification failed after 5 attempts.");
                    return false;
                }

                // Retry immediately without Thread.sleep
            }
        }

        return false;
    }

    

  
    public boolean isPONumberPresent(String targetPONumber) {
        boolean isSecondOptionClicked = false;

        for (int attempt = 0; attempt < 2; attempt++) {
            List<WebElement> rows = driver.findElements(By.xpath("//table[contains(@class,'table-hover')]/tbody/tr"));

            for (WebElement row : rows) {
                try {
                    String poNumber = row.findElement(By.xpath("./td[3]")).getText().trim();
                    System.out.println("🔍 Checking PO: " + poNumber);

                    if (poNumber.equalsIgnoreCase(targetPONumber)) {
                        System.out.println("✅ PO Number found: " + poNumber);

                        WebElement purchaseIcon = row.findElement(By.xpath(".//img[contains(@src,'phar.png')]"));

                        // Optional: Scroll into view if needed
                        // ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block: 'center'});", purchaseIcon);
                        waitForClickability(purchaseIcon).click();
               
                        System.out.println("✅ Clicked Purchase icon for PO No.: " + poNumber);
                        return true;
                    }
                } catch (Exception e) {
                    System.out.println("⚠️ Skipping row due to structure issue or missing data: " + e.getMessage());
                }
            }

            // Only click dropdown if not already done
            if (!isSecondOptionClicked) {
                try {
                    waitForClickability(dropdownArrow).click();
                    waitForClickability(secondOption).click();
                   // Add a short wait if data loads dynamically
                    isSecondOptionClicked = true;
                } catch (Exception e) {
                    System.out.println("⚠️ Failed to change dropdown filter: " + e.getMessage());
                    break;
                }
            }
        }

        System.out.println("❌ PO Number not found even after filtering: " + targetPONumber);
        return false;
    }


//    
//    public void clickPurchaseIconForPO(String targetPONumber) {
//        boolean found = false;
//        for (int attempt = 0; attempt < 2; attempt++) {
//        for (WebElement row : tableRows) {
//            try {
//                String poNumber = row.findElement(By.xpath("./td[3]")).getText().trim();
//                System.out.println(poNumber);
//
//                if (poNumber.equals(targetPONumber)) {
//                    WebElement purchaseIcon = row.findElement(By.xpath(".//img[contains(@src,'phar.png')]"));
//
//                js.executeScript("arguments[0].scrollIntoView({block: 'center'});", purchaseIcon);
//                    js.executeScript("arguments[0].click();", purchaseIcon);
//
//                    System.out.println("✅ Clicked Purchase icon for PO No.: " + poNumber);
//                    found = true;
//                    break;
//                }
//
//            } catch (NoSuchElementException e) {
//                System.out.println("⚠️ Skipping row due to structure issue.");
//            }
//        }
//
//        if (!found) {
//            System.out.println("❌ PO No. " + targetPONumber + " not found.");
//        }
//    }
    
    public PharmacyPoOrderPurchasePage selectPharmacyLocation() {
    	PharmacyPoOrderPurchasePage poOrderPage= new PharmacyPoOrderPurchasePage(driver);
    	return poOrderPage;
    }

    
}
