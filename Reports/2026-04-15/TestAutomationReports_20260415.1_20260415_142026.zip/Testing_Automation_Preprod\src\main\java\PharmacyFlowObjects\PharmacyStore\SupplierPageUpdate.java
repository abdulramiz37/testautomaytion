
package PharmacyFlowObjects.PharmacyStore;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class SupplierPageUpdate extends Abstraction {

    WebDriver driver;

    public SupplierPageUpdate(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // --------------------------- Supplier Information ---------------------------
    @FindBy(xpath = "//label[contains(text(),'Supplier Name')]/following-sibling::input")
    private WebElement supplierNameInput;

    @FindBy(xpath = "//label[contains(text(),'Supplier Type')]/following-sibling::ngx-select")
    private WebElement supplierTypeDropdown;

    @FindBy(xpath = "//label[contains(text(),'Credit Days')]/following-sibling::input")
    private WebElement creditDaysInput;

    @FindBy(xpath = "//label[contains(text(),'GSTN')]/following-sibling::input")
    private WebElement gstnInput;

    @FindBy(xpath = "//label[contains(text(),'Drug Licence No.')]/following-sibling::input")
    private WebElement drugLicenseInput;

    @FindBy(xpath = "//label[contains(text(),'PAN No')]/following-sibling::input")
    private WebElement panInput;

    // --------------------------- Contact Information ---------------------------
    @FindBy(xpath = "//label[contains(text(),'Mobile')]/following-sibling::input")
    private WebElement mobileInput;

    @FindBy(xpath = "//label[contains(text(),'Alternate Mobile')]/following-sibling::input")
    private WebElement alternateMobileInput;

    @FindBy(xpath = "//label[contains(text(),'Work phone')]/following-sibling::input")
    private WebElement workPhoneInput;

    @FindBy(xpath = "//label[contains(text(),'Email')]/following-sibling::input")
    private WebElement emailInput;

    @FindBy(xpath = "//label[contains(text(),'Door No / Street Name')]/following-sibling::input")
    private WebElement addressInput;

    @FindBy(xpath = "//label[contains(text(),'Area')]/following-sibling::input")
    private WebElement areaInput;

    @FindBy(xpath = "//label[contains(text(),'Pincode')]/following-sibling::input")
    private WebElement pincodeInput;

    @FindBy(xpath = "//label[contains(text(),'City')]/following-sibling::input")
    private WebElement cityInput;

    @FindBy(xpath = "//label[contains(text(),'Contact Name')]/following-sibling::input")
    private WebElement contactNameInput;

    @FindBy(xpath = "//label[contains(text(),'District')]/following-sibling::ngx-select")
    private WebElement districtDropdown;

    @FindBy(xpath = "//label[contains(text(),'State')]/following-sibling::ngx-select")
    private WebElement stateDropdown;

    @FindBy(xpath = "//label[contains(text(),'Country')]/following-sibling::ngx-select")
    private WebElement countryDropdown;

    // --------------------------- Bank Information ---------------------------
    @FindBy(xpath = "//label[contains(text(),'Bank Name')]/following-sibling::input")
    private WebElement bankNameInput;

    @FindBy(xpath = "//label[contains(text(),'IFSC')]/following-sibling::input")
    private WebElement ifscInput;

    @FindBy(xpath = "//label[contains(text(),'Account Number')]/following-sibling::input")
    private WebElement accountNumberInput;

    @FindBy(xpath = "//label[contains(text(),'Branch Name')]/following-sibling::input")
    private WebElement branchNameInput;

    // --------------------------- Checkbox ---------------------------
    @FindBy(xpath = "//label[contains(text(),'IsActive')]/input")
    private WebElement isActiveCheckbox;

    // --------------------------- Methods ---------------------------

    // Supplier Information
    @FindBy(xpath = "//a[text()=' Supplier']")
    private WebElement supplierTab;

    @FindBy(xpath = "(//a[@role='button'])[1]")
    private WebElement expandFirstButton;

    // --------------------------- Getters / Actions ---------------------------

    public void enterSupplierInfo(String name) {
    	supplierTab.click();
    	expandFirstButton.click();

        supplierNameInput.clear();
        supplierNameInput.sendKeys(name);
    }

    public void selectSupplierType(String type) {
        selectDropdownOption(supplierTypeDropdown, type);
    }

    public void enterCreditDays(String days) {
        creditDaysInput.clear();
        creditDaysInput.sendKeys(days);
    }

    public void enterGSTN(String gstn) {
        gstnInput.clear();
        gstnInput.sendKeys(gstn);
    }

    public void enterDrugLicense(String license) {
        drugLicenseInput.clear();
        drugLicenseInput.sendKeys(license);
    }

    public void enterPAN(String pan) {
        panInput.clear();
        panInput.sendKeys(pan);
    }

    // Contact Information
    public void enterMobile(String mobile) {
        mobileInput.clear();
        mobileInput.sendKeys(mobile);
    }

    public void enterAlternateMobile(String altMobile) {
        alternateMobileInput.clear();
        alternateMobileInput.sendKeys(altMobile);
    }

    public void enterWorkPhone(String workPhone) {
        workPhoneInput.clear();
        workPhoneInput.sendKeys(workPhone);
    }

    public void enterEmail(String email) {
        emailInput.clear();
        emailInput.sendKeys(email);
    }

    public void enterAddress(String address) {
        addressInput.clear();
        addressInput.sendKeys(address);
    }

    public void enterArea(String area) {
        areaInput.clear();
        areaInput.sendKeys(area);
    }

    public void enterPincode(String pincode) {
        pincodeInput.clear();
        pincodeInput.sendKeys(pincode);
    }

    public void enterCity(String city) {
        cityInput.clear();
        cityInput.sendKeys(city);
    }

    public void enterContactName(String contactName) {
        contactNameInput.clear();
        contactNameInput.sendKeys(contactName);
    }

    public void selectDistrict(String district) {
        selectDropdownOption(districtDropdown, district);
    }

    public void selectState(String state) {
        selectDropdownOption(stateDropdown, state);
    }

    public void selectCountry(String country) {
        selectDropdownOption(countryDropdown, country);
    }

    // Bank Information
    public void enterBankName(String bank) {
        bankNameInput.clear();
        bankNameInput.sendKeys(bank);
    }

    public void enterIFSC(String ifsc) {
        ifscInput.clear();
        ifscInput.sendKeys(ifsc);
    }

    public void enterAccountNumber(String accountNumber) {
        accountNumberInput.clear();
        accountNumberInput.sendKeys(accountNumber);
    }

    public void enterBranchName(String branch) {
        branchNameInput.clear();
        branchNameInput.sendKeys(branch);
    }
    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;
    // Checkbox
    public void toggleIsActive(boolean status) {
        if (isActiveCheckbox.isEnabled()) {
            if (isActiveCheckbox.isSelected() != status) {
                isActiveCheckbox.click();
            }
        }
    }
    public void clickSave() {
        waitForClickability(saveButton).click();
    }
    // --------------------------- Helper for ngx-select ---------------------------
    private void selectDropdownOption(WebElement dropdown, String optionText) {
        dropdown.click(); // open the dropdown

        // Wait a bit for dropdown to render (optional, can use WebDriverWait)
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices') and contains(@class,'show')]//span[text()='" + optionText + "']"
        ));
        option.click();
    }

}
