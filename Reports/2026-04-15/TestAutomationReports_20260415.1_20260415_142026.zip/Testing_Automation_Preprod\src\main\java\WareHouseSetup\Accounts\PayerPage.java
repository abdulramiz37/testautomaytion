package WareHouseSetup.Accounts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import EzionAbstractionComponents.Abstraction;

public class PayerPage extends Abstraction {

    public PayerPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//div[@class=\"ngx-select__toggle btn form-control\"]")
    private WebElement typeDropdown;

    @FindBy(xpath = "//input[@formcontrolname='typeName']")
    private WebElement payerNameField;

    @FindBy(xpath = "(//div[contains(@class, 'ngx-select__toggle') and contains(@class, 'form-control')])[2]")
                   
    private WebElement ownershipTypeDropdown;

    @FindBy(xpath = "//input[@formcontrolname='workPhone']")
    private WebElement workPhoneField;

    @FindBy(xpath = "//input[@formcontrolname='officeEmail']")
    private WebElement officeEmailField;

    @FindBy(xpath = "//input[@formcontrolname='website']")
    private WebElement websiteField;

    @FindBy(xpath = "//input[@formcontrolname='contactName']")
    private WebElement contactNameField;

    @FindBy(xpath = "//input[@formcontrolname='contactmobile']")
    private WebElement mobileField;

    @FindBy(xpath = "//input[@formcontrolname='contactAltrMobile']")
    private WebElement alternateMobileField;

    @FindBy(xpath = "//input[@formcontrolname='contactEmail']")
    private WebElement contactEmailField;

    @FindBy(xpath = "//textarea[@formcontrolname='address']")
    private WebElement addressField;

    @FindBy(xpath = "//input[@formcontrolname='creditDays']")
    private WebElement creditDaysField;

    @FindBy(xpath = "//input[@formcontrolname='tax']")
    private WebElement gstField;

    @FindBy(xpath = "//input[@formcontrolname='tds']")
    private WebElement tdsField;

    @FindBy(xpath = "//ngx-select[@formcontrolname='settlementCategory']")
    private WebElement settlementCategoryDropdown;

    @FindBy(xpath = "//label[contains(text(),'Active')]")
    private WebElement activeCheckbox;

    @FindBy(xpath = "//label[contains(text(),'Variable Price')]")
    private WebElement variablePriceCheckbox;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;
    
    @FindBy(xpath = "//a[text()=' Payer ']")
    private WebElement userType;

    @FindBy(xpath = "//a[text()=' Add Payer ']")
    private WebElement adduserType;
     
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}
    
    public void selectFromDropdownByVisibleText(WebElement dropdownElement, String visibleText) {
        Select select = new Select(dropdownElement);
        select.selectByVisibleText(visibleText);
    }

    // ---- Reusable Form Actions ----
    public void selectType(String typeOption) {
    	typeDropdown.click();
        WebElement option = driver.findElement(By.xpath("//ul[@role='menu']//span[normalize-space()='" + typeOption + "']"));
        option.click();
    }
    public void selectType2(String typeOption) {
    	ownershipTypeDropdown.click();
        WebElement option = driver.findElement(By.xpath("//ul[@role='menu']//span[normalize-space()='" + typeOption + "']"));
        option.click();
    }

    public void selectType3(String typeOption) {
    	settlementCategoryDropdown.click();
        WebElement option = driver.findElement(By.xpath("//ul[@role='menu']//span[normalize-space()='" + typeOption + "']"));
        option.click();
    }
    public void enterPayerName(String payerName) {
        payerNameField.clear();
        payerNameField.sendKeys(payerName);
    }



    public void enterWorkPhone(String workPhone) {
        workPhoneField.clear();
        workPhoneField.sendKeys(workPhone);
    }

    public void enterOfficeEmail(String officeEmail) {
        officeEmailField.clear();
        officeEmailField.sendKeys(officeEmail);
    }

    public void enterWebsite(String website) {
        websiteField.clear();
        websiteField.sendKeys(website);
    }

    public void enterContactName(String contactName) {
        contactNameField.clear();
        contactNameField.sendKeys(contactName);
    }

    public void enterMobile(String mobile) {
        mobileField.clear();
        mobileField.sendKeys(mobile);
    }

    public void enterAlternateMobile(String alternateMobile) {
        alternateMobileField.clear();
        alternateMobileField.sendKeys(alternateMobile);
    }

    public void enterContactEmail(String contactEmail) {
        contactEmailField.clear();
        contactEmailField.sendKeys(contactEmail);
    }

    public void enterAddress(String address) {
        addressField.clear();
        addressField.sendKeys(address);
    }

    public void enterCreditDays(String creditDays) {
        creditDaysField.clear();
        creditDaysField.sendKeys(creditDays);
    }

    public void enterGST(String gst) {
        gstField.clear();
        gstField.sendKeys(gst);
    }

    public void enterTDS(String tds) {
        tdsField.clear();
        tdsField.sendKeys(tds);
    }



    public void toggleActiveCheckbox(boolean shouldBeChecked) {
        if (activeCheckbox.isSelected() != shouldBeChecked) {
            activeCheckbox.click();
        }
    }

    public void toggleVariablePrice(boolean shouldBeChecked) {
        if (variablePriceCheckbox.isSelected() != shouldBeChecked) {
            variablePriceCheckbox.click();
        }
    }

    public void clickSave() {
        waitForClickability(saveButton).click();
    }

    // ---- Fill the Entire Form in One Go ----
    public void fillForm(
        String type,
        String payerName,
        String ownershipType,
        String workPhone,
        String officeEmail,
        String website,
        String contactName,
        String mobile,
        String alternateMobile,
        String contactEmail,
        String address,
        String creditDays,
        String gst,
        String tds,
        String settlementCategory,
        boolean isActive,
        boolean isVariablePrice
    ) {
    	clickbuttonapproval();
        selectType(type);
        enterPayerName(payerName);
        selectType2(ownershipType);
        enterWorkPhone(workPhone);
        enterOfficeEmail(officeEmail);
        enterWebsite(website);
        enterContactName(contactName);
        enterMobile(mobile);
        enterAlternateMobile(alternateMobile);
        enterContactEmail(contactEmail);
        enterAddress(address);
        enterCreditDays(creditDays);
        enterGST(gst);
        enterTDS(tds);
        selectType3(settlementCategory);
        toggleActiveCheckbox(isActive);
        toggleVariablePrice(isVariablePrice);
    }
}
