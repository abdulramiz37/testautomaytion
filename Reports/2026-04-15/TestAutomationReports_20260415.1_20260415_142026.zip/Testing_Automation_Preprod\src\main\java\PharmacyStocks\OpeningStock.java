package PharmacyStocks;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class OpeningStock extends Abstraction {

    public OpeningStock(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    // --- Page Elements ---

    @FindBy(xpath = "//a[@title='Pharmacy']")
    private WebElement pharmacyMenu;

    @FindBy(xpath = "(//a[@title='Stock'])[1]")
    private WebElement stockMenu;

    @FindBy(xpath = "(//a[@title='Opening Stock'])[1]")
    private WebElement openingStockMenu;

    @FindBy(xpath = "//a[text()='Add Opening Stock']")
    private WebElement addOpeningStockBtn;

    @FindBy(xpath = "(//span[text()='Select'])[1]")
    private WebElement firstSelectDropdown;

    @FindBy(xpath = "//input[@placeholder='Select']")
    private WebElement Select;
    // For the second "Select " (supplier) dropdown: use helper
    // WebElement visibility and clicks for form fields:
    @FindBy(xpath = "//input[@formcontrolname='batchNumber']")
    private WebElement batchNumberInput;

    @FindBy(xpath = "//input[@formcontrolname='expiryDate']")
    private WebElement expiryDateInput;

    @FindBy(xpath = "//input[@formcontrolname='pricePerStrips']")
    private WebElement pricePerStripsInput;

    @FindBy(xpath = "//input[@formcontrolname='mrpPerStrip']")
    private WebElement mrpPerStripInput;

    @FindBy(xpath = "//input[@formcontrolname='sellPriceStrip']")
    private WebElement sellPriceStripInput;

    @FindBy(xpath = "//input[@formcontrolname='qtyInStrips']")
    private WebElement qtyInStripsInput;

    @FindBy(xpath = "//input[@formcontrolname='qtyInUnits']")
    private WebElement qtyInUnitsInput;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//span[text()='Low Stock List']")
    private WebElement LowStockBtn;
    
    @FindBy(xpath = "//span[text()='Excess Stock List']")
    private WebElement ExcessStockBtn;
    
    
    @FindBy(xpath = "//ngx-validation-message[@label='Cost Price']//p")
    WebElement costPriceError;

    public String getCostPriceError() {
        waitForVisibility(costPriceError); // Optional helper
        return costPriceError.getText().trim();
    }

    
    @FindBy(xpath = "//ngx-validation-message[@label='MRP Price']//p")
    WebElement mrpPriceError;

    public String getMrpPriceError() {
        waitForVisibility(mrpPriceError);
        return mrpPriceError.getText().trim();
    }

    @FindBy(xpath = "//ngx-validation-message[@label='Sell Price']//p")
    WebElement sellPriceError;

    public String getSellPriceError() {
        waitForVisibility(sellPriceError);
        return sellPriceError.getText().trim();
    }

    @FindBy(xpath = "//ngx-validation-message[@label='Qty In Strips']//p")
    WebElement qtyInStripsError;

    public String getQtyInStripsError() {
        waitForVisibility(qtyInStripsError);
        return qtyInStripsError.getText().trim();
    }
    
    @FindBy(xpath = "//ngx-validation-message[@label='Qty In Units']//p")
    WebElement qtyInUnitsError;

    public String getQtyInUnitsError() {
        waitForVisibility(qtyInUnitsError);
        return qtyInUnitsError.getText().trim();
    }


    @FindBy(xpath = "//input[@value='Search']")
    private WebElement searchButton;
    // --- Helper: build By for span text (normalize-space) ---
    private By getSpanByText(String text) {
        // normalize-space to ignore extra whitespace
        return By.xpath("//span[normalize-space(text())='" + text + "']");
    }

    @FindBy(xpath = "//div[contains(@class, 'ngx-select__toggle')]")
    WebElement dropdownToggle;

    public void selectDropdownOption(String optionText) {
        WebElement option = driver.findElement(By.xpath("//ul[contains(@class, 'ngx-select__choices')]//a[contains(@class,'ngx-select__item')]/span[normalize-space(text())='" + optionText + "']"));
        option.click();
    }

public void StockMenu() {
	   waitForClickability(pharmacyMenu).click();
       waitForClickability(stockMenu).click();
}
    public void addOpeningStock(String location,
                                String supplierName,
                                String batchNumber,
                                String expiryMonthYear,
                                String pricePerStrips,
                                String mrpPerStrip,
                                String sellPriceStrip,
                                String qtyInStrips,
                                String qtyInUnits) {

        // Navigate menus
        waitForClickability(pharmacyMenu).click();
        waitForClickability(stockMenu).click();
        waitForClickability(openingStockMenu).click();
        waitForClickability(addOpeningStockBtn).click();

        // Select location (first dropdown)
        waitForClickability(firstSelectDropdown).click();
        waitForClickability(getSpanByText(location)).click();

        // Select supplier (second dropdown). Assuming the next dropdown also uses a "Select " span:
        // Click the next select dropdown: often same locator text "(//span[text()='Select '])[?]"
        // We locate it by visible text "Select " or via known position:
        waitForClickability(By.xpath("//span[text()='Select ']")).click();
        waitForClickability(getSpanByText(supplierName)).click();

        // Fill stock details:
        waitForVisibility(batchNumberInput).sendKeys(batchNumber);

        // Set expiry date via JS to format yyyy-MM
        WebElement expiryElem = waitForVisibility(expiryDateInput);
        js.executeScript(
            "arguments[0].value='" + expiryMonthYear + "'; arguments[0].dispatchEvent(new Event('input'));",
            expiryElem);

        waitForVisibility(pricePerStripsInput).sendKeys(pricePerStrips);
        waitForVisibility(mrpPerStripInput).sendKeys(mrpPerStrip);
        waitForVisibility(sellPriceStripInput).sendKeys(sellPriceStrip);
        waitForVisibility(qtyInStripsInput).sendKeys(qtyInStrips);
        waitForVisibility(qtyInUnitsInput).sendKeys(qtyInUnits);

        // Click Save
        WebElement saveBtn = waitForClickability(saveButton);
        js.executeScript("arguments[0].click();", saveBtn);
        
    
    }
    
    public void lowStock(String uniqueName) {
        waitForClickability(LowStockBtn).click();
        waitForClickability(dropdownToggle).click();
        selectDropdownOption(uniqueName);
        waitForClickability(searchButton).click();
        
    }
    public void checker(String uniqueName) {
        waitForClickability(LowStockBtn).click();
        waitForClickability(dropdownToggle).click();
        waitForClickability(Select).sendKeys(uniqueName);
//        waitForClickability(searchButton).click();
        
    }
    public void highStock(String uniqueName) {
    	waitForClickability(ExcessStockBtn).click();
        waitForClickability(dropdownToggle).click();
        selectDropdownOption(uniqueName);
        waitForClickability(searchButton).click();
    }
}
