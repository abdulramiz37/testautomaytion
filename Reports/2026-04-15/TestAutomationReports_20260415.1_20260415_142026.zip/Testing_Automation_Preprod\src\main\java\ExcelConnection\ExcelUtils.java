package ExcelConnection;



	import java.io.File;
	import java.io.FileInputStream;
	import java.util.ArrayList;
	import java.util.HashMap;
	import java.util.List;

	import org.apache.poi.ss.usermodel.*;

	public class ExcelUtils {

	    public static List<HashMap<String, String>> getExcelData(String filePath, String sheetName) throws Exception {
	        FileInputStream file = new FileInputStream(new File(filePath));
	        Workbook workbook = WorkbookFactory.create(file);
	        Sheet sheet = workbook.getSheet(sheetName);

	        List<HashMap<String, String>> allData = new ArrayList<>();
	        Row headerRow = sheet.getRow(0);
	        int rowCount = sheet.getPhysicalNumberOfRows();
	        int colCount = headerRow.getPhysicalNumberOfCells();

	        for (int i = 1; i < rowCount; i++) {
	            Row row = sheet.getRow(i);
	            HashMap<String, String> rowData = new HashMap<>();
	            for (int j = 0; j < colCount; j++) {
	                Cell cell = row.getCell(j);
	                String cellValue = (cell == null) ? "" : cell.toString();
	                rowData.put(headerRow.getCell(j).toString(), cellValue);
	            }
	            allData.add(rowData);
	        }

	        workbook.close();
	        file.close();
	        return allData;
	    }
	}


