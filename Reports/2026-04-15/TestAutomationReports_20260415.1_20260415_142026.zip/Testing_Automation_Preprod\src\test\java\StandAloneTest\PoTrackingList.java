package StandAloneTest;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
@Test
public class PoTrackingList {
	public void PPLE() throws InterruptedException {

	WebDriver driver = new EdgeDriver();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	driver.get("https://apps.ezovion.com/auth/login");
	//driver.manage().deleteAllCookies();
	driver.manage().window().maximize();
	

	driver.findElement(By.xpath("//div[@class=\"form-control-group\"]//input")).sendKeys("50107299");
	driver.findElement(By.xpath("//button[@size=\"large\"]")).click();
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
        // Wait until the button with text "CONTINUE" is clickable
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
	
     driver.findElement(By.xpath("//input[@placeholder=\"Mobile No\"]")).sendKeys("7766554433");
	driver.findElement(By.xpath("//input[@placeholder=\"Password\"]")).sendKeys("12345");
	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@status=\"primary\"]")));
	 Thread.sleep(2000);
	 driver.findElement(By.xpath("//button[@status=\"primary\"]")).click();
	 for (int i = 0; i < 5; i++) { // Try up to 5 times
		    try {
		        
		        Thread.sleep(3000); // wait for any transition

		        WebElement adminTab = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Admin']")));
		        adminTab.click();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Roles Management']"))).click();
		        break; // Exit loop if successful
		    } catch (Exception e) {
		        System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
		        if (i == 4) {
		            throw e; // Re-throw if max attempts reached
		        }
		    }
		}

	// 1. Click on "Pharmacy"
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Pharmacy']"))).click();
	 
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Purchase'])[1]"))).click();

		// 2. Click on "Purchase Order"
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='PO Tracking List'])[1]"))).click();
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class=\"mat-select-arrow ng-tns-c363-144\"]"))).click();
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//mat-option[@role=\"option\"])[2]"))).click();
	 String targetPONumber = "54";  // Replace with the PO number you want to match

	 List<WebElement> rows = driver.findElements(By.xpath("//table[contains(@class,'table-hover')]/tbody/tr"));

	 boolean found = false;

	 for (WebElement row : rows) {
	     try {
	         String poNumber = row.findElement(By.xpath("./td[3]")).getText().trim(); // 3rd <td> is PO No.
System.out.println(poNumber);
	         if (poNumber.equals(targetPONumber)) {
	             WebElement purchaseIcon = row.findElement(By.xpath(".//img[contains(@src,'phar.png')]"));

	             // Optional scroll and click with JS
	             JavascriptExecutor js = (JavascriptExecutor) driver;
	             js.executeScript("arguments[0].scrollIntoView({block: 'center'});", purchaseIcon);
	             js.executeScript("arguments[0].click();", purchaseIcon);

	             System.out.println("✅ Clicked Purchase icon for PO No.: " + poNumber);
	             found = true;
	             break;
	         }

	     } catch (NoSuchElementException e) {
	         System.out.println("⚠️ Skipping row due to structure issue.");
	     }
	 }

	 if (!found) {
	     System.out.println("❌ PO No. " + targetPONumber + " not found.");
	 }
	//div[@class="mat-select-arrow ng-tns-c363-144"]
      wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();
     wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Pharamacy Loaction'])[1]"))).click();

	 int invoiceNo = 1;

     while (true) {
         driver.findElement(By.xpath("//input[@formcontrolname='invNo']")).clear();
         driver.findElement(By.xpath("//input[@formcontrolname='invNo']")).sendKeys(String.valueOf(invoiceNo));
         Thread.sleep(2000); // Wait for validation to appear

         if (driver.findElements(By.xpath("//*[contains(text(), 'Invoice No Already Exists')]")).isEmpty()) {
             System.out.println("✅ Unique Invoice No: " + invoiceNo);
             break; // Stop loop when number is accepted
         }

         invoiceNo++; // Try next number
     }

    

     WebElement invDate = wait.until(ExpectedConditions.visibilityOfElementLocated(
             By.xpath("//input[@formcontrolname='invDate']")));
     ((JavascriptExecutor) driver).executeScript(
             "arguments[0].value='06/12/2025'; arguments[0].dispatchEvent(new Event('input'));", invDate);

     WebElement invDueDate = wait.until(ExpectedConditions.visibilityOfElementLocated(
             By.xpath("//input[@formcontrolname='invDueDate']")));
     ((JavascriptExecutor) driver).executeScript(
             "arguments[0].value='06/12/2025'; arguments[0].dispatchEvent(new Event('input'));", invDueDate);

     wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Search'])[1]"))).click();
     WebElement syrupItem = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='mat-option-text']/span[contains(text(), 'medicine')]")));
     JavascriptExecutor js = (JavascriptExecutor) driver;
     js.executeScript("arguments[0].click();", syrupItem);
     


     Thread.sleep(2000); // Suggest replacing with a wait on visibility or condition
     WebElement batchNumberField = wait.until(ExpectedConditions.visibilityOfElementLocated(
             By.xpath("//input[@formcontrolname='BatchNumber']")));
     batchNumberField.sendKeys("4");
     Thread.sleep(2000);

     WebElement expiryDateInput = wait.until(ExpectedConditions.visibilityOfElementLocated(
             By.xpath("//input[@formcontrolname='expiryDate']")));
     ((JavascriptExecutor) driver).executeScript(
             "const input = arguments[0];" +
                     "const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;" +
                     "nativeInputValueSetter.call(input, '2027-07');" +
                     "input.dispatchEvent(new Event('input', { bubbles: true }));" +
                     "input.dispatchEvent(new Event('change', { bubbles: true }));",
             expiryDateInput);
     Thread.sleep(2000);

//     wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='noOfStrips']"))).sendKeys("4");
//     wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='freeStrips']"))).sendKeys("5");
//     wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='mrpPerStrip']"))).sendKeys("25");
//     wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='pricePerStrip']"))).sendKeys("25");

     // You can uncomment and use the below when you're ready to perform final submission
//      wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='sellPrice']"))).sendKeys("45");
     
      
      String payableAmtElement =  driver.findElement(By.xpath("//label[text()='Payable Amt']/following-sibling::p")).getText().trim();
      wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@formcontrolname='invValue'])[1]"))).sendKeys(payableAmtElement);
      wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Add']"))).click();
      wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();
      wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value=\"Yes\"]"))).click();
      wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value=\"Approve\"]"))).click();
	}
}
