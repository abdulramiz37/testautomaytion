 package PharmacyFlowObjects.PharmacyStore;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.*;

import EzionAbstractionComponents.Abstraction;

public class HMSLocationPage extends Abstraction {

    WebDriver driver;
 

    public HMSLocationPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
   
    }

    // WebElements using PageFactory
    @FindBy(xpath = "//a[text()=' HMS Location ']")
    private WebElement hmsLocationTab;

    @FindBy(xpath = "//a[text()=' Add Hospital Location']")
    private WebElement addHospitalLocationBtn;

    @FindBy(xpath = "//input[@formcontrolname='locationName']")
    private WebElement locationNameInput;

    @FindBy(xpath = "//input[@formcontrolname='mobile']")
    private WebElement mobileInput;

    @FindBy(xpath = "//input[@formcontrolname='email']")
    private WebElement emailInput;

    @FindBy(xpath = "(//span[@class='checkmark'])[2]")
    private WebElement checkboxSecondOption;

    @FindBy(xpath = "(//span[@class='checkmark'])[1]")
    private WebElement checkboxFirstOption;
    
    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveBtn;

    @FindBy(xpath = "//span[contains(text(),'Name Already Exists..')]")
    private WebElement errorMessage;
    
 // ---------- Communication Address Fields ----------

    @FindBy(xpath = "//input[@formcontrolname='doorNo']")
    private WebElement doorNoInput;

    @FindBy(xpath = "//input[@formcontrolname='address1']")
    private WebElement address1Input;

    @FindBy(xpath = "//input[@formcontrolname='address2']")
    private WebElement address2Input;

    @FindBy(xpath = "//input[@formcontrolname='city']")
    private WebElement cityInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='district']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement districtDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='state']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement stateDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='country']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement countryDropdown;

    @FindBy(xpath = "//input[@formcontrolname='landmark']")
    private WebElement landmarkInput;

    @FindBy(xpath = "//input[@formcontrolname='pincode']")
    private WebElement pincodeInput;

 // ---------- Report Details Fields ----------

    @FindBy(xpath = "//input[@formcontrolname='reportLine1']")
    private WebElement reportLine1Input;

    @FindBy(xpath = "//input[@formcontrolname='reportLine2']")
    private WebElement reportLine2Input;

    @FindBy(xpath = "//input[@formcontrolname='reportLine3']")
    private WebElement reportLine3Input;

    @FindBy(xpath = "//input[@formcontrolname='reportLine4']")
    private WebElement reportLine4Input;

    @FindBy(xpath = "//input[@formcontrolname='reportLine5']")
    private WebElement reportLine5Input;

    @FindBy(xpath = "//input[@formcontrolname='reportMessage']")
    private WebElement reportMessageInput;
 
    // ---------- Actions ----------
    public void selectWarehouseCommunication(String name) {
        String xpath = String.format("//a[contains(@class,'ngx-select__item')]//span[normalize-space(text())='%s']", name);
        WebElement option = waitForClickability(By.xpath(xpath));
        option.click();
    }
    public String duplicateErrorMessage() {
    	return errorMessage.getText();
    }
    
    public void checkMarkDefault() {
    	selectSecondCheckboxOption();
    }
    
    public void checkMarkLocation() {
    	selectfirstCheckboxOption();
    }
    public void clickHMSLocationTab() {
    	waitForVisibility(hmsLocationTab).click();
    }

    public void clickAddHospitalLocation() {
    	waitForVisibility(addHospitalLocationBtn).click();
    }

    public void enterLocationName(String name) {
    	waitForVisibility(locationNameInput).sendKeys(name);
    

        
    }

    public void enterMobileNumber(String mobile) {
    	waitForVisibility(mobileInput).sendKeys(mobile);
    }

    public void enterEmail(String email) {
    	waitForVisibility(emailInput).sendKeys(email);
    }

    public void selectSecondCheckboxOption() {
    	waitForVisibility(checkboxSecondOption).click();
    }
    public void selectfirstCheckboxOption() {
    	waitForVisibility(checkboxFirstOption).click();
    }
    public void clickSave() {
    	waitForVisibility(saveBtn).click();
    }
    public void enterDoorNo(String value) {
        waitForVisibility(doorNoInput).clear();
        doorNoInput.sendKeys(value);
    }

    public void enterAddress1(String value) {
        waitForVisibility(address1Input).clear();
        address1Input.sendKeys(value);
    }

    public void enterAddress2(String value) {
        waitForVisibility(address2Input).clear();
        address2Input.sendKeys(value);
    }

    public void enterCity(String value) {
        waitForVisibility(cityInput).clear();
        cityInput.sendKeys(value);
    }

    public void openDistrictDropdown() {
        waitForClickability(districtDropdown).click();
    }

  

    public void selectDistrict(String district) {
        openDistrictDropdown();
        selectWarehouseCommunication(district);
    }

   

    public void enterLandmark(String value) {
        waitForVisibility(landmarkInput).clear();
        landmarkInput.sendKeys(value);
    }

    public void enterPincode(String value) {
        waitForVisibility(pincodeInput).clear();
        pincodeInput.sendKeys(value);
    }
    
    public void enterReportLine1(String line1) {
        waitForVisibility(reportLine1Input).clear();
        reportLine1Input.sendKeys(line1);
    }

    public void enterReportLine2(String line2) {
        waitForVisibility(reportLine2Input).clear();
        reportLine2Input.sendKeys(line2);
    }

    public void enterReportLine3(String line3) {
        waitForVisibility(reportLine3Input).clear();
        reportLine3Input.sendKeys(line3);
    }

    public void enterReportLine4(String line4) {
        waitForVisibility(reportLine4Input).clear();
        reportLine4Input.sendKeys(line4);
    }

    public void enterReportLine5(String line5) {
        waitForVisibility(reportLine5Input).clear();
        reportLine5Input.sendKeys(line5);
    }

    public void enterReportMessage(String message) {
        waitForVisibility(reportMessageInput).clear();
        reportMessageInput.sendKeys(message);
    }

    // Combined action for test
    public void addHospitalLocation(String name, String mobile, String email) {
        clickHMSLocationTab();
        clickAddHospitalLocation();
        enterLocationName(name);
        enterMobileNumber(mobile);
        enterEmail(email);
        
       
    }
    
    public void fillCommunicationAddress(String doorNo, String addr1, String addr2, String city,
            String district,
            String landmark, String pincode) {
enterDoorNo(doorNo);
enterAddress1(addr1);
enterAddress2(addr2);
enterCity(city);
selectDistrict(district);
enterLandmark(landmark);
enterPincode(pincode);
}

    public void enterReportDetails(String line1, String line2, String line3, String line4, String line5, String message) {
        enterReportLine1(line1);
        enterReportLine2(line2);
        enterReportLine3(line3);
        enterReportLine4(line4);
        enterReportLine5(line5);
        enterReportMessage(message);
    }
    
    public void save1() {
    	   clickSave();
    }
    
    public PharmacyDashBoardPage save() {
    	   clickSave();
  	  waitForPharmacyPageWithBackClick();
  	  PharmacyDashBoardPage pharmacyDashboard= new PharmacyDashBoardPage(driver);
  	  return pharmacyDashboard;
  }
    
    @FindBy(xpath = "//p[contains(text(),'Incorrect Name')]")
    private WebElement incorrectNameMessage;

    public String getIncorrectNameMessage() {
        return waitForVisibility(incorrectNameMessage).getText();
    }

    @FindBy(xpath = "//p[contains(text(),'Incorrect Mobile No')]")
    private WebElement incorrectMobileMessage;

    public String getIncorrectMobileMessage() {
        return waitForVisibility(incorrectMobileMessage).getText();
    }

    @FindBy(xpath = "//p[contains(text(),'Incorrect Email')]")
    private WebElement incorrectEmailMessage;

    public String getIncorrectEmailMessage() {
        return waitForVisibility(incorrectEmailMessage).getText();
    }

    @FindBy(xpath = "//p[contains(text(),'Incorrect City')]")
    private WebElement incorrectCityMessage;

    public String getIncorrectCityMessage() {
        return waitForVisibility(incorrectCityMessage).getText();
    }

    @FindBy(xpath = "//p[contains(text(),'Incorrect Pincode')]")
    private WebElement incorrectPincodeMessage;

    public String getIncorrectPincodeMessage() {
        return waitForVisibility(incorrectPincodeMessage).getText();
    }

    @FindBy(xpath = "//p[contains(text(),'Incorrect Report Line1')]")
    private WebElement incorrectReportLine1Message;

    public String getIncorrectReportLine1Message() {
        return waitForVisibility(incorrectReportLine1Message).getText();
    }
}
