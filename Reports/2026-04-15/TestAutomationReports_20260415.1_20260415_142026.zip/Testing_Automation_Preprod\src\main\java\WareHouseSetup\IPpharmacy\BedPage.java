package WareHouseSetup.IPpharmacy;

import java.util.Random;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class BedPage extends Abstraction {

    private WebDriver driver;

    public BedPage(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // -------------------- LOCATORS --------------------

    @FindBy(xpath = "//label[text()=' Bed Category ']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement bedCategoryDropdown;

    @FindBy(xpath = "//label[text()=' Building Name ']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement buildingNameDropdown;

    @FindBy(xpath = "//label[text()=' Floor Name ']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement floorNameDropdown;

    @FindBy(xpath = "//label[text()=' Room Number ']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement roomNumberDropdown;

    @FindBy(xpath = "//label[text()=' Ward ']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement wardDropdown;

    @FindBy(xpath = "//label[text()=' Nursing Counter Name ']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement nursingCounterDropdown;


    @FindBy(xpath = "//input[@formcontrolname='bedNo']")
    private WebElement bedNumberInput;

    @FindBy(xpath = "//input[@formcontrolname='isActive']")
    private WebElement isActiveCheckbox;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//input[@value='Cancel']")
    private WebElement cancelButton;

    // -------------------- METHODS --------------------
    @FindBy(xpath = "//a[text()=' Bed']")
    private WebElement userType;
  
    @FindBy(xpath = "//a[text()=' Add Bed ']")
    private WebElement adduserType;
    
    @FindBy(xpath = "//p[text()='Bed List']")
    private WebElement addbedlist;
    // 🔹 Methods
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(addbedlist).click();
		waitForClickability(adduserType).click();
	}
    public void selectBedCategory(String category) {
        bedCategoryDropdown.click();
        WebElement option = driver.findElement(By.xpath("//ul[@role='menu']//span[normalize-space()='" + category + "']"));
        option.click();
    }

    public void selectBuilding(String building) {
        buildingNameDropdown.click();
        WebElement option = driver.findElement(By.xpath("//ul[@role='menu']//span[normalize-space()='" + building + "']"));
        option.click();
    }

    public void selectFloor(String floor) {
        floorNameDropdown.click();
        WebElement option = driver.findElement(By.xpath("//ul[@role='menu']//span[normalize-space()='" + floor + "']"));
        option.click();
    }

    public void selectRoom(String room) {
        roomNumberDropdown.click();
        WebElement option = driver.findElement(By.xpath("//ul[@role='menu']//span[normalize-space()='" + room + "']"));
        option.click();
    }

    public void selectWard(String ward) {
        wardDropdown.click();
        WebElement option = driver.findElement(By.xpath("//ul[@role='menu']//span[normalize-space()='" + ward + "']"));
        option.click();
    }

    public void selectNursingCounter(String nursingCounter) {
        nursingCounterDropdown.click();
        WebElement option = driver.findElement(By.xpath("//ul[@role='menu']//span[normalize-space()='" + nursingCounter + "']"));
        option.click();
    }
    public String lastEnteredbedNumber;
    public void enterBedNumber(String bedNumber) {
        if (bedNumber == null || bedNumber.isEmpty()) {
            bedNumber = generateRandomBedNumber();
        }
        lastEnteredbedNumber=bedNumber;
        waitForVisibility(bedNumberInput).clear();
        bedNumberInput.sendKeys(bedNumber);
    }

    private String generateRandomBedNumber() {
        Random random = new Random();
        // Generate a random bed number like "B123" or "BED45"
        String prefix = "Bed";
        int number = 100 + random.nextInt(900); // random 3-digit number between 100–999
        return prefix + number;
    }


    public void setIsActive(boolean active) {
        if (isActiveCheckbox.isSelected() != active) {
            isActiveCheckbox.click();
        }
    }

    public void clickSave() {
        saveButton.click();
    }

    public void clickCancel() {
        cancelButton.click();
    }
}
