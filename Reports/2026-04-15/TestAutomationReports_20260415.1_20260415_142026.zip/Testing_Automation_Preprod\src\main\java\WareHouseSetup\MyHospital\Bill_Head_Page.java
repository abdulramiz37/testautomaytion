package WareHouseSetup.MyHospital;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class Bill_Head_Page extends Abstraction {

    WebDriver driver;

    public Bill_Head_Page(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement billHeadNameInput;

    @FindBy(xpath = "//input[@formcontrolname='sortOrderNo']")
    private WebElement sortOrderNoInput;

    @FindBy(xpath = "//textarea[@formcontrolname='description']")
    private WebElement descriptionTextarea;

    @FindBy(xpath = "//span[@class='checkmark']")
    private WebElement isActiveCheckbox;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//input[@value='Cancel']")
    private WebElement cancelButton;

    @FindBy(xpath = "//a[text()=' Bill Head']")
    private WebElement userType;

    @FindBy(xpath = "//a[text()=' Add Bill Head ']")
    private WebElement adduserType;
     
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}
    public void enterBillHeadName(String name) {
        billHeadNameInput.clear();
        billHeadNameInput.sendKeys(name);
    }

    public void enterSortOrderNo(String sortOrder) {
        sortOrderNoInput.clear();
        sortOrderNoInput.sendKeys(sortOrder);
    }

    public void enterDescription(String description) {
        descriptionTextarea.clear();
        descriptionTextarea.sendKeys(description);
    }

    public void setIsActive(boolean isActive) {
        if (isActiveCheckbox.isSelected() != isActive) {
            isActiveCheckbox.click();
        }
    }

    public void clickSave() {
        saveButton.click();
    }

    public void clickCancel() {
        cancelButton.click();
    }
    public void fillBillHeadForm(String name, String sortOrder, String description, boolean isActive) {
    	clickbuttonapproval();
        WebElement nameField = waitForVisibility(billHeadNameInput);
        nameField.clear();
        nameField.sendKeys(name);

        WebElement sortOrderField = waitForVisibility(sortOrderNoInput);
        sortOrderField.clear();
        sortOrderField.sendKeys(sortOrder);

        WebElement descriptionField = waitForVisibility(descriptionTextarea);
        descriptionField.clear();
        descriptionField.sendKeys(description);
        waitForClickability(isActiveCheckbox);
     
        clickSave();
    }

}
