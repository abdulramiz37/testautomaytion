package TestComponents.Appointment;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Appointment.FrontEndDashBorad;
import EzionpageObjects.UserIdPage;
import PrakashSirAppointmentBooking.AppointmentBooking;
import Registration.NewRegistrationPage;
import Registration.PatientList;
import abdulTest.BaseTest;
import ezion.Resources.EnvUtil;

public class Appointment_Services  extends BaseTest{
	 UserIdPage data;
	  NewRegistrationPage registrationPage ;

	   @Test(dataProvider = "getDataForLogin",priority = 1)
	   public void Login(HashMap<String, String> input) throws InterruptedException {
	       // Login
	       data = login.login(EnvUtil.get("USER_ID"));
	       data.enterMobileNumber(EnvUtil.get("PERSON_ID"));
	       data.enterPassword(EnvUtil.get("PASSWORD"));

	       data.clickContinue();
//	   Thread.sleep(8000);
	       }
	   String targetMobileNumber;
	   String storedFirstName1;
	   @Test(dataProvider = "getDataForLogin",priority = 3)
	   public void patientName(HashMap<String, String> input) throws InterruptedException {
		   Thread.sleep(8000);	 
	       // Step 1: Search patient
	       registrationPage = new NewRegistrationPage(driver);

	       // Call the fillNewRegistrationForm method with all necessary form values
	       registrationPage.clickbuttonapproval();
	       registrationPage.selectTitle();
	       registrationPage.selectOptionFromNgxDropdown("Mr.");
	       registrationPage.enterFirstName("");
	       registrationPage.enterMiddleName("doe");
	       registrationPage.enterLastName("abraham");
	       registrationPage.selectGender();
	       registrationPage.selectOptionFromNgxDropdown("Male");
	       registrationPage.enterDOB("01/05/2024");
	       registrationPage.enterMobileNumber("");
	       storedFirstName1=registrationPage.storedFirstName;
	       targetMobileNumber=registrationPage.lastEnteredMobileNumber;
	       registrationPage.selectNationality("Indian");
//	       targetMobileNumber="7411081113";
	       registrationPage.save();

	//System.out.println(targetMobileNumber);
	   } 
	   
	   @Test(dataProvider = "getDataForLogin",priority = 4)
	   public void patientlist(HashMap<String, String> input) throws InterruptedException {
	       // Login
//		   Thread.sleep(5000);
		   PatientList patient = new PatientList(driver);
		   System.out.println(targetMobileNumber);
//		   patient.findPatientByMobile(targetMobileNumber);

	        patient.findPatientByMobile(targetMobileNumber, "Walk-In Appointment");
//	        patient.findPatientByMobile(targetMobileNumber, "Admission");
//	        patient.findPatientByMobile(targetMobileNumber, "Patient Wallet");
//	        patient.findPatientByMobile(targetMobileNumber, "Edit Patient");
//	        patient.findPatientByMobile(targetMobileNumber, "Certificates");
//	        patient.findPatientByMobile(targetMobileNumber, "Patient Merge");
//	        patient.findPatientByMobile(targetMobileNumber, "Print");
//	        patient.findPatientByMobile(targetMobileNumber, "Cancel Registration");
	       }
	   @Test(dataProvider = "getDataForLogin",priority = 5)
	   public void appointmentlist(HashMap<String, String> input) throws InterruptedException {
	       // Login
//		   Thread.sleep(5000);
		   AppointmentBooking appointmentPage = new AppointmentBooking(driver);
		   appointmentPage.selectdepartment("General");
		   appointmentPage.selectDoctor("Dr. Izaan");
//		   appointmentPage.setStartDate("11/26/2025 12:30 PM");
		   appointmentPage.save();
		   FrontEndDashBorad dash = new FrontEndDashBorad(driver);
		   Thread.sleep(5000);
		   dash.findPatientByMobile(targetMobileNumber, "Check In");
	   }
	   
	   @Test(dataProvider = "getDataForLogin",priority = 6)
	   public void patientlist2(HashMap<String, String> input) throws InterruptedException {
	       // Login
//		   Thread.sleep(5000);
		   PatientList patient = new PatientList(driver);
		   System.out.println(targetMobileNumber);
//		   patient.findPatientByMobile(targetMobileNumber);
		   patient.patientlist();
	        patient.findPatientByMobile(targetMobileNumber, "Walk-In Appointment");
//	        patient.findPatientByMobile(targetMobileNumber, "Admission");
//	        patient.findPatientByMobile(targetMobileNumber, "Patient Wallet");
//	        patient.findPatientByMobile(targetMobileNumber, "Edit Patient");
//	        patient.findPatientByMobile(targetMobileNumber, "Certificates");
//	        patient.findPatientByMobile(targetMobileNumber, "Patient Merge");
//	        patient.findPatientByMobile(targetMobileNumber, "Print");
//	        patient.findPatientByMobile(targetMobileNumber, "Cancel Registration");
	       }
//	   
	   @Test(dataProvider = "getDataForLogin",priority = 7)
	   public void appointmentlist2(HashMap<String, String> input) throws InterruptedException {
	       // Login
//		   Thread.sleep(5000);
		   AppointmentBooking appointmentPage = new AppointmentBooking(driver);
		   appointmentPage.selectdepartment("General");
		   appointmentPage.selectDoctor("Dr. Izaan");
		   appointmentPage.setStartDate("01/12/2026 10:30 AM");
		   appointmentPage.save();
		   FrontEndDashBorad dash = new FrontEndDashBorad(driver);
		   Thread.sleep(5000);
		   dash.selectDateRange("Next Month");
		   dash.clickSearchButton();
		   Thread.sleep(5000);
		   dash.findPatientByMobile(targetMobileNumber, "Check In");
	   }
	    @DataProvider
	    public Object[][] getDataForLogin() throws IOException {
	        List<HashMap<String, String>> data = getJsonDataToMap(
	            System.getProperty("user.dir") + "//src//main//java//ezion//Resources//AppointMent.json"
	        );
	        return new Object[][] { { data.get(0) } };
	    }
}
