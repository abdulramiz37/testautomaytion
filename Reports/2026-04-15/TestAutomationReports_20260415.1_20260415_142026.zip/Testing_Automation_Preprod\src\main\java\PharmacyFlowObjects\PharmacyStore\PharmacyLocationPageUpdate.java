package PharmacyFlowObjects.PharmacyStore;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.*;
import EzionAbstractionComponents.Abstraction;

public class PharmacyLocationPageUpdate extends Abstraction {

    WebDriver driver;
    WebDriverWait wait;

    public PharmacyLocationPageUpdate(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    // ---------- Navigation ----------
    @FindBy(xpath = "//a[text()=' Pharmacy Location ']")
    private WebElement pharmacyLocationTab;

    @FindBy(xpath = "//a[text()=' Add Pharmacy Location']")
    private WebElement addPharmacyLocationBtn;

    // ---------- Form Fields ----------
    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement locationNameInput;

    @FindBy(xpath = "//input[@formcontrolname='mobileno']")
    private WebElement mobileNumberInput;

    @FindBy(xpath = "//input[@formcontrolname='email']")
    private WebElement emailInput;

    @FindBy(xpath = "//input[@formcontrolname='gstn']")
    private WebElement gstnInput;

    @FindBy(xpath = "//input[@formcontrolname='dlno']")
    private WebElement dlnoInput;






    // ---------- Sales Section ----------

    @FindBy(xpath = "(//label[contains(text(),'Sales')]/span[@class='checkmark'])[1]")
    private WebElement salesCheckmark;

    @FindBy(xpath = "(//ngx-select[@formcontrolname='salesWarehouse']//div[contains(@class,'ngx-select__toggle')])[1]")
    private WebElement salesWarehouseDropdown;

    // ---------- Purchase Section ----------
    @FindBy(xpath = "(//label[contains(text(),'Purchase')]/span[@class='checkmark'])[1]")
    private WebElement purchaseCheckmark;

    @FindBy(xpath = "(//ngx-select[@formcontrolname='purchaseWarehouse']//div[contains(@class,'ngx-select__toggle')])[1]")
    private WebElement purchaseWarehouseDropdown;

    // ---------- Address Checkboxes ----------
    @FindBy(xpath = "//label[contains(text(),'Use This Location Address Into Pharmacy Sales And Purchase')]/span[@class='checkmark']")
    private WebElement useThisLocationCheckmark;

    @FindBy(xpath = "//label[contains(text(),'Use Default Common Address Into Pharmacy Sales And Purchase')]/span[@class='checkmark']")
    private WebElement useDefaultAddressCheckmark;

    // ---------- Buttons ----------
    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//input[@value='Cancel']")
    private WebElement cancelButton;

    // ---------- Optional Checkmark ----------
    @FindBy(xpath = "(//span[@class='checkmark'])[4]")
    private WebElement checkMark;

    // ---------- Actions ----------
    
    
    public void selectWarehouse(String warehouseName) {
        String xpath = String.format("//a[contains(@class,'ngx-select__item')]//span[normalize-space(text())='%s']", warehouseName);
        WebElement option = waitForClickability(By.xpath(xpath));
        option.click();
    }


    
    public void clickPharmacyLocationTab() {
        waitForClickability(pharmacyLocationTab).click();
    }

    public void clickAddPharmacyLocation() {
        waitForClickability(addPharmacyLocationBtn).click();
    }

    public void enterLocationName(String name) {
    
        
        int counter = 1;
      String  uniqueName = name ;

       while (true) {
           waitForVisibility(locationNameInput).clear();
           locationNameInput.sendKeys(uniqueName);

           try {
               new WebDriverWait(driver, Duration.ofSeconds(0))
                   .until(ExpectedConditions.invisibilityOfElementLocated(
                       By.xpath("//span[contains(text(),'Name Already Exists..')]")));
               break;
           } catch (TimeoutException e) {
               counter++;
               uniqueName = name + counter;
           }
       }
    }

    public void enterMobileNumber(String mobile) {
        waitForVisibility(mobileNumberInput).clear();
        mobileNumberInput.sendKeys(mobile);
    }

    public void enterEmail(String email) {
        waitForVisibility(emailInput).clear();
        emailInput.sendKeys(email);
    }

    public void enterGSTN(String gstn) {
        waitForVisibility(gstnInput).clear();
        gstnInput.sendKeys(gstn);
    }

    public void enterDLNO(String dlno) {
        waitForVisibility(dlnoInput).clear();
        dlnoInput.sendKeys(dlno);
    }

    public void selectSalesCheckbox() {
        if (!salesCheckmark.isSelected()) {
            waitForClickability(salesCheckmark).click();
        }
    }

    public void openSalesWarehouseDropdown() {
        waitForClickability(salesWarehouseDropdown).click();
    }

    public void selectPurchaseCheckbox() {
        if (!purchaseCheckmark.isSelected()) {
            waitForClickability(purchaseCheckmark).click();
        }
    }

    public void openPurchaseWarehouseDropdown() {
        waitForClickability(purchaseWarehouseDropdown).click();
    }

    public void selectUseThisLocationCheckbox() {
        if (!useThisLocationCheckmark.isSelected()) {
            waitForClickability(useThisLocationCheckmark).click();
        }
    }

    public void selectUseDefaultAddressCheckbox() {
        if (!useDefaultAddressCheckmark.isSelected()) {
            waitForClickability(useDefaultAddressCheckmark).click();
        }
    }

    public void clickSave() {
        waitForClickability(saveButton).click();
    }

    public void clickCancel() {
        waitForClickability(cancelButton).click();
    }

    public void useDefaultAddressCheckmark() {
    	if (!useDefaultAddressCheckmark.isSelected()) {
        waitForClickability(useDefaultAddressCheckmark).click();
    	}
    }
    public void selectSalesWarehouse(String warehouseName) {
        openSalesWarehouseDropdown();  // dropdown must be visible
        selectWarehouse(warehouseName); // pass e.g. "primary warehouse"
    }

    public void selectPurchaseWarehouse(String warehouseName) {
        openPurchaseWarehouseDropdown();
        selectWarehouse(warehouseName);
    }

    // ---------- High-Level Methods ----------
    public void addPharmacyLocation(String name, String mobile, String email, String gstn, String dlno, String salesWh, String purchaseWh) {
        clickPharmacyLocationTab();
        clickAddPharmacyLocation();
        enterLocationName(name);
        enterMobileNumber(mobile);
        enterEmail(email);
        enterGSTN(gstn);
        enterDLNO(dlno);
        selectSalesCheckbox();
        selectSalesWarehouse(salesWh);
        selectPurchaseCheckbox();
        selectPurchaseWarehouse(purchaseWh);

       
    }



    public HMSLocationPageUpdate saveAndReturnToHMSPage() {
        clickSave();
       waitForPharmacyPageWithBackClick(); // Custom method from Abstraction
        return new HMSLocationPageUpdate(driver);
    }
}
