package WareHouseSetup.Settings;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class HospitalSchedulePage extends Abstraction {

    WebDriver driver;

    public HospitalSchedulePage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // --- Date and Slot Duration ---

    
    @FindBy(xpath = "//input[@formcontrolname='startDate']")
    private WebElement fromDateInput;

    @FindBy(xpath = "//input[@formcontrolname='endDate']")
    private WebElement toDateInput;

    @FindBy(xpath = "//input[@formcontrolname='timeSlotInMin']")
    private WebElement timeSlotInput;

    // --- Week Schedule Section ---

    @FindBy(xpath = "//ngx-select[@formcontrolname='dayOfWeek']//input[@type='text']")
    private WebElement dayOfWeekDropdownInput;

    @FindBy(id = "branchLocation")
    private WebElement branchDropdown;

    @FindBy(xpath = "//input[@formcontrolname='startTime']")
    private WebElement fromTimeInput;

    @FindBy(xpath = "//input[@formcontrolname='endTime']")
    private WebElement toTimeInput;

    @FindBy(xpath = "//input[@type='button' and @value='Add']")
    private WebElement addButton;

    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
    private WebElement cancelButton;

    @FindBy(xpath = "//input[@type='button' and @value='Clear']")
    private WebElement clearButton;

    @FindBy(xpath = "//a[text()=' Hospital Slots ']")
    private WebElement hospitalSlots;
    // --- Actions ---

    public void enterFromDate(String date) {
        WebElement element = waitForClickability(fromDateInput);
        element.clear();
        element.sendKeys(date);
    }

    public void enterToDate(String date) {
        WebElement element = waitForClickability(toDateInput);
        element.clear();
        element.sendKeys(date);
    }

    public void enterTimeSlot(String minutes) {
        WebElement element = waitForClickability(timeSlotInput);
        element.clear();
        element.sendKeys(minutes);
    }

    public void selectDayOfWeek(String dayText) {
        waitForClickability(dayOfWeekDropdownInput).click();
        String xpath = String.format("//span[contains(text(),'%s')]", dayText);
        WebElement option = waitForClickability(By.xpath(xpath));
        clickWithJavaScript(option); // In case standard click fails due to Angular overlays
    }

    public void selectBranch(String branchText) {
        waitForClickability(branchDropdown).click();
        String xpath = String.format("//span[contains(text(),'%s')]", branchText);
        WebElement option = waitForClickability(By.xpath(xpath));
        clickWithJavaScript(option);
    }

    public void enterFromTime(String fromTime) {
        WebElement element = waitForClickability(fromTimeInput);
        element.clear();
        element.sendKeys(fromTime);
    }

    public void enterToTime(String toTime) {
        WebElement element = waitForClickability(toTimeInput);
        element.clear();
        element.sendKeys(toTime);
    }

    public void clickAdd() {
        waitForClickability(addButton).click();
    }

    public void clickCancel() {
        waitForClickability(cancelButton).click();
    }

    public void clickClear() {
        waitForClickability(clearButton).click();
    }
    public void fillSlotScheduleFormForMultipleDays(String fromDate, String toDate, String slotDuration,
            String dayOfWeekList, String branch, String fromTime, String toTime) {

        waitForClickability(hospitalSlots).click();  

        enterFromDate(fromDate);
        enterToDate(toDate);
        enterTimeSlot(slotDuration);

        // Handle multiple days from a string like "[Monday,Tuesday,Wednesday]"
        String cleanedList = dayOfWeekList.replace("[", "").replace("]", "").replace("\"", "");
        String[] days = cleanedList.split(",");

        for (String day : days) {
            day = day.trim(); // Remove any leading/trailing spaces
            selectDayOfWeek(day); 
        }
        selectBranch(branch);
        enterFromTime(fromTime);
        enterToTime(toTime);
        clickAdd();
        
    }


    
}
