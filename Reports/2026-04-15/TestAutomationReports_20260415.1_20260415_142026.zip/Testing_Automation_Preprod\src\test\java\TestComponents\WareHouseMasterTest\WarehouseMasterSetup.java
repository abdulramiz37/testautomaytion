package TestComponents.WareHouseMasterTest;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EzionpageObjects.UserIdPage;
import PharmacyFlowObjects.MasterSetupPage;

import WareHouseSetup.Approval.Approval;
import WareHouseSetup.Approval.Branchbased.BillCancelPage;
import WareHouseSetup.Approval.Branchbased.BillDiscountPage;
import WareHouseSetup.Approval.Branchbased.Branch_Based_Master;
import WareHouseSetup.Approval.Tenant_Master.CallStatusPage;
import WareHouseSetup.Approval.Tenant_Master.Tenant_Based_Master;
import WareHouseSetup.Settings.Unique_id_Generator;
import abdulTest.BaseTest;

public class WarehouseMasterSetup extends BaseTest {

    @Test(dataProvider = "getDataForLogin")
    public void Login1(HashMap<String, String> input) throws InterruptedException {
        UserIdPage data = login.login(input.get("userId"));
        data.enterMobileNumber(input.get("personId"));
        data.enterPassword(input.get("password"));
        data.clickContinue();
        data.openMasterSetup();
//        Assert.assertTrue(data.isIncorrectCredentialAlertDisplayed().contains("You have been successfully logged in."));
        Approval approvalPage = new Approval(driver);
        approvalPage.clickbuttonapproval();

        // Fill dropdowns using data from JSON
        approvalPage.selectUserName(input.get("userName"));
        approvalPage.selectAccountType(input.get("accountType"));
        approvalPage.selectAccountSubType(input.get("accountSubType"));

        // Click Save
        approvalPage.clickSave();
        data.masterSetupOpenOnly();
        Branch_Based_Master branchBased = new Branch_Based_Master(driver);
        branchBased.clickbuttonapproval();
        branchBased.fillItemDiscountForm(
            input.get("discountName"),
            input.get("discountCode"),
            input.get("discountDescription"),
            Boolean.parseBoolean(input.get("isActive")
            		));
        
        BillDiscountPage billpage = new BillDiscountPage(driver); 
        billpage.clickbuttonapproval();
        billpage.fillBillDiscountForm(
                input.get("name"), 
                input.get("code"), 
                input.get("description"), 
                Boolean.parseBoolean(input.get("isActive"))
            );
        
        BillCancelPage billPage = new BillCancelPage(driver);
        billPage.clickbuttonapproval();
        billPage.fillBalanceForm(
        	    input.get("billCancelName"),
        	    input.get("billCancelCode"),
        	    input.get("billCancelDescription"),
        	    input.get("isActive").equalsIgnoreCase("true")
        	);

         
        data.masterSetupOpenOnly();
        
        Tenant_Based_Master tenant = new Tenant_Based_Master(driver);
        tenant.clickbuttonapproval();
        tenant.fillCallCategoryForm(
        	    input.get("categoryName"),
        	    input.get("categoryCode"),
        	    input.get("categoryDescription"),
        	    Boolean.parseBoolean(input.get("isActive"))
        	);
        
        CallStatusPage callstatus = new CallStatusPage(driver);
        callstatus.clickbuttonapproval();
        callstatus.fillCallStatusForm(
            input.get("callStatusName"),
            input.get("callStatusCode"),
            input.get("callStatusDescription"),
            Boolean.parseBoolean(input.get("isActive"))
        );
        data.masterSetupOpenOnly();
        
        Unique_id_Generator uniqueId = new Unique_id_Generator(driver);

     // Fill form using dynamic data
     uniqueId.selectUniqueIdFor(input.get("UniqueIDFor"));
     uniqueId.enterText(input.get("Text"));
     uniqueId.enterNumber(input.get("Number"));
     uniqueId.selectDateFormat(input.get("DateFormat"));
     uniqueId.selectPrefix(input.get("Prefix"));
     uniqueId.selectTenantBased(); // Or use input.get("Type") if needed

     // Checkbox selections (if provided in input)
     if (input.get("EnableText").equalsIgnoreCase("yes")) uniqueId.selectTextCheckbox();
     if (input.get("EnableDateFormat").equalsIgnoreCase("yes")) uniqueId.selectDateFormatCheckbox();

     // Try saving and retry if length error
     int attempts = 0;
     while (!uniqueId.isSaveSuccessMessageDisplayed() && attempts < 5) {
         uniqueId.clickSave();
         if (uniqueId.isLengthErrorDisplayed()) uniqueId.incrementDigit();
         attempts++;
     }

     uniqueId.clickSave(); // Final save
     data.masterSetupOpenOnly();

        

        
	
    }
//
    @DataProvider
    public Object[][] getDataForLogin() throws IOException {
        List<HashMap<String, String>> data = getJsonDataToMap(
            System.getProperty("user.dir") + "//src//main//java//ezion//Resources//WareHouseMaster.json"
        );
        return new Object[][] { { data.get(0) } };
    }
}
