package Appointment.DoctorList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class AccreditationDetailsPage extends Abstraction {

    public AccreditationDetailsPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // WebElement locators
    @FindBy(xpath = "//label[contains(text(), 'Select Accreditation')]/following-sibling::ngx-select//div[@class='ngx-select__toggle btn form-control']")
    private WebElement accreditationDropdown;

    @FindBy(xpath = "//input[@formcontrolname='accreditationNotes']")
    private WebElement accreditationNotesInput;

    @FindBy(xpath = "(//input[@formcontrolname='date'])[2]")
    private WebElement registrationDateInput;

    @FindBy(xpath = "//input[@type='button' and @value='Add']")
    private WebElement addButton;

    @FindBy(xpath = "(//input[@type='button' and @value='Save'])[5]")
    private WebElement saveButton;

    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
    private WebElement cancelButton;

    // Actions

    public void selectAccreditation(String accreditation) {
        waitForClickability(accreditationDropdown).click();
        selectDropdownOptionByVisibleText(accreditation);
    }

    public void enterAccreditationNotes(String notes) {
        waitForVisibility(accreditationNotesInput).clear();
        accreditationNotesInput.sendKeys(notes);
    }

    public void enterRegistrationDate(String date) {
        waitForVisibility(registrationDateInput).clear();
        registrationDateInput.sendKeys(date);
    }

    public void clickAddButton() {
        waitForClickability(addButton).click();
    }

    public void clickSaveButton() {
        waitForClickability(saveButton).click();
    }

    public void clickCancelButton() {
        waitForClickability(cancelButton).click();
    }

    public void selectDropdownOptionByVisibleText(String text) {
        WebElement option = driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[text()='" + text + "']"));
        waitForClickability(option).click();
    }

    // Combined form fill method
    public void fillAccreditationDetailsForm(String accreditation, String notes, String date) {
        selectAccreditation(accreditation);
        enterAccreditationNotes(notes);
        enterRegistrationDate(date);
        // clickAddButton(); // Optional: Uncomment if required to add to list
    }
}
