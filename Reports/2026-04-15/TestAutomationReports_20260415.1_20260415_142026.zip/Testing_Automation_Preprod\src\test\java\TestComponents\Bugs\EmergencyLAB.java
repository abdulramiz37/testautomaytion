package TestComponents.Bugs;



import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeoutException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EHR.ClinicalAseesment.BloodGroup;
import EHR.ClinicalAseesment.EHRHomePage;

import org.testng.Assert;

import EzionpageObjects.UserIdPage;
import IP.AdmissionFormPage;
import IP.Serviceip;
import Lab.ApprovedListPage;
import Lab.LabWorkOrder;
import Lab.NewListTable;
import Lab.Re_TestPage;
import Lab.SampleCollectedList;
import Lab.SampleCollected_EditWorkList;
import Lab.WaitingApprovalPage;
import PrakashSirAppointmentBooking.AppointmentBooking;
import PrakashSirAppointmentBooking.EMR;
import PrakashSirAppointmentBooking.CaseSheet.BrandListPage;
import PrakashSirAppointmentBooking.CaseSheet.ChiefComplaintsPage;
import PrakashSirAppointmentBooking.CaseSheet.DiagnosisPage;
import PrakashSirAppointmentBooking.CaseSheet.ExaminationPage;
import PrakashSirAppointmentBooking.CaseSheet.HighRiskPage;
import PrakashSirAppointmentBooking.CaseSheet.InstructionPage;
import PrakashSirAppointmentBooking.CaseSheet.InvestigationPage;
import PrakashSirAppointmentBooking.CaseSheet.NurseNotesPage;
import PrakashSirAppointmentBooking.CaseSheet.OpAssessmentTemplatePage;
import PrakashSirAppointmentBooking.CaseSheet.PrescriptionPage;
import PrakashSirAppointmentBooking.CaseSheet.VaccinationTableActions;
import PrakashSirAppointmentBooking.CaseSheet.VaccinePage;
import PrakashSirAppointmentBooking.CaseSheet.VitalPage;
import PrakashSirAppointmentBooking.CaseSheet.TaskOrder.AdmissionReferralPage;
import PrakashSirAppointmentBooking.CaseSheet.TaskOrder.CounsellingPage;
import PrakashSirAppointmentBooking.CaseSheet.TaskOrder.InjectionPage;
import PrakashSirAppointmentBooking.CaseSheet.TaskOrder.PatientTherapyPage;
import PrakashSirAppointmentBooking.CaseSheet.TaskOrder.TreatmentPage;
import PrakashSirAppointmentBooking.CaseSheet.TaskOrder.TreatmentPlanPage;
import PrakashSirAppointmentBooking.CaseSheet.TaskOrder.VaccinationPage;
import Radiology.Radiology;
import Registration.NewRegistrationPage;
import Registration.PatientList;
import Registration.ServiceList;
import WareHouseSetup.IPpharmacy.BedPage;
import WareHouseSetup.IPpharmacy.NursingCounterPage;
import abdulTest.BaseTest;
import ezion.Resources.EnvUtil;

public class EmergencyLAB  extends BaseTest {
	
	 UserIdPage data;
	  NewRegistrationPage registrationPage ;
    @Test(dataProvider = "getDataForLogin",priority = 1)
    public void Login(HashMap<String, String> input) throws InterruptedException {
        // Login
//        data = login.login(EnvUtil.get("USER_ID"));
//        data.enterMobileNumber(EnvUtil.get("PERSON_ID"));
//        data.enterPassword(EnvUtil.get("PASSWORD"));
//
//        data.clickContinue();
//    Thread.sleep(8000);
        String userId = prop.getProperty("USER_ID");
        String personId = prop.getProperty("PERSON_ID");
        String password = prop.getProperty("PASSWORD");
        String browser = System.getProperty("BROWSER");
        data = login.login(userId);
        data.enterMobileNumber(personId);
        data.enterPassword(password);
        data.clickContinue();
        System.out.println("Browser: " + browser);
//        System.out.println("Base URL: " + baseUrl);
        System.out.println("User ID: " + userId);
        System.out.println("Person ID: " + personId);
        data.clickContinue();
        data.navigateSalesWithRetry();
        }
    String targetMobileNumber;
    String firstname;
    String storedFirstName1;
    @Test(dataProvider = "getDataForLogin",priority = 2)
    public void patientName(HashMap<String, String> input) {
        // Step 1: Search patient
        registrationPage = new NewRegistrationPage(driver);

        // Call the fillNewRegistrationForm method with all necessary form values
        registrationPage.clickbuttonapproval();
        registrationPage.selectTitle();
        registrationPage.selectOptionFromNgxDropdown("Mr.");
        registrationPage.enterFirstName("");
        firstname=registrationPage.storedFirstName;
        registrationPage.enterMiddleName("doe");
        registrationPage.enterLastName("abraham");
        registrationPage.selectGender();
        registrationPage.selectOptionFromNgxDropdown("Male");
        registrationPage.enterDOB("12/12/2024");
        registrationPage.enterMobileNumber("");
        storedFirstName1=registrationPage.storedFirstName;
        targetMobileNumber=registrationPage.lastEnteredMobileNumber;
//        targetMobileNumber="7411081113";
        registrationPage.save();

//System.out.println(targetMobileNumber);
    } 
    
    @Test(dataProvider = "getDataForLogin", priority = 3)
    public void PatientRegistration(HashMap<String, String> input) throws InterruptedException {
    	PatientList patient = new PatientList(driver);
    	patient.patientlist();
    	patient.patientlist();
    	patient.patientlist();
    	patient.findPatientByMobile(targetMobileNumber);
    	
    	ServiceList service = new ServiceList(driver);
//    	Blood Sugar2 - LabTest
//     	service.fillBillingForm("General", "Dr. Izaan", "Self","Blood Sugar - LabTest","10","%","5");
    	Thread.sleep(5000);

     	service.selectDropdownOption("General");

//     	service.clickPhysicianDropdown();
	   	service.selectDropdownOption("Dr. Dr. John");

//	   	service.clickBillTypeDropdown();
//      service.selectDropdownOption("Self");
//      service.clickPayerSelectDropdown();
      service.selectDropdownOption("Blood Sugar - LabTest");
      service.enterQuantity("10");

      service.clickDiscountTypeDropdown();
      service.selectDropdownOption("%");

      service.enterDiscountPercentage("5");

      service.clickAddButton();
    	
     	  service.clickServiceNameDropdown();
        service.selectDropdownOption("vfx - Radiology"); // or any other service

        service.enterQuantity("10");

        service.clickDiscountTypeDropdown();
        service.selectDropdownOption("%");

        service.enterDiscountPercentage("5");

        service.clickAddButton();
        service.clickByText("Emergency");
        service.save();
        }
    String getbillNo;
    String workId ;    
    @Test(dataProvider = "getDataForLogin", priority = 4)
    public void NewList(HashMap<String, String> input) throws InterruptedException {
    	ServiceList patient = new ServiceList(driver);
    	Thread.sleep(5000);
    	getbillNo=patient.getBillNo();
    	System.out.println(getbillNo);
    	NewListTable listTable = new NewListTable(driver);
    	listTable.clickbuttonapproval();
    	Thread.sleep(5000);
    	listTable.clickActionByPatientAndPhysician(
    			getbillNo);
    	
 workId = listTable.workId;
    	
//    	String workId = "808088";
    	System.out.println(workId);
    }
    @Test(dataProvider = "getDataForLogin", priority = 5)
    public void labworkOrder(HashMap<String, String> input) throws InterruptedException {
    	LabWorkOrder labOrder= new LabWorkOrder(driver);
    	Thread.sleep(5000);
    	labOrder.clickByTextContains("Delay Reason");
    	Thread.sleep(5000);
    	labOrder.clickArrowDropdown(1);
    	labOrder.clickByText("delay reason");
    	labOrder.enterNotes("jhd");
    	labOrder.clickByText("Save");
    	Thread.sleep(5000);
    	labOrder.clickCheckboxByTestName("Blood Sugar");
   
    }
////    
    @Test(dataProvider = "getDataForLogin", priority = 6)
    public void sampleList(HashMap<String, String> input) throws InterruptedException, TimeoutException  {
    	
    	
    	
//    	String workId = "808088";
    	Thread.sleep(5000);
//    	System.out.println(workId);
    	SampleCollectedList sampleList = new SampleCollectedList(driver);
  
    	System.out.println(workId +"new");
    	sampleList.clickReorderByWorkOrder2(workId);
    }
    
    @Test(dataProvider = "getDataForLogin", priority = 7)
    public void sampleList_workorderList(HashMap<String, String> input) throws InterruptedException, TimeoutException {
    	LabWorkOrder labOrder= new LabWorkOrder(driver);
    	SampleCollected_EditWorkList worklist = new SampleCollected_EditWorkList(driver);
    	Thread.sleep(5000);
    	labOrder.clickByTextContains("Delay Reason");
    	Thread.sleep(5000);
    	labOrder.clickArrowDropdown(2);
    	labOrder.clickByText("delay reason");
    	labOrder.enterNotes("jhd");
    	labOrder.clickByText("Save");
    	Thread.sleep(5000);
//    	worklist.clickEditIconByTestName("Blood Urea");
    	worklist.editTestValueByTestName("Blood Sugar","2","jsdd");
//    	worklist.fillHistopathologyForm(
//    		    "HP-001",
//    		    "Livdf",
//    		    "Brodf",
//    		    "Abdf",
//    		    "Shdfh",
//    		    "Hadsf"
//    		);
    	
    	
    	worklist.selectDropdownValue("Cb");
    }
    @Test(dataProvider = "getDataForLogin", priority = 8)
    public void waitingList(HashMap<String, String> input) throws InterruptedException, TimeoutException {
    	LabWorkOrder labOrder= new LabWorkOrder(driver);
    	WaitingApprovalPage waitingApproval = new WaitingApprovalPage(driver);
       	Thread.sleep(5000);
    	Thread.sleep(5000);
       	Thread.sleep(5000);
    	waitingApproval.clickReorderByWorkOrder(workId);
    	Thread.sleep(5000);
    	labOrder.clickByTextContains("Delay Reason");
    	Thread.sleep(5000);
    	labOrder.clickArrowDropdown(1);
    	labOrder.clickByText("delay reason");
    	labOrder.enterNotes("jhd");
    	labOrder.clickByText("Save");
    	Thread.sleep(5000);
//    	waitingApproval.selectApprovalStatus("Approved");
    	labOrder.clickByButtonValue("Save");
     	
    }
//    
    @Test(dataProvider = "getDataForLogin", priority = 9)
    public void approvalList(HashMap<String, String> input) throws InterruptedException {
    	ApprovedListPage approval = new ApprovedListPage(driver);
    	Thread.sleep(5000);
    	Thread.sleep(5000);
    	approval.clickReorderByWorkOrder(workId);
    	Re_TestPage retest = new Re_TestPage(driver);
    	Thread.sleep(5000);
    	retest.clickCheckboxForTest("Blood Sugar");
 
    	
    	retest.clickByButtonValue("Sample Reject");
//      	Thread.sleep(5000);
      	retest.byTextAttach("Requested Date", "/ancestor::div[1]//input").sendKeys("07/02/2026");
     	retest.byTextAttach("Rejection Name", "/ancestor::div[1]//div").click();
//    	retest.byTextAttach("Requested Date", "/ancestor::div[1]//div").click();
    	retest.clickByText("sss",1);
//    	retest.clickGenerateWorkOrder();
    	retest.selectRequestedByEmployee("Cb");
   
     	retest.byTextAttach("Reason Notes", "/ancestor::div[1]//textarea").sendKeys("dfdd");
     	retest.clickByButtonValue("Save");
//    	retest.selectApprovedByEmployee("Cb");
    	
    }
    @Test(dataProvider = "getDataForLogin", priority = 10)
    public void approvalList3(HashMap<String, String> input) throws InterruptedException {
    	ApprovedListPage approval = new ApprovedListPage(driver);
    	Thread.sleep(5000);
    
    	approval.clickByText("Lab Order List", 1);
    	System.out.println(getbillNo+"  last");
    	approval.clickActionByCategoryt(getbillNo,"//a[@title='Edit']");
    	
    	
    }
    @Test(dataProvider = "getDataForLogin", priority = 11)
    public void labworkOrder3(HashMap<String, String> input) throws InterruptedException {
    	LabWorkOrder labOrder= new LabWorkOrder(driver);
    	Thread.sleep(5000);
    	labOrder.clickByTextContains("Delay Reason");
    	Thread.sleep(5000);
    	labOrder.clickArrowDropdown(1);
    	labOrder.clickByText("delay reason");
    	labOrder.enterNotes("jhd");
    	labOrder.clickByText("Save");
    	Thread.sleep(5000);
    	labOrder.clickByButtonValue("Update");
    	Thread.sleep(5000);   
    	labOrder.clickActionByCategoryt(getbillNo,"//a[@title='Edit']");
    	labOrder.clickByButtonValue("Update");
      
    }
    @Test(dataProvider = "getDataForLogin", priority = 12)
    public void approvalList4(HashMap<String, String> input) throws InterruptedException {
    	ApprovedListPage approval = new ApprovedListPage(driver);
    	Thread.sleep(5000);
    	Thread.sleep(5000);
//    	approval.clickByText("Lab Order List", 1);
    	System.out.println(getbillNo+"  last");
    	approval.clickActionByCategoryt(getbillNo,"//li[@title='Add']");
    	
    	
    }
    
    @Test(dataProvider = "getDataForLogin", priority = 13)
    public void print(HashMap<String, String> input) throws InterruptedException {
    	ApprovedListPage approval = new ApprovedListPage(driver);
    	Thread.sleep(5000);
    	Thread.sleep(5000);
//    	approval.clickByText("Lab Order List", 1);
    approval.clickByButtonValue("Update and Print");
	Thread.sleep(5000);
    approval.clickByButtonValue("Yes");
  	approval.clickActionByCategoryt("Blood Sugar","//td[1]//input[@type='checkbox']");
  	approval.clickActionByCategoryt("Blood Sugar","//td[7]//input[@type='checkbox']");	
  	approval.clickByText("Do you want to print Notes?");
    approval.clickByButtonValue("Print");
    }
    
    @Test(dataProvider = "getDataForLogin",priority = 14)
    public void testEditLastVisit(HashMap<String, String> input) throws InterruptedException {
        // Step 1: Search patient
    	Thread.sleep(5000);
  	  ApprovedListPage approval = new ApprovedListPage(driver);
  		approval.clickByText("Radiology", 1);
  		approval.clickByText("Radiology Dashboard", 1);
  		approval.clickByText("X-Ray - Ches", 1);
  		approval.clickActionByCategoryttt(getbillNo,"//a[img[contains(@src,'edit')]]");
  		Radiology radio = new Radiology(driver);
      	radio.clickActionByTitle("Attachment");
      	Thread.sleep(5000);
       	String path = System.getProperty("user.dir") + "\\test-output\\passed.png";
      	radio.uploadFile(path);
      	approval.clickByText("Add");
      	Thread.sleep(5000);
      	approval.clickByButtonValue("Cancel",2);
      	approval.clickByText("New", 2); 
      	approval.selectTypeFromNgxSelect("Waiting");
       
      	
      	approval.clickByButtonValue("Update");
//      	
    } 
    
    @Test(dataProvider = "getDataForLogin",priority = 15)
    public void testEditLastVisit2(HashMap<String, String> input) throws InterruptedException {
        // Step 1: Search patient
  		Thread.sleep(5000);
  	  ApprovedListPage approval = new ApprovedListPage(driver);
  		approval.clickByText("Waiting List", 2);

  		approval.clickActionByCategoryttt(getbillNo,"//a[img[contains(@src,'edit')]]");
  		Radiology radio = new Radiology(driver);
      	radio.clickActionByTitle("Attachment");
      	Thread.sleep(5000);
       	String path = System.getProperty("user.dir") + "\\test-output\\passed.png";
      	radio.uploadFile(path);
      	approval.clickByText("Add");
      	Thread.sleep(5000);
      	approval.clickByButtonValue("Cancel",2);
      	approval.clickByText("Waiting", 2); 
      	approval.selectTypeFromNgxSelect("Completed");
       
      	
      	approval.clickByButtonValue("Update");
//      	
    } 
    
    @Test(dataProvider = "getDataForLogin", priority = 16)
    public void MEDICALHISTORY(HashMap<String, String> input) throws InterruptedException {
    	
    	 data.openMasterSetup();
    		Thread.sleep(5000);
        data.masterSetupOpenOnly();
//        Allergy allerg= new Allergy(driver);
        data.clickByText("All");
        data.clickByText("Service");
        data.clickByText("Lab Test");
        Thread.sleep(5000);
        data.clickActionByCategoryttt("Blood Sugar"," //a[@title='Edit']");
        Thread.sleep(5000);
        data.byTextAttach("Mins","/ancestor::div[1]//input").clear();
        data.byTextAttach("Mins","/ancestor::div[1]//input").sendKeys("30");
        data.clickByButtonValue("Save");
    } 
    
    
    BedPage bedSetupPage ;
	   
	   @Test(dataProvider = "getDataForLogin", priority = 17)
	    public void testCreateBedSetup(HashMap<String, String> input) throws InterruptedException {
		   Thread.sleep(5000);
		   data.masterSetupOpenOnly();
	         bedSetupPage = new BedPage(driver);
	        bedSetupPage.clickbuttonapproval();
	        bedSetupPage.selectBedCategory("Bed");
	        bedSetupPage.selectBuilding("Main Building - A");
	        bedSetupPage.selectFloor("Second Floor");
	        bedSetupPage.selectRoom("101");
	        bedSetupPage.selectWard("General Ward A");
	        bedSetupPage.selectNursingCounter("Emergency Counter");
	        bedSetupPage.enterBedNumber("");
	        
	        bedSetupPage.setIsActive(true);

	        // Click Save
	        bedSetupPage.clickSave();

	        // Assertion (basic example – check URL or success message)
//	        String currentUrl = driver.getCurrentUrl();
//	        Assert.assertTrue(currentUrl.contains("bed-setup"), "Bed setup not saved successfully!");
	    }
	    

    @Test(dataProvider = "getDataForLogin",priority = 18)
	   public void patientlist(HashMap<String, String> input) throws InterruptedException {
	       // Login
//		   Thread.sleep(5000);
		   PatientList patient = new PatientList(driver);
		   patient.patientlist();
	    	patient.patientlist();
	    	patient.patientlist();
		   System.out.println(targetMobileNumber);
//		   patient.findPatientByMobile(targetMobileNumber);

//	        patient.findPatientByMobile(targetMobileNumber, "Service");
	        patient.findPatientByMobile(targetMobileNumber, "Admission");
//	        patient.findPatientByMobile(targetMobileNumber, "Patient Wallet");
//	        patient.findPatientByMobile(targetMobileNumber, "Edit Patient");
//	        patient.findPatientByMobile(targetMobileNumber, "Certificates");
//	        patient.findPatientByMobile(targetMobileNumber, "Patient Merge");
//	        patient.findPatientByMobile(targetMobileNumber, "Print");
//	        patient.findPatientByMobile(targetMobileNumber, "Cancel Registration");
	       }
	   
	   
	   @Test(dataProvider = "getDataForLogin",priority = 19)
	   public void testFillAdmissionFormAndSave(HashMap<String, String> input) throws InterruptedException {
	       // Login
		   NursingCounterPage nursingPage = new NursingCounterPage(driver);
		   AdmissionFormPage   admissionFormPage = new AdmissionFormPage(driver);
		   
		   admissionFormPage.selectDepartment("General");

	        // Select Physician
	        admissionFormPage.selectPhysician("Dr. ajjyniatlp");

	        // Select Admission Type
	        admissionFormPage.selectAdmissionType("Surgery");

	        // Enter Admission Date (format: MM/DD/YYYY HH:MM AM/PM)
//	        admissionFormPage.enterAdmissionDate("");

	        // Select Nursing Counter
	        admissionFormPage.selectNursingCounter("Emergency Counter");

	        // Select Ward
	        admissionFormPage.selectWard("General Ward A");

	        // Enter Locker Number
	        admissionFormPage.enterLockerNumber("L-101");
//	    Thread.sleep(5000);
//	        admissionFormPage.clickBedByNumber("B-17");
	        admissionFormPage.clickBedImageSimpleNoWait(bedSetupPage.lastEnteredbedNumber);
	        // Click Save
	        admissionFormPage.clickSave();

	        // ✅ Assertion (example: verify page URL or success message)
//	        String currentUrl = driver.getCurrentUrl();
//	        Assert.assertTrue(currentUrl.contains("admission"), "Form not submitted successfully!");

	       }
	   @Test(dataProvider = "getDataForLogin", priority = 20)
	   public void getMedicineData2(HashMap<String, String> input) throws InterruptedException {
		   Thread.sleep(5000);
	   	Serviceip serviceiptest= new Serviceip(driver);
	   	serviceiptest.frontdesk();
	   	serviceiptest.opentheappointmentpage();
//	   	serviceiptest.selectDropdownValue("10");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "Services");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "Advance");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "Nurse Notes");

   	serviceiptest.findPatientByMobileAndName(targetMobileNumber,"Mr. " + storedFirstName1 + " doe abraham", "Doctor Notes");
//   	serviceiptest.findPatientByMobileAndName(targetMobileNumber,"Mr. " + storedFirstName1 + " doe abraham", "Doctor Notes");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "Doctor Notes");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "IP Billing");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "OT Booking");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "Blood Request");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "Payer");
//	   	serviceiptest.findPatientByMobileAndName("7136304087", "Mr. kmxjaa doe abraham", "Inventory Sales");
//	      	serviceiptest.frontdesk();

//	   	for(int i=0;i<=10;i++) {
//	   	serviceiptest.selectRandomOptionsFromDropdown();
//	   	System.out.println(i);
   	
   	
   	
   	
//	   	}
	   }

	   PrescriptionPage prescriptionPage;


	   @Test(dataProvider = "getDataForLogin",priority = 21)
	   public void useGeneratedMedicines27(HashMap<String, String> input) throws InterruptedException {
		   Thread.sleep(5000);
		   prescriptionPage = new PrescriptionPage(driver);
		   System.out.println("pahucg gaya");
		     prescriptionPage.clickByText("Payer",2);
		     prescriptionPage.clickByText("Add Payer",1);
		     prescriptionPage.byTextAttach("Payer Type","/ancestor::div[1]//div").click();
		     prescriptionPage.selectTypeFromNgxSelect("Insurance");
		     prescriptionPage.byTextAttach("Payer Sub Type","/ancestor::div[1]//div").click();
		     prescriptionPage.selectTypeFromNgxSelect("ECHS");
		     prescriptionPage.byTextAttach("Insurance Name","/ancestor::div[1]//div").click();
		     prescriptionPage.selectTypeFromNgxSelect("Adithya Birla Health Insurance Co. Ltd");
;
		     prescriptionPage.byTextAttach("Policy Type","/ancestor::div[1]//div").click();
		     prescriptionPage.selectTypeFromNgxSelect("Individual");
//		     prescriptionPage.byTextAttach("Patient Type","/ancestor::div[1]//div").click();
//		     prescriptionPage.selectTypeFromNgxSelect("Self");
//		     prescriptionPage.byTextAttach("Employee ID","/ancestor::div[1]//input").sendKeys("456");
//		     prescriptionPage.byTextAttach("Employee Designation","/ancestor::div[1]//input").sendKeys("ghjgj");
//		     prescriptionPage.byTextAttach("Employee Department","/ancestor::div[1]//input").sendKeys("hgj");
//		     prescriptionPage.byTextAttach("Credit Limit","/ancestor::div[1]//input").sendKeys("45678");
//		     prescriptionPage.byTextAttach("Approval Amount","/ancestor::div[1]//input").sendKeys("4");
//	
//		     prescriptionPage.byTextAttach("Claim no. /Authorization no.","/ancestor::div[1]//input").sendKeys("45678");
//		     prescriptionPage.byTextAttach("Service No","/ancestor::div[1]//input").sendKeys("45678");
//		     prescriptionPage.byTextAttach("Service Department","/ancestor::div[1]//div").click();
//		     prescriptionPage.selectTypeFromNgxSelect("Assam Rifles pensioners");
//		     prescriptionPage.byTextAttach("Reg No","/ancestor::div[1]//input").sendKeys("45678");
		     prescriptionPage.clickByButtonValue("Save Payer");
	   }
	   
	   @Test(dataProvider = "getDataForLogin",priority = 22)
	   public void useGeneratedMedicines28(HashMap<String, String> input) throws InterruptedException {
		   prescriptionPage = new PrescriptionPage(driver);
		   Thread.sleep(5000);
		   prescriptionPage.clickByText("IP Services",1);
		   Thread.sleep(5000);
		   prescriptionPage.clickByTextAttachJS("Payer","/ancestor::div[1]//button");
		   prescriptionPage.byTextAttach("Payer Type","/ancestor::div[2]/ngx-select").click();
		   prescriptionPage.selectTypeFromNgxSelect("Insurance");
		   prescriptionPage.byTextAttach("Payer Name","/ancestor::div[2]/ngx-select").click();
		   prescriptionPage.selectTypeFromNgxSelect("Adithya Birla Health Insurance Co. Ltd");
		   prescriptionPage.clickByButtonValue("Save",3);
	   }
	   
	   @Test(dataProvider = "getDataForLogin",priority = 23)
	   public void useGeneratedMedicines29(HashMap<String, String> input) throws InterruptedException {
		   prescriptionPage = new PrescriptionPage(driver);
		   Thread.sleep(5000);
	
		   prescriptionPage.byTextAttach("Service Name","/ancestor::div[1]//ngx-select").click();
		   prescriptionPage.selectTypeFromNgxSelect("Blood Test-General");
//		   prescriptionPage.byTextAttach("Payer Type","/ancestor::div[2]/ngx-select").click();
		
		   prescriptionPage.clickByButtonValue("Add",1);
		   prescriptionPage.clickByButtonValue("Send Item",1);
	   }
	   
//	 
    @DataProvider
    public Object[][] getDataForLogin() throws IOException {
        List<HashMap<String, String>> data = getJsonDataToMap(
            System.getProperty("user.dir") + "//src//main//java//ezion//Resources//AppointMent.json"
        );
        return new Object[][] { { data.get(0) } };
    }
}