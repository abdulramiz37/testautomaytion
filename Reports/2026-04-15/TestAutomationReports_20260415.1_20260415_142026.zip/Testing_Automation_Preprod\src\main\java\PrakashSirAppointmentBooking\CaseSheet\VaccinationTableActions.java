package PrakashSirAppointmentBooking.CaseSheet;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class VaccinationTableActions extends Abstraction {

	public VaccinationTableActions(WebDriver driver) {
		super(driver);
	      PageFactory.initElements(driver, this);
	}
	
    @FindBy(xpath = "//h4[normalize-space(text())='Vaccine']/following::img[contains(@class,'openclose')][1]")
    private WebElement vaccineToggleIcon;
    
    @FindBy(xpath = "//input[@type='button' and @value='Confirm']")
    private WebElement confirmButton;
    
  public void vaccinetoggle() {
    	
	  vaccineToggleIcon.click();
    }
    public void clickConfirmButton() {
    	
        confirmButton.click();
    }
    
    public boolean clickVaccineIfBirthPresent( String targetStage,String vaccine) {
        boolean isFound = false;

        try {
            // XPath: vaccine in row AND stage in the same row or in preceding rowspan row
        	String xpath = "(//tbody)[2]/tr[" +
                    "td[normalize-space(text())='" + targetStage + "'] " +
                    "or td[normalize-space(text())='" + vaccine + "']" +
                    "]//a[@title='Add / Edit']/img";
          

            List<WebElement> buttons = driver.findElements(By.xpath(xpath));

            if (!buttons.isEmpty()) {
                // Click the last matching button
                WebElement lastButton = buttons.get(buttons.size() - 1);
                clickWithJavaScript(lastButton);
                System.out.println("✅ Clicked Add/Edit for Stage: " + targetStage + " | Vaccine: " + vaccine);
                isFound = true;
            } else {
                System.out.println("❌ Vaccine '" + vaccine + "' under Stage '" + targetStage + "' not found.");
            }

        } catch (Exception e) {
            System.out.println("⚠️ Error while clicking vaccine: " + e.getMessage());
        }

        return isFound;
    }


    
    public boolean clickEditOnSpecificVaccine(String vaccineName) {
        boolean isFound = false;
        
        // Wait for the table to load
        waitForClickability(
            By.xpath("(//tbody)[2]/tr"));
        
        // Find all vaccine name cells
        List<WebElement> vaccineCells = driver.findElements(
            By.xpath("(//tbody)[2]/tr/td[2]"));
        
        for (int i = 0; i < vaccineCells.size(); i++) {
            try {
                WebElement vaccineCell = vaccineCells.get(i);
                String currentVaccine = vaccineCell.getText().trim();
                
                if (currentVaccine.equalsIgnoreCase(vaccineName)) {
                    // Get the parent row
                    WebElement row = vaccineCell.findElement(By.xpath("./.."));
                    
                    // Find the edit button in this row
                    WebElement editButton = row.findElement(
                        By.xpath(".//a[@title='Add / Edit']/img"));
                    
                    // Scroll into view and click
                    clickWithJavaScript(editButton);
                    
                    System.out.println("✅ Clicked Edit for Vaccine: " + vaccineName);
                    isFound = true;
                    break;
                }
            } catch (Exception e) {
                System.out.println("⚠️ Error processing vaccine at index " + i + ": " + e.getMessage());
            }
        }
        
        if (!isFound) {
            System.out.println("❌ Vaccine '" + vaccineName + "' not found in the table.");
        }
        
        return isFound;
    }
    
    // Helper method to wait for URL (similar to your existing method)
//    public void waitForUrl(String url) {
//        wait.until(ExpectedConditions.urlToBe(url));
//    }
}
