package TestComponents.Appointment;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Appointment.DoctorList.AccreditationDetailsPage;
import Appointment.DoctorList.CouncilPage;
import Appointment.DoctorList.DigitalSignaturePage;
import Appointment.DoctorList.DoctorDashboardSetting;
import Appointment.DoctorList.EducationDetailsPage;
import Appointment.DoctorList.ExperienceDetailsPage;
import Appointment.DoctorList.Physician;
import Appointment.DoctorList.ProfileFormPage;
import EzionpageObjects.UserIdPage;
import Registration.NewRegistrationPage;
import abdulTest.BaseTest;
import ezion.Resources.EnvUtil;

public class AppointmentTest extends BaseTest {
    UserIdPage data;
    
    @Test(dataProvider = "getDataForLogin", priority = 1)
    public void login(HashMap<String, String> input) throws InterruptedException {
        data = login.login(EnvUtil.get("USER_ID"));
        data.enterMobileNumber(EnvUtil.get("PERSON_ID"));
        data.enterPassword(EnvUtil.get("PASSWORD"));

        data.clickContinue();
//        Thread.sleep(8000);
//        data.openMasterSetup();
    }
    
    @Test(dataProvider = "getDataForLogin", priority = 2)
    public void testNewPatientRegistration(HashMap<String, String> input) {
        // Create an instance of the NewRegistrationPage with the driver
        NewRegistrationPage registrationPage = new NewRegistrationPage(driver);

        // Call the fillNewRegistrationForm method with all necessary form values
        registrationPage.fillNewRegistrationForm(
            "Mr.",                     // Title dropdown value
            "John",                  // First name
            "doe",                  // Middle name
            "abraham",                  // Last name
            "Male",                   // Gender dropdown value

            "01/01/2025",             // Date of birth (DOB)
            "1 Ps, Padampur",                  // Birth place dropdown value
            "12:30",                  // Birth time

            "",             // Mobile number
            "0807654321",             // Alternate mobile/landline
            "04012345678",            // Office phone number
            "abdul@example.com",      // Email ID

            "C/o.",                 // Relation title dropdown
            "Mohammed",         // Name of guardian/parent

            true,                     // Auto-fill address checkbox (true = checked)

            "12/3",                   // Door number / Street
            "Green Park Colony",      // Address line 1
            "Near Garden",            // Address line 2

            "Akola City",             // City dropdown
            "444001",                 // Pincode
            "1 Ps, Padampur",                // Area dropdown
            "Akola",                  // District dropdown
            "Maharashtra",           // State dropdown
            "India",                  // Country dropdown
            "Central",                // Region dropdown

            "Yusuf Khan",             // Emergency contact name
            "Brother",                // Emergency relationship dropdown
            "+91",                    // Emergency country code dropdown
            "9001234567",             // Emergency mobile
            "0724-223344",            // Emergency landline
            "Flat No. 7, Sector 5",   // Emergency address
            
            "Employee",
            "Fddf Fgf",
            
            "Outpatixxent",                 // How did you know about us dropdown
            "Muslim",                  // Religion dropdown
            "Indian",                 // Citizenship dropdown
            "Indian",                 // Nationality dropdown
            "Unmarried",                 // Marital status dropdown

            "Hindi",                  // Preferred language
            "Engineer",               // Occupation dropdown
            "Abnormal",                   // Special care dropdown
            "VIP",                    // Special courtesy dropdown
            "None",                   // Gender extension dropdown
            "None",                   // Study dropdown

            "N1234567",               // Passport number
            "ID998877",               // National ID
            "DLAB1234567894444",          // Driving license number
            "RF123456",               // Refugee number

            "ABCDE1234F",             // PAN card number
            "123456789012",           // Aadhar number
            "FRRO56789",              // FRRO number
            "12-1234-1234-4568",           // ABHA number
            "abha@ndhm",              // ABHA address

            "01/01/2025",             // Visa issue date
            "10/13/2025",             // Visa validity date
            "02/01/2025",             // Date of entry
            "Mumbai Airport",         // Port of entry

            "Ghatkopar, Mumbai",      // Residential address
            "Andheri Office",         // Office address
            "No remarks",             // Remarks textarea

            false,                    // Deceased checkbox
            true                      // Is active checkbox
        );
        
        registrationPage.save();
    }
//    
//  @Test(dataProvider = "getDataForLogin", priority = 3, dependsOnMethods = "login")
//  public void DoctorPhysicain(HashMap<String, String> input) throws InterruptedException {
//     
//	  Physician physicianPage = new Physician(driver);
//
//       // Fill the form using input map
//	  physicianPage.addPhysician(
//			    "Dr.",              // prefix
//			    "",             // physicianName
//			    "Doe",              // lastName
//			    "John D.",          // displayName
//			    "Male",             // gender
//			    "01/01/1980",       // dob
//			    "44",               // age
//			    "", // email
//			    "",       // mobile
//			    "9123456780",       // altMobile
//			    "0221234567",       // workPhone
//			    "ABCDE1234F",       // panCard
//
//			    "General",              // department
//			    "Therapist",            // jobCategory
//			    "Permanent Employee",   // jobType
//			    "Senior",               // academicRank
//
//			    "123 Baker Street",     // street
//			    "Downtown",             // area
//			    "400001",               // pincode
//			    "Mumbai",               // city
//			    "Bagalkot",               // district
//			    "Maharashtra",          // state
//			    "India",                // country
//
//			    true,                   // isActive
//
//			    "Booked",     // appointmentChargesPostedWhen
//			    "Direct Appointment",       // appointmentBookingType
//			    "Able to see only my appointment",         // restrictedViewOption
//			    "Department",           // consultationChargeType
//			    "Tamil",
//			 true
//
//	        );
////	  physicianPage.clickSaveButton();
//
//	  physicianPage.clickSaveAndContinue();
//    }  
  
//@Test(dataProvider = "getDataForLogin", priority = 4, dependsOnMethods = "DoctorPhysicain")
//public void educationDetails(HashMap<String, String> input) {
//	
//	
//EducationDetailsPage  educationDetailsPage=new EducationDetailsPage(driver);
//educationDetailsPage.fillEducationDetailsForm(
//	    " Anatomy",   // qualification
//	    "BE Mech",           // short name
//	    "2020",              // year of passing
//	    "GOVERNMENT MEDICAL COLLEGE ERNAKULAM",      // institution
//	    "Mumbai",            // city
//	    "India"              // country
//	);
//
//	educationDetailsPage.clickSaveAndContinue();
//
//
//
//}
//@Test(dataProvider = "getDataForLogin", priority = 5, dependsOnMethods = "educationDetails")
//public void councilDetails(HashMap<String, String> input) {
//
//    CouncilPage councilDetailsPage = new CouncilPage(driver);
//
//    councilDetailsPage.fillCouncilDetails(
//      "12",    // Council Number
//       "Andhra Pradesh State Dental Council",      // Select Council (dropdown value)
//       "01/02/1988"  // Date of Registration in format "DD/MM/YYYY"
//    );
//
//    councilDetailsPage.clickSaveAndContinue();
//}
//@Test(dataProvider = "getDataForLogin", priority = 6, dependsOnMethods = "councilDetails")
//public void experienceDetails(HashMap<String, String> input) throws InterruptedException {
//    ExperienceDetailsPage experiencePage = new ExperienceDetailsPage(driver);
//
//    experiencePage.fillExperienceDetailsForm(
//            "Apollo Hospital",  // Hospital Name
//            "Automation QA Lead",   // Designation
//            "01/01/2015",       // Start Date (DD/MM/YYYY)
//            "8/1/2025"        // End Date (DD/MM/YYYY)
//        );
//
//    experiencePage.clickSaveAndContinue();
//}
//@Test(priority = 7, dependsOnMethods = "experienceDetails")
//public void accreditationDetails() {
//	AccreditationDetailsPage accreditationPage = new AccreditationDetailsPage(driver);
//
//    accreditationPage.fillAccreditationDetailsForm(
//        "Academy of Hospital Administration (AHA)",
//        "Standard compliance",
//        "20/01/2020"
//    );
//
////    accreditationPage.clickAddButton();    // Optional: if needed to add to table/list
//    accreditationPage.clickSaveButton();
//}
//
//@Test(priority = 8, dependsOnMethods = "accreditationDetails")
//public void fillDigitalSignatureForm() {
//	
//	
//    DigitalSignaturePage dsp = new DigitalSignaturePage(driver);
//
//    dsp.selectPages("Prescription");
//    dsp.enterSignatureLabel("Dr. John Signature");
//    dsp.uploadSignatureFile("C:\\Users\\ezobgvmuser\\Pictures\\Screenshots\\Screenshot (19).png");
//    dsp.chooseSignatureColor("black");
//    dsp.drawSignature(driver);
//    dsp.clickSave();
//}
//
//@Test(priority = 9, dependsOnMethods = "accreditationDetails")
//public void ProfileFormPage() {
//	
//	ProfileFormPage formPage = new ProfileFormPage(driver);
//
//	formPage.enterAbout("Experienced medical professional");
//	formPage.enterWorkExperience("5 years at City Hospital");
//	formPage.enterQualification("MBBS, MD");
//	formPage.enterEducation("XYZ Medical University");
//	formPage.enterMemberships("Indian Medical Association");
//	formPage.enterAwards("Best Doctor 2020");
//	formPage.enterSpecialities("Cardiology");
//	formPage.enterServiceAvailed("Inpatient and Outpatient");
//	formPage.enterRegistration("Reg123456");
//	formPage.clickSaveButton();
//}
//
//@Test(priority = 10, dependsOnMethods = "ProfileFormPage")
//public void DoctorDashboard() {
//	
//	DoctorDashboardSetting visitPage = new DoctorDashboardSetting(driver);
//
//	visitPage.enterMorningVisitTime("06:30 AM");
//	visitPage.enterAfternoonVisitTime("01:00 PM");
//	visitPage.enterEveningVisitTime("06:00 PM");
//	visitPage.enterNightVisitTime("09:30 PM");
//
//	visitPage.enterFutureAlert("2");
//	visitPage.enterPastAlert("1");
//
//	visitPage.setShowFutureTasks(true);
//	visitPage.setShowVideoCallTasks(true);
//
//	visitPage.selectDefaultTab("OT");
//
//	visitPage.enterNotificationSection("Lab and Radiology Alerts");
//
//	visitPage.setLabReportAlert(true);
//	visitPage.setRadiologyReportAlert(false);
//
//	visitPage.clickSave();
//
//}

    
    @DataProvider
    public Object[][] getDataForLogin() throws IOException {
        List<HashMap<String, String>> data = getJsonDataToMap(
            System.getProperty("user.dir") + "//src//main//java//ezion//Resources//WareHouseMaster.json"
        );
        return new Object[][] { { data.get(0) } };
    }
}
