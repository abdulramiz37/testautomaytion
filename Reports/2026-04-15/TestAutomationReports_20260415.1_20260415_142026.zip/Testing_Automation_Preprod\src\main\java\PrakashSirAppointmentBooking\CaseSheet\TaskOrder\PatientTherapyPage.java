package PrakashSirAppointmentBooking.CaseSheet.TaskOrder;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class PatientTherapyPage extends Abstraction {

    WebDriver driver;

    public PatientTherapyPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // --- Section Toggle ---
    @FindBy(xpath = "//a[normalize-space()='Therapy']")
    private WebElement therapySection;

    // --- Dropdowns ---
    @FindBy(xpath = "//label[contains(text(),'Therapy')]/following::ngx-select[1]")
    private WebElement therapyDropdown;

    @FindBy(xpath = "//label[contains(text(),'Therapist Name')]/following::ngx-select[1]//input")
    private WebElement therapistDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='performDoc']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement performingDoctorDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='performNurse']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement performingNurseDropdown;

    // --- Text Fields ---
    @FindBy(xpath = "//input[@formcontrolname='result']")
    private WebElement improvementMarksInput;

    @FindBy(xpath = "//textarea[@formcontrolname='notes']")
    private WebElement notesTextarea;

    // --- Duration ---
    private String durationXpath = "//ul[@class='healper-input']//a[normalize-space(text())='%s']";

    // --- Buttons ---
    @FindBy(xpath = "//input[@value='Add Therapy']")
    private WebElement addTherapyBtn;

    @FindBy(xpath = "//input[@value='Reset']")
    private WebElement resetBtn;


    // --- Actions ---
    public void clickTherapyTab() {
    	therapySection.click();
    }
    public void selectTherapy(String therapy) {
        therapyDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[@role='menu']//li[@role='menuitem']/a/span[normalize-space(text())='" + therapy + "']"));
        option.click();
    }

    public void selectTherapists(String... therapists) {
        for (String therapist : therapists) {
            therapistDropdown.click();
            WebElement option = driver.findElement(By.xpath(
                "//ul[@role='menu']//li[@role='menuitem']/a/span[normalize-space(text())='" + therapist + "']"));
            option.click();
        }
    }


    public void enterImprovementMarks(String marks) {
        improvementMarksInput.clear();
        improvementMarksInput.sendKeys(marks);
    }

    public void selectDuration(String duration) {
        WebElement option = driver.findElement(By.xpath(String.format(durationXpath, duration)));
        option.click();
    }

    public void selectPerformingDoctor(String doctor) {
        performingDoctorDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + doctor + "']"));
        option.click();
    }

    public void selectPerformingNurse(String nurse) {
        performingNurseDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + nurse + "']"));
        option.click();
    }

    public void enterNotes(String notes) {
        notesTextarea.clear();
        notesTextarea.sendKeys(notes);
    }

    public void clickAddTherapy() {
        addTherapyBtn.click();
    }

    public void clickReset() {
        resetBtn.click();
    }
}
