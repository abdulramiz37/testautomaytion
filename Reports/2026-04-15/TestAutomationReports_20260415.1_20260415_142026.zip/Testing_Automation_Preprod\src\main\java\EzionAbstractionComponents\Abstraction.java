package EzionAbstractionComponents;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import EzionpageObjects.NewRegistration;
import PharmacyFlowObjects.MasterSetupPage;
import PharmacyFlowObjects.MasterSetupUpdate;
import PharmacyFlowObjects.RolesManagementPage;
import PharmacyIndentFlow.IndentApprovalTablePage;
import PharmacyIndentFlow.IndentRequestPage;
import PharmacyPurchaseOrder.PharmacyPurchaseOrderPage;
import PharmacyPurchaseReturn.PharmacyPurchasePage;
import PharmacyPurchaseReturn.PurchaseReturnPage;
import PharmacySalesPage.SalesPage;

public class Abstraction {

	protected WebDriver driver;
	protected JavascriptExecutor js;

	public Abstraction(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
		this.js = (JavascriptExecutor) driver;

	}

	@FindBy(xpath = "//a[@title='Registration']")
	private WebElement registrationElement;

	@FindBy(xpath = "//span[text()='Admin']")
	private WebElement adminTab;

	@FindBy(xpath = "//span[text()='Roles Management']")
	private WebElement rolesManagement;

	@FindBy(xpath = "//a[@title='Masters']")
	private WebElement mastersTab;

	@FindBy(xpath = "//a[@title='Master Set-up']")
	private WebElement masterSetupTab;

	@FindBy(xpath = "//div[@class='back-icon']")
	private WebElement backIcon;

	@FindBy(xpath = "//h4[text()=' Pharmacy']")
	private WebElement pharmacyHeading;

	@FindBy(xpath = "//span[text()='Pharmacy']")
	private WebElement pharmacyTab;

	@FindBy(xpath = "(//span[text()='Purchase'])[1]")
	private WebElement purchaseMenu;

	@FindBy(xpath = "(//span[text()='Indent'])[1]")
	private WebElement indent;
//    (//span[text()='Indent Approval'])[1]
	@FindBy(xpath = "(//span[text()='Indent Approval'])[1]")
	private WebElement indentApproval;

	@FindBy(xpath = "(//span[text()='Internal Indent'])[1]")
	private WebElement indentRequest;

	@FindBy(xpath = "(//span[text()='Purchase Order'])[1]")
	private WebElement orderMenu;
//    (//span[text()='Internal Indent'])[1]
	@FindBy(xpath = "(//span[text()='Purchase Return'])[1]")
	private WebElement purchaseReturnMenu;

	@FindBy(xpath = "(//span[text()='Sales'])[1]")
	private WebElement sales;

	@FindBy(xpath = "(//span[text()='Sales'])[2]")
	private WebElement sales2;
	// a[@title='Pharmacy']

	public void clickBackButton() {
		backIcon.click();
	}
	public String todayDate = LocalDate.now().format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));
	// Wait for visibility and return the WebElement
	public WebElement waitForVisibility(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		return wait.until(ExpectedConditions.visibilityOf(element));
	}

	public void masterSetupOpenOnly() {
		waitForClickability(masterSetupTab).click();
	}

	public List<WebElement> waitForVisibility(List<WebElement> element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		return wait.until(ExpectedConditions.visibilityOfAllElements(element));
	}

	// Wait for clickability and return the WebElement
	public WebElement waitForClickability(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		return wait.until(ExpectedConditions.elementToBeClickable(element));
	}

	public WebElement waitForClickability(By by) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		return wait.until(ExpectedConditions.elementToBeClickable(by));
	}

	public NewRegistration clickOnRegistration() throws InterruptedException {

		WebElement registrationElements = waitForVisibility(registrationElement);
		registrationElements.click();
		NewRegistration newregister = new NewRegistration(driver);
		return newregister;
	}

	public void navigateToPurchaseWithRetry() {
		for (int i = 0; i < 3; i++) {
			try {
				WebElement pharmacy = waitForClickability(pharmacyTab);
				pharmacy.click();

				WebElement purchase = waitForClickability(purchaseMenu);
				purchase.click();
				System.out.println("✅ Navigation to Purchase successful on attempt " + (i + 1));
				break;
			} catch (Exception e) {
				System.out.println("❌ Attempt " + (i + 1) + " failed: " + e.getMessage());
				if (i == 4)
					throw e;
			}
		}
	}

	public void navigateToIndentWithRetry() {
		for (int i = 0; i < 5; i++) {
			try {
				WebElement pharmacy = waitForClickability(pharmacyTab);
				pharmacy.click();

				WebElement purchase = waitForClickability(indent);
				purchase.click();
				System.out.println("✅ Navigation to Purchase successful on attempt " + (i + 1));
				break;
			} catch (Exception e) {
				System.out.println("❌ Attempt " + (i + 1) + " failed: " + e.getMessage());
				if (i == 4)
					throw e;
			}
		}
	}

	public void navigateSalesWithRetry() {
	    for (int i = 0; i < 5; i++) {
	        try {
	        	System.out.println("Page Source Length: " + driver.getPageSource().length());
	        	 byTextAttach("Analytics", "/ancestor::div[1]//li//nb-icon//img[@class='menuicons']").click();
	            WebElement pharmacy = waitForClickability(pharmacyTab);
	            clickWithJavaScript(pharmacy);

	            WebElement sales1 = waitForClickability(sales);
	            clickWithJavaScript(sales1);
	            System.out.println("✅ Navigation to Sales successful on attempt " + (i + 1));
	            break;

	        } catch (Exception e) {
	            System.out.println("❌ Attempt " + (i + 1) + " failed: " + e.getMessage());

	            if (i == 4) throw e;

	            try { Thread.sleep(1000); } catch (InterruptedException ie) {}
	        }
	    }
	}

	public void navigateSalesWithRetrystart() {
	    for (int i = 0; i < 5; i++) {
	        try {
	        	System.out.println("Page Source Length: " + driver.getPageSource().length());
	        	 byTextAttach("Analytics", "/ancestor::div[1]//li//nb-icon//img[@class='menuicons']").click();
//	            WebElement pharmacy = waitForClickability(pharmacyTab);
//	            clickWithJavaScript(pharmacy);
//
//	            WebElement sales1 = waitForClickability(sales);
//	            clickWithJavaScript(sales1);
//	            System.out.println("✅ Navigation to Sales successful on attempt " + (i + 1));
	            break;

	        } catch (Exception e) {
//	            System.out.println("❌ Attempt " + (i + 1) + " failed: " + e.getMessage());

	            if (i == 4) throw e;

	            try { Thread.sleep(1000); } catch (InterruptedException ie) {}
	        }
	    }
	}

	public void navigateSalesWithRetry2() {
		for (int i = 0; i < 10; i++) {
			try {
				WebElement pharmacy = waitForClickability(pharmacyTab);
				pharmacy.click();

				WebElement sales1 = waitForClickability(sales);
				sales1.click();
				waitForClickability(sales2).click();
				System.out.println("✅ Navigation to Purchase successful on attempt " + (i + 1));
				break;
			} catch (Exception e) {
				System.out.println("❌ Attempt " + (i + 1) + " failed: " + e.getMessage());
				if (i == 4)
					throw e;
			}
		}
	}

	@FindBy(xpath = "//a[.//span[normalize-space()='Sales Dashboard']]")
	private WebElement salesDashboardLink;

	public void openSalesDashboard() {
		waitForClickability(salesDashboardLink).click();
	}

	public void navigateSalesWithRetry3() {
		for (int i = 0; i < 10; i++) {
			try {
				WebElement pharmacy = waitForClickability(pharmacyTab);
				pharmacy.click();

				WebElement sales1 = waitForClickability(sales);
				sales1.click();

				openSalesDashboard();
				System.out.println("✅ Navigation to Purchase successful on attempt " + (i + 1));
				break;
			} catch (Exception e) {
				System.out.println("❌ Attempt " + (i + 1) + " failed: " + e.getMessage());
				if (i == 4)
					throw e;
			}
		}
	}

	public WebElement waitForInvisibility(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.invisibilityOf(element));
		return element;
	}

	public WebElement waitForClickability(WebElement element, int seconds) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(seconds));
		return wait.until(ExpectedConditions.elementToBeClickable(element));
	}

	public WebElement waitForVisibility(WebElement element, int seconds) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(seconds));
		return wait.until(ExpectedConditions.visibilityOf(element));
	}

	public List<WebElement> waitForVisibility(List<WebElement> element, int seconds) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(seconds));
		return wait.until(ExpectedConditions.visibilityOfAllElements(element));
	}

	public void timeoutElement() throws InterruptedException {

	}

	public void clickWithJavaScript(WebElement element) {
		try {
			js.executeScript("arguments[0].click();", element);
		} catch (Exception e) {
			System.out.println("JS click failed: " + e.getMessage());
		}
	}

	public void clickWithJavaScript(By element) {
		try {
			js.executeScript("arguments[0].click();", element);
		} catch (Exception e) {
			System.out.println("JS click failed: " + e.getMessage());
		}
	}

	public RolesManagementPage openRolesManagement() {
		for (int i = 0; i < 5; i++) {
			try {

				waitForClickability(adminTab).click();
				waitForClickability(rolesManagement).click();
				return new RolesManagementPage(driver);
			} catch (Exception e) {
				System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
				if (i == 4)
					throw new RuntimeException("Failed to open Roles Management", e);
			}
		}

		throw new RuntimeException("Unexpected error in openRolesManagement");
	}

	public PharmacyPurchasePage purchasePage() {
		navigateToPurchaseWithRetry();
		PharmacyPurchasePage purchasePage = new PharmacyPurchasePage(driver);

		return purchasePage;
	}

	public PurchaseReturnPage returnPage() {
//    	
		PurchaseReturnPage purchaseReturn = new PurchaseReturnPage(driver);
//    	navigateToPurchaseWithRetry();
		waitForClickability(purchaseReturnMenu).click();
		return purchaseReturn;
	}

	public PharmacyPurchaseOrderPage orderPage() {
		navigateToPurchaseWithRetry();
		waitForClickability(orderMenu).click();
		PharmacyPurchaseOrderPage purchaseOrder = new PharmacyPurchaseOrderPage(driver);
		return purchaseOrder;

	}

	public IndentRequestPage indentPage() {
		navigateToIndentWithRetry();
		waitForClickability(indentRequest).click();
		IndentRequestPage indentPage = new IndentRequestPage(driver);
		return indentPage;

	}

	public IndentApprovalTablePage indentApproval() {
		navigateToIndentWithRetry();
		clickWithJavaScript(indentApproval);
		IndentApprovalTablePage indentApproval = new IndentApprovalTablePage(driver);
		return indentApproval;

	}

//    public IndentApprovalTablePage indentStock() {
//    	navigateToIndentWithRetry();
//    	 waitForClickability(indentApproval).click();
//    	 IndentApprovalTablePage indentApproval= new IndentApprovalTablePage(driver);
//    	 return indentApproval;
//    	
//    }
	public SalesPage sales() {
		navigateSalesWithRetry();
		waitForClickability(sales2).click();
		SalesPage salesPage = new SalesPage(driver);
		return salesPage;

	}

	public MasterSetupPage openMasterSetup() {
		for (int i = 0; i < 5; i++) {
			try {

				waitForClickability(mastersTab).click();
				waitForClickability(masterSetupTab).click();
				return new MasterSetupPage(driver);
			} catch (Exception e) {
				System.out.println("Attempt " + (i + 1) + " failed in Master Set-up: " + e.getMessage());
				if (i == 4)
					throw new RuntimeException("Failed to open Master Set-up", e);
			}
		}
		return null;
	}

	public MasterSetupUpdate openMasterSetup1() {
		for (int i = 0; i < 5; i++) {
			try {

				waitForClickability(mastersTab).click();
				waitForClickability(masterSetupTab).click();
				return new MasterSetupUpdate(driver);
			} catch (Exception e) {
				System.out.println("Attempt " + (i + 1) + " failed in Master Set-up: " + e.getMessage());
				if (i == 4)
					throw new RuntimeException("Failed to open Master Set-up", e);
			}
		}
		return null;
	}

	public void waitForPharmacyPageWithBackClick() {
		for (int i = 0; i <= 10; i++) {
			try {
				waitForClickability(backIcon, 1).click(); // waits 3 seconds max
				waitForVisibility(pharmacyHeading, 3); // waits 3 seconds max

				System.out.println("Pharmacy page is visible.");
				break;
			} catch (Exception e) {
				System.out.println("Attempt " + (i + 1) + ": Pharmacy not visible yet.");
				if (i == 4) {
					throw new RuntimeException("Failed to navigate back to Pharmacy page", e);
				}
			}
		}
	}

	public void waitForPharmacyPageWithBackClickOnce() {
		for (int i = 0; i <= 10; i++) {
			try {
				waitForClickability(backIcon, 1).click(); // waits 3 seconds max

				waitForVisibility(pharmacyHeading, 3);
				System.out.println("harmacy page is visible.");
				break;
			} catch (Exception e) {
				System.out.println("Attempt " + (i + 1) + ": Pharmacy not visible yet.");
				if (i == 4) {
					throw new RuntimeException("Failed to navigate back to Pharmacy page", e);
				}
			}
		}
	}

	public List<WebElement> waitForPresenceOfAll(By locator) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		return wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(locator));
	}

	public void waitForUrl(String expectedUrl) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.urlToBe(expectedUrl));
	}

	public void waitForUrlContains(String partialUrl) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.urlContains(partialUrl));
	}

	public void waitForPharmacyPageWithBackClickOnce2() {
		By backIconLocator = By.xpath("//i[@class='fa fa-chevron-left']");
		By pharmacyHeadingLocator = By.xpath("//h4[text()=' Pharmacy']");

		for (int i = 0; i < 5; i++) {
			try {
				WebElement backIconElement = driver.findElement(backIconLocator);
				js.executeScript("arguments[0].click();", backIconElement);

				WebDriverWait shortWait = new WebDriverWait(driver, Duration.ofSeconds(3));
				shortWait.until(ExpectedConditions.visibilityOfElementLocated(pharmacyHeadingLocator));

				System.out.println("Pharmacy page is visible.");
				break;
			} catch (Exception e) {
				System.out.println("Attempt " + (i + 1) + ": Pharmacy page not visible yet.");
				if (i == 4) {
					throw new RuntimeException("Failed to load Pharmacy page after 5 attempts", e);
				}
			}
		}
	}

	public void selectTypeFromNgxSelect(String optionText) {

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		// Select option
		WebElement option = wait.until(ExpectedConditions.elementToBeClickable(By
				.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + optionText + "']")));
		option.click();
	}

	public void uploadFileByLabel(String labelText, String filePath) {

		WebElement fileInput = driver.findElement(
				By.xpath("//label[normalize-space()='" + labelText + "']" + "/following::input[@type='file'][1]"));

		if (fileInput.isDisplayed() && fileInput.isEnabled()) {
			fileInput.sendKeys(filePath);
			return;
		}

		throw new RuntimeException("File upload input not found for label '" + labelText + "'");
	}
	public void clickLightboxClose(String labelText, int i) {

		 WebElement closeBtn = driver.findElement(
			        By.xpath("(//div[contains(@class,'" + labelText + "')]//i)[" + i + "]")
			    );

			    if (closeBtn.isDisplayed()) {
			        closeBtn.click();
			    } else {
			        throw new RuntimeException("Lightbox close button not visible");
			    }

		throw new RuntimeException("File upload input not found for label '" + labelText + "'");
	}
	public void clickLightboxClose() {
		WebElement closeBtn = driver.findElement(By.xpath("//div[contains(@class,'lightbox-close')]//i"));

		if (closeBtn.isDisplayed()) {
			closeBtn.click();
		} else {
			throw new RuntimeException("Lightbox close button not visible");
		}
	}

	public void robotEnter() {
		try {
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
		} catch (Exception e) {
			throw new RuntimeException("Robot ENTER failed", e);
		}
	}

    public void clickActionByCategory2(String categoryName, String actionTitle) {

	    WebElement actionBtn = driver.findElement(
	        By.xpath(
	            "//tbody//tr[td[normalize-space()='" + categoryName + "']]"
	          + "//img[@title='" + actionTitle + "']"
	        )
	    );

	    actionBtn.click();
	}

	public void clickActionByCategory(String categoryName, String actionTitle) {

		By actionLocator = By.xpath(
				"//tbody//tr[td[normalize-space()='" + categoryName + "']]" + "//a[@title='" + actionTitle + "']");

		By nextBtnLocator = By.xpath("//div[contains(@class,'pagi-block-right')]//a");

		while (true) {

			// 🔍 SEARCH AGAIN on current page
			List<WebElement> actionBtns = driver.findElements(actionLocator);

			if (!actionBtns.isEmpty()) {
				actionBtns.get(0).click();
				return;
			}

			// 👉 If not found, move to next page
			List<WebElement> nextBtns = driver.findElements(nextBtnLocator);

			if (nextBtns.isEmpty() || !nextBtns.get(0).isEnabled()) {
				throw new RuntimeException(
						"Category '" + categoryName + "' with action '" + actionTitle + "' not found in any page");
			}

			nextBtns.get(0).click();

			// ⏳ wait for new page data to load
			waitForTableReload();
		}
	}
	
	public void clickActionByCategoryt(String categoryName,String action) {

		By actionLocator = By.xpath(
				"//tbody//tr[td[normalize-space()='" + categoryName + "']]" + action);

		By nextBtnLocator = By.xpath("//div[contains(@class,'pagi-block-right')]//a");

		while (true) {

			// 🔍 SEARCH AGAIN on current page
			List<WebElement> actionBtns = driver.findElements(actionLocator);

			if (!actionBtns.isEmpty()) {
				actionBtns.get(0).click();
				return;
			}

			// 👉 If not found, move to next page
			List<WebElement> nextBtns = driver.findElements(nextBtnLocator);

			if (nextBtns.isEmpty() || !nextBtns.get(0).isEnabled()) {
				throw new RuntimeException(
						"Category '" + categoryName + "' with action '" + "' not found in any page");
			}

			nextBtns.get(0).click();

			// ⏳ wait for new page data to load
			waitForTableReload();
		}
	}

	public void clickActionByCategoryttt(String categoryName,String action) {

		By actionLocator = By.xpath(
				"//tbody//tr[td[normalize-space(text()[1])='" + categoryName + "']]" + action);

		By nextBtnLocator = By.xpath("//div[contains(@class,'pagi-block-right')]//a");

		while (true) {

			// 🔍 SEARCH AGAIN on current page
			List<WebElement> actionBtns = driver.findElements(actionLocator);

			if (!actionBtns.isEmpty()) {
				actionBtns.get(0).click();
				return;
			}

			// 👉 If not found, move to next page
			List<WebElement> nextBtns = driver.findElements(nextBtnLocator);

			if (nextBtns.isEmpty() || !nextBtns.get(0).isEnabled()) {
				throw new RuntimeException(
						"Category '" + categoryName + "' with action '" + "' not found in any page");
			}

			nextBtns.get(0).click();

			// ⏳ wait for new page data to load
			waitForTableReload();
		}
	}

	private void waitForTableReload() {
		new WebDriverWait(driver, Duration.ofSeconds(5))
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tbody//tr")));
	}

	public void clickByText(String text) {
		driver.findElement(By.xpath("//*[normalize-space(text())='" + text + "']")).click();
	}
	
	public void clickByTextJS(String text) {
	    WebElement element = driver.findElement(
		        By.xpath("//*[normalize-space(text())='" + text + "']"));

		    JavascriptExecutor js = (JavascriptExecutor) driver;
		    js.executeScript(
			        "arguments[0].scrollIntoView({block: 'center', inline: 'nearest'});",
			        element
			    );
		
	}
	
	public WebElement byTextAttach(String text, String attachXpath) {
	    return driver.findElement(
	        By.xpath("//*[normalize-space(text())='" + text + "']" + attachXpath)
	    );
	    
	}
	public WebElement byTextAttachClickable(String text, String attachXpath) {

	    By locator = By.xpath("//*[normalize-space(text())='" + text + "']" + attachXpath);

	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

	    return wait.until(ExpectedConditions.elementToBeClickable(locator));
	}
	public void jsSendKeysByText(String label, String attachXpath, String value) {

	    WebElement input = byTextAttach(label, attachXpath);
	    
	    JavascriptExecutor js = (JavascriptExecutor) driver;

	    // Clear existing value
	    js.executeScript("arguments[0].value='';", input);

	    // Set new value
	    js.executeScript("arguments[0].value=arguments[1];", input, value);
	}
	public void hoverByTextAttach(String text, String attachXpath) {
	    WebElement element = byTextAttach(text, attachXpath);

	    Actions actions = new Actions(driver);
	    actions.moveToElement(element).perform();
	}

	public void scrollToElementCenter(WebElement element) {

	    JavascriptExecutor js = (JavascriptExecutor) driver;

	    js.executeScript(
	        "arguments[0].scrollIntoView({block: 'center', inline: 'nearest'});",
	        element
	    );
	}
	public void clickByTextAttachJS(String text, String attachXpath) {
	    WebElement element = byTextAttach(text, attachXpath);
	    
	    JavascriptExecutor js = (JavascriptExecutor) driver;
	    js.executeScript("arguments[0].click();", element);
	}

	public void clickByText(String text, int i) {
	    WebElement element = driver.findElement(
	        By.xpath("(//*[normalize-space(text())='" + text + "'])[" + i + "]")
	    );

	    JavascriptExecutor js = (JavascriptExecutor) driver;
	    js.executeScript("arguments[0].click();", element);
	}


	public void clickByButtonValue(String value) {
		driver.findElement(By.xpath("//input[@value='" + value + "']")).click();
	}
	public void clickByButtonValue(String value, int i) {

	    driver.findElement(
	        By.xpath("(//input[@value='" + value + "'])[" + i + "]")
	    ).click();
	}
	public void clickDropdown(String sectionName, String fieldName) {

		List<WebElement> dropdowns = driver.findElements(By.xpath("//div[.//div[normalize-space()='" + sectionName
				+ "']]//" + "ngx-select[@formcontrolname='" + fieldName + "']//div"));

		for (WebElement dropdown : dropdowns) {
			try {
				if (dropdown.isDisplayed() && dropdown.isEnabled()) {
					dropdown.click();
					return; // stop after successful click
				}
			} catch (Exception e) {
				// try next element
			}
		}

		throw new RuntimeException(
				"No clickable dropdown found for field '" + fieldName + "' in section '" + sectionName + "'");
	}
	public void enterText(String sectionName, String fieldName, String value) {

		List<WebElement> fields = driver.findElements(By.xpath("//div[.//div[normalize-space()='" + sectionName
				+ "']]//*[ " + "((self::input or self::textarea) and @formcontrolname='" + fieldName + "') " + "or "
				+ "(self::ngx-select[@formcontrolname='" + fieldName + "']//input)" + "]"));

		for (WebElement field : fields) {
			try {
				if (field.isDisplayed() && field.isEnabled()) {

					field.clear();
					field.sendKeys(value);
					return; // stop after successful entry
				}

			} catch (Exception e) {
				// ignore and try next element
			}
		}

		throw new RuntimeException("No editable field found for '" + fieldName + "' in section '" + sectionName + "'");
	}
	
	public void clickActionforinternaldr(String categoryName,String action) {

		By actionLocator = By.xpath(
				"//tbody//tr[td[normalize-space(text()[1])='" + categoryName + "']]" + action);

		By nextBtnLocator = By.xpath("//button[contains(@class,'mat-paginator-navigation-last')]");

		while (true) {

			// 🔍 SEARCH AGAIN on current page
			List<WebElement> actionBtns = driver.findElements(actionLocator);

			if (!actionBtns.isEmpty()) {
				actionBtns.get(0).click();
				return;
			}

			// 👉 If not found, move to next page
			List<WebElement> nextBtns = driver.findElements(nextBtnLocator);

			if (nextBtns.isEmpty() || !nextBtns.get(0).isEnabled()) {
				throw new RuntimeException(
						"Category '" + categoryName + "' with action '" + "' not found in any page");
			}

			nextBtns.get(0).click();

			// ⏳ wait for new page data to load
			waitForTableReload();
		}
	}
	
	public void clickByTextContains(String text) {
	    driver.findElement(By.xpath("//*[contains(text(),'" + text + "')]")).click();
	}
	public void sendKeysInTinyMCE(String label, String attachXpath, String value) {

	    WebElement frame = byTextAttach(label, attachXpath);

	    driver.switchTo().frame(frame);

	    WebElement body = driver.findElement(By.tagName("body"));
	    body.clear();
	    body.sendKeys(value);

	    driver.switchTo().defaultContent();
	}
}
