package PrakashSirAppointmentBooking.CaseSheet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import EzionAbstractionComponents.Abstraction;

public class InstructionPage extends Abstraction {

    WebDriver driver;

    // 🔹 Constructor
    public InstructionPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // ================== LOCATORS ==================

    // Instruction dropdown
    @FindBy(xpath = "//label[contains(text(),'Instruction')]/following::ngx-select[1]/div")
    private WebElement instructionDropdown;

    // Performing Doctor dropdown
    @FindBy(xpath = "(//label[contains(text(),'Performing Doctor')]/following::ngx-select[1])")
    private WebElement performingDoctorDropdown;

    // Performing Nurse dropdown
    @FindBy(xpath = "(//label[contains(text(),'Performing Nurse')]/following::ngx-select[1])")
    private WebElement performingNurseDropdown;

    // Notes textarea
    @FindBy(xpath = "//textarea[@formcontrolname='name']")
    private WebElement notesTextarea;

    // Add button (Plus icon)
    @FindBy(xpath = "(//button[.//nb-icon[@icon='plus-square-outline']])")
    private WebElement addButton;

    // Reset button (Broom icon)
    @FindBy(xpath = "//button[contains(@class,'btn_casereset')]")
    private WebElement resetButton;

    // Success messages
    @FindBy(xpath = "//span[contains(text(),'Instruction Saved Successfully')]")
    private WebElement successSaveMessage;

    @FindBy(xpath = "//span[contains(text(),'Instruction Updated Successfully')]")
    private WebElement successUpdateMessage;

    @FindBy(xpath = "//span[contains(text(),'Instruction Deleted Successfully')]")
    private WebElement successDeleteMessage;

    // Toggle open/close (for Instruction section)
    @FindBy(xpath = "//h4[normalize-space(text())='Task Order']/following::img[contains(@class,'openclose')][1]")
    private WebElement instructionToggleIcon;

    // ================== METHODS ==================

    // Click toggle
    public void clickInstructionToggle() {
        instructionToggleIcon.click();
    }

    // Select Instruction
    public void selectInstruction(String instructionName) {
        clickInstructionToggle();
        instructionDropdown.click();
        driver.findElement(
            By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + instructionName + "']")
        ).click();
    }

    // Select Performing Doctor
    public void selectDoctor(String doctorName) {
        performingDoctorDropdown.click();
        driver.findElement(
            By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + doctorName + "']")
        ).click();
    }

    // Select Performing Nurse
    public void selectNurse(String nurseName) {
        performingNurseDropdown.click();
        driver.findElement(
            By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + nurseName + "']")
        ).click();
    }

    // Enter Notes
    public void enterNotes(String notes) {
        notesTextarea.clear();
        notesTextarea.sendKeys(notes);
    }

    // Click Add button
    public void clickAdd() {
        addButton.click();
    }

    // Click Reset button
    public void clickReset() {
        resetButton.click();
    }

    // Validation messages
    public boolean isSaveMessageDisplayed() {
        return successSaveMessage.isDisplayed();
    }

    public boolean isUpdateMessageDisplayed() {
        return successUpdateMessage.isDisplayed();
    }

    public boolean isDeleteMessageDisplayed() {
        return successDeleteMessage.isDisplayed();
    }
}
