package PharmacyPurchaseReturn;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class Supplier_Dues_Page extends Abstraction{
    public Supplier_Dues_Page(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

	public String clickEditFromSecondTabAndUpdate(String targetSupplierName) {
	    Actions actions = new Actions(driver);
	    boolean isFound = false;
	    String poNumber = "";

	    while (!isFound) {
	        List<WebElement> rows = driver.findElements(
	            By.xpath("(//table)[2][@class='table table-hover']/tbody/tr")
	        );

	        for (int i = 0; i < rows.size(); i++) {
	            try {
	                WebElement row = rows.get(i);

	                // Adjust column indices based on actual table
	                String supplierName = row.findElement(By.xpath("./td[2]")).getText().trim();
	                System.out.println("Supplier: " + supplierName);

	                // There may not be a status column in this table — skip if so
	                if (supplierName.equalsIgnoreCase(targetSupplierName)) {
	                    WebElement editIcon = row.findElement(By.xpath(".//img[contains(@src,'edit.png')]"));
	                    waitForClickability(editIcon).click();
	                    System.out.println("✅ Clicked Edit for Supplier: " + supplierName);
	                    isFound = true;
	                    break;
	                }
	            } catch (NoSuchElementException  e) {
	                System.out.println("⚠️ Skipping row " + i + " due to missing or stale element.");
	            }
	        }

	        if (!isFound) {
	            try {
	                WebElement nextButton = driver.findElement(
	                    By.xpath("//a[@role='button']//i[contains(@class,'fa-chevron-right')]")
	                );
	                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextButton);
//	                Thread.sleep(1000); // wait for page to load next results
	            } catch (NoSuchElementException e) {
	                System.out.println("❌ Next page button not found. Ending search.");
	                break;
	            } 
	        }
	    }
	    return poNumber;
	}
	
	public void clickAccountsMenu() {
	    WebElement element = driver.findElement(By.xpath("(//a[@title='Accounts'])[2]"));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	    waitForClickability(element).click();
	    System.out.println("✅ Clicked on 'Accounts' after ensuring visibility.");
	}
	public void clickCreditNote() {
	    WebElement supplierDues = waitForClickability(
	        driver.findElement(By.xpath("//a[@title='Credit Note']"))
	    );
	    supplierDues.click();
	    System.out.println("✅ Clicked on 'Credit note ' menu successfully.");
	}
	public void clickSupplierDuesMenu() {
	    WebElement supplierDues = waitForClickability(
	        driver.findElement(By.xpath("//a[@title='Supplier Dues']"))
	    );
	    supplierDues.click();
	    System.out.println("✅ Clicked on 'Supplier Dues' menu successfully.");
	}
	public void clickSaveButton() {
	    WebElement saveBtn = driver.findElement(By.xpath("//input[@value='Save']"));
	    try {
	        waitForClickability(saveBtn).click();
	    } catch (Exception e) {
	        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", saveBtn);
	    }
	    System.out.println("✅ Clicked on 'Save' button (with JS fallback).");
	}
	@FindBy(xpath = "//input[@value='Yes']")
	private WebElement yesButton;

	public void clickYesButton() {
	    waitForClickability(yesButton).click();
	    System.out.println("✅ Clicked on 'Yes' button successfully.");
	}
	public void clickSupplierPaymentListMenu() {
	    WebElement element = driver.findElement(By.xpath("//a[@title='Supplier Payment List']"));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	    waitForClickability(element).click();
	    System.out.println("✅ Clicked on 'Supplier Payment List' after ensuring visibility.");
	}
	public void clickPurchaseMenu() {
	    WebElement element = driver.findElement(By.xpath("//a[@title='Purchase Return Adjustment']"));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	    waitForClickability(element).click();
	    System.out.println("✅ Clicked on 'Supplier Payment List' after ensuring visibility.");
	}

}
