package WareHouseSetup.IPpharmacy;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class NursingCounterPage extends Abstraction{
    WebDriver driver;

    public NursingCounterPage(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // ===== LOCATORS =====

    // Building Name dropdown
    @FindBy(xpath = "//label[contains(text(),'Building Name')]/following::ngx-select[1]")
    private WebElement buildingNameDropdown;

    // Floor Name dropdown
    @FindBy(xpath = "//label[contains(text(),'Floor Name')]/following::ngx-select[1]")
    private WebElement floorNameDropdown;

    // Nursing Counter Name text field
    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement nursingCounterNameInput;

    // Is Active checkbox
    @FindBy(xpath = "//input[@formcontrolname='isActive']")
    private WebElement isActiveCheckbox;

    // Save button
    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;

    // Cancel button
    @FindBy(xpath = "//input[@value='Cancel']")
    private WebElement cancelButton;


    // ===== METHODS =====
    
    @FindBy(xpath = "//a[text()=' Nursing Counter ']")
    private WebElement userType;

    @FindBy(xpath = "//a[text()=' Add Nursing Counter ']")
    private WebElement adduserType;

    // 🔹 Methods
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}
 // Select Building Name
    public void selectBuilding(String buildingName) {
        buildingNameDropdown.click();
        WebElement option = driver.findElement(
            By.xpath("//ul[@role='menu']//span[normalize-space()='" + buildingName + "']")
        );
        option.click();
    }

    // Select Floor Name
    public void selectFloor(String floorName) {
        floorNameDropdown.click();
        WebElement option = driver.findElement(
            By.xpath("//ul[@role='menu']//span[normalize-space()='" + floorName + "']")
        );
        option.click();
    }


    public void enterNursingCounterName(String counterName) {
        nursingCounterNameInput.clear();
        nursingCounterNameInput.sendKeys(counterName);
    }

    public void setIsActive(boolean status) {
        if (status && !isActiveCheckbox.isSelected()) {
            isActiveCheckbox.click();
        } else if (!status && isActiveCheckbox.isSelected()) {
            isActiveCheckbox.click();
        }
    }

    public void clickSave() {
        saveButton.click();
    }

    public void clickCancel() {
        cancelButton.click();
    }
}

