package Lab;



	import java.time.Duration;
import java.util.List;
	import java.util.NoSuchElementException;
import java.util.concurrent.TimeoutException;

import org.openqa.selenium.By;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.interactions.Actions;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import EzionAbstractionComponents.Abstraction;

	public class WaitingApprovalPage extends Abstraction{

		public WaitingApprovalPage(WebDriver driver) {
			super(driver);
		    PageFactory.initElements(driver, this);
		}


	    @FindBy(xpath = "//span[text()='Waiting for Approval']")
	    private WebElement adduserType;
	     
	    public void clickbuttonapproval() {
//			waitForClickability(userType).click();
			waitForClickability(adduserType).click();
			WebElement refreshButton = driver.findElement(By.xpath("//a[contains(@class,'repeatcls') and contains(normalize-space(.), 'Refresh')]"));
			refreshButton.click();
		}
		public void clickReorderByWorkOrder(String actualWorkOrder) throws TimeoutException {
			clickbuttonapproval();
			clickbuttonapproval();
			clickbuttonapproval();
			clickbuttonapproval();
			clickbuttonapproval();
			 boolean isFound = false;
			    int retryCount = 0;
			    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		    while (!isFound) {
		        List<WebElement> rows = driver.findElements(
		            By.xpath("(//tbody)[2]/tr[contains(@class,'ng-star-inserted')]")
		        );

		        for (WebElement row : rows) {
		            try {
		                // Get Work Order from 3rd column
		                WebElement workOrderCell = row.findElement(By.xpath(".//td[3]"));
		                String workOrderText = workOrderCell.getText().trim();
		                System.out.println(workOrderText);
		                if (workOrderText.equals(actualWorkOrder)) {
		                    // Bill No is also in 3rd td as per your structure
		                    String billNo = workOrderText;
		                    System.out.println("🧾 Bill No: " + billNo);

		                    // Click Reorder (last <li> in action column)
		                    WebElement reorderBtn = row.findElement(
		                        By.xpath(".//td[contains(@class,'action-table')]//li[last()-2]/a")
		                    );
		                    waitForClickability(reorderBtn);
		                    Actions actions = new Actions(driver);
		                    actions.doubleClick(reorderBtn).perform();


		                    System.out.println("🔄 Clicked Reorder for Work Order: " + actualWorkOrder);
		                    isFound = true;
		                    break;
		                }
		            } catch (NoSuchElementException ignored) {}
		        }

		        if (!isFound) {
	                try {
	                    // ✅ Wait for "Next" button to be clickable
	                    WebElement nextButton = wait.until(ExpectedConditions.elementToBeClickable(
	                        By.xpath("(//tbody)[2]/tr[contains(@class,'ng-star-inserted')]/ancestor::div[1]/ancestor::div[2]//li[contains(@class,'pagination-next')]/a[contains(.,'Next')]")
	                    ));

	                    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextButton);
	                    System.out.println("➡️ Moved to next page...");

	                    // ✅ Wait for table to refresh after clicking next
	                    wait.until(ExpectedConditions.stalenessOf(rows.get(0)));
	                    wait.until(ExpectedConditions.visibilityOfElementLocated(
	                        By.xpath("(//tbody)[2]/tr[contains(@class,'ng-star-inserted')]")
	                    ));

	                } catch (NoSuchElementException e) {
	                    System.out.println("❌ No more pages. Work Order not found.");
	                    break;
	                }
	            }

	        }
	    }


		public void selectApprovalStatus(String statusValue) {
		    String xpath = String.format("//input[@formcontrolname='approvedStatus' and @value='%s']", statusValue);
		    WebElement radioBtn = driver.findElement(By.xpath(xpath));

		    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", radioBtn);
		    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", radioBtn);

		    System.out.println("✅ Selected approval status: " + statusValue);
		    clickSaveButton();
		}

		@FindBy(xpath = "//input[@type='button' and @value='Save' and contains(@class,'btn-primary')]")
		private WebElement saveButton;

		public void clickSaveButton() {
		    saveButton.click();
		    
		    saveButton.click();
		    saveButton.click();
		}

	}


