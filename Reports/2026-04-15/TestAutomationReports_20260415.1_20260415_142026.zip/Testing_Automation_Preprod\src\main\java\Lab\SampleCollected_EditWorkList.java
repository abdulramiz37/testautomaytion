package Lab;

import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeoutException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import EzionAbstractionComponents.Abstraction;

public class SampleCollected_EditWorkList extends Abstraction{

	public SampleCollected_EditWorkList(WebDriver driver) {
		super(driver);
	    PageFactory.initElements(driver, this) ;
	}
	  @FindBy(xpath = "//button[@class=\"btn btn-primary ng-star-inserted\"]")
	    private WebElement saveButton2;

	public void clickEditIconByTestName(String testName) {
	    try {
	        WebElement editIcon = driver.findElement(By.xpath(
	            "//tr[contains(@class,'ng-star-inserted')]" +
	            "[.//td[contains(translate(normalize-space(.), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '" 
	            + testName.toLowerCase() + "')]]" +
	            "//img[contains(@class,'edit-icon')]"
	        ));

	        waitForClickability(editIcon).click();
	        System.out.println("✅ Clicked edit icon for test: " + testName);

	    } catch (NoSuchElementException e) {
	        System.out.println("❌ Test '" + testName + "' not found in table");
	        throw e;
	    }
	}
	@FindBy(xpath = "//textarea[contains(@class,'culture-textarea')]")
    private WebElement cultureTextarea;

	public void editTestValueByTestName(String testName, String newValue,String text) throws TimeoutException {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    try {
	        // ✅ Wait for table rows to appear
	        wait.until(ExpectedConditions.visibilityOfElementLocated(
	            By.xpath("//tbody/tr[contains(@class,'ng-star-inserted')]")
	        ));

	        // ✅ Dynamic XPath for edit icon by test name
	       

	        // ✅ Wait for the input box for that specific test to become visible
	        String inputXpath = "//tr[contains(@class,'ng-star-inserted')]" +
	            "[.//td[contains(translate(normalize-space(.), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '" 
	            + testName.toLowerCase() + "')]]" +
	            "//input[@formcontrolname='value']";

	        WebElement inputField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(inputXpath)));

	        // ✅ Clear and enter new value
	        inputField.clear();
	        inputField.sendKeys(newValue);
	        System.out.println("✏️ Entered new value '" + newValue + "' for test: " + testName);
	        String editIconXpath = "//tr[contains(@class,'ng-star-inserted')]" +
		            "[.//td[contains(translate(normalize-space(.), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '" 
		            + testName.toLowerCase() + "')]]" +
		            "//img[contains(@class,'edit-icon')]";

		        // ✅ Wait for the edit icon to be clickable and click it
		        WebElement editIcon = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(editIconXpath)));
		        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", editIcon);
		        System.out.println("✅ Clicked edit icon for test: " + testName);
		        
		        

	
		            try {
		            

		                cultureTextarea.clear();
		                cultureTextarea.sendKeys(text);
		                saveButton2.click();
		                System.out.println("📝 Entered text into Culture textarea: " + text);
		            } catch (Exception e) {
		                System.out.println("⚠️ Error while entering text into Culture textarea: " + e.getMessage());
		            }
		        


	    } catch (NoSuchElementException e) {
	        System.out.println("❌ Test '" + testName + "' not found in table.");
	        throw e;
	    } catch (Exception e) {
	        System.out.println("⚠️ Unexpected error while editing test '" + testName + "': " + e.getMessage());
	        throw e;
	    }
	}

	   @FindBy(name = "HPNo")
	    private WebElement hpNoField;

	    @FindBy(name = "SpecimanName")
	    private WebElement specimanNameField;

	    @FindBy(xpath = "(//textarea[contains(@class,'culture-textarea')])[1]")
	    private WebElement grossAppearanceField;

	    @FindBy(xpath = "(//textarea[contains(@class,'culture-textarea')])[2]")
	    private WebElement microscopicAppearanceField;

	    @FindBy(xpath = "(//textarea[contains(@class,'culture-textarea')])[3]")
	    private WebElement impressionField;

	    @FindBy(xpath = "(//textarea[contains(@class,'culture-textarea')])[4]")
	    private WebElement notesField;

	    @FindBy(xpath = "//button[@class='btn btn-primary' and text()='Add']")
	    private WebElement addButton;

	    // ---------- Constructor ----------


	    // ---------- Field Methods ----------
	    public void enterHpNo(String hpNo) {
	        hpNoField.clear();
	        hpNoField.sendKeys(hpNo);
	    }

	    public void enterSpecimanName(String specimanName) {
	        specimanNameField.clear();
	        specimanNameField.sendKeys(specimanName);
	    }

	    public void enterGrossAppearance(String text) {
	        grossAppearanceField.clear();
	        grossAppearanceField.sendKeys(text);
	    }

	    public void enterMicroscopicAppearance(String text) {
	        microscopicAppearanceField.clear();
	        microscopicAppearanceField.sendKeys(text);
	    }

	    public void enterImpression(String text) {
	        impressionField.clear();
	        impressionField.sendKeys(text);
	    }

	    public void enterNotes(String text) {
	        JavascriptExecutor js = (JavascriptExecutor) driver;
	        js.executeScript("arguments[0].value = arguments[1];", notesField, text);
	    }

	    public void clickAddButton() {
	        JavascriptExecutor js = (JavascriptExecutor) driver;
	        js.executeScript("arguments[0].click();", addButton);
	    }

	    public void scrollToBottom() {
	        JavascriptExecutor js = (JavascriptExecutor) driver;
	        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
	    }


	    // ---------- Combined Fill Method ----------
	    public void fillHistopathologyForm(String hpNo, String specimanName,
	                                       String grossAppearance, String microscopicAppearance,
	                                       String impression, String notes) {

	        enterHpNo(hpNo);
	        enterSpecimanName(specimanName);
	        enterGrossAppearance(grossAppearance);
	        enterMicroscopicAppearance(microscopicAppearance);
	        enterImpression(impression);
	        scrollToBottom();
	        enterNotes(notes);
	        clickAddButton();
	    }
	    
	    @FindBy(xpath = "(//div[@class='ngx-select__toggle btn form-control'])[2]")
	    private WebElement selectDropdown;
	    
	    public void selectDropdownOption(String value) {
	        WebElement option = driver.findElement(By.xpath("//li[@role='menuitem']//span[normalize-space(text())='" + value + "']"));
	        option.click();
	    }
	    @FindBy(xpath = "//input[@type='button' and @value='Save']")
	    private WebElement saveButton;

	    public void clickSaveButton() {
	        saveButton.click();
	    }

	    public void selectDropdownValue(String value) {
	        // Click the dropdown to open it
	        selectDropdown.click();
	        
	        // Select the desired option dynamically
	        selectDropdownOption(value) ;
	        clickSaveButton();
	    }

	
	}

