package WareHouseSetup.IPpharmacy;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class RoomPage extends Abstraction{

    private WebDriver driver;

    public RoomPage(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // ==================== Locators ====================

    // Building Name Dropdown
    @FindBy(xpath = "//label[contains(normalize-space(),'Building Name')]/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement buildingNameDropdown;

    // Floor Name Dropdown
    @FindBy(xpath = "//label[contains(normalize-space(),'Floor Name')]/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement floorNameDropdown;

    // Room Number Input
    @FindBy(xpath = "//input[@formcontrolname='roomNo']")
    private WebElement roomNumberInput;

    // Is Active Checkbox
    @FindBy(xpath = "//input[@formcontrolname='isActive']")
    private WebElement isActiveCheckbox;

    // Save Button
    @FindBy(xpath = "//input[@type='button' and @value='Save']")
    private WebElement saveButton;

    // Cancel Button
    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
    private WebElement cancelButton;


    // ==================== Methods ====================
    @FindBy(xpath = "//a[text()=' Room ']")
    private WebElement userType;

    @FindBy(xpath = "//a[text()=' Add Room ']")
    private WebElement adduserType;
    
    
    // 🔹 Methods
    
    
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}
    // Select Building
    public void selectBuilding(String buildingName) {
        buildingNameDropdown.click();
        WebElement option = driver.findElement(
            By.xpath("//ul[@role='menu']//span[normalize-space()='" + buildingName + "']"));
        option.click();
    }

    // Select Floor
    public void selectFloor(String floorName) {
        floorNameDropdown.click();
        WebElement option = driver.findElement(
            By.xpath("//ul[@role='menu']//span[normalize-space()='" + floorName + "']"));
        option.click();
    }

    // Enter Room Number
    public void enterRoomNumber(String roomNo) {
        roomNumberInput.clear();
        roomNumberInput.sendKeys(roomNo);
    }

    // Set "Is Active" checkbox
    public void setIsActive(boolean active) {
        if (isActiveCheckbox.isSelected() != active) {
            isActiveCheckbox.click();
        }
    }

    // Click Save
    public void clickSave() {
        saveButton.click();
    }

    // Click Cancel
    public void clickCancel() {
        cancelButton.click();
    }
}
