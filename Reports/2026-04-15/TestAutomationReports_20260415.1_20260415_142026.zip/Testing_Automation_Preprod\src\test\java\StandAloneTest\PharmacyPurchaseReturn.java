package StandAloneTest;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import java.util.List;
import java.util.NoSuchElementException;

public class PharmacyPurchaseReturn {

    WebDriver driver;

    @Test
    public void Return() throws InterruptedException {
        driver =new  ChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize();
        driver.get("https://apps.ezovion.com/auth/login");

        driver.findElement(By.xpath("//div[@class=\"form-control-group\"]//input")).sendKeys("50107299");
        driver.findElement(By.xpath("//button[@size=\"large\"]")).click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
        driver.findElement(By.xpath("//input[@placeholder=\"Mobile No\"]")).sendKeys("7766554433");
        driver.findElement(By.xpath("//input[@placeholder=\"Password\"]")).sendKeys("12345");

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@status=\"primary\"]"))).click();

        for (int i = 0; i < 5; i++) {
            try {
                Thread.sleep(3000); // Optional: can be optimized with expected conditions
                WebElement adminTab = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Admin']")));
                adminTab.click();
                wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Roles Management']"))).click();
                break;
            } catch (Exception e) {
                System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
                if (i == 4) throw e;
            }
        }

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Pharmacy']"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Purchase'])[1]"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Purchase'])[2]"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[text()=' Add Purchase '])[1]"))).click();

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Pharamacy Loaction'])[1]"))).click();

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='supplier name'])[2]"))).click();

        

        int invoiceNo = 52;

        while (true) {
            driver.findElement(By.xpath("//input[@formcontrolname='invNo']")).clear();
            driver.findElement(By.xpath("//input[@formcontrolname='invNo']")).sendKeys(String.valueOf(invoiceNo));
            Thread.sleep(2000); // Wait for validation to appear

            if (driver.findElements(By.xpath("//*[contains(text(), 'Invoice No Already Exists')]")).isEmpty()) {
                System.out.println("✅ Unique Invoice No: " + invoiceNo);
                break; // Stop loop when number is accepted
            }

            invoiceNo++; // Try next number
        }


        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@formcontrolname='invValue'])[1]"))).sendKeys("100");

        WebElement invDate = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[@formcontrolname='invDate']")));
        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].value='06/12/2025'; arguments[0].dispatchEvent(new Event('input'));", invDate);

        WebElement invDueDate = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[@formcontrolname='invDueDate']")));
        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].value='06/12/2025'; arguments[0].dispatchEvent(new Event('input'));", invDueDate);

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Search'])[1]"))).click();
        WebElement syrupItem = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='syrup14 ']")));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", syrupItem);
        


        Thread.sleep(2000); // Suggest replacing with a wait on visibility or condition
        WebElement batchNumberField = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[@formcontrolname='BatchNumber']")));
        batchNumberField.sendKeys("4");
        Thread.sleep(2000);

        WebElement expiryDateInput = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[@formcontrolname='expiryDate']")));
        ((JavascriptExecutor) driver).executeScript(
                "const input = arguments[0];" +
                        "const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;" +
                        "nativeInputValueSetter.call(input, '2027-07');" +
                        "input.dispatchEvent(new Event('input', { bubbles: true }));" +
                        "input.dispatchEvent(new Event('change', { bubbles: true }));",
                expiryDateInput);
        Thread.sleep(2000);

//        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='noOfStrips']"))).sendKeys("4");
//        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='freeStrips']"))).sendKeys("5");
//        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='mrpPerStrip']"))).sendKeys("25");
//        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='pricePerStrip']"))).sendKeys("25");

        // You can uncomment and use the below when you're ready to perform final submission
//         wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='sellPrice']"))).sendKeys("45");
         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Add']"))).click();
         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();
         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value=\"Yes\"]"))).click();
         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value=\"Approve\"]"))).click();
         
      // 1. Click "Purchase Return"
         Thread.sleep(2000);
         
         String grnNo = null;
       //  List<WebElement> rows = driver.findElements(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[2]/tr"));

         boolean matchFound = false;
         System.out.println("Invoice Number: " + invoiceNo);
         while (!matchFound) {
        	    // Relocate the rows before processing
        	    List<WebElement> rows = driver.findElements(By.xpath("//table[contains(@class, 'table-hover')]/tbody/tr"));

        	    // Iterate through rows using a simple for loop
        	    for (int i = 0; i < rows.size(); i++) {  // Use rows.size() to avoid IndexOutOfBounds
        	        try {
        	            // Get the row element using the index
        	            WebElement row = rows.get(i);

        	            // 2. Get the Invoice Number from the row (assuming it's in td[5])
        	            String currentInvoiceNumber = row.findElement(By.xpath(".//td[5]")).getText().trim();
        	            System.out.println("Current Invoice: " + currentInvoiceNumber);

        	            // 3. If the current Invoice Number matches the one you're looking for
        	            if (currentInvoiceNumber.equals(String.valueOf(invoiceNo))) {
        	                // 4. Extract the corresponding GRN No from the first column (assuming it's in td[2])
        	                grnNo = row.findElement(By.xpath(".//td[2]")).getText().trim();
        	                System.out.println("Found GRN No: " + grnNo + " for Invoice Number: " + invoiceNo);
        	                matchFound = true;
        	                break;
        	            }
        	        } catch (NoSuchElementException e) {
        	            // This catches any rows that are missing the expected elements
        	            System.out.println("Row missing expected elements. Skipping...");
        	        }
        	    }

        	    // If no match found, click the "Next Page" button
        	    if (!matchFound) {
        	        try {
        	            // Locate the "Next Page" button
        	            WebElement nextPageButton = driver.findElement(By.xpath("(//i[@class='fas fa-chevron-right'])[1]"));
        	            
        	            // Use JavaScript to click the "Next Page" button
        	       
        	            js.executeScript("arguments[0].click();", nextPageButton);
        	            System.out.println("Clicked on the 'Next Page' button using JavaScript.");

        	            // Wait for the page to load before relocating rows
        	            Thread.sleep(1000); // Adjust wait time as needed
        	        } catch (NoSuchElementException e) {
        	            System.out.println("Next Page button not found. End of pages.");
        	            break; // Stop the loop if the button is not found
        	        } catch (InterruptedException e) {
        	            System.out.println("Thread sleep interrupted.");
        	        }
        	    }
        	}


         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Purchase Return'])[1]"))).click();
//         
         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[text()=' Add Purchase Return'])[1]"))).click();
         // 2. Click first "Select" (e.g., for Pharmacy Location)
//         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();

         // 3. Select "Pharamacy Loaction"
         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Pharamacy Loaction'])[1]"))).click();
         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Pharamacy Loaction'])[1]"))).click();
         // 4. Click "Select" again (for Supplier)
         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click(); // NOTE: This is the same as above. If it's the second dropdown, use index [2].

         // 5. Click "supplier name"
         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='supplier name'])[2]"))).click();

         // 6. Click second "Select" (e.g., for item category)
         String invoiceRange = invoiceNo + " - " + grnNo;

         WebElement option = driver.findElement(By.xpath("//span[text()='" + invoiceRange + "']"));

      // Use JavaScript Executor to click the element
   
      js.executeScript("arguments[0].click();", option);


         // 7. Click "Damaged Items"
         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Damaged Items']"))).click();
       //span[text()='medicine1syrup']
//         wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='syrup10Batch : 45']")));

         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='syrup14']"))).click();
       //input[@formcontrolname='quantity']
         
         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@formcontrolname='quantity']"))).sendKeys("1");
         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Add']"))).click();
         wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//textarea[@formcontrolname='returnRemarks']"))).sendKeys("damaged not usable");

      // 3. Click Save Button
      wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();

      // 4. Confirm with Yes
      wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Yes']"))).click();
      
      Thread.sleep(2000);
    
      String expectedInvoiceNo = String.valueOf(invoiceNo);
      String expectedDate = "June 20, 2025";
      boolean matchFound2 = false;

      while (!matchFound2) {
          // Fetch the rows again for each page (since the page may change after clicking "Next")
          List<WebElement> rows1 = driver.findElements(By.xpath("//table[@class='table table-hover table-style']/tbody/tr"));

          // Iterate through each row on the current page
          for (WebElement row : rows1) {
              String prDate = row.findElement(By.xpath("./td[1]")).getText().trim();
              String invoiceNo2 = row.findElement(By.xpath("./td[4]/h4")).getText().trim();

              // Check if the current row matches the expected Date and Invoice Number
              if ( invoiceNo2.equals(expectedInvoiceNo)) {
                  // Found matching row, click the "Edit" button
                  WebElement editButton = row.findElement(By.xpath(".//img[contains(@src,'edit.png')]"));
                  editButton.click();
                  System.out.println("✅ Clicked Edit for Invoice No: " + invoiceNo2 + " on Date: " + prDate);
                  matchFound2 = true;  // Set flag to true to stop the loop
                  break;  // Exit the loop as the match was found
              }
          }

          // If the match was not found, click the "Next Page" button
          if (!matchFound2) {
              try {
                  // Locate the "Next Page" button
                  WebElement nextPageButton = driver.findElement(By.xpath("(//i[@class='fas fa-chevron-right'])[1]"));
                  
                  // Click the "Next Page" button using JavaScript Executor
            
                  js.executeScript("arguments[0].click();", nextPageButton);
                  System.out.println("Clicked on the 'Next Page' button.");
                  
                  // Wait for the next page to load
                  Thread.sleep(1000);  // Adjust this wait time as per your page load time
              } catch (NoSuchElementException e) {
                  // If there's no "Next Page" button (i.e., end of the pages)
                  System.out.println("No more pages or 'Next Page' button not found.");
                  break;  // Exit the loop as there are no more pages
              } catch (InterruptedException e) {
                  System.out.println("Thread sleep interrupted.");
              }
          }
      }



      wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Update & Approval']"))).click();

         
    }

}
