package PharmacyPurchaseReturn;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class PharmacyPurchasePageNegative extends Abstraction {

    private String generatedInvoiceNo;

    public PharmacyPurchasePageNegative(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    public WebElement getSpanByExactText(String exactText) {
        String xpath = "//span[text()='" + exactText + "']";
        return driver.findElement(By.xpath(xpath));
    }

    public WebElement getInputByFormControl(String formControlName) {
        String xpath = "//input[@formcontrolname='" + formControlName + "']";
        return driver.findElement(By.xpath(xpath));
    }

    @FindBy(xpath = "(//span[text()='Purchase'])[2]")
    private WebElement purchaseMenu;

    @FindBy(xpath = "(//a[text()=' Add Purchase '])[1]")
    private WebElement addPurchaseBtn;

    @FindBy(xpath = "(//span[text()='Select'])[1]")
    private WebElement locationDropdown;

    @FindBy(xpath = "(//span[text()='Search'])[1]")
    private WebElement searchBtn;

    @FindBy(xpath = "//span[text()='syrup14 ']")
    private WebElement syrupItem;

    @FindBy(xpath = "//label[text()='Payable Amt']/following-sibling::p")
    private WebElement payableAmtLabel;

    @FindBy(xpath = "(//input[@formcontrolname='invValue'])[1]")
    private WebElement invoiceValueInput;

    @FindBy(xpath = "//input[@value='Add']")
    private WebElement addBtn;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveBtn;

    @FindBy(xpath = "//input[@value='Yes']")
    private WebElement yesBtn;

    @FindBy(xpath = "//input[@value='Approve']")
    private WebElement approveBtn;

    @FindBy(xpath = "(//span[text()='Search'])[1]")
    private WebElement searchMedicineBtn;
    
    @FindBy(xpath = "//input[@formcontrolname='invNo']/following-sibling::span[contains(text(),'Invoice No Already Exists')]")
    WebElement invoiceNumberErrorMessage;

    @FindBy(xpath = "//input[@formcontrolname='noOfStrips']/following-sibling::ngx-validation-message//p[contains(text(),'Incorrect No Of Strips')]")
    WebElement noOfStripsErrorMessage;

    @FindBy(xpath = "//input[@formcontrolname='freeStrips']/following-sibling::ngx-validation-message//p[contains(text(),'Incorrect Free Strips')]")
    WebElement freeStripsErrorMessage;

    @FindBy(xpath = "//input[@formcontrolname='mrpPerStrip']/following-sibling::ngx-validation-message//p[contains(text(),'Incorrect MRP Per Strip')]")
    WebElement mrpErrorMessage;

    @FindBy(xpath = "//input[@formcontrolname='pricePerStrip']/following-sibling::ngx-validation-message//p[contains(text(),'Incorrect Price Per Strip')]")
    WebElement costPriceErrorMessage;

    @FindBy(xpath = "//input[@formcontrolname='sellPrice']/following-sibling::ngx-validation-message//p[contains(text(),'Incorrect Sell Price')]")
    WebElement sellPriceErrorMessage;

    // Example waitForVisibility method, assumed to be available in your base class
    @FindBy(xpath = "//input[@formcontrolname='invNo']/following-sibling::ngx-validation-message//p")
    WebElement invoiceNumberErrorMessage2;

    @FindBy(xpath = "//input[@formcontrolname='invDate']/following-sibling::ngx-validation-message//p")
    WebElement invoiceDateErrorMessage;

    @FindBy(xpath = "//input[@formcontrolname='invDueDate']/following-sibling::ngx-validation-message//p")
    WebElement invoiceDueDateErrorMessage;

    public String getInvoiceNumberErrorMessage2() {
        waitForVisibility(invoiceNumberErrorMessage2);
        System.out.println(invoiceNumberErrorMessage2.getText().trim());
        return invoiceNumberErrorMessage2.getText().trim();
    }

    public String getInvoiceDateErrorMessage() {
        waitForVisibility(invoiceDateErrorMessage);
        System.out.println(invoiceDateErrorMessage.getText().trim());
        return invoiceDateErrorMessage.getText().trim();
    }

    public String getInvoiceDueDateErrorMessage() {
        waitForVisibility(invoiceDueDateErrorMessage);
        System.out.println(invoiceDueDateErrorMessage.getText().trim());
        return invoiceDueDateErrorMessage.getText().trim();
    }
    public String getInvoiceNumberErrorMessage() {
        waitForVisibility(invoiceNumberErrorMessage);
        return invoiceNumberErrorMessage.getText().trim();
    }

    public String getNoOfStripsErrorMessage() {
        waitForVisibility(noOfStripsErrorMessage);
        return noOfStripsErrorMessage.getText().trim();
    }

    public String getFreeStripsErrorMessage() {
        waitForVisibility(freeStripsErrorMessage);
        return freeStripsErrorMessage.getText().trim();
    }

    public String getMrpErrorMessage() {
        waitForVisibility(mrpErrorMessage);
        return mrpErrorMessage.getText().trim();
    }

    public String getCostPriceErrorMessage() {
        waitForVisibility(costPriceErrorMessage);
        return costPriceErrorMessage.getText().trim();
    }

    public String getSellPriceErrorMessage() {
        waitForVisibility(sellPriceErrorMessage);
        return sellPriceErrorMessage.getText().trim();
    }
    
    public String getGeneratedInvoiceNo() {
        return generatedInvoiceNo;
    }

    public void getMedicineByName(String medicineName) {
    	String xpath = "//mat-option[normalize-space(.)='" + medicineName + "']";
    	driver.findElement(By.xpath(xpath)).click();
    }

    
    public void createNewPurchase(String location, String supplier,String invoiceNumber, String invDate, String dueDate, String expiryDate,
                                  String medicineName, String batchNo, String strips, String freeStrips, String mrp, String price) {

        waitForClickability(purchaseMenu).click();
        waitForClickability(addPurchaseBtn).click();

        waitForClickability(locationDropdown).click();
        waitForClickability(getSpanByExactText(location)).click();

        waitForClickability(locationDropdown).click();
        waitForClickability(getSpanByExactText(supplier)).click();
        WebElement invInput = getInputByFormControl("invNo");
        invInput.clear();
        invInput.sendKeys(String.valueOf(invoiceNumber));
        
      

        
        

        generatedInvoiceNo = invoiceNumber;

        js.executeScript("arguments[0].value='" + invDate + "'; arguments[0].dispatchEvent(new Event('input'));",
            getInputByFormControl("invDate"));
        js.executeScript("arguments[0].value='" + dueDate + "'; arguments[0].dispatchEvent(new Event('input'));",
            getInputByFormControl("invDueDate"));
        
        
        waitForClickability(searchMedicineBtn).click();
        getMedicineByName(medicineName);


        getInputByFormControl("BatchNumber").sendKeys(batchNo);

        WebElement expiry = getInputByFormControl("expiryDate");
        js.executeScript(
            "const input = arguments[0];" +
            "const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;" +
            "setter.call(input, '" + expiryDate + "');" +
            "input.dispatchEvent(new Event('input', { bubbles: true }));" +
            "input.dispatchEvent(new Event('change', { bubbles: true }));",
            expiry);

        List<WebElement> lastProduct = driver.findElements(By.xpath("//div[@class='last-product pt-2']"));
        if (lastProduct.isEmpty() || !lastProduct.get(0).isDisplayed()) {
            getInputByFormControl("noOfStrips").sendKeys(strips);
            getInputByFormControl("freeStrips").sendKeys(freeStrips);
            getInputByFormControl("mrpPerStrip").sendKeys(mrp);
            getInputByFormControl("pricePerStrip").sendKeys(price);
        }

        String amt = null;
        for (int i = 0; i < 50; i++) {
            WebElement amtEl = waitForVisibility(payableAmtLabel, 30);
            amt = amtEl.getText().trim();
            System.out.println(amt);
            if (!amt.equals("-")) break;
        }

        waitForVisibility(invoiceValueInput).sendKeys(amt);
        waitForClickability(addBtn).click();        
     
    }
    public GRNVerificationPage save() {
        waitForClickability(saveBtn).click();
        waitForClickability(yesBtn).click();
        waitForClickability(approveBtn).click();
        GRNVerificationPage grnPage= new GRNVerificationPage(driver);
        return grnPage;
        }
}

