package StandAloneTest;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeoutException;

import org.openqa.selenium.Keys;
@Test
public class IndentFlow {
	

	public void PPLE() throws InterruptedException {
		String currentIndentNo = "";
	WebDriver driver = new EdgeDriver();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	driver.get("https://apps.ezovion.com/auth/login");

	driver.manage().window().maximize();
	

	driver.findElement(By.xpath("//div[@class=\"form-control-group\"]//input")).sendKeys("50107299");
	driver.findElement(By.xpath("//button[@size=\"large\"]")).click();
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
        // Wait until the button with text "CONTINUE" is clickable
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
	
     driver.findElement(By.xpath("//input[@placeholder=\"Mobile No\"]")).sendKeys("7766554433");
	driver.findElement(By.xpath("//input[@placeholder=\"Password\"]")).sendKeys("12345");
	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@status=\"primary\"]")));
	 Thread.sleep(2000);
	 driver.findElement(By.xpath("//button[@status=\"primary\"]")).click();
	 for (int i = 0; i < 5; i++) { // Try up to 5 times
		    try {
		        
		        Thread.sleep(3000); // wait for any transition

		        WebElement adminTab = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Admin']")));
		        adminTab.click();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Roles Management']"))).click();
		        break; // Exit loop if successful
		    } catch (Exception e) {
		        System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
		        if (i == 4) {
		            throw e; // Re-throw if max attempts reached
		        }
		    }
		}
	 
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Pharmacy']"))).click();
	 
	// Click "Indent"
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Indent'])[1]"))).click();

	 // Click "Internal Indent"
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Internal Indent'])[1]"))).click();
	 

	 
	 // Click "Indent Request"
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[text()=' Indent Request '])[1]"))).click();
	 

	 
	 // Click first "Select" (Assumed for Location)
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();
	 

	 
	 // Click "Pharamacy Loaction"
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Pharamacy Loaction'])[1]"))).click();

	 // Wait and interact with Date Input
	 

	 
		

	 // Click second "Select"
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();

	 
	 // Click "Fddf"
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Fddf'])[1]"))).click();
	 

	 
	 // Click third "Select"
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[1]"))).click();
	 

	 
	 // Click "Dddd"
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Dddd'])[1]"))).click();
	 

	 
	 // Click "Search Medicine"
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Search Medicine'])[1]"))).click();
	 
	 
	 
	 // Click on Syrup medicine card
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//h4[text()='Medidine Ezovion'])[1]"))).click();
	 

	 
	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='indentQuantity']"))).sendKeys("5");
	 

	 WebElement addButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@value='Add'])[1]")));

	 JavascriptExecutor js = (JavascriptExecutor) driver;
	 js.executeScript("arguments[0].click();", addButton);


	 // Click on first edit icon
	 
	
	 WebElement saveButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@value='Save'])[1]")));

	
	 js.executeScript("arguments[0].click();", saveButton);

			 
//	 (//a[@class="ng-star-inserted"])[3]				 
						Thread.sleep(2000);	
						boolean isFound = false;

						while (!isFound) {
						    List<WebElement> freshRows = driver.findElements(By.xpath("//table[@class='table table-hover table-style']/tbody/tr"));

						    for (int i = 1; i <= freshRows.size(); i++) {
						         currentIndentNo = driver.findElement(By.xpath("//table[@class='table table-hover table-style']/tbody/tr[" + i + "]/td[2]")).getText().trim();
						        String currentStatus = driver.findElement(By.xpath("//table[@class='table table-hover table-style']/tbody/tr[" + i + "]/td[6]")).getText().trim();

						        if (currentStatus.equalsIgnoreCase("NEW")) {
						            WebElement editButton = driver.findElement(By.xpath("//table[@class='table table-hover table-style']/tbody/tr[" + i + "]/td[7]/li[1]/a"));
						            wait.until(ExpectedConditions.elementToBeClickable(editButton)).click();

						            System.out.println("Clicked Edit for Indent No: " + currentIndentNo + " with Status: New");
						            isFound = true;
						            break;
						        }
						       
						    }

						    if (!isFound) {
						        try {
						            WebElement nextButton = driver.findElement(By.xpath("(//i[@class='fas fa-chevron-right'])[1]"));
						            if (nextButton.isEnabled()) {
						                wait.until(ExpectedConditions.elementToBeClickable(nextButton)).click();
						                Thread.sleep(1000); // wait for the table to refresh
						            } else {
						                System.out.println("Reached the last page. No Indent with status 'New' found.");
						                break;
						            }
						        } catch (NoSuchElementException e) {
						            System.out.println("Next page button not found. Probably last page.");
						            break;
						        }
						    }
						}



					  //  System.out.println("No matching row found with Indent No: " + indentNo1 + " and Status: New");

	 // Click on "Add" button
	// wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@value='Add'])[1]"))).click();

	 // Click on "Send Request" button
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@value='Send Request'])[1]"))).click();

	 // Click on "Indent Approval"
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Indent Approval'])[1]"))).click();
//		Thread.sleep(2000);


	    // Get all table rows
boolean isFound2=false;
        while (!isFound2) {
            List<WebElement> rows = driver.findElements(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[4]/tr"));

            // Loop through each row in the table
            for (int i = 1; i <= 10; i++) {
                String indentNo2 = driver.findElement(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[4]/tr[" + i + "]/td[2]")).getText().trim();
                String status = driver.findElement(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[4]/tr[" + i + "]/td[7]/span")).getText().trim();

               // System.out.println("Row " + i + " Status: " + status);

                // Check for "Waiting for Approval" status and click "Edit"
                if ( currentIndentNo.equals(indentNo2) &&status.equals("WAITING FOR APPROVAL")) {
                    driver.findElement(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[4]/tr[" + i + "]/td[9]/li[1]/a")).click();
                    System.out.println("Clicked Edit for Indent No: " + indentNo2 + " with Status: Waiting for Approval");
                    isFound2 = true;
                    break;
                }
              
            }
            // If no row is found, try to click the "Next" page button
            if (!isFound2) {
                try {
                    WebElement nextPageButton = driver.findElement(By.xpath("(//i[@class='fas fa-chevron-right'])[2]"));
                    String classAttr = nextPageButton.getAttribute("class");

                    // If the Next button is disabled, break the loop
                    if (classAttr.contains("disabled")) {
                        System.out.println("Next button is disabled. Reached last page.");
                        break;
                    }

                    // Click the next page button using JavaScriptExecutor
                    JavascriptExecutor js1 = (JavascriptExecutor) driver;
                    js1.executeScript("arguments[0].click();", nextPageButton);

                    // Wait for the table to refresh before checking the next page
                    Thread.sleep(1500); // Adjust the sleep time as needed
                } catch (NoSuchElementException e) {
		            System.out.println("Next page button not found. Probably last page.");
		            break;
		        }
            }
        
        }
        




	  //  System.out.println("No matching row found with Indent No: " + indentNo1 + " and Status: New");

	 // Click "Update" button
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@value='Update'])[1]"))).click();
	 
	 boolean isFound3=false;
     while (!isFound3) {
         List<WebElement> rows2 = driver.findElements(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[4]/tr"));

         // Loop through each row in the table
         for (int i = 1; i <= 10; i++) {
             String indentNo3 = driver.findElement(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[4]/tr[" + i + "]/td[2]")).getText().trim();
             String status = driver.findElement(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[4]/tr[" + i + "]/td[7]/span")).getText().trim();

            // System.out.println("Row " + i + " Status: " + status);

             // Check for "Waiting for Approval" status and click "Edit"
             if (currentIndentNo.equals(indentNo3) ) {
                 driver.findElement(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[4]/tr[" + i + "]/td[9]/li[2]/a")).click();
                 System.out.println("Clicked Edit for Indent No: " + indentNo3 + " with Status: Waiting for Approval");
                 isFound3 = true;
                 break;
             }
           
         }
         // If no row is found, try to click the "Next" page button
         if (!isFound3) {
             try {
                 WebElement nextPageButton = driver.findElement(By.xpath("(//i[@class='fas fa-chevron-right'])[2]"));
                 String classAttr = nextPageButton.getAttribute("class");

                 // If the Next button is disabled, break the loop
                 if (classAttr.contains("disabled")) {
                     System.out.println("Next button is disabled. Reached last page.");
                     break;
                 }

                 // Click the next page button using JavaScriptExecutor
                 JavascriptExecutor js1 = (JavascriptExecutor) driver;
                 js1.executeScript("arguments[0].click();", nextPageButton);

                 // Wait for the table to refresh before checking the next page
                 Thread.sleep(1500); // Adjust the sleep time as needed
             } catch (NoSuchElementException e) {
		            System.out.println("Next page button not found. Probably last page.");
		            break;
		        }
         }
     
     }
//     Thread.sleep(2000);
//   div[@class="lightbox-close"]
//     (//span[text()='Select'])[10]
//    		span[text()='Fddf']
//   input[@inputmode="numeric"].sendkeys("2")
//   input[@value="Save"]
     wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='lightbox-close']"))).click();
     
     wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[10]"))).click();
     wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Fddf']"))).click();
     WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@inputmode='numeric']")));
     input.sendKeys(Keys.CONTROL + "a"); 
     input.sendKeys(Keys.DELETE); 
     input.sendKeys("2");
     wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();
     
     String expectedIssueDate="Jun 18, 2025";
     boolean isFound4=false;
     while (!isFound4) {
         List<WebElement> rows3 = driver.findElements(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[6]/tr"));

         // Loop through each row in the table
         for (int i = 1; i <= 10; i++) {
             String actualIssueDate = driver.findElement(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[6]/tr[" + i + "]/td[2]")).getText().trim();
          //   String status = driver.findElement(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[6]/tr[" + i + "]/td[7]/span")).getText().trim();

            // System.out.println("Row " + i + " Status: " + status);

             // Check for "Waiting for Approval" status and click "Edit"
             try {
            	    // Check if the expected and actual issue dates match
            	  
            	        // Attempt to click on the element based on the dynamically constructed XPath
            	        driver.findElement(By.xpath("//a[@title='Go To Receive']/img[contains(@src, 'phar.png') and contains(@style, 'opacity: 1')]")).click();

            	        // Wait for the 'Save' button to be visible and click it
            	      

            	        // If everything is successful, set isFound4 to true and break the loop
            	        isFound4 = true;
            	        break;
            	    
            	} catch (NoSuchElementException e) {
            	    System.out.println("Element not found: " + e.getMessage());
            	} 

           
         }
         // If no row is found, try to click the "Next" page button
         if (!isFound4) {
             try {
                 WebElement nextPageButton = driver.findElement(By.xpath("(//i[@class='fas fa-chevron-right'])[2]"));
                 String classAttr = nextPageButton.getAttribute("class");

                 // If the Next button is disabled, break the loop
                 if (classAttr.contains("disabled")) {
                     System.out.println("Next button is disabled. Reached last page.");
                     break;
                 }

                 // Click the next page button using JavaScriptExecutor
                 JavascriptExecutor js1 = (JavascriptExecutor) driver;
                 js1.executeScript("arguments[0].click();", nextPageButton);

                 // Wait for the table to refresh before checking the next page
                 Thread.sleep(1500); // Adjust the sleep time as needed
             } catch (NoSuchElementException e) {
		            System.out.println("Next page button not found. Probably last page.");
		            break;
		        }
         }
     
     }
     
     wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Select'])[14]"))).click();
     wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Fddf']"))).click();
     wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();
}
}

