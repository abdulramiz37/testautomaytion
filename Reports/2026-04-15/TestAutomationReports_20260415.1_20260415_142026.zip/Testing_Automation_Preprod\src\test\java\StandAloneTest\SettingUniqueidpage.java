package StandAloneTest;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import WareHouseSetup.Settings.Unique_id_Generator;

public class  SettingUniqueidpage {
	
	public static void main(String[] args) {
		
	  	 WebDriver driver;
	       driver = new ChromeDriver();
	       WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

	       driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	       driver.manage().window().maximize();
	       driver.get("https://apps.ezovion.com/auth/login");

	       driver.findElement(By.xpath("//div[@class=\"form-control-group\"]//input")).sendKeys("50107299");
	       driver.findElement(By.xpath("//button[@size=\"large\"]")).click();

	       wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
	       driver.findElement(By.xpath("//input[@placeholder=\"Mobile No\"]")).sendKeys("7766554433");
	       driver.findElement(By.xpath("//input[@placeholder=\"Password\"]")).sendKeys("12345");

	       wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@status=\"primary\"]"))).click();

	       for (int i = 0; i < 5; i++) {
	           try {
	               WebElement adminTab = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Admin']")));
	               adminTab.click();
	               wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Roles Management']"))).click();
	               break;
	           } catch (Exception e) {
	               System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
	               if (i == 4) throw e;
	           }
	       }
	       wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Masters']"))).click();
	       wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Master Set-up']"))).click();
	        // Step 2: Assert login success
	       Unique_id_Generator uniqueId = new Unique_id_Generator(driver);


           // Step 1: Select the "Unique ID For" dropdown value
           uniqueId.selectUniqueIdFor("Registration"); // You can pass a specific value if dynamic

           // Step 2: Modify digit count
           uniqueId.incrementDigit(); // Increase digit count by one
           uniqueId.decrementDigit(); // Optional

           // Step 3: Select checkbox options
           uniqueId.selectTextCheckbox();
           uniqueId.selectDateFormatCheckbox();

           // Step 4: Enter format fields
           uniqueId.enterText("ZZZ");
           uniqueId.enterNumber("1");

           
           uniqueId.selectDateFormat("ddMMMyyyy");

           // Step 6: Select prefix value
           uniqueId.selectPrefix("Text");

         
           uniqueId.selectTenantBased();

           // Step 8: Save
           uniqueId.clickSave();
           
           int attempts = 0;
           while (!uniqueId.isSaveSuccessMessageDisplayed() && attempts < 5) {
               uniqueId.clickSave();
//               Thread.sleep(1000); // Use WebDriverWait in real use
               if (uniqueId.isLengthErrorDisplayed()) uniqueId.incrementDigit();
               attempts++;
           }
           uniqueId.clickSave();
	}
}
