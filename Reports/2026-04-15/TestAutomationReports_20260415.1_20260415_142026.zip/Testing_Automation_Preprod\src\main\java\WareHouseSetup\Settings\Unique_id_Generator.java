package WareHouseSetup.Settings;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class Unique_id_Generator extends Abstraction{

	public Unique_id_Generator(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	    this.driver = driver;
        PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//label[text()=' Unique ID For ']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
	private WebElement uniqueIdForDropdown;

	@FindBy(xpath = "//span[contains(@class,'ngx-select__selected-single')]//span[text()='Admission']")
	private WebElement selectedUniqueIdForValue;

	@FindBy(xpath = "//label[text()=' Number of digit ']/following::button[1]")
	private WebElement minusButton;

	@FindBy(xpath = "//label[text()=' Number of digit ']/following::button[2]")
	private WebElement plusButton;

	@FindBy(xpath = "//label[text()=' Content ']/following::label[contains(.,'Text')]/input")
	private WebElement checkboxText;

	@FindBy(xpath = "//label[text()=' Content ']/following::label[contains(.,'Date Format')]/input")
	private WebElement checkboxDateFormat;

	@FindBy(xpath = "//label[text()=' Content ']/following::label[contains(.,'Number')]/input")
	private WebElement checkboxNumber;

	@FindBy(xpath = "//input[@formcontrolname='format1text']")
	private WebElement inputText;

	@FindBy(xpath = "//label[text()=' Date Format ']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
	private WebElement dateFormatDropdown;

	@FindBy(xpath = "//input[@formcontrolname='format1number']")
	private WebElement inputNumber;

	@FindBy(xpath = "//label[text()=' Prefix ']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
	private WebElement prefixDropdown;

	@FindBy(xpath = "//input[@type='radio' and @value='tenantbased']")
	private WebElement tenantBasedRadio;

	@FindBy(xpath = "//input[@type='radio' and @value='branchbased']")
	private WebElement branchBasedRadio;

	@FindBy(xpath = "//input[@value='Save']")
	private WebElement saveButton;

	@FindBy(xpath = "//input[@value='Cancel']")
	private WebElement cancelButton;

	@FindBy(xpath = "//input[@value='Reset']")
	private WebElement resetButton;

	@FindBy(xpath = "//div[@class='sequence-priview-wrap']//li/span")
	private WebElement previewGeneratedId;

	@FindBy(xpath = "//span[contains(text(),'Unique ID saved successfully')]")
	private WebElement successMessageSave;

	@FindBy(xpath = "//span[contains(text(),'Please Check the fields and Length of the digits')]")
	private WebElement errorLengthMessage;
	
	@FindBy(xpath = "//a[text()=' Unique ID Generator ']")
	private WebElement uniqueId;
	
	public void selectFromDropdown(String value) {
	    WebElement option = driver.findElement(By.xpath("//span[text()='" + value + "']"));
	    option.click();
	}

	public void selectFromDropdown2(String value) {
	    WebElement option = driver.findElement(By.xpath("(//span[text()='" + value + "'])[2]"));
	    option.click();
	}
	
	public void selectUniqueIdFor(String value) {
		uniqueId.click();
	    uniqueIdForDropdown.click();
	    selectFromDropdown(value);
	}

	public void incrementDigit() {
	    plusButton.click();
	}

	public void decrementDigit() {
	    minusButton.click();
	}

	public void selectTextCheckbox() {
	    if (!checkboxText.isSelected()) {
	        checkboxText.click();
	    }
	}

	public void selectDateFormatCheckbox() {
	    if (!checkboxDateFormat.isSelected()) {
	        checkboxDateFormat.click();
	    }
	}

	public void enterText(String value) {
	    inputText.clear();
	    inputText.sendKeys(value);
	}

	public void enterNumber(String number) {
	    inputNumber.clear();
	    inputNumber.sendKeys(number);
	}

	public void selectDateFormat(String value) {
	    dateFormatDropdown.click();
	    selectFromDropdown(value);
	}

	public void selectPrefix(String value) {
	    prefixDropdown.click();
	    selectFromDropdown2(value);
	}

	public void selectTenantBased() {
	    tenantBasedRadio.click();
	}

	public void selectBranchBased() {
	    branchBasedRadio.click();
	}

	public void clickSave() {
	    saveButton.click();
	}

	public void clickCancel() {
	    cancelButton.click();
	}

	public void clickReset() {
	    resetButton.click();
	}

	public String getPreviewText() {
	    return previewGeneratedId.getText();
	}

	public boolean isSaveSuccessMessageDisplayed() {
		System.out.println(successMessageSave.isDisplayed());
	    return successMessageSave.isDisplayed();
	}

	public boolean isLengthErrorDisplayed() {
	    return errorLengthMessage.isDisplayed();
	}


}
