package PharmacyIndentFlow;

import java.util.List;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

import EzionAbstractionComponents.Abstraction;

public class IndentApprovalTablePage extends Abstraction {

    public IndentApprovalTablePage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    // ------------------ Page Elements ------------------

    @FindBy(xpath = "(//span[text()='Indent Approval'])[1]")
    private WebElement indentApprovalTab;

    @FindBy(xpath = "(//i[@class='fas fa-chevron-right'])[2]")
    private WebElement nextPageButton;

    @FindBy(xpath = "(//input[@value='Update'])[1]")
    private WebElement updateButton;

    @FindBy(xpath = "(//table[contains(@class, 'table-hover')]/tbody)[4]/tr")
    private List<WebElement> tableRows;

    // ------------------ Actions ------------------

    public void openIndentApprovalTab() {
        waitForClickability(indentApprovalTab).click();
    }

    public boolean findAndEditIndentForApproval(String targetIndentNo) {
      
        waitForVisibility(tableRows);
        while (true) {
        	List<WebElement> freshRows = waitForVisibility(tableRows);

            for (int i = 1; i <= tableRows.size(); i++) {
                WebElement indentCell = driver.findElement(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[4]/tr[" + i + "]/td[2]"));
                WebElement statusCell = driver.findElement(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[4]/tr[" + i + "]/td[7]/span"));

                String indentNo = indentCell.getText().trim();
                String status = statusCell.getText().trim();

                if (targetIndentNo.equals(indentNo) && status.equalsIgnoreCase("WAITING FOR APPROVAL")) {
                    WebElement editBtn = driver.findElement(By.xpath("(//table[contains(@class, 'table-hover')]/tbody)[4]/tr[" + i + "]/td[9]/li[1]/a"));
                    waitForClickability(editBtn).click();
                    return true;
                }
            }

            // Check if Next Page button is clickable
            if (!nextPageButton.getAttribute("class").contains("disabled")) {
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextPageButton);
//                waitForVisibilityAll(tableRows);
            } else {
                break;
            }
        }

        return false;
    }

    public IndentIssue clickUpdateButton() {
        waitForClickability(updateButton).click();
        IndentIssue indent = new IndentIssue(driver);
        return indent;
    }
}
