package PharmacyFlowObjects.PharmacyStore;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import EzionAbstractionComponents.Abstraction;

public class SupplierPage extends Abstraction {

    public SupplierPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    // --- Existing Elements ---

    @FindBy(xpath = "//a[text()=' Supplier']")
    private WebElement supplierTab;

    @FindBy(xpath = "(//a[@role='button'])[1]")
    private WebElement expandFirstButton;

    @FindBy(xpath = "(//input[@type='text'])[3]")
    private WebElement supplierNameInput;

    @FindBy(xpath = "(//span[text()='Select'])[1]")
    private WebElement selectDropdown1;

    @FindBy(xpath = "(//span[text()='Pharmacy'])[2]")
    private WebElement pharmacyOption;

    @FindBy(xpath = "(//input[@type='text'])[4]")
    private WebElement quantityInput;

    @FindBy(xpath = "(//input[@type='text'])[7]")
    private WebElement phoneInput;

    @FindBy(xpath = "(//input[@type='text'])[9]")
    private WebElement mobileInput;

    @FindBy(xpath = "(//input[@type='text'])[11]")
    private WebElement stateCodeInput;

    @FindBy(xpath = "(//input[@type='text'])[13]")
    private WebElement pincodeInput;

    @FindBy(xpath = "(//input[@type='text'])[14]")
    private WebElement cityInput;

    @FindBy(xpath = "(//span[text()='Chamoli'])[1]")
    private WebElement chamoliOption;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//span[contains(text(),'Name Already Exists')]")
    private WebElement nameAlreadyExistsError;

    @FindBy(xpath = "//div[@class='back-icon']")
    private WebElement backIcon;

    // --- Existing Actions ---

    public void openSupplierTab() {
        waitForClickability(supplierTab).click();
    }

    public void expandFirstSupplierBlock() {
        waitForClickability(expandFirstButton).click();
    }
   
    public WebElement getSpanByExactText(String exactText) {
    	String xpath = "//span[normalize-space(text())='" + exactText.trim() + "']";
        return driver.findElement(By.xpath(xpath));
    }
    
    public void enterSupplierDetails(String name, String qty, String phone, String mobile, String stateCode, String pincode, String city,String district) {
        waitForVisibility(supplierNameInput).sendKeys(name);
        waitForClickability(selectDropdown1).click();
        waitForClickability(pharmacyOption).click();
        waitForVisibility(quantityInput).sendKeys(qty);
        waitForVisibility(phoneInput).sendKeys(phone);
        waitForVisibility(mobileInput).sendKeys(mobile);
        waitForVisibility(stateCodeInput).sendKeys(stateCode);
        waitForVisibility(pincodeInput).sendKeys(pincode);
        waitForVisibility(cityInput).sendKeys(city);
        waitForClickability(selectDropdown1).click();
        getSpanByExactText(district).click();
    }

    public void createSupplier(String name, String qty, String phone, String mobile, String stateCode, String pincode, String city,String district) {
        openSupplierTab();
        expandFirstSupplierBlock();
        enterSupplierDetails(name, qty, phone, mobile, stateCode, pincode, city,district);
    }

    public StorageShelfPage clickSaveSupplier() {
        waitForClickability(saveButton).click();
        return new StorageShelfPage(driver);
    }

    public String errorMessage() {
        System.out.print(nameAlreadyExistsError.getText());
        return nameAlreadyExistsError.getText();
    }

    // ========== New Input Fields ==========

    @FindBy(xpath = "//input[@formcontrolname='gstn']")
    private WebElement gstnInputField;

    @FindBy(xpath = "//input[@formcontrolname='drugLicNo']")
    private WebElement drugLicenseInputField;

    @FindBy(xpath = "//input[@formcontrolname='email']")
    private WebElement emailInputField;

    @FindBy(xpath = "//input[@formcontrolname='address']")
    private WebElement addressInputField;

    @FindBy(xpath = "//input[@formcontrolname='area']")
    private WebElement areaInputField;

    @FindBy(xpath = "//input[@formcontrolname='contactName']")
    private WebElement contactNameInputField;

    @FindBy(xpath = "//input[@formcontrolname='creditDays']")
    private WebElement creditDaysInputField;

    @FindBy(xpath = "//input[@formcontrolname='bankName']")
    private WebElement bankNameInputField;

    @FindBy(xpath = "//input[@formcontrolname='ifscCode']")
    private WebElement ifscInputField;

    @FindBy(xpath = "//input[@formcontrolname='accountNum']")
    private WebElement accountNumberInputField;

    @FindBy(xpath = "//input[@formcontrolname='branchName']")
    private WebElement branchNameInputField;

    @FindBy(xpath = "//ngx-select[@formcontrolname='districtId']")
    private WebElement districtDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='state']")
    private WebElement stateDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='country']")
    private WebElement countryDropdown;
    
    @FindBy(xpath = "//input[@formcontrolname='altrMobile']")
    private WebElement alternateMobileInput;

    // ========== New Input Methods ==========

    public void enterGstn(String gstn) {
        waitForVisibility(gstnInputField).sendKeys(gstn);
    }

    public void enterDrugLicense(String license) {
        waitForVisibility(drugLicenseInputField).sendKeys(license);
    }

    public void enterEmailAddress(String email) {
        waitForVisibility(emailInputField).sendKeys(email);
    }

    public void enterStreetAddress(String address) {
        waitForVisibility(addressInputField).sendKeys(address);
    }

    public void enterAreaField(String area) {
        waitForVisibility(areaInputField).sendKeys(area);
    }

    public void enterContactName(String contactName) {
        waitForVisibility(contactNameInputField).sendKeys(contactName);
    }

    public void enterCreditDays(String creditDays) {
        waitForVisibility(creditDaysInputField).sendKeys(creditDays);
    }
    public void enterAlternateMobile(String altMobile) {
        
        alternateMobileInput.sendKeys(altMobile);
    }
    public void enterBankDetails(String bankName, String ifsc, String accNum, String branchName) {
        waitForVisibility(bankNameInputField).sendKeys(bankName);
        waitForVisibility(ifscInputField).sendKeys(ifsc);
        waitForVisibility(accountNumberInputField).sendKeys(accNum);
        waitForVisibility(branchNameInputField).sendKeys(branchName);
    }

    public void selectDistrict() {
        waitForClickability(districtDropdown).click();
        // Add dropdown selection logic if needed
    }

    public void selectState() {
        waitForClickability(stateDropdown).click();
        // Add dropdown selection logic if needed
    }

    public void selectCountry() {
        waitForClickability(countryDropdown).click();
        // Add dropdown selection logic if needed
    }

    // Optional: Fill all new info at once
    public void fillAdditionalSupplierInfo(String gstn, String drugLic, String email, String address, String area,
                                           String contact, String creditDays, String bank, String ifsc, String acc, String branch) {
        enterGstn(gstn);
        enterDrugLicense(drugLic);
        enterEmailAddress(email);
        enterStreetAddress(address);
        enterAreaField(area);
        enterContactName(contact);
        enterCreditDays(creditDays);
        enterBankDetails(bank, ifsc, acc, branch);
        selectDistrict();
        selectState();
        selectCountry();
    }
    
    @FindBy(css = "input[formcontrolname='name'] ~ ngx-validation-message p")
    private WebElement supplierNameError;

    @FindBy(css = "input[formcontrolname='creditDays'] ~ ngx-validation-message p")
    private WebElement creditDaysError;

    @FindBy(css = "input[formcontrolname='mobile'] ~ ngx-validation-message p")
    private WebElement mobileError;

    @FindBy(css = "input[formcontrolname='workPhone'] ~ ngx-validation-message p")
    private WebElement workPhoneError;

    @FindBy(css = "input[formcontrolname='email'] ~ ngx-validation-message p")
    private WebElement emailError;

    @FindBy(css = "input[formcontrolname='address'] ~ ngx-validation-message p")
    private WebElement addressError;

    @FindBy(css = "input[formcontrolname='pincode'] ~ ngx-validation-message p")
    private WebElement pincodeError;

    @FindBy(css = "input[formcontrolname='city'] ~ ngx-validation-message p")
    private WebElement cityError;

    @FindBy(css = "input[formcontrolname='contactName'] ~ ngx-validation-message p")
    private WebElement contactNameError;

    @FindBy(css = "input[formcontrolname='gstn'] ~ ngx-validation-message p")
    private WebElement gstnError;

    @FindBy(css = "input[formcontrolname='drugLicNo'] ~ ngx-validation-message p")
    private WebElement drugLicenseError;

    @FindBy(css = "input[formcontrolname='altrMobile'] ~ ngx-validation-message p")
    private WebElement alternateMobileError;

    @FindBy(css = "input[formcontrolname='area'] ~ ngx-validation-message p")
    private WebElement areaError;

    @FindBy(xpath = "//label[text()='District *']/following-sibling::div[contains(text(),'District')]")
    private WebElement districtError;

    @FindBy(xpath = "//label[text()='State *']/following-sibling::div[contains(text(),'State')]")
    private WebElement stateError;

    @FindBy(xpath = "//label[text()='Country *']/following-sibling::div[contains(text(),'Country')]")
    private WebElement countryError;

    @FindBy(css = "input[formcontrolname='bankName'] ~ ngx-validation-message p")
    private WebElement bankNameError;

    @FindBy(css = "input[formcontrolname='ifscCode'] ~ ngx-validation-message p")
    private WebElement ifscError;

    @FindBy(css = "input[formcontrolname='accountNum'] ~ ngx-validation-message p")
    private WebElement accountNumberError;

    @FindBy(css = "input[formcontrolname='branchName'] ~ ngx-validation-message p")
    private WebElement branchNameError;

    public String getSupplierNameError() {
        String msg = waitForVisibility(supplierNameError).getText();
        System.out.println("Supplier Name Error: " + msg);
        return msg;
    }

    public String getCreditDaysError() {
        String msg = waitForVisibility(creditDaysError).getText();
        System.out.println("Credit Days Error: " + msg);
        return msg;
    }

    public String getMobileError() {
        String msg = waitForVisibility(mobileError).getText();
        System.out.println("Mobile Error: " + msg);
        return msg;
    }

    public String getWorkPhoneError() {
        String msg = waitForVisibility(workPhoneError).getText();
        System.out.println("Work Phone Error: " + msg);
        return msg;
    }

    public String getEmailError() {
        String msg = waitForVisibility(emailError).getText();
        System.out.println("Email Error: " + msg);
        return msg;
    }

    public String getAddressError() {
        String msg = waitForVisibility(addressError).getText();
        System.out.println("Address Error: " + msg);
        return msg;
    }

    public String getPincodeError() {
        String msg = waitForVisibility(pincodeError).getText();
        System.out.println("Pincode Error: " + msg);
        return msg;
    }

    public String getCityError() {
        String msg = waitForVisibility(cityError).getText();
        System.out.println("City Error: " + msg);
        return msg;
    }

    public String getContactNameError() {
        String msg = waitForVisibility(contactNameError).getText();
        System.out.println("Contact Name Error: " + msg);
        return msg;
    }

    public String getGstnError() {
        String msg = waitForVisibility(gstnError).getText();
        System.out.println("GSTN Error: " + msg);
        return msg;
    }

    public String getDrugLicenseError() {
        String msg = waitForVisibility(drugLicenseError).getText();
        System.out.println("Drug License Error: " + msg);
        return msg;
    }

    public String getAlternateMobileError() {
        String msg = waitForVisibility(alternateMobileError).getText();
        System.out.println("Alternate Mobile Error: " + msg);
        return msg;
    }

    public String getAreaError() {
        String msg = waitForVisibility(areaError).getText();
        System.out.println("Area Error: " + msg);
        return msg;
    }

    public String getDistrictError() {
        String msg = waitForVisibility(districtError).getText();
        System.out.println("District Error: " + msg);
        return msg;
    }

    public String getStateError() {
        String msg = waitForVisibility(stateError).getText();
        System.out.println("State Error: " + msg);
        return msg;
    }

    public String getCountryError() {
        String msg = waitForVisibility(countryError).getText();
        System.out.println("Country Error: " + msg);
        return msg;
    }

    public String getBankNameError() {
        String msg = waitForVisibility(bankNameError).getText();
        System.out.println("Bank Name Error: " + msg);
        return msg;
    }

    public String getIfscError() {
        String msg = waitForVisibility(ifscError).getText();
        System.out.println("IFSC Error: " + msg);
        return msg;
    }

    public String getAccountNumberError() {
        String msg = waitForVisibility(accountNumberError).getText();
        System.out.println("Account Number Error: " + msg);
        return msg;
    }

    public String getBranchNameError() {
        String msg = waitForVisibility(branchNameError).getText();
        System.out.println("Branch Name Error: " + msg);
        return msg;
    }

}
