package WareHouseSetup.MyHospital;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

/**
 * Page class for User Restrictions form.
 */
public class UserRestrictionsPage extends Abstraction {

    WebDriver driver;

    public UserRestrictionsPage(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // ====== LOCATORS ======

    @FindBy(xpath = "//ngx-select[@formcontrolname='pageId']//div[contains(@class,'ngx-select__toggle')]")
    public WebElement pageNameDropdown;

    @FindBy(xpath = "//span[contains(@class,'ngx-select__selected-single')]")
    public WebElement selectedPageName;

    @FindBy(xpath = "//span[text()='This Data already exists']")
    public WebElement pageNameError;

    @FindBy(id = "inlineUserRadio1")
    public WebElement userRestrictionAllRadio;

    @FindBy(id = "inlineUserRadio2")
    public WebElement userRestrictionSelectedRadio;

    @FindBy(xpath = "//input[@formcontrolname='isManualDate']")
    public WebElement enableManualEntryCheckbox;

    @FindBy(xpath = "//span[@class='checkmark']")
    public WebElement isActiveCheckbox;

    @FindBy(xpath = "//input[@type='button' and @value='Save']")
    public WebElement saveButton;

    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
    public WebElement cancelButton;
    
    @FindBy(xpath = "//a[text()=' Manual Date Picker Settings ']")
    private WebElement userType;

    @FindBy(xpath = "//a[text()=' Create ']")
    private WebElement adduserType;
     
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}
    // ====== METHODS ======

    // Select Page Name from dropdown
    public void selectPageName(String pageName) {
        pageNameDropdown.click();
        WebElement option = driver.findElement(By.xpath("//span[contains(text(),'" + pageName + "')]"));
        option.click();
    }

    public void selectUserRestrictionAll() {
        userRestrictionAllRadio.click();
    }

    public void selectUserRestrictionOnlySelected() {
        userRestrictionSelectedRadio.click();
    }

    public void toggleManualEntry(boolean enable) {
        if (enableManualEntryCheckbox.isSelected() != enable) {
            enableManualEntryCheckbox.click();
        }
    }

    public void toggleIsActive(boolean enable) {
        if (!isActiveCheckbox.isSelected() != enable) {
            isActiveCheckbox.click();
        }
    }

    public void clickSave() {
        saveButton.click();
    }

    public void clickCancel() {
        cancelButton.click();
    }

    public boolean isDuplicateErrorDisplayed() {
        try {
            return pageNameError.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    // Fill the entire User Restrictions form
    public void fillUserRestrictionsForm(String pageName, String userRestriction, boolean enableManualEntry, boolean isActive) {
    	clickbuttonapproval();
        selectPageName(pageName);

        if (userRestriction.equalsIgnoreCase("All")) {
            selectUserRestrictionAll();
        } else if (userRestriction.equalsIgnoreCase("Only Selected")) {
            selectUserRestrictionOnlySelected();
        }

        toggleManualEntry(enableManualEntry);
        toggleIsActive(isActive);
        clickSave();
    }
}
