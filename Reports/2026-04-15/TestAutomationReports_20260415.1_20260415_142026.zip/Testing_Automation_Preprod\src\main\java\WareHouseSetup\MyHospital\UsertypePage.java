package WareHouseSetup.MyHospital;

 

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

/**
 * Page Object class for the Usertype form.
 */
public class UsertypePage extends Abstraction{

    WebDriver driver;

    public UsertypePage(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Locator for the Usertype Name input field
    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement usertypeNameInput;

    // Locator for the Save button
    @FindBy(xpath = "//input[@type='button' and @value='Save']")
    private WebElement saveButton;

    // Locator for the Cancel button
    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
    private WebElement cancelButton;

    @FindBy(xpath = "//a[text()=' User Type ']")
    private WebElement userType;

    @FindBy(xpath = "//a[text()=' Add User Type ']")
    private WebElement adduserType;
     
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}
    public void enterUsertypeName(String name) {
        usertypeNameInput.clear();
        usertypeNameInput.sendKeys(name);
    }

    // Method to click the Save button
    public void clickSave() {
        saveButton.click();
    }

    // Method to click the Cancel button
    public void clickCancel() {
        cancelButton.click();
    }
    public void fillUsertypeForm(String name) {
    	clickbuttonapproval();
        enterUsertypeName(name);
        clickSave();
    }

}

