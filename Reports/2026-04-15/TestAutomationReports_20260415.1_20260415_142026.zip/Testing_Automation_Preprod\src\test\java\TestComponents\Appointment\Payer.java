package TestComponents.Appointment;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Accounts.CreditBillSelf;
import Appointment.PayerDetailPage;
import Appointment.PaymentPage;
import Bill.Bill;
import EzionpageObjects.UserIdPage;
import PrakashSirAppointmentBooking.EMR;
import PrakashSirAppointmentBooking.CaseSheet.InvestigationPage;
import Registration.NewRegistrationPage;
import Registration.PatientList;
import Registration.ServiceList;
import abdulTest.BaseTest;
import ezion.Resources.EnvUtil;

public class Payer extends BaseTest {
	 UserIdPage data;
	  NewRegistrationPage registrationPage ;

	   @Test(dataProvider = "getDataForLogin",priority = 1)
	   public void Login(HashMap<String, String> input) throws InterruptedException {
	       // Login
	       data = login.login(EnvUtil.get("USER_ID"));
	       data.enterMobileNumber(EnvUtil.get("PERSON_ID"));
	       data.enterPassword(EnvUtil.get("PASSWORD"));

	       data.clickContinue();
	       data.navigateSalesWithRetry();
//	   Thread.sleep(8000);
	       }
	   String targetMobileNumber;
	   String storedFirstName1;
	   @Test(dataProvider = "getDataForLogin",priority = 3)
	   public void patientName(HashMap<String, String> input) throws InterruptedException {
//		   Thread.sleep(8000);	 
//		   Thread.sleep(8000);	
//		   Thread.sleep(8000);	
	       // Step 1: Search patient
	       registrationPage = new NewRegistrationPage(driver);

	       // Call the fillNewRegistrationForm method with all necessary form values
	       registrationPage.clickbuttonapproval();
	       registrationPage.selectTitle();
	       registrationPage.selectOptionFromNgxDropdown("Mr.");
	       registrationPage.enterFirstName("");
	       registrationPage.enterMiddleName("doe");
	       registrationPage.enterLastName("abraham");
	       registrationPage.selectGender();
	       registrationPage.selectOptionFromNgxDropdown("Male");
	       registrationPage.enterDOB("12/12/2024");
	       registrationPage.enterMobileNumber("");
	       storedFirstName1=registrationPage.storedFirstName;
	       targetMobileNumber=registrationPage.lastEnteredMobileNumber;
	       registrationPage.selectNationality("Indian");
//	       targetMobileNumber="7411081113";
	       registrationPage.save();

	//System.out.println(targetMobileNumber);
	   } 
	   
	   @Test(dataProvider = "getDataForLogin",priority = 4)
	   public void patientlist(HashMap<String, String> input) throws InterruptedException {
	       // Login
//		   Thread.sleep(5000);
		   PatientList patient = new PatientList(driver);
		   System.out.println(targetMobileNumber);
//		   patient.findPatientByMobile(targetMobileNumber);

	        patient.findPatientByMobile(targetMobileNumber, "Payer");
//	        patient.findPatientByMobile(targetMobileNumber, "Admission");
//	        patient.findPatientByMobile(targetMobileNumber, "Patient Wallet");
//	        patient.findPatientByMobile(targetMobileNumber, "Edit Patient");
//	        patient.findPatientByMobile(targetMobileNumber, "Certificates");
//	        patient.findPatientByMobile(targetMobileNumber, "Patient Merge");
//	        patient.findPatientByMobile(targetMobileNumber, "Print");
//	        patient.findPatientByMobile(targetMobileNumber, "Cancel Registration");
	       }
	   
	   
	   @Test(dataProvider = "getDataForLogin",priority = 5)
	   public void payerPage(HashMap<String, String> input) throws InterruptedException {
	       // Login
//		   Thread.sleep(5000);
	       PayerDetailPage payerPage = new PayerDetailPage(driver);
	       payerPage.clickAddPayer();
	        // Navigate to payer page (if applicable in your system)
	        payerPage.openPayerTab();

	        // Fill Payer Form
	        payerPage.selectPayerType("Corporate");
	        payerPage.selectPayerSubType("ECHS");

	        payerPage.selectCompanyName("Test Payer");
            
            // Fill Individual/Family section (Corporate)
	        payerPage.selectCorporatePatientType("Self");
	        payerPage.enterEmployeeName("Ramiz");
	        payerPage.enterEmployeeId("EMP789018");
            payerPage.enterEmployeeDesignation("Senior Manager");
            payerPage.enterEmployeeDepartment("Information Technology");
            payerPage.enterCreditLimit("1000");
            payerPage.enterApprovalAmount("1000");
//            payerPage.selectStatus("Pending");
//            payerPage.enterClaimAuthorizationNo("Assam Rifles pensioners");
////            payerPage.setSamePayerForAllBills(false);
////            payerPage.setSkipCreditValidation(true);
//            
//            // Fill ECHS Details section
//            payerPage.enterServiceNo("SRV556677");
//            payerPage.selectServiceDepartment("Assam Rifles pensioners");
//            payerPage.enterRegNo("REG112234");
            
            // Save the payer
            payerPage.clickSavePayer();
	       }
//	   
	   @Test(dataProvider = "getDataForLogin", priority = 7)
	   public void PatientRegistration(HashMap<String, String> input) throws InterruptedException {
	   	PatientList patient = new PatientList(driver);
	    Thread.sleep(1000);
	    patient.patientlist();
	   	patient.findPatientByMobile(targetMobileNumber);
	   	
	   	ServiceList service = new ServiceList(driver);
//	   	service.fillBillingForm("General", "Dr. Izaan", "Payer","Blood Sugar - LabTest","10","%","5");

	   	service.selectDropdownOption("General");

//        clickPhysicianDropdown();
	   	service.byTextAttach("Physician", "/ancestor::div[1]//ngx-select").click();
	   	service.byTextAttach("Physician", "/ancestor::div[1]//a").click();

	   	service.clickBillTypeDropdown();
        service.selectDropdownOption("Payer");
        service.clickPayerSelectDropdown();
        service.selectDropdownOption("Test Payer");
        
        service.clickServiceNameDropdown();
        
        service.selectDropdownOption("Blood Sugar - LabTest"); // or any other service

        service.enterQuantity("10");

        service.clickDiscountTypeDropdown();
        service.selectDropdownOption("%");
//        Thread.sleep(8000);
        service.enterDiscountPercentage("5");
//        Thread.sleep(5000);
        service.clickAddButton();
        service.clickServiceNameDropdown();
        service.selectDropdownOption("Blood Sugar2 - LabTest"); // or any other service

        service.enterQuantity("10");

        service.clickDiscountTypeDropdown();
        service.selectDropdownOption("%");
//        Thread.sleep(8000);
        service.enterDiscountPercentage("5");
//        Thread.sleep(5000);
        service.clickAddButton();
        PaymentPage payment = new PaymentPage(driver);
//        String payerName = "Test Payer";
        String referenceNo = "477";
        String amount = "0";
//        payment.enterCreditAmount("2");
        payment.enterInsurancePayment( referenceNo, amount);
        service.save();
        Thread.sleep(5000);
        service.clickServiceNameDropdown();
        service.selectDropdownOption("Blood Sugar1 - LabTest"); // or any other service

        service.enterQuantity("10");

        service.clickDiscountTypeDropdown();
        service.selectDropdownOption("%");
//        Thread.sleep(8000);
        service.enterDiscountPercentage("5");
//        Thread.sleep(5000);
        service.clickAddButton();
//      service.clickServiceNameDropdown();
        payment.enterInsurancePayment( referenceNo, amount);
// 
        service.save();
        Thread.sleep(5000);
        patient.patientlist();
	   	patient.findPatientByMobile(targetMobileNumber,"EMR / Accounts");
//		Thread.sleep(5000);
    	EMR	emrPage = new EMR(driver);
        emrPage.clickCaseSheetWrapper();
//      Thread.sleep(5000);
       

    

    	int attempts = 0;

    	while (attempts < 5) {
    	    try {
    	        emrPage.clickCaseSheetWrapper();
    	        emrPage.clickByText("New Case Sheet");
    	        emrPage.byTextAttach("Case Sheet", "/ancestor::div[1]//input")
    	               .sendKeys("izaan");
    	        break;   // stop loop once success
    	    } catch (Exception e) {
    	        attempts++;
    	    }
    	}
    Thread.sleep(5000);
      emrPage.clickByText("Dr. Izaan");
    Thread.sleep(5000);
	   }
	   
	   @Test(dataProvider = "getDataForLogin", priority = 19)
	    public void investigation(HashMap<String, String> input) throws InterruptedException {

	        // Step 1: Create Page Object
	        InvestigationPage investigationPage = new InvestigationPage(driver);
	        investigationPage.clickInvestigationToggle();

	        // Step 2: Define multiple investigations dynamically
	        List<Map<String, String>> investigationList = new ArrayList<>();

	        // Investigation 1
	        Map<String, String> inv1 = new HashMap<>();
	        inv1.put("service", "Basic Health - GeneralPackage");
	        inv1.put("doctor", "Izaan");
	        inv1.put("nurse", "Fddf");
	        inv1.put("results", "Hemoglobin slightly low, needs monitoring.");
	        inv1.put("notes", "Recommend further iron studies.");
	        inv1.put("outsideTest", "true");
	        inv1.put("provideDiscount", "true");
	        inv1.put("discountType", "By Percentage");
	        inv1.put("discountAmount", "10");
	        investigationList.add(inv1);

	        // Investigation 2
//	        Map<String, String> inv2 = new HashMap<>();
//	        inv2.put("service", "General Tests");
//	        inv2.put("doctor", "Izaan");
//	        inv2.put("nurse", "Fddf");
//	        inv2.put("results", "Normal results.");
//	        inv2.put("notes", "No further action required.");
//	        inv2.put("outsideTest", "false");
//	        inv2.put("provideDiscount", "false");
//	        investigationList.add(inv2);

	        // Step 3: Loop through each investigation and fill the form
	        for (Map<String, String> inv : investigationList) {
//	        	investigationPage.scrollToElementCenter("//*[normalize-space(text())='Investigation']/ancestor::div[3]//*[normalize-space(text())='Service']/ancestor::div[1]//ng-select//input");
	            investigationPage.clickByTextAttachJS("Investigation", "/ancestor::div[3]//*[normalize-space(text())='Service']/ancestor::div[1]//ng-select");
	            investigationPage.byTextAttach("Investigation", "/ancestor::div[3]//*[normalize-space(text())='Service']/ancestor::div[1]//ng-select//input").sendKeys("basic health");
	            investigationPage.byTextAttach(inv.get("service"),"").click();
//	            investigationPage.selectPerformingDoctor(inv.get("doctor"));
	            investigationPage.selectPerformingNurse(inv.get("nurse"));
	            investigationPage.enterTestResults(inv.get("results"));
	            investigationPage.enterNotes(inv.get("notes"));

	            // Handle Outside Test
	            if (inv.get("outsideTest").equalsIgnoreCase("true")) {
	                investigationPage.checkOutsideTest();
	            }

	            // Handle Discount
	            if (inv.get("provideDiscount").equalsIgnoreCase("true")) {
	                investigationPage.checkProvideDiscount();
	                investigationPage.selectDiscountType(inv.get("discountType"));
	                investigationPage.enterDiscountAmount(inv.get("discountAmount"));
	            }

	            // Click Add Investigation
	            investigationPage.clickAddInvestigation();
	        }

	        // Step 4: Collapse Investigation section
	        investigationPage.clickInvestigationToggle();
	    }

	    
	    @Test(dataProvider = "getDataForLogin", priority = 20)
		   public void holdbill(HashMap<String, String> input) throws InterruptedException {
		   	PatientList patient = new PatientList(driver);
		    Thread.sleep(1000);
		    patient.patientlist();
		   	patient.findPatientByMobile(targetMobileNumber);
		   	
		   	ServiceList service = new ServiceList(driver);
//		   	service.fillBillingForm("General", "Dr. Izaan", "Payer","Blood Sugar - LabTest","10","%","5");
//
//		   	service.selectDropdownOption("General");
//
////	        clickPhysicianDropdown();
//		   	service.selectDropdownOption("Dr. Izaan");
//
//		   	service.clickBillTypeDropdown();
//	        service.selectDropdownOption("Payer");
//	        service.clickPayerSelectDropdown();
//	        service.selectDropdownOption("Test Payer");
//	        
//	        service.clickServiceNameDropdown();
			service.byTextAttach("Physician", "/ancestor::div[1]//a").click();
	        service.selectDropdownOption("Blood Sugar - LabTest"); // or any other service

	        service.enterQuantity("10");

	        service.clickDiscountTypeDropdown();
	        service.selectDropdownOption("%");
//	        Thread.sleep(8000);
	        service.enterDiscountPercentage("5");
//	        Thread.sleep(5000);
	        service.clickAddButton();
	        service.clickServiceNameDropdown();
	        service.selectDropdownOption("Blood Sugar2 - LabTest"); // or any other service

	        service.enterQuantity("10");

	        service.clickDiscountTypeDropdown();
	        service.selectDropdownOption("%");
//	        Thread.sleep(8000);
	        service.enterDiscountPercentage("5");
//	        Thread.sleep(5000);
	        service.clickAddButton();
	        PaymentPage payment = new PaymentPage(driver);
//	        String payerName = "Test Payer";
	        String referenceNo = "477";
	        String amount = "0";
//	        payment.enterCreditAmount("2");
	        payment.enterInsurancePayment( referenceNo, amount);
	        
	        service.clickServiceNameDropdown();
	        service.selectDropdownOption("Blood Sugar1 - LabTest"); // or any other service

	        service.enterQuantity("10");

	        service.clickDiscountTypeDropdown();
	        service.selectDropdownOption("%");
//	        Thread.sleep(8000);
	        service.enterDiscountPercentage("5");
//	        Thread.sleep(5000);
	        service.clickAddButton();
//	      service.clickServiceNameDropdown();

	// 
	        service.hold();
	    }
//	    
		String strbillno ;
	    @Test(dataProvider = "getDataForLogin", priority = 21)
		   public void creditbill(HashMap<String, String> input) throws InterruptedException {
		   	PatientList patient = new PatientList(driver);
		    Thread.sleep(1000);
		    patient.patientlist();
		   	patient.findPatientByMobile(targetMobileNumber);
		   	
		   	ServiceList service = new ServiceList(driver);
//		   	service.fillBillingForm("General", "Dr. Izaan", "Payer","Blood Sugar - LabTest","10","%","5");
//
//		   	service.selectDropdownOption("General");
//
////	        clickPhysicianDropdown();
//		   	service.selectDropdownOption("Dr. Izaan");
//
//		   	service.clickBillTypeDropdown();
//	        service.selectDropdownOption("Payer");
//	        service.clickPayerSelectDropdown();
//	        service.selectDropdownOption("Test Payer");
//	        
//	        service.clickServiceNameDropdown();
			service.byTextAttach("Physician", "/ancestor::div[1]//a").click();
	        service.selectDropdownOption("Blood Sugar - LabTest"); // or any other service

	        service.enterQuantity("10");

	        service.clickDiscountTypeDropdown();
	        service.selectDropdownOption("%");
//	        Thread.sleep(8000);
	        service.enterDiscountPercentage("5");
//	        Thread.sleep(5000);
	        service.clickAddButton();
	        service.clickServiceNameDropdown();
	        service.selectDropdownOption("Blood Sugar2 - LabTest"); // or any other service

	        service.enterQuantity("10");

	        service.clickDiscountTypeDropdown();
	        service.selectDropdownOption("%");
//	        Thread.sleep(8000);
	        service.enterDiscountPercentage("5");
//	        Thread.sleep(5000);
	        service.clickAddButton();
	        PaymentPage payment = new PaymentPage(driver);
//	        String payerName = "Test Payer";
	        String referenceNo = "477";
	        String amount = "0";
//	        payment.enterCreditAmount("2");
	        payment.enterInsurancePayment( referenceNo, amount);
	        service.save();
	        service.clickServiceNameDropdown();
	        service.selectDropdownOption("Blood Sugar1 - LabTest"); // or any other service

	        service.enterQuantity("10");

	        service.clickDiscountTypeDropdown();
	        service.selectDropdownOption("%");
//	        Thread.sleep(8000);
	        service.enterDiscountPercentage("5");
//	        Thread.sleep(5000);
	        service.clickAddButton();
//	      service.clickServiceNameDropdown();
	        payment.enterCashAmount("0");
	        payment.enterCreditAmount("70");
	// 
	        service.save();
	       	Bill billno = new Bill(driver);
		   	 strbillno = billno.getBillNumber();
	    }
	    
	    
	    
	    @Test(dataProvider = "getDataForLogin", priority = 22)
		   public void creditbillaccounts(HashMap<String, String> input) throws InterruptedException {
		   	PatientList patient = new PatientList(driver);
		    Thread.sleep(1000);
		    patient.patientlist();
		   	patient.findPatientByMobile(targetMobileNumber);
		   	CreditBillSelf credit = new CreditBillSelf(driver);
		   	credit.clickbuttonapproval();
		
		   	credit.selectPatientByBillNo(strbillno);
		   	credit.receptionist();
		    PaymentPage payment = new PaymentPage(driver);
		    payment.enterCashAmount("1");
		    payment.enterCardPayment2("Visa", "1234", "10");
		    payment.enterOnlinePayment("Airtel Pay", "234", "50");
//		    payment.chequedd("25", "5");
		    payment.enterNetBankingPayment("AB Bank Ltd.", "24", "5");
		    payment.chequedd("25", "4");
//		    payment.enterWalletAmount2("0");
		 	ServiceList service = new ServiceList(driver);
		 	service.save();
		    
	    }
	    @Test(dataProvider = "getDataForLogin", priority = 24)
		   public void podiotry(HashMap<String, String> input) throws InterruptedException {
		   	PatientList patient = new PatientList(driver);
		    Thread.sleep(1000);
		    patient.patientlist();
		   	patient.findPatientByMobile(targetMobileNumber);
		   	
		   	ServiceList service = new ServiceList(driver);
//		   	service.fillBillingForm("General", "Dr. Izaan", "Payer","Blood Sugar - LabTest","10","%","5");
//
//		   	service.selectDropdownOption("General");
//
////	        clickPhysicianDropdown();
//		   	service.selectDropdownOption("Dr. Izaan");
//
//		   	service.clickBillTypeDropdown();
//	        service.selectDropdownOption("Payer");
//	        service.clickPayerSelectDropdown();
//	        service.selectDropdownOption("Test Payer");
//	        
//	        service.clickServiceNameDropdown();
			service.byTextAttach("Physician", "/ancestor::div[1]//a").click();
		   	service.billCounter();
		   	service.selectDropdownOption("podiatry");
		    service.clickServiceNameDropdown();
	        service.selectDropdownOption("Blood Sugar - LabTest"); // or any other service

	        service.enterQuantity("10");

	        service.clickDiscountTypeDropdown();
	        service.selectDropdownOption("%");
//	        Thread.sleep(8000);
	        service.enterDiscountPercentage("5");
//	        Thread.sleep(5000);
	        service.clickAddButton();
	        service.clickServiceNameDropdown();
	        service.selectDropdownOption("Blood Sugar2 - LabTest"); // or any other service

	        service.enterQuantity("10");

	        service.clickDiscountTypeDropdown();
	        service.selectDropdownOption("%");
//	        Thread.sleep(8000);
	        service.enterDiscountPercentage("5");
//	        Thread.sleep(5000);
	        service.clickAddButton();
	        PaymentPage payment = new PaymentPage(driver);
//	        String payerName = "Test Payer";
	        String referenceNo = "477";
	        String amount = "0";
//	        payment.enterCreditAmount("2");
	        payment.enterInsurancePayment( referenceNo, amount);
	        service.save();
	        service.clickServiceNameDropdown();
	        service.selectDropdownOption("Blood Sugar1 - LabTest"); // or any other service

	        service.enterQuantity("10");

	        service.clickDiscountTypeDropdown();
	        service.selectDropdownOption("%");
//	        Thread.sleep(8000);
	        service.enterDiscountPercentage("5");
//	        Thread.sleep(5000);
	        service.clickAddButton();
//	      service.clickServiceNameDropdown();
//	        payment.enterCashAmount("0");
//	        payment.enterCreditAmount("70");
	// 
	        service.save();
	    }  
////	    

	    @DataProvider
	    public Object[][] getDataForLogin() throws IOException {
	        List<HashMap<String, String>> data = getJsonDataToMap(
	            System.getProperty("user.dir") + "//src//main//java//ezion//Resources//AppointMent.json"
	        );
	        return new Object[][] { { data.get(0) } };
	    }
}
