package Lab;

import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class ResultEntryPage extends Abstraction{

	public ResultEntryPage(WebDriver driver) {
		super(driver);
	    PageFactory.initElements(driver, this);
	}
	public void clickEditIconByTestName(String testName) {
	    try {
	        WebElement editIcon = driver.findElement(By.xpath(
	            "//tr[contains(@class,'ng-star-inserted')]" +
	            "[.//td[contains(translate(normalize-space(.), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '" 
	            + testName.toLowerCase() + "')]]" +
	            "//img[contains(@class,'edit-icon')]"
	        ));

	        waitForClickability(editIcon).click();
	        System.out.println("✅ Clicked edit icon for test: " + testName);

	    } catch (NoSuchElementException e) {
	        System.out.println("❌ Test '" + testName + "' not found in table");
	        throw e;
	    }
	}

}
