package PharmacySalesPage;

public class Snippet {
	public static void main(String[] args) {
	
	}
}

