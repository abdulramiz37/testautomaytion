package WareHouseSetup.MyHospital;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import EzionAbstractionComponents.Abstraction;

import java.util.List;

public class ValidityTypePage extends Abstraction {

    WebDriver driver;

    public ValidityTypePage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // --- Locators ---

    @FindBy(xpath = "//ngx-select[@formcontrolname='type']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement validityTypeDropdown;

    @FindBy(xpath = "//ul[contains(@class,'ngx-select__choices')]/li/a/span")
    private List<WebElement> validityTypeOptions;

    @FindBy(xpath = "//input[@formcontrolname='days']")
    private WebElement daysInput;

    @FindBy(xpath = "//input[@type='button' and @value='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
    private WebElement cancelButton;

    @FindBy(xpath = "//a[text()=' Package Validity ']")
    private WebElement userType;

    @FindBy(xpath = "//a[text()=' Add Package Validity ']")
    private WebElement adduserType;
     
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}
    // Select a Validity Type option (e.g., "Days", "One Time", "Till Consumed", "Life Time")
    public void selectValidityType(String type) {
        validityTypeDropdown.click();
        for (WebElement option : validityTypeOptions) {
            if (option.getText().trim().equalsIgnoreCase(type)) {
                option.click();
                break;
            }
        }
    }
    public void clearAndType(WebElement element, String value) {
        element.clear();
        element.sendKeys(value);
    }

    // Enter number of Days
    public void enterDays(String days) {
        clearAndType(daysInput, days);
    }

    // Click Save button
    public void clickSave() {
        saveButton.click();
    }

    // Click Cancel button
    public void clickCancel() {
        cancelButton.click();
    }

    // Combined method to fill and submit form
    public void fillValidityTypeForm(String type, String days) {
    	clickbuttonapproval();
        selectValidityType(type);
        enterDays(days);
        clickSave();
    }
}
