package WareHouseSetup.IPpharmacy;


import java.util.List;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class WardInformationPage extends Abstraction {

    WebDriver driver;

    public WardInformationPage(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // ---------------- Locators ---------------- //

    @FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement wardNameInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='wardMap']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement wardMappingDropdown;

    @FindBy(xpath = "//input[@formcontrolname='tariff']")
    private WebElement fullDayTariffInput;

    @FindBy(xpath = "//input[@formcontrolname='halfDayTariff']")
    private WebElement halfDayTariffInput;

    @FindBy(xpath = "//input[@formcontrolname='hourlyTariff']")
    private WebElement hourlyTariffInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='gstPercentage']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement gstDropdown;

    @FindBy(xpath = "//input[@formcontrolname='peopleAllowed']")
    private WebElement peopleAllowedInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='facility']//input[@role='combobox']")
    private WebElement facilitiesNameDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='comboServices']//input[@role='combobox']")
    private WebElement comboServicesDropdown;

    @FindBy(xpath = "//input[@value='24 HRS']")
    private WebElement calculationMethod24HrsRadio;

    @FindBy(xpath = "//input[@value='Check Out Time']")
    private WebElement calculationMethodCheckOutRadio;

    @FindBy(xpath = "//input[@formcontrolname='isICU']")
    private WebElement isICUCheckbox;

    @FindBy(xpath = "//input[@formcontrolname='isActive']")
    private WebElement isActiveCheckbox;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//input[@value='Cancel']")
    private WebElement cancelButton;

    @FindBy(xpath = "//input[@value='Clear']")
    private WebElement clearButton;

    // ---------------- Methods ---------------- //
    @FindBy(xpath = "//a[text()=' Ward']")
    private WebElement userType;

    @FindBy(xpath = "//a[text()=' Add Ward ']")
    private WebElement adduserType;
    // 🔹 Methods
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}
    public void enterWardName(String name) {
        wardNameInput.clear();
        wardNameInput.sendKeys(name);
    }

    public void selectWardMapping(String optionText) {
        wardMappingDropdown.click();
        WebElement option = driver.findElement(By.xpath("//ul[@role='menu']//span[normalize-space()='" + optionText + "']"));
        option.click();
    }

    public void enterFullDayTariff(String tariff) {
        fullDayTariffInput.clear();
        fullDayTariffInput.sendKeys(tariff);
    }

    public void enterHalfDayTariff(String tariff) {
        halfDayTariffInput.clear();
        halfDayTariffInput.sendKeys(tariff);
    }

    public void enterHourlyTariff(String tariff) {
        hourlyTariffInput.clear();
        hourlyTariffInput.sendKeys(tariff);
    }

    public void selectGST(String gstValue) {
        gstDropdown.click();
        WebElement option = driver.findElement(By.xpath("//ul[@role='menu']//span[normalize-space()='" + gstValue + "']"));
        option.click();
    }

    public void enterPeopleAllowed(String number) {
        peopleAllowedInput.clear();
        peopleAllowedInput.sendKeys(number);
    }

    public void selectFacilities(List<String> facilityNames) {
        for (String facility : facilityNames) {
        	facilitiesNameDropdown.clear();
            facilitiesNameDropdown.sendKeys(facility);
            facilitiesNameDropdown.sendKeys(Keys.ENTER);
        }
    }

    public void selectComboService(List<String> serviceNames) {
        for (String service : serviceNames) {
        	comboServicesDropdown.clear();
        	   comboServicesDropdown.sendKeys(service);
               comboServicesDropdown.sendKeys(Keys.ENTER);
        }
    }


    public void selectCalculationMethod(String method) {
        if (method.equalsIgnoreCase("24 HRS")) {
            calculationMethod24HrsRadio.click();
        } else if (method.equalsIgnoreCase("Check Out Time")) {
            calculationMethodCheckOutRadio.click();
        }
    }

    public void setICU(boolean enable) {
        if (isICUCheckbox.isSelected() != enable) {
            isICUCheckbox.click();
        }
    }

    public void setActive(boolean enable) {
        if (isActiveCheckbox.isSelected() != enable) {
            isActiveCheckbox.click();
        }
    }

    public void clickSave() {
        saveButton.click();
    }

    public void clickCancel() {
        cancelButton.click();
    }

    public void clickClear() {
        clearButton.click();
    }
}

