package WareHouseSetup.MyHospital.Service;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import EzionAbstractionComponents.Abstraction;

public class GeneralPackagePage extends Abstraction {

    WebDriver driver;

    public GeneralPackagePage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // ========== Locators ==========

    @FindBy(xpath = "(//input[@formcontrolname='name'])[7]")
    private WebElement generalPackageNameInput;

    @FindBy(xpath = "(//input[@formcontrolname='packagePrice'])")
    private WebElement generalPackagePriceInput;

    @FindBy(xpath = "//ngx-select[@formcontrolname='packageType']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement packageTypeDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='packageStatus']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement packageStatusDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='editStatus']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement allowEditingDropdown;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//input[@value='Cancel']")
    private WebElement cancelButton;

    @FindBy(xpath = "//span[text()='General Package']")
    private WebElement generalPackageTab;

    @FindBy(xpath = "//a[contains(@class,'btn-plus') and .//img[@alt='add']]")
    private WebElement addPackageButton;

    
    @FindBy(xpath = "//ngx-select[@formcontrolname='validity']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement validityDropdown;

    @FindBy(xpath = "(//ngx-select[@formcontrolname='scid']//div[contains(@class,'ngx-select__toggle')])[5]")
    private WebElement serviceCategoryDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='applicableFor']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement applicableForDropdown;

    @FindBy(xpath = "//input[@formcontrolname='packBudgetLimit1']")
    private WebElement minBudgetLimitInput;

    @FindBy(xpath = "//input[@formcontrolname='packBudgetLimit2']")
    private WebElement maxBudgetLimitInput;

    @FindBy(xpath = "//input[@formcontrolname='zeroServiceFlag'][@type='checkbox']")
    private WebElement allowZeroCheckbox;

    @FindBy(xpath = "(//input[@name='restrictType' and @value='1'])[5]")
    private WebElement restrictAllRadio;

    @FindBy(xpath = "(//input[@name='restrictType' and @value='2'])[5]") //
    private WebElement restrictWeekdaysRadio;

    @FindBy(xpath = "(//input[@name='restrictType' and @value='3'])[5]")
    private WebElement restrictWeekendRadio;

    @FindBy(xpath = "(//input[@name='restrictType' and @value='4'])[5]")
    private WebElement restrictManualRadio;

    @FindBy(xpath = "//ngx-select[@formcontrolname='lgid']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement selectLabTestDropdown;

    @FindBy(xpath = "(//input[@value='Add'])[3]")
    private WebElement addLabTestButton;


 // Visit Name Dropdown (Select/Type)
    @FindBy(xpath = "//ngx-select[@formcontrolname='visitName']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement visitNameDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='visitName']//input[@type='text']")
    private WebElement visitNameSearchInput;

    // Optional: Placeholder text or selected value
    @FindBy(xpath = "//ngx-select[@formcontrolname='visitName']//span[contains(@class,'ngx-select__placeholder')]")
    private WebElement visitNamePlaceholder;

    // Sort Order Position input
    @FindBy(xpath = "//input[@formcontrolname='sortOrderPositionId']")
    private WebElement sortOrderPositionInput;

    // Quantity input
    @FindBy(xpath = "//input[@formcontrolname='quantity']")
    private WebElement quantityInput;

    @FindBy(xpath = "//input[@formcontrolname='priceLimit1']")
    private WebElement minPriceLimitInput;

    @FindBy(xpath = "//input[@formcontrolname='priceLimit2']")
    private WebElement maxPriceLimitInput;

    // ========== Actions ==========

    public void openGeneralPackageForm() {
        clickWithJavaScript(generalPackageTab);
        clickWithJavaScript(addPackageButton);
    }

    public void enterPackageName(String name) {
        generalPackageNameInput.clear();
        generalPackageNameInput.sendKeys(name);
    }

    public void enterPackagePrice(String price) {
        generalPackagePriceInput.clear();
        generalPackagePriceInput.sendKeys(price);
    }

    public void selectPackageType(String type) {
        packageTypeDropdown.click();
        selectDropdownOption(type);
    }

    public void selectPackageStatus(String status) {
        packageStatusDropdown.click();
        selectDropdownOption(status);
    }

    public void selectAllowEditing(String editingOption) {
        allowEditingDropdown.click();
        selectDropdownOption(editingOption);
    }

    public void clickSave() {
        saveButton.click();
    }

    public void clickCancel() {
        cancelButton.click();
    }

    // Generic reusable dropdown selector
    public void selectDropdownOption(String text) {
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//a[contains(@class,'ngx-select__item')]//span[text()='" + text + "']"
        ));
        waitForClickability(option).click();
    }

    public void selectValidity(String validityOption) {
        validityDropdown.click();
        selectDropdownOption(validityOption);
    }

    public void selectServiceCategory(String category) {
        serviceCategoryDropdown.click();
        selectDropdownOption(category);
    }

    public void selectApplicableFor(String applicableForOption) {
        applicableForDropdown.click();
        selectDropdownOption(applicableForOption);
    }

    public void enterMinBudgetLimit(String minLimit) {
        minBudgetLimitInput.clear();
        minBudgetLimitInput.sendKeys(minLimit);
    }

    public void enterMaxBudgetLimit(String maxLimit) {
        maxBudgetLimitInput.clear();
        maxBudgetLimitInput.sendKeys(maxLimit);
    }

    public void setAllowZero(boolean allowZero) {
        boolean isChecked = allowZeroCheckbox.isSelected();
        if (allowZero && !isChecked) {
            allowZeroCheckbox.click();
        } else if (!allowZero && isChecked) {
            allowZeroCheckbox.click();
        }
    }
    public void selectRestrictAll() {
        restrictAllRadio.click();
    }

    public void selectRestrictWeekdays() {
        restrictWeekdaysRadio.click();
    }

    public void selectRestrictWeekend() {
        restrictWeekendRadio.click();
    }

    public void selectRestrictManual() {
        restrictManualRadio.click();
    }

    public void selectLabTest() {
        selectLabTestDropdown.click();
        // add selection logic
    }

    public void clickAddLabTest() {
        addLabTestButton.click();
    }
    public void selectVisitName(String visitName) {
        visitNameDropdown.click();
        visitNameSearchInput.sendKeys(visitName);
        WebElement option = driver.findElement(By.xpath(
        	    "//a[contains(@class,'ngx-select__item') and contains(@class,'active')]//strong[text()='" + visitName + "']"
        	));

        waitForClickability(option).click();
    }

    public void enterSortOrderPosition(String position) {
        sortOrderPositionInput.clear();
        sortOrderPositionInput.sendKeys(position);
    }

    public void enterQuantity(String quantity) {
        quantityInput.clear();
        quantityInput.sendKeys(quantity);
    }
    
    public void setMinPriceLimit(String value) {
        minPriceLimitInput.clear();
        minPriceLimitInput.sendKeys(value);
    }

    // Set maximum price limit
    public void setMaxPriceLimit(String value) {
        maxPriceLimitInput.clear();
        maxPriceLimitInput.sendKeys(value);
    }

    // ========== Master Form Fill Method ==========

    public void fillForm(String name, String price, String type, String status, String allowEditOption, boolean submit,String validity, String category, String applicableFor,
            String minBudget, String maxBudget, boolean allowZero,String restrictType, 
            
            String labTestToSelect) {
        openGeneralPackageForm();
        enterPackageName(name);
        enterPackagePrice(price);
        selectPackageType(type);
        selectPackageStatus(status);
        selectAllowEditing(allowEditOption);
 
        selectValidity(validity);
        selectServiceCategory(category);
        selectApplicableFor(applicableFor);
        enterMinBudgetLimit(minBudget);
        enterMaxBudgetLimit(maxBudget);
//        setAllowZero(allowZero);
        
        switch (restrictType.toLowerCase()) {
        case "all":
            selectRestrictAll();
            break;
        case "weekdays":
            selectRestrictWeekdays();
            break;
        case "weekend":
            selectRestrictWeekend();
            break;
        case "manual":
            selectRestrictManual();
            break;
        default:
            throw new IllegalArgumentException("Invalid restrict type: " + restrictType);
    }

    // Lab test dropdown and selection
    selectLabTest();
    selectDropdownOption(labTestToSelect);
    
    
    selectVisitName("nklkl");
    enterSortOrderPosition("1");
    enterQuantity("3");
    setMinPriceLimit("1");
    setMaxPriceLimit("2");
    clickAddLabTest();
    
    }
}
