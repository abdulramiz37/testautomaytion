package StandAloneTest;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EzionpageObjects.NewRegistration;
import EzionpageObjects.OPBillingService;
import EzionpageObjects.UserIdPage;
import abdulTest.BaseTest;
@Test(dataProvider = "getData", groups = {"ErrorHandling"})
public class FormValidationTest extends BaseTest {
	public void FormValidation(HashMap<String,String> input) throws InterruptedException {
		UserIdPage data =login.login(input.get("userId"));
		data.enterMobileNumber(input.get("personId"));
		data.enterPassword(input.get("password"));
		
		data.clickContinue();
		
	Assert.assertTrue(data.getAlertMsg().equalsIgnoreCase("You have been successfully logged in."));
		
		NewRegistration newregistered=data.clickOnRegistration();
		newregistered.clickNewRegistration();
		newregistered.selectTitle();
		newregistered.enterFullName(input.get("firstName"), input.get("middleName"), input.get("lastName"));
		newregistered.selectDOB();
		newregistered.enterMobileNumber(input.get("mobileNumber2"));
		OPBillingService billing= newregistered.clickSave();
		billing.fillAppearanceForm(input.get("opbilling"));
	
	}
	
	@DataProvider
	public Object[][] getData() throws IOException
	{

		
		List<HashMap<String,String>> data = getJsonDataToMap(System.getProperty("user.dir")+"//src//main//java//ezion//Resources//FormValidation.json");
		return new Object[][]  {{data.get(0)}};
		
	}
}
