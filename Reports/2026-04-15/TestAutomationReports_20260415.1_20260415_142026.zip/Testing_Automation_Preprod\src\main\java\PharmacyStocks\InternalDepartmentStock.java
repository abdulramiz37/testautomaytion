package PharmacyStocks;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class InternalDepartmentStock extends Abstraction {
	WebDriver driver;

	public InternalDepartmentStock(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
    @FindBy(xpath = "//a[@title='Pharmacy']")
    private WebElement pharmacyMenu;

    @FindBy(xpath = "(//a[@title='Stock'])[1]")
    private WebElement stockMenu;
    
    @FindBy(xpath = "(//a[@title='Internal Department Stock'])[1]")
    private WebElement internalStock;
//	By tableRows   = By.xpath("//tbody//tr");
//	By medicineH4  = By.xpath(".//h4");                 // 👈 medicine name
//	By editButton  = By.xpath(".//img[@alt='image']");
//	By nextButton  = By.xpath("//span[normalize-space()='Next']");
    
    public void addOpeningStock() {

// Navigate menus
waitForClickability(pharmacyMenu).click();
waitForClickability(stockMenu).click();
waitForClickability(internalStock).click();
    }
	
	public void findMedicineAndClickEdit(String targetMedicineName) {

	    boolean isMedicineFound = false;
	    int clickCount = 0; // persist across pages

	    while (!isMedicineFound) {

	        List<WebElement> rows = driver.findElements(
	            By.xpath("(//tbody)[2]//tr")
	        );

	        for (int i = 0; i < rows.size(); i++) {
	            try {
	                WebElement row = rows.get(i);

	                // 🎯 Medicine name <h4>
	                WebElement medicineH4 = row.findElement(By.xpath(".//td[1]//h4"));
	                String medicineName = medicineH4.getText().trim();

	                System.out.println("💊 Found: " + medicineName);

	                if (medicineName.equalsIgnoreCase(targetMedicineName)) {

	                    // 🖊️ Click Edit
	                    WebElement editBtn = row.findElement(
	                        By.xpath(".//img[@alt='image']")
	                    );
	                    waitForClickability(editBtn).click();

	                    System.out.println("✅ Edit clicked for medicine: " + medicineName);
	                    isMedicineFound = true;
	                    break;
	                }

	            } catch (NoSuchElementException e) {
	                System.out.println("⚠️ Skipping row " + i + " (missing/stale element)");
	            }
	        }

	        // ➡️ If NOT found → go to next page
	        if (!isMedicineFound) {

	            if (clickCount >= 14) {
	                System.out.println("⛔ Stopped after 14 pages. Medicine not found.");
	                break;
	            }

	            try {
	                WebElement nextButton = driver.findElement(
	                    By.xpath("///span[contains(@class,'ng-star-inserted') and starts-with(normalize-space(.),'Next')]")
	                );

	                ((JavascriptExecutor) driver)
	                    .executeScript("arguments[0].click();", nextButton);

	                clickCount++;
	                System.out.println("➡️ Moving to next page... (Click " + clickCount + ")");

	                Thread.sleep(1500); // wait for table refresh

	            } catch (NoSuchElementException e) {
	                System.out.println("❌ Next button not found. Ending search.");
	                break;
	            } catch (InterruptedException e) {
	                Thread.currentThread().interrupt();
	            }
	        }
	    }
	}
	@FindBy(xpath = "//ngx-select[@formcontrolname='stockType']//div[contains(@class,'ngx-select__toggle')]")
	private WebElement stockTypeDropdown;

	@FindBy(xpath = "//input[@formcontrolname='noOfStrip']")
	private WebElement qtyInput;
	
	

	public void stockdameges() {
	    waitForVisibility(stockTypeDropdown).click();;
	
	}
	 public void selectdropdown(String damaged) {
	        

	        WebElement option = driver.findElement(By.xpath(
	            "//ul[@role='menu']//li[@role='menuitem']//span[normalize-space(text())='" + damaged + "']"
	        ));
	        option.click();
	    }
	
	public void enterQuantity(String qty) {
	    waitForVisibility(qtyInput).click();
	    qtyInput.clear();
	    qtyInput.sendKeys(qty);
	    System.out.println("✅ Quantity entered: " + qty);
	}
	@FindBy(xpath = "//textarea[contains(@class,'form-control')]")
	private WebElement notesTextarea;
	
	public void enterNotes(String notes) {
	    notesTextarea.clear();
	    notesTextarea.sendKeys(notes);
	}

}