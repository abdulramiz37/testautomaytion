package StandAloneTest;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
@Test
public class SalesReturn {
	public void PPLE() throws InterruptedException {

	WebDriver driver = new EdgeDriver();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	driver.get("https://apps.ezovion.com/auth/login");

	driver.manage().window().maximize();
	

	driver.findElement(By.xpath("//div[@class=\"form-control-group\"]//input")).sendKeys("50107299");
	driver.findElement(By.xpath("//button[@size=\"large\"]")).click();
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
        // Wait until the button with text "CONTINUE" is clickable
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\"Mobile No\"]")));
	
     driver.findElement(By.xpath("//input[@placeholder=\"Mobile No\"]")).sendKeys("7766554433");
	driver.findElement(By.xpath("//input[@placeholder=\"Password\"]")).sendKeys("12345");
	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@status=\"primary\"]")));
	 Thread.sleep(2000);
	 driver.findElement(By.xpath("//button[@status=\"primary\"]")).click();
	 for (int i = 0; i < 5; i++) { // Try up to 5 times
		    try {
		        
		        Thread.sleep(3000); // wait for any transition

		        WebElement adminTab = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Admin']")));
		        adminTab.click();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Roles Management']"))).click();
		        break; // Exit loop if successful
		    } catch (Exception e) {
		        System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
		        if (i == 4) {
		            throw e; // Re-throw if max attempts reached
		        }
		    }
		}
	 
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Pharmacy']"))).click();

	// 1. Click on "Pharmacy"
	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[text()='Sales'])[1]"))).click();


					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[text()='Sales'])[2]"))).click();

					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Counter Sales ']"))).click();

					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='mobilenumber']")))
					    .sendKeys("9876543210");

					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@role='combobox']")))
					    .sendKeys("abdul ramiz");

					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn btn-primary ng-star-inserted']")))
					    .click();

					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//strong[text()='abdul ramiz']"))).click();

					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Select Doctor']")))
					    .click();

					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Dr.  Ramiz']")))
					    .click();

//					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Search Medicine']")))
//					    .click();

					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h4[text()='Medidine Ezovion']"))).click();

					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname='quantity']")))
					    .sendKeys("4");

					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Add']")))
					    .click();

					WebElement saveButton = driver.findElement(By.xpath("//input[@value='Save']"));
					JavascriptExecutor js = (JavascriptExecutor) driver;

					// Scroll into view
					js.executeScript("arguments[0].scrollIntoView(true);", saveButton);

					// Click using JavaScript
					js.executeScript("arguments[0].click();", saveButton);


					WebElement yesButton = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@value='Yes']")));
					JavascriptExecutor js1 = (JavascriptExecutor) driver;
					js1.executeScript("arguments[0].click();", yesButton);
					
				//	(//b[@class="headerfont"])[3].getText
					
					String targetBillNo = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//b[@class='headerfont'])[3]"))).getText();

					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[text()='Sales'])[2]"))).click();
					boolean matchFound=false;
					   while (!matchFound) {
			        	    // Relocate the rows before processing
					         List<WebElement> rows = driver.findElements(By.cssSelector("table.table-style tbody tr"));
					            
					            // Iterate through each row
					            for (WebElement row : rows) {
					                try {
					                    // Get the bill number from the row
					                    WebElement billNoElement = row.findElement(By.cssSelector("td:nth-child(2) h4"));
					                    String currentBillNo = billNoElement.getText().trim();
					                    
					                    // Check if this is the row we're looking for
					                    if (currentBillNo.equals(targetBillNo)) {
					                        System.out.println("Found bill number: " + currentBillNo);
					                        
					                        // Find and click the "Go Sales Return" button
					                        WebElement salesReturnBtn = row.findElement(By.cssSelector("li a[title='Go Sales Return'] img"));
					                        salesReturnBtn.click();
					                        
					                        System.out.println("Clicked 'Go Sales Return' for bill " + targetBillNo);
					                        matchFound=true;
					                        break; // Exit loop after finding the target
					                    }
					                } catch (Exception e) {
					                    System.err.println("Error processing row: " + e.getMessage());
					                }
					            }

			        	    // If no match found, click the "Next Page" button
			        	    if (!matchFound) {
			        	        try {
			        	            // Locate the "Next Page" button
			        	            WebElement nextPageButton = driver.findElement(By.xpath("(//i[@class='fas fa-chevron-right'])[1]"));
			        	            
			        	            // Use JavaScript to click the "Next Page" button
			        	       
			        	            js.executeScript("arguments[0].click();", nextPageButton);
			        	            System.out.println("Clicked on the 'Next Page' button using JavaScript.");

			        	            // Wait for the page to load before relocating rows
			        	            Thread.sleep(1000); // Adjust wait time as needed
			        	        } catch (NoSuchElementException e) {
			        	            System.out.println("Next Page button not found. End of pages.");
			        	            break; // Stop the loop if the button is not found
			        	        } catch (InterruptedException e) {
			        	            System.out.println("Thread sleep interrupted.");
			        	        }
			        	    }
			        	}
					   
					 //input[@placeholder="Search"]
					 //h4[contains(normalize-space(), 'Medidine Ezovion')]
					   
//					   (//span[@class="checkmark"])[1]
					   //input[@formcontrolname="discount_percentage"].srndkeys("10")
					 //span[@class="custom-checkbox"]
					 //input[@value="Save"]
					   
						wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Search Medicine']")))
					    .click();
					   wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h4[contains(normalize-space(), 'Medidine Ezovion')]"))).click();
					   
					   wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[@class=\"checkmark\"])[1]"))).click();
					   wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@formcontrolname=\"discount_percentage\"]"))).sendKeys("10");
					   
					   wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value=\"Add\"]"))).click();
					     
					   wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='custom-checkbox']"))).click();
					
					   wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(" //div[@class=\"phar-tot-grands1\"]"))).click();
					   for (int i = 0; i < 5; i++) {
						    try {
						        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Save']"))).click();
						        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@value='Yes']"))).click();
						        System.out.println("Clicked Save and Yes in iteration: " + i);
						    } catch (Exception e) {
						        System.out.println("Exception in iteration " + i + ": " + e.getMessage());
						    }
						}

	}
	
}
