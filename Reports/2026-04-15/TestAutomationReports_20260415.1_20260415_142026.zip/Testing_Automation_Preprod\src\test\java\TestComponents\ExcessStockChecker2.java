package TestComponents;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EzionpageObjects.UserIdPage;
import PharmacyFlowObjects.PharmacyStore.MedicinePage;
import PharmacyFlowObjects.PharmacyStore.MedicinePageUpdate;
import PharmacyStocks.OpeningStock;
import abdulTest.BaseTest;

public class ExcessStockChecker2 extends BaseTest {

    UserIdPage data;
    MedicinePageUpdate medicinePage;
    OpeningStock openingStock;

    HashMap<String, String> currentInput;
    String uniqueName;

    // ✅ Step 1: Login for excess stock validation
    @Test(dataProvider = "getData")
    public void ExcessStockChecker2_ShouldLoginSuccessfullyForUser(HashMap<String, String> input) throws InterruptedException {
        this.currentInput = input;

//        data = login.login(input.get("userId"));
//        data.enterMobileNumber(input.get("personId"));
//        data.enterPassword(input.get("password"));
//        data.clickContinue();
        String userId = prop.getProperty("USER_ID");
        String personId = prop.getProperty("PERSON_ID");
        String password = prop.getProperty("PASSWORD");
        String browser = System.getProperty("BROWSER");
        data = login.login(userId);
        data.enterMobileNumber(personId);
        data.enterPassword(password);
        data.clickContinue();
        System.out.println("Browser: " + browser);
//        System.out.println("Base URL: " + baseUrl);
        System.out.println("User ID: " + userId);
        System.out.println("Person ID: " + personId);
        data.clickContinue();
        data.openMasterSetup();
    }

    // ✅ Step 2: Add medicine for max/min qty validation
    @Test(dependsOnMethods = "ExcessStockChecker2_ShouldLoginSuccessfullyForUser")
    public void ExcessStockChecker2_ShouldAddMedicineForExcessStockValidation() throws InterruptedException {
    	  MedicinePage medicinePage = new MedicinePage(driver);
	        medicinePage.addmedicine();
//	    for(int i=0;i<=10;i++) {
//	            MedicinePage medicinePage = new MedicinePage(driver);

	            // Add Medicine with manual values
	            medicinePage.addMedicine(
	                "",   // medicineName
	                "Schedule A1",            // scheduleText
	                "CAPSULE",       // categoryText
	                "Orlistat", // compositionText
	                "3 M HEALTH CARE",    // manufacturerText
	                "100"           // quantity
	            );
	            uniqueName=    medicinePage.uniquename;
	            // Fill additional fields manually
	            medicinePage.enterMinQty("1");
	            medicinePage.enterMaxQty("200");
	            medicinePage.enterReorderQty("20");
	            medicinePage.enterReorderLevel("5");
	            medicinePage.enterHSNCode("30049099");
	            medicinePage.selectGST("0");
	            medicinePage.selectDiscountRequired("Yes");
	            medicinePage.enterDescription("Used for fever and mild pain relief");
	            medicinePage.enterDiscount("5");
	             medicinePage.selectVaccineCheckbox(); // Uncomment if required
	            medicinePage.enterAttribute("OTC");
	            medicinePage.enterCostPrice("8.50");
	            medicinePage.enterMRP("12.00");
	            medicinePage.enterSellPrice("11.00");
	            medicinePage.enterNoOfStrips("10");
	            medicinePage.enterFreeStrips("1");

	            // Save medicine
	            medicinePage.save();
    }

    // ✅ Step 3: Add opening stock to validate excess quantity rule
    @Test(dependsOnMethods = "ExcessStockChecker2_ShouldAddMedicineForExcessStockValidation")
    public void ExcessStockChecker2_ShouldAddOpeningStockToMedicine() {
        openingStock = new OpeningStock(driver);
        openingStock.addOpeningStock(
            currentInput.get("location"),
            uniqueName,
            currentInput.get("batchNumber"),
            currentInput.get("expiryMonthYear"),
            currentInput.get("pricePerStrips"),
            currentInput.get("mrpPerStrip"),
            currentInput.get("sellPriceStrip"),
            currentInput.get("qtyInStrips"),
            currentInput.get("qtyInUnits")
        );
        
     
    }

    // ✅ Data provider
    @DataProvider
    public Object[][] getData() throws IOException {
        List<HashMap<String, String>> data = getJsonDataToMap(
            System.getProperty("user.dir") + "//src//main//java//ezion//Resources//StockList.json"
        );
        return new Object[][] { { data.get(0) } };
    }
}
