package Radiology;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class Radiology extends Abstraction {

	public Radiology(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	public void clickActionByTitle(String actionTitle) {

		WebElement actionBtn = driver.findElement(By.xpath("//ul//a[@title='" + actionTitle + "']"));

		actionBtn.click();
	}

	public void uploadFile(String filePath) {

		WebElement fileInput = driver.findElement(By.xpath("//div[contains(@class,'file-area')]//input[@type='file']"));

		fileInput.sendKeys(filePath);
	}

}
