package PrakashSirAppointmentBooking.CaseSheet.TaskOrder;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class InjectionPage extends Abstraction {

    WebDriver driver;

    public InjectionPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // --- Section Tabs ---
    @FindBy(xpath = "//a[normalize-space()='Injection']")
    private WebElement injectionTab;

    // --- Dropdowns ---
    @FindBy(xpath = "//label[contains(text(),'Injection')]/following::ngx-select[1]")
    private WebElement injectionDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='performDoc']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement performingDoctorDropdown;

    @FindBy(xpath = "//ngx-select[@formcontrolname='performNurse']//div[contains(@class,'ngx-select__toggle')]")
    private WebElement performingNurseDropdown;

    // --- Textarea ---
    @FindBy(xpath = "//textarea[@formcontrolname='notes']")
    private WebElement notesTextarea;

    // --- Buttons ---
    @FindBy(xpath = "//input[@value='Add Injection']")
    private WebElement addInjectionBtn;

    @FindBy(xpath = "//input[@value='Reset']")
    private WebElement resetBtn;

    // --- Success / Error Messages ---
    @FindBy(xpath = "//div[contains(@class,'succesfull-info-popup')]/span[contains(text(),'Injection Saved Successfully')]")
    private WebElement successMsg;

    @FindBy(xpath = "//div[contains(@class,'succesfull-info-popup')]/span[contains(text(),'Please Check the Fields')]")
    private WebElement errorMsg;

    // --- Actions ---
    public void openInjectionTab() {
        injectionTab.click();
    }

    public void selectInjection(String injection) {
        injectionDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[@role='menu']//li[@role='menuitem']/a/span[normalize-space(text())='" + injection + "']"));
        option.click();
    }

    public void selectPerformingDoctor(String doctor) {
        performingDoctorDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + doctor + "']"));
        option.click();
    }

    public void selectPerformingNurse(String nurse) {
        performingNurseDropdown.click();
        WebElement option = driver.findElement(By.xpath(
            "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space(text())='" + nurse + "']"));
        option.click();
    }

    public void enterNotes(String notes) {
        notesTextarea.clear();
        notesTextarea.sendKeys(notes);
    }

    public void clickAddInjection() {
        addInjectionBtn.click();
    }

    public void clickReset() {
        resetBtn.click();
    }

    public boolean isInjectionSavedSuccessfully() {
        return successMsg.isDisplayed();
    }

    public boolean isInjectionErrorDisplayed() {
        return errorMsg.isDisplayed();
    }
}
