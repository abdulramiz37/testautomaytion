package PharmacySalesPage;

import java.util.List;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import EzionAbstractionComponents.Abstraction;

public class SalesReturnPage extends Abstraction {

    public SalesReturnPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    // Static factory-based elements
    @FindBy(xpath = "//span[text()='Search Medicine']")
    WebElement searchMedicineBtn;

    @FindBy(xpath = "(//span[@class='checkmark'])[1]")
    WebElement checkboxSelect;

    @FindBy(xpath = "//input[@formcontrolname='discount_percentage']")
    WebElement discountInput;

    @FindBy(xpath = "//input[@value='Add']")
    WebElement addButton;

    @FindBy(xpath = "//span[@class='custom-checkbox']")
    WebElement customCheckbox;

    @FindBy(xpath = "//div[@class='phar-tot-grands1']")
    WebElement grandTotalSection;

    @FindBy(xpath = "//input[@value='Save']")
    WebElement saveButton;

    @FindBy(xpath = "//input[@value='Yes']")
    WebElement yesButton;

    @FindBy(xpath = "//input[@formcontrolname='quantity']")
    WebElement quantityInput;
    
 // at top of class
    @FindBy(xpath = "//input[@formcontrolname='quantity']/ancestor::div[contains(@class,'form-group')]//p[contains(text(),'Quantity is required')]")
    private WebElement quantityRequiredError;

    @FindBy(xpath = "//input[@formcontrolname='discount_percentage']/ancestor::div[contains(@class,'form-group')]//p[contains(text(),'Max Discount % length is')]")
    private WebElement maxDiscountLengthError;

    @FindBy(xpath = "//input[@formcontrolname='discount_percentage']/ancestor::div[contains(@class,'form-group')]//p[contains(text(),'Incorrect Discount')]")
    private WebElement incorrectDiscountError;


    
    public String getQuantityRequiredError() {
    	System.out.println((quantityRequiredError).getText());
        return waitForVisibility(quantityRequiredError).getText().trim();
    }

    public String getMaxDiscountLengthError() {
    	System.out.println((maxDiscountLengthError).getText());
        return waitForVisibility(maxDiscountLengthError).getText().trim();
    }

    public String getIncorrectDiscountError() {
    	
        return waitForVisibility(incorrectDiscountError).getText().trim();
    }
    
   
    public void enterQuantity(String quantity) {
        try {
            // Wait for the quantity input to be visible and clickable
            WebElement input = waitForVisibility(quantityInput);
            waitForClickability(input);

            // Clear existing value and enter the new quantity
            input.clear();
            input.sendKeys(quantity);

            System.out.println("✅ Quantity entered successfully: " + quantity);
        } catch (Exception e) {
            System.err.println("❌ Failed to enter quantity: " + e.getMessage());
        }
    }


    public void processSalesReturn(List<String> medicineNames, List<String> quantities, List<String> discounts) {
        for (int i = 0; i < medicineNames.size(); i++) {
            String medicineName = medicineNames.get(i);
            String quantity = quantities.get(i);
            String discount = discounts.get(i);

            waitForClickability(searchMedicineBtn).click();

            // Dynamic locator for medicine card
            By dynamicMedicineCard = By.xpath("//h4[contains(normalize-space(), '" + medicineName + "')]");
            WebElement medicineCardElement = waitForClickability(driver.findElement(dynamicMedicineCard));
            medicineCardElement.click();

            waitForClickability(checkboxSelect).click();
            enterQuantity(quantity);
            waitForVisibility(discountInput).sendKeys(discount);

            waitForClickability(addButton).click();
        }

        // ✅ After processing all medicines, finalize
        waitForClickability(customCheckbox).click();
        waitForClickability(grandTotalSection).click();
    }

    public void savetheSales() {
        for (int i = 0; i < 3; i++) {
            try {
                waitForClickability(saveButton,2).click();
                waitForClickability(yesButton,2).click();
                System.out.println("✅ Save successful on iteration: " + i);
                break;
            } catch (Exception e) {
                System.out.println("⚠️ Attempt " + i + " failed: " + e.getMessage());
                if (i == 2) throw e;
            }
        }
    }
}
