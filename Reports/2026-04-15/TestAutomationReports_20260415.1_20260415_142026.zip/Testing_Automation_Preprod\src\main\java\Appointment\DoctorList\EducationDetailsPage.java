package Appointment.DoctorList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class EducationDetailsPage extends Abstraction{

	public EducationDetailsPage(WebDriver driver) {
		super(driver);
	    this.driver = driver;
        PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "//label[contains(text(), 'Select Qualification')]/following-sibling::ngx-select//div[@class='ngx-select__toggle btn form-control']")
	private WebElement qualificationDropdown;

	@FindBy(xpath = "//input[@formcontrolname='qualificationNotes']")
	private WebElement shortNameInput;

	@FindBy(xpath = "//input[@formcontrolname='yearofpassing']")
	private WebElement yearOfPassingInput;

	@FindBy(xpath = "//label[contains(text(), 'Select Institution')]/following-sibling::ngx-select//div[@class='ngx-select__toggle btn form-control']")
	private WebElement institutionDropdown;

	@FindBy(xpath = "(//input[@formcontrolname='city'])[2]")
	private WebElement cityNameInput;

	@FindBy(xpath = "(//label[contains(text(), 'Select Country')]/following-sibling::ngx-select//div[@class='ngx-select__toggle btn form-control'])[2]")
	private WebElement countryDropdown;

	@FindBy(xpath = "//input[@type='button' and @value='Add']")
	private WebElement addEducationButton;

	@FindBy(xpath = "//input[@type='button' and @value='Save']")
	private WebElement saveButton;

	@FindBy(xpath = "(//input[@type='button' and @value='Save and Continue'])[2]")
	private WebElement saveAndContinueButton;

	@FindBy(xpath = "//input[@type='button' and @value='Cancel']")
	private WebElement cancelButton;

	public void selectQualification(String qualification) {
	    qualificationDropdown.click();
	    selectDropdownOptionByVisibleText(qualification); // Custom method to select from dropdown
	}

	public void enterShortName(String shortName) {
	    waitForVisibility(shortNameInput).clear();
	    shortNameInput.sendKeys(shortName);
	}

	public void enterYearOfPassing(String year) {
	    waitForVisibility(yearOfPassingInput).clear();
	    yearOfPassingInput.sendKeys(year);
	}

	public void selectInstitution(String institution) {
	    institutionDropdown.click();
	    selectDropdownOptionByVisibleText(institution);
	}

	public void enterCityName(String city) {
	    waitForVisibility(cityNameInput).clear();
	    cityNameInput.sendKeys(city);
	}

	public void selectCountry(String country) {
	    countryDropdown.click();
	    selectDropdownOptionByVisibleText(country);
	}

	public void clickAddEducation() {
	    waitForClickability(addEducationButton).click();
	}

	public void clickSave() {
	    waitForClickability(saveButton).click();
	}

	public void clickSaveAndContinue() {
	    waitForClickability(saveAndContinueButton).click();
	}

	public void clickCancel() {
	    waitForClickability(cancelButton).click();
	}
	public void selectDropdownOptionByVisibleText(String text) {
	    WebElement option = driver.findElement(By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[text()='" + text + "']"));
	    waitForClickability(option).click();
	}

	public void fillEducationDetailsForm(String qualification, String shortName, String yearOfPassing, String institution, String city, String country) {
	    selectQualification(qualification);
	    enterShortName(shortName);
	    enterYearOfPassing(yearOfPassing);
	    selectInstitution(institution);
	    enterCityName(city);
	    selectCountry(country);
//	    clickAddEducation();
	}


}
