package StandAloneTest;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EzionpageObjects.UserIdPage;
import abdulTest.BaseTest;
import org.testng.Assert;

public class SubmitOrderTest extends BaseTest {
	@Test(dataProvider="getData")
	public void submitOrdertest(HashMap<String,String> input) throws InterruptedException {
		UserIdPage data =login.login(input.get("userId"));
		data.enterMobileNumber(input.get("personId"));
		data.enterPassword(input.get("password"));
		
		data.clickContinue();
		
		Assert.assertTrue(data.getAlertMsg().equalsIgnoreCase("You have been successfully logged in."));
		
	
	
	}
	
	@DataProvider
	public Object[][] getData() throws IOException
	{

		
		List<HashMap<String,String>> data = getJsonDataToMap(System.getProperty("user.dir")+"//src//main//java//ezion//Resources//Credenitals.json");
		return new Object[][]  {{data.get(0)}
		, {data.get(1) },{data.get(2) },{data.get(3) }
		};
		
	}
}
