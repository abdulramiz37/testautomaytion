package PharmacyFlowObjects.PharmacyStore;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.*;

import EzionAbstractionComponents.Abstraction;

import java.time.Duration;

public class MedicinePageUpdate extends Abstraction {

    WebDriver driver;
    WebDriverWait wait;

    public MedicinePageUpdate(WebDriver driver) {
        super(driver);
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        PageFactory.initElements(driver, this);
    }

    // --- Web Elements ---

    @FindBy(xpath = "//a[text()=' Medicine']")
    private WebElement medicineMenu;

    @FindBy(xpath = "//a[text()=' Add Medicine ']")
    private WebElement addMedicineBtn;

    @FindBy(xpath = "(//input[@type='text'])[3]")
    private WebElement medicineNameInput;

    @FindBy(xpath = "(//input[@type='text'])[4]")
    private WebElement scheduleDropdownInput;

    @FindBy(xpath = "(//input[@type='text'])[5]")
    private WebElement categoryDropdownInput;

    @FindBy(xpath = "(//input[@type='text'])[6]")
    private WebElement brandDropdownInput;

    @FindBy(xpath = "(//input[@type='text'])[7]")
    private WebElement compositionDropdownInput;

    @FindBy(xpath = "(//input[@type='text'])[8]")
    private WebElement manufacturerDropdownInput;

    @FindBy(xpath = "//input[@formcontrolname='minQty']")
    private WebElement minQtyInput;

    @FindBy(xpath = "//input[@formcontrolname='maxQty']")
    private WebElement maxQtyInput;

    @FindBy(xpath = "(//input[@type='number'])[1]")
    private WebElement quantityInput;

    @FindBy(xpath = "(//input[@type='text'])[12]")
    private WebElement rackDropdownInput;

    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveButton;
    private WebElement getSpanByText2(String text) {
        String xpath = String.format("//span[text()='%s']", text);
        return driver.findElement(By.xpath(xpath));
    }
    // --- Dynamic Span Getter ---
    private By getSpanByText(String text) {
        return By.xpath("//span[normalize-space(text())='" + text + "']");
    }

    // --- Actions ---
    String uniqueName=null;
    public void addMedicine(String baseMedicineName, String scheduleText, String categoryText, String brandText,
                            String compositionText, String manufacturerText, String quantity,
                            String minQty, String maxQty,String rackText) throws InterruptedException {

        medicineMenu.click();
        addMedicineBtn.click();

        waitForPageLoad();

        // Generate unique medicine name logic
        int counter = 1;
         uniqueName = baseMedicineName + counter;

        while (true) {
            waitForVisibility(medicineNameInput).clear();
            medicineNameInput.sendKeys(uniqueName);

            try {
                new WebDriverWait(driver, Duration.ofSeconds(0))
                    .until(ExpectedConditions.invisibilityOfElementLocated(
                        By.xpath("//span[contains(text(),'Name Already Exists..')]")));
                break;
            } catch (TimeoutException e) {
                counter++;
                uniqueName = baseMedicineName + counter;
            }
        }

        scheduleDropdownInput.click();
        retryClickSpan(scheduleText, 4);

        categoryDropdownInput.click();
        retryClickSpan(categoryText, 4);

        brandDropdownInput.click();
        retryClickSpan(brandText, 5);

        compositionDropdownInput.click();
        retryClickSpan(compositionText, 5);

        manufacturerDropdownInput.click();
        retryClickSpan(manufacturerText, 4);

        quantityInput.sendKeys(quantity);
        minQtyInput.sendKeys(minQty);
        maxQtyInput.sendKeys(maxQty);

       
        rackDropdownInput.click();
        retryClickSpan2(rackText, 4);
    }

    public CustomerPageUpdate save() {
        saveButton.click();
        waitForPharmacyPageWithBackClickOnce2();
        return new CustomerPageUpdate(driver);
    }

    private void waitForPageLoad() {
        wait.until(webDriver ->
            ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
    }

    private void retryClickSpan(String spanText, int maxAttempts) throws InterruptedException {
        By locator = getSpanByText(spanText);
        
        for (int i = 0; i < maxAttempts; i++) {
            try {
                wait.until(ExpectedConditions.elementToBeClickable(locator)).click();
                break;
            } catch (Exception e) {
                if (i == maxAttempts - 1) throw e;
            }
        }
    }
    public String uniqueName() {
    	return uniqueName;
    }
    private void retryClickSpan2(String spanText, int maxAttempts) throws InterruptedException {
        for (int i = 0; i < maxAttempts; i++) {
            try {
            	waitForClickability(getSpanByText2(spanText)).click();
                break;
            } catch (Exception e) {
                System.out.println("Attempt " + (i + 1) + " failed: " + e.getMessage());
                if (i == maxAttempts - 1) throw e;
             
            }
        }
    }
    
    
}

