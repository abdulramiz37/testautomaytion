package Appointment.DoctorList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class CouncilPage extends Abstraction{

	public CouncilPage(WebDriver driver) {
		super(driver);
	    this.driver = driver;
        PageFactory.initElements(driver, this);
	}
	
	// --- Council Details Locators ---

	@FindBy(xpath = "//input[@formcontrolname='councilNum']")
	private WebElement councilNumberInput;

	@FindBy(xpath = "//ngx-select[@formcontrolname='councilId']//div[contains(@class,'ngx-select__toggle')]")
	private WebElement councilDropdown;

	@FindBy(xpath = "//input[@formcontrolname='date']")
	private WebElement registrationDateInput;

	@FindBy(xpath = "//input[@type='button' and @value='Add']")
	private WebElement addCouncilButton;

	@FindBy(xpath = "//input[@type='button' and @value='Save']")
	private WebElement saveButton;

	@FindBy(xpath = "(//input[@type='button' and @value='Save and Continue'])[3]")
	private WebElement saveAndContinueButton;

	@FindBy(xpath = "//input[@type='button' and @value='Cancel']")
	private WebElement cancelButton;

	
	public void enterCouncilNumber(String councilNumber) {
	    waitForVisibility(councilNumberInput).clear();
	    councilNumberInput.sendKeys(councilNumber);
	}

	public void selectCouncil(String councilName) {
	    councilDropdown.click();
	    WebElement option = driver.findElement(
	        By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[text()='" + councilName + "']")
	    );
	    waitForClickability(option).click();
	}

	public void enterRegistrationDate(String date) {
	    registrationDateInput.clear();
	    registrationDateInput.sendKeys(date);
	}

	public void clickAddCouncil() {
	    waitForClickability(addCouncilButton).click();
	}

	public void clickSaveCouncilDetails() {
	    waitForClickability(saveButton).click();
	}

	public void clickSaveAndContinue() {
	    waitForClickability(saveAndContinueButton).click();
	}

	public void clickCancelCouncilDetails() {
	    waitForClickability(cancelButton).click();
	}
	public void fillCouncilDetails(String number, String council, String regDate) {
	    enterCouncilNumber(number);
	    selectCouncil(council);
	    enterRegistrationDate(regDate);
//	    clickAddCouncil();
	}

}
