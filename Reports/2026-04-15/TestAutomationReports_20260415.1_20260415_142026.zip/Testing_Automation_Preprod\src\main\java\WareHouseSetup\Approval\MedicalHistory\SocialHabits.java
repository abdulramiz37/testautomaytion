package WareHouseSetup.Approval.MedicalHistory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class SocialHabits extends Abstraction {

	public SocialHabits(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//input[@formcontrolname='name']")
	private WebElement txtSocialHabitName;

	@FindBy(xpath = "//input[@type='checkbox' and @formcontrolname='isActive']")
	private WebElement chkIsActive;

	@FindBy(xpath = "//input[@formcontrolname='attribute']")
	private WebElement txtAttribute;

	@FindBy(xpath = "//input[@type='button' and @value='Add Attribute']")
	private WebElement btnAddAttribute;

	@FindBy(xpath = "//input[@type='button' and @value='Reset']")
	private WebElement btnReset;

	@FindBy(xpath = "//input[@type='button' and @value='Save']")
	private WebElement btnSave;

	@FindBy(xpath = "//a[text()=' Social Habits ']")
	private WebElement userType;

	@FindBy(xpath = "//a[text()=' Add Social Habit ']")
	private WebElement adduserType;

	public void clickbuttonapproval() {
		waitForClickability(userType).click();
//		waitForClickability(adduserType).click();
	}

	public void enterSocialHabitName(String name) {
		txtSocialHabitName.clear();
		txtSocialHabitName.sendKeys(name);
	}

	public void setIsActive(boolean value) {
		if (chkIsActive.isSelected() != value) {
			chkIsActive.click();
		}
	}

	public void enterAttribute(String attribute) {
		txtAttribute.clear();
		txtAttribute.sendKeys(attribute);
	}

	public void clickAddAttribute() {
		btnAddAttribute.click();
	}

	public void clickSave() {
		btnSave.click();
	}

}
