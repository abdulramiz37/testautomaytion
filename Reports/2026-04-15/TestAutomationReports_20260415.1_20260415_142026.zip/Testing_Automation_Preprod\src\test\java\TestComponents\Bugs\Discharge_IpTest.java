package TestComponents.Bugs;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EzionpageObjects.UserIdPage;
import PrakashSirAppointmentBooking.AppointmentBooking;
import PrakashSirAppointmentBooking.Discharge_Ip;
import abdulTest.BaseTest;

public class Discharge_IpTest extends BaseTest {

    @Test(dataProvider = "getDataForLogin")
    public void Login(HashMap<String, String> input) throws InterruptedException {
        // Login
        UserIdPage data = login.login(input.get("userId"));
        data.enterMobileNumber(input.get("personId"));
        data.selectOptionByName("Pondicherry");
        data.enterPassword(input.get("password"));
        data.clickContinue();
  
        Discharge_Ip discharge = new Discharge_Ip(driver);
        discharge.opentheappointmentpage();
        
        for (int i = 0; i < 20; i++) {
        discharge.opentheadmiison();
       
        discharge.table("Miss. Kalai");
        discharge.clickDischargeSummary();
        discharge.clickSlider();
        }
    }

    @DataProvider
    public Object[][] getDataForLogin() throws IOException {
        List<HashMap<String, String>> data = getJsonDataToMap(
            System.getProperty("user.dir") + "//src//main//java//ezion//Resources//AppointMent.json"
        );
        return new Object[][] { { data.get(1) } };
    }
}
