package Registration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import EzionAbstractionComponents.Abstraction;

public class ServiceList extends Abstraction {

	public ServiceList(WebDriver driver) {
		super(driver);
	    PageFactory.initElements(driver, this);
	}
	// Locators
	@FindBy(xpath = "//input[@formcontrolname='billPhysType' and @id='Internal']")
	private WebElement internalRadio;

	@FindBy(xpath = "//input[@formcontrolname='billPhysType' and @id='External']")
	private WebElement externalRadio;

	@FindBy(xpath = "//input[@formcontrolname='billPhysType' and @id='Physician not required']")
	private WebElement physicianNotRequiredRadio;

	 @FindBy(xpath = "(//ngx-select[@formcontrolname='departmentId']//div[contains(@class,'ngx-select__toggle')])[1]")
	    private WebElement departmentDropdown;

	    @FindBy(xpath = "(//ngx-select[@formcontrolname='physicianId']//div[contains(@class,'ngx-select__toggle')])[1]")
	    private WebElement physicianDropdown;

	    @FindBy(xpath = "(//ngx-select[@formcontrolname='billingType']//div[contains(@class,'ngx-select__toggle')])[1]")
	    private WebElement billTypeDropdown;

	 // Service Name dropdown
	    @FindBy(xpath = "//label[normalize-space()='Service Name']/following::ngx-select[1]//div[contains(@class,'ngx-select__toggle')]")
	    private WebElement serviceNameDropdown;
	    
	    @FindBy(xpath = "//label[normalize-space()='Service Name']/following::ngx-select[1]//input")
	    private WebElement serviceNameDropdown1;
	    // Quantity input
	    @FindBy(xpath = "//input[@formcontrolname='quantity']")
	    private WebElement quantityInput;

	    // Rate input (readonly)
	    @FindBy(xpath = "//input[@formcontrolname='rate']")
	    private WebElement rateInput;

	    // Amount input (readonly)
	    @FindBy(xpath = "//input[@formcontrolname='amount']")
	    private WebElement amountInput;

	    // Discount Type dropdown
	    @FindBy(xpath = "//label[normalize-space()='Disc Type']/following::ngx-select[1]//div[contains(@class,'ngx-select__toggle')]")
	    private WebElement discountTypeDropdown;

	    // Discount % input
	    @FindBy(xpath = "//input[@formcontrolname='discountpercentage']")
	    private WebElement discountPercentageInput;

	    // Net Amount input (readonly)
	    @FindBy(xpath = "//input[@formcontrolname='netamount']")
	    private WebElement netAmountInput;

	    // Add button
	    @FindBy(xpath = "//input[@type='button' and @value='Add']")
	    private WebElement addButton;

	    // Cancel button
	    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
	    private WebElement cancelButton;

	    // Common dropdown options (dynamic)
	    private String dropdownOptionXpath = "//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='%s']";
	    
	    @FindBy(xpath = "//input[@type='button' and @value='Save']")
	    private WebElement saveButton;

	    // Common dropdown options for ngx-select
	

	// Method to select Medical Services Referred By
	public void selectMedicalServicesReferredBy(String option) {
	    switch (option.trim().toLowerCase()) {
	        case "internal":
	            waitForClickability(internalRadio).click();
	            break;
	        case "external":
	            waitForClickability(externalRadio).click();
	            break;
	        case "physician not required":
	            waitForClickability(physicianNotRequiredRadio).click();
	            break;
	        default:
	            throw new IllegalArgumentException("Invalid option for Medical Services Referred By: " + option);
	    }
	    System.out.println("✅ Selected Medical Services Referred By: " + option);
	}
	 public void clickDepartmentDropdown() {
	        waitForClickability(departmentDropdown).click();
	    }

	    public void clickPhysicianDropdown() {
	        waitForClickability(physicianDropdown).click();
	    }

	    public void clickBillTypeDropdown() {
	        waitForClickability(billTypeDropdown).click();
	    }

	    @FindBy(xpath = "//label[text()='Bill Counter']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
	    private WebElement billCounterDropdown;
	    

	    public void billCounter() {
	        waitForClickability(billCounterDropdown).click();
	    }
	    public void selectDropdownOption(String text) {
	        WebElement option = driver.findElement(
	            By.xpath("//ul[contains(@class,'ngx-select__choices')]//span[normalize-space()='" + text + "']")
	        );
	        waitForClickability(option).click();
	    }
	    
	    @FindBy(xpath = "(//ngx-select[@formcontrolname='payer']//div[contains(@class,'ngx-select__toggle')])[1]")
	    private WebElement payerSelectDropdown;

	    public void clickPayerSelectDropdown() {
	        waitForClickability(payerSelectDropdown).click();
	    }
	    
	 // Click Service Name dropdown
	    public void clickServiceNameDropdown() {
	    	clickWithJavaScript(serviceNameDropdown);
	    }

	    // Select option from dropdown (generic)


	    // Enter quantity
	    public void enterQuantity(String qty) {
	        quantityInput.clear();
	        quantityInput.sendKeys(qty);
	    }

	    // Get rate value (readonly field)
	    public String getRateValue() {
	        return rateInput.getAttribute("value");
	    }

	    // Get amount value
	    public String getAmountValue() {
	        return amountInput.getAttribute("value");
	    }

	    // Click Discount Type dropdown
	    public void clickDiscountTypeDropdown() {
	        waitForClickability(discountTypeDropdown).click();
	    }

	    // Enter Discount %
	    public void enterDiscountPercentage(String discount) {
	        discountPercentageInput.clear();
	        discountPercentageInput.sendKeys(discount);
	    }

	    // Get Net Amount value
	    public String getNetAmountValue() {
	        return netAmountInput.getAttribute("value");
	    }

	    // Click Add button
	    public void clickAddButton() {
	        waitForClickability(addButton).click();
	    }

	    // Click Cancel button
	    public void clickCancelButton() {
	        waitForClickability(cancelButton).click();
	    }

	    public void save() {
	    	clickWithJavaScript(saveButton);
	    }
	    @FindBy(xpath = "//input[@type='button' and @value='Hold Bill']")
	    private WebElement holdBillButton;
	    public void hold() {
	        waitForClickability(holdBillButton).click();
	    }
	    @FindBy(xpath = "//td[normalize-space(text())='Bill No']/following-sibling::td/strong")
	    private WebElement billNoElement;

	    
	    public String getBillNo() {
	    	  waitForVisibility(billNoElement);
	    	  System.out.println(billNoElement.getText().trim());
	        return billNoElement.getText().trim();
	    }

	    public void fillBillingForm(String department, String physician, String billType,String servicename,String quantiy, String percentageoramount,String discount) {
//	        clickDepartmentDropdown();
	        selectDropdownOption(department);

//	        clickPhysicianDropdown();
	        selectDropdownOption(physician);

	        clickBillTypeDropdown();
	        selectDropdownOption(billType);
	        clickServiceNameDropdown();
	        serviceNameDropdown1.sendKeys(servicename);
	        selectDropdownOption(servicename); // or any other service

	        enterQuantity(quantiy);

	        clickDiscountTypeDropdown();
	        selectDropdownOption(percentageoramount);

	        enterDiscountPercentage(discount);

	        clickAddButton();
	        save();
//	        getBillNo();
	    }
	    
	 // Inside your Page Object class
	
}
