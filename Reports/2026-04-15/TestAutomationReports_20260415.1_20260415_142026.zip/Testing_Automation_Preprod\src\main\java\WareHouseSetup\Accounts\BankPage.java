package WareHouseSetup.Accounts;

import java.util.List;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import EzionAbstractionComponents.Abstraction;

public class BankPage extends Abstraction {

    public BankPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    // ===========================
    // ====== Input Fields =======
    // ===========================



	@FindBy(xpath = "//input[@formcontrolname='name']")
    private WebElement bankNameInput;

    @FindBy(xpath = "//input[@formcontrolname='accountNumber']")
    private WebElement accountNumberInput;

    @FindBy(xpath = "//input[@formcontrolname='accountName']")
    private WebElement accountNameInput;

    @FindBy(xpath = "//input[@formcontrolname='branchName']")
    private WebElement branchNameInput;

    @FindBy(xpath = "//input[@formcontrolname='bsrCode']")
    private WebElement bsrCodeInput;

    @FindBy(xpath = "//input[@formcontrolname='ifscCode']")
    private WebElement ifscCodeInput;

    @FindBy(xpath = "//input[@formcontrolname='clientCode']")
    private WebElement clientCodeInput;

    // ===========================
    // ===== Dropdown ============
    // ===========================

    @FindBy(xpath = "//label[text()='Primarly Used']/following-sibling::ngx-select//div[contains(@class,'ngx-select__toggle')]")
    private WebElement primarilyUsedDropdown;

    // Dynamic dropdown options
    private By dropdownOptions = By.xpath("//a[contains(@class,'ngx-select__item')]/span");

    // ===========================
    // ===== Buttons =============
    // ===========================

    @FindBy(xpath = "//button[text()='Save']")
    private WebElement saveButton;

    @FindBy(xpath = "//input[@type='button' and @value='Cancel']")
    private WebElement cancelButton;

    // ===========================
    // ===== Action Methods ======
    // ===========================

    
    @FindBy(xpath = "//a[text()=' Bank ']")
    private WebElement userType;

    @FindBy(xpath = "//a[text()=' Add Bank ']")
    private WebElement adduserType;
     
    public void clickbuttonapproval() {
		waitForClickability(userType).click();
		waitForClickability(adduserType).click();
	}
    public void enterBankName(String name) {
        waitForVisibility(bankNameInput).sendKeys(name);
    }

    public void enterAccountNumber(String number) {
        waitForVisibility(accountNumberInput).sendKeys(number);
    }

    public void enterAccountName(String name) {
        waitForVisibility(accountNameInput).sendKeys(name);
    }

    public void enterBranchName(String branch) {
        waitForVisibility(branchNameInput).sendKeys(branch);
    }

    public void enterBSRCode(String bsr) {
        waitForVisibility(bsrCodeInput).sendKeys(bsr);
    }

    public void enterIFSCCode(String ifsc) {
        waitForVisibility(ifscCodeInput).sendKeys(ifsc);
    }

    public void enterClientCode(String code) {
        waitForVisibility(clientCodeInput).sendKeys(code);
    }

    public void selectPrimarilyUsed(String optionText) {
        waitForClickability(primarilyUsedDropdown).click();
        List<WebElement> options = waitForPresenceOfAll(dropdownOptions);
        for (WebElement option : options) {
            if (option.getText().trim().equalsIgnoreCase(optionText)) {
                waitForClickability(option).click();
                return;
            }
        }
        throw new NoSuchElementException("Option '" + optionText + "' not found in Primarly Used dropdown");
    }

    public void clickSave() {
        waitForClickability(saveButton).click();
    }

    public void clickCancel() {
        waitForClickability(cancelButton).click();
    }

    // ===========================
    // ===== Form Submission =====
    // ===========================

    public void fillBankDetailsForm(
            String bankName,
            String accountNumber,
            String accountName,
            String branchName,
            String bsrCode,
            String ifscCode,
            String clientCode,
            String primarilyUsed
    ) {
    	clickbuttonapproval();
        enterBankName(bankName);
        enterAccountNumber(accountNumber);
        enterAccountName(accountName);
        enterBranchName(branchName);
        enterBSRCode(bsrCode);
        enterIFSCCode(ifscCode);
        enterClientCode(clientCode);
        selectPrimarilyUsed(primarilyUsed);
        clickSave();
    }
}
