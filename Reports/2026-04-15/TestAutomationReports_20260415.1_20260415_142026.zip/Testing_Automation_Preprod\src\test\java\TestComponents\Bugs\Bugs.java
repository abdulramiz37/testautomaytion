
package TestComponents.Bugs;



import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeoutException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EHR.ClinicalAseesment.BloodGroup;
import EHR.ClinicalAseesment.EHRHomePage;
import EzionpageObjects.UserIdPage;
import Lab.ApprovedListPage;
import Lab.LabWorkOrder;
import Lab.NewListTable;
import Lab.Re_TestPage;
import Lab.SampleCollectedList;
import Lab.SampleCollected_EditWorkList;
import Lab.WaitingApprovalPage;
import PharmacyFlowObjects.PharmacyStore.MedicinePage;
import PrakashSirAppointmentBooking.EMR;
import Radiology.Radiology;
import Registration.NewRegistrationPage;
import Registration.PatientList;
import Registration.ServiceList;
import abdulTest.BaseTest;

public class Bugs extends BaseTest {
	 UserIdPage data;
	  NewRegistrationPage registrationPage ;
   @Test(dataProvider = "getDataForLogin",priority = 1)
   public void Login(HashMap<String, String> input) throws InterruptedException {
       // Login
//       data = login.login(EnvUtil.get("USER_ID"));
//       data.enterMobileNumber(EnvUtil.get("PERSON_ID"));
//       data.enterPassword(EnvUtil.get("PASSWORD"));
//
//       data.clickContinue();
//   Thread.sleep(8000);
       String userId = prop.getProperty("USER_ID");
       String personId = prop.getProperty("PERSON_ID");
       String password = prop.getProperty("PASSWORD");
       String browser = System.getProperty("BROWSER");
       data = login.login(userId);
       data.enterMobileNumber(personId);
       data.enterPassword(password);
       data.clickContinue();
       System.out.println("Browser: " + browser);
//       System.out.println("Base URL: " + baseUrl);
       System.out.println("User ID: " + userId);
       System.out.println("Person ID: " + personId);
       data.clickContinue();
       data.navigateSalesWithRetry();
       data.openMasterSetup();
       }
 @Test(dataProvider = "getDataForLogin", priority = 2)
 public void PayerEsc(HashMap<String, String> input) throws InterruptedException {

     data.masterSetupOpenOnly();
     data.clickByText("Pharmacy", 1);
     data.clickByText("Stock", 1);
     data.clickByText("Stock List", 1);
     Thread.sleep(5000);
     data.byTextAttach("Warehouse Name", "/ancestor::div[1]//input").click();
     data.byTextAttach("Warehouse Name", "/ancestor::div[1]//input").sendKeys("h - InActive");
     data.clickByText("h - InActive");
     
 } 
 
 @Test(dataProvider = "getDataForLogin", priority = 3)
 public void DSM(HashMap<String, String> input) throws InterruptedException {

     data.masterSetupOpenOnly();
     data.clickByText("DSM Header", 1);
     Thread.sleep(5000);
     data.hoverByTextAttach("Add DSM Header","/ancestor::div[2]//button[@nbpopovertrigger='hover']");
     data.clickByText("Excel");
     data.robotEnter();
     
 }
 
 @Test(dataProvider = "getDataForLogin", priority = 3)
 public void medicinedecimal(HashMap<String, String> input) throws InterruptedException {

     data.masterSetupOpenOnly();
     MedicinePage medicinePage = new MedicinePage(driver);
     medicinePage.addmedicine();
// for(int i=0;i<=10;i++) {
//         MedicinePage medicinePage = new MedicinePage(driver);

         // Add Medicine with manual values
         medicinePage.addMedicine(
             "",   // medicineName
             "Schedule A1",            // scheduleText
             "CAPSULE",       // categoryText
             "Orlistat", // compositionText
             "3 M HEALTH CARE",    // manufacturerText
             "100"           // quantity
         );

         // Fill additional fields manually
         medicinePage.enterMinQty("1");
         medicinePage.enterMaxQty("200");
         medicinePage.enterReorderQty("20");
         medicinePage.enterReorderLevel("5");
         medicinePage.enterHSNCode("30049099");
         medicinePage.selectGST("0");
         medicinePage.selectDiscountRequired("Yes");
         medicinePage.enterDescription("Used for fever and mild pain relief");
         medicinePage.enterDiscount("5.5");
          medicinePage.selectVaccineCheckbox(); // Uncomment if required
         medicinePage.enterAttribute("OTC");
         medicinePage.enterCostPrice("8.50");
         medicinePage.enterMRP("12.00");
         medicinePage.enterSellPrice("11.00");
         medicinePage.enterNoOfStrips("10");
         medicinePage.enterFreeStrips("1");

         // Save medicine
         medicinePage.save();
     
 }
 @DataProvider
 public Object[][] getDataForLogin() throws IOException {
     List<HashMap<String, String>> data = getJsonDataToMap(
         System.getProperty("user.dir") + "//src//main//java//ezion//Resources//AppointMent.json"
     );
     return new Object[][] { { data.get(0) } };
 }
}
