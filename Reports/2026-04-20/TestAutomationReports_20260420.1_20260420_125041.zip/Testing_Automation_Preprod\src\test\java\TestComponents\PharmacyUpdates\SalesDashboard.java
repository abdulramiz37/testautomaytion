package TestComponents.PharmacyUpdates;

import java.awt.AWTException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EzionpageObjects.UserIdPage;
import PharmacySalesPage.DynamicDoctor;
import PharmacySalesPage.ExcelPrint;
import PharmacySalesPage.PatientDetails;
import PharmacySalesPage.PrintTemplate;
import PharmacySalesPage.SalesDashboards;
import PharmacySalesPage.SalesDashborad_Archivedlist;
import PharmacySalesPage.SalesPage;
import PharmacySalesPage.SalesReturnPage;
import PharmacySalesPage.SearchAndReturnBill;
import PharmacySalesPage.Accounts.Creditbill;
import PharmacyStocks.StockList;
import PrakashSirAppointmentBooking.EMR;
import PrakashSirAppointmentBooking.CaseSheet.PrescriptionPage;
import PrakashSirAppointmentBooking.IpOnboarding.Serviceip;
import Registration.NewRegistrationPage;
import Registration.PatientList;
import Registration.ServiceList;
import abdulTest.BaseTest;
import ezion.Resources.EnvUtil;

public class SalesDashboard extends BaseTest{
	 UserIdPage data;
	  NewRegistrationPage registrationPage ;

   @Test(dataProvider = "getDataForLogin",priority = 1)
   public void Login(HashMap<String, String> input) throws InterruptedException {
       // Login
//       data = login.login(EnvUtil.get("USER_ID"));
//       data.enterMobileNumber(EnvUtil.get("PERSON_ID"));
//       data.enterPassword(EnvUtil.get("PASSWORD"));
//
//       data.clickContinue();
	   String userId = prop.getProperty("USER_ID");
       String personId = prop.getProperty("PERSON_ID");
       String password = prop.getProperty("PASSWORD");
       String browser = System.getProperty("BROWSER");
       data = login.login(userId);
       data.enterMobileNumber(personId);
       data.enterPassword(password);
       data.clickContinue();
       System.out.println("Browser: " + browser);
//       System.out.println("Base URL: " + baseUrl);
       System.out.println("User ID: " + userId);
       System.out.println("Person ID: " + personId);
       data.clickContinue();
//   Thread.sleep(8000);
       }
   String targetMobileNumber;
   @Test(dataProvider = "getDataForLogin",priority = 2)
   public void patientName(HashMap<String, String> input) throws InterruptedException {
	   Thread.sleep(3000);	 
       // Step 1: Search patient
       registrationPage = new NewRegistrationPage(driver);

       // Call the fillNewRegistrationForm method with all necessary form values
       registrationPage.clickbuttonapproval();
       registrationPage.selectTitle();
       registrationPage.selectOptionFromNgxDropdown("Mr.");
       registrationPage.enterFirstName("");
       registrationPage.enterMiddleName("doe");
       registrationPage.enterLastName("abraham");
       registrationPage.selectGender();
       registrationPage.selectOptionFromNgxDropdown("Male");
       registrationPage.enterDOB("12/12/2024");
       registrationPage.enterMobileNumber("");
       targetMobileNumber=registrationPage.lastEnteredMobileNumber;
       registrationPage.selectNationality("Indian");
//       targetMobileNumber="7411081113";
       registrationPage.save();

//System.out.println(targetMobileNumber);
   } 
   
   @Test(dataProvider = "getDataForLogin", priority = 3)
   public void PatientRegistration(HashMap<String, String> input) throws InterruptedException {
   	PatientList patient = new PatientList(driver);
    Thread.sleep(1000);
   	patient.findPatientByMobile(targetMobileNumber);
   	
   	ServiceList service = new ServiceList(driver);
//	ServiceList service = new ServiceList(driver);
//	Blood Sugar2 - LabTest
//	service.fillBillingForm("General", "Dr. Izaan", "Self","Blood Sugar - LabTest","10","%","5");
//	Thread.sleep(5000);
service.clickByText("Department");
	
	service.byTextAttach("Department", "/ancestor::div[1]//ngx-select").click();
	
service.byTextAttach("Department", "/ancestor::div[1]//input").sendKeys("General");
Thread.sleep(5000);
	service.clickByText("General");
	
	service.clickByText("Physician");
	
	
	service.byTextAttachClickable("Physician", "/ancestor::div[1]//ngx-select").click();
	
service.byTextAttachClickable("Physician", "/ancestor::div[1]//input").sendKeys("ramiz");

//	service.clickByText("Dr. Ramiz");
	
//clickPhysicianDropdown();
	service.selectDropdownOption("Dr. Ramiz");

//	service.clickBillTypeDropdown();
	
	   	
	service.clickByText("Bill Type");
	service.byTextAttach("Bill Type", "/ancestor::div[1]//ngx-select").click();
	
service.byTextAttach("Bill Type", "/ancestor::div[1]//input").sendKeys("self");

//	service.clickByText("Self");
	
	
service.selectDropdownOption("Self");
//service.clickPayerSelectDropdown();
//service.selectDropdownOption("Test Payer");

//service.clickServiceNameDropdown();

//service.selectDropdownOption("Blood Sugar - LabTest"); // or any other service
	service.clickByText("Service Name");
	service.byTextAttach("Service Name", "/ancestor::div[1]//ngx-select").click();
	
service.byTextAttach("Service Name", "/ancestor::div[1]//input").sendKeys("Blood Sugar - LabTest");

service.selectDropdownOption("Blood Sugar - LabTest");
service.enterQuantity("10");

service.clickDiscountTypeDropdown();
service.selectDropdownOption("%");

service.enterDiscountPercentage("5");

service.clickAddButton();
service.save();
   }
   
   @Test(dataProvider = "getDataForLogin", priority = 4)
   public void PatientRegistration1(HashMap<String, String> input) throws InterruptedException {
	   data.navigateSalesWithRetry3();
	   SalesDashboards salesdash= new SalesDashboards(driver);
	   Thread.sleep(1000);
//	   salesdash.openSalesDashboard();
	   salesdash.clickPatientList();
	   salesdash.clickNewBillForPatient(targetMobileNumber);
   }
   
   @Test(dataProvider = "getDataForLogin", priority = 5)
   public void PatientRegistration2(HashMap<String, String> input) throws InterruptedException {
	   PatientDetails patientPage = new PatientDetails(driver);
	 
	   Thread.sleep(1000);
	    // Step 2: Create list of multiple patient detail sets
	    List<Map<String, String>> patientDetailsList = new ArrayList<>();

	    // 1st Set of Details
	    HashMap<String, String> details1 = new HashMap<>();
	    details1.put("prescribedBy", "Internal Dr");
	    details1.put("medicine", "medicine1syrup");
	    details1.put("internalDoctor", "Dr. Izaan");
	    details1.put("referral", "Dr. Ashwin");
	    details1.put("billType", "Self");
	    patientDetailsList.add(details1);

	    // 2nd Set of Details
	    HashMap<String, String> details2 = new HashMap<>();
	    details2.put("prescribedBy", "");
	    details2.put("medicine", "syrup14");
	    details2.put("internalDoctor", "");
	    details2.put("referral", "");
	    details2.put("billType", "");
	    patientDetailsList.add(details2);

	    // Step 3: Loop through each set of details and perform actions
	    for (Map<String, String> details : patientDetailsList) {
	    	
	    
	        // Select prescribed by (Internal / External Dr)
//	        if (details.get("prescribedBy").equalsIgnoreCase("Internal Dr")) {
	        	 if(details.get("prescribedBy") != null && !details.get("prescribedBy").isEmpty()){
	            patientPage.selectPrescriptionByInternalDr();
	        } else {
	            System.out.println("ok");
	        }

	        // Select Internal Doctor if available
	        if (details.get("internalDoctor") != null && !details.get("internalDoctor").isEmpty()) {
	            patientPage.selectInternalDoctor(details.get("internalDoctor"));
	        }
	        else {
	          System.out.println("ok");
	        }
//	        Thread.sleep(5000);
	        patientPage.medicine(details.get("medicine"));
	        patientPage.enterQuantity("1");

//	        Thread.sleep(5000);
	        // Select Referral
	        if (details.get("referral") != null && !details.get("referral").isEmpty()) {
	            patientPage.selectReferral(details.get("referral"));
	        }
	        else {
		          System.out.println("ok");
		        }
		        
	        // Select Bill Type
	        if (details.get("billType") != null && !details.get("billType").isEmpty()) {
	            patientPage.selectBillType(details.get("billType"));
	        }
	        else {
		          System.out.println("ok");
		        }
		        
	    
	  
	        patientPage.clickAddButton();
	    
   }
	    SalesPage salesPage = new SalesPage(driver);
      salesPage.excape();
	    patientPage.clickSaveButton();
	    patientPage.yesButton();
	    patientPage.waitForUrlContains("pages/pharmacy");
//	    data.sales();
   }
   
   @Test(dataProvider = "getDataForLogin",priority = 6)
   public void testEditLastVisit(HashMap<String, String> input) throws InterruptedException {
       // Step 1: Search patient
	   	EMR	emrPage = new EMR(driver);
	    Thread.sleep(1000);
	       emrPage.enterPatientNameOrMobile(registrationPage.storedFirstName);

	       // Step 2: Click the first John abraham in list
	       emrPage.clickFirstJohnAbraham(registrationPage.storedFirstName, 1);

	       // Step 3: Click EMR / Accounts
	       emrPage.clickEmrAccounts();
	      
	       
	       int attempts = 0;

	   	while (attempts < 5) {
	   	    try {
	   	        emrPage.clickCaseSheetWrapper();
	   	        emrPage.clickByText("New Case Sheet");
	   	        emrPage.byTextAttach("Case Sheet", "/ancestor::div[1]//input")
	   	               .sendKeys("Izaan");
	   	        break;   // stop loop once success
	   	    } catch (Exception e) {
	   	        attempts++;
	   	    }
	   	}
	   Thread.sleep(5000);
	     emrPage.clickByText("Dr. Izaan");
	   Thread.sleep(5000);
   }
   
   PrescriptionPage prescriptionPage;
//   
   @Test(dataProvider = "getDataForLogin", priority = 7)
   public void prescription(HashMap<String, String> input) throws InterruptedException {

       // Step 1: Create Page Object
        prescriptionPage = new PrescriptionPage(driver);
        Thread.sleep(5000);       // Step 2: Open Prescription section
       prescriptionPage.clickPrescriptionToggle();
       prescriptionPage.addPrescriptionBtne2();
       // Step 3: Define medicines dynamically
       List<Map<String, String>> medicineList = new ArrayList<>();

       // Medicine 1
       Map<String, String> med1 = new HashMap<>();
       med1.put("medicine", "hfdivgmtb");
       med1.put("frequency", "1 - 0 - 1  Twice a day");
       med1.put("dosage", "3.0");
       med1.put("unit", "nos");
       med1.put("when", "After Food");
       med1.put("duration", "5d");
       med1.put("quantity", "5");
       med1.put("route", "hbsd");
       med1.put("instructions", "Hot Water");
       med1.put("doctor", "Izaan");
       med1.put("nurse", "Fddf");
       medicineList.add(med1);

       // Medicine 2



       // Step 4: Loop through medicines and fill the form
       for (Map<String, String> med : medicineList) {
           try {
               // Select or add medicine
               prescriptionPage.selectMedicineName(med.get("medicine"));
           
               // If new medicine creation popup appears
               if (prescriptionPage.isAddMedicinePopupDisplayed()) {
                   prescriptionPage.enterMedicineName(prescriptionPage.finalMedicine);
                 

//                   prescriptionPage.enterMedicineCode("M"+"235");
                   prescriptionPage.selectMedicineType("Schedule A1");
                   prescriptionPage.selectMedicineCategory("SALTS");
                   prescriptionPage.selectManufacturer("	CALTEN");
                   prescriptionPage.selectGenericName("METFORMIN HCL");
                   prescriptionPage.selectRack("ajhj");
                   prescriptionPage.enterUnits("10");
                   prescriptionPage.selectGST("0");
                   prescriptionPage.checkIsVaccine();
                   
                   prescriptionPage.clickSaveButton();
                   prescriptionPage.clickCloseButton();
                 
                 
               }
           } catch (Exception e) {
               System.out.println("⚠️ Error while adding Medicine: " + e.getMessage());
               e.printStackTrace();
           }

//            Fill prescription details
//           prescriptionPage.senditem(prescriptionPage.finalMedicine);
           System.out.println(prescriptionPage.finalMedicine);
           prescriptionPage.selectMedicineName2(prescriptionPage.finalMedicine+" /"+" METFORMIN HCL");
           prescriptionPage.addGeneratedMedicine(prescriptionPage.finalMedicine);
           prescriptionPage.selectUnit(med.get("unit"));
           prescriptionPage.selectDosage(med.get("dosage"));
           prescriptionPage.selectFrequency(med.get("frequency"));
           prescriptionPage.selectWhenToTaken(med.get("when"));
           prescriptionPage.selectDuration(med.get("duration"));
           prescriptionPage.enterQuantity(med.get("quantity"));
           prescriptionPage.selectRoute(med.get("route"));
           prescriptionPage.selectInstructions(med.get("instructions"));
           prescriptionPage.enterNotes("Monitor for side effects.");
           prescriptionPage.selectPerformingDoctor(med.get("doctor"));
           prescriptionPage.selectPerformingNurse(med.get("nurse"));

           // Add Medicine to prescription list
           prescriptionPage.clickAddMedicine();
        
           prescriptionPage.clickCloseButton1();
       }

       // Step 5: Save Prescription
    
       prescriptionPage.clickSendToPharmacy();
       // Step 6: Collapse Prescription section
       prescriptionPage.clickPrescriptionToggle();
//       System.out.println("Generated Medicines in this test: " + prescriptionPage.getGeneratedMedicines());
   }
   
   String firstMedicineName;
   @Test(dataProvider = "getDataForLogin",priority = 8)
   public void useGeneratedMedicines23(HashMap<String, String> input) {
       List<String> meds = prescriptionPage.getGeneratedMedicines();
       System.out.println("📌 Medicines created: " + meds);

       if (!meds.isEmpty()) {
           // Take the first medicine and store in class-level variable
           firstMedicineName = meds.get(0);
           System.out.println("✅ First medicine stored: " + firstMedicineName);

           // Select it on the page
//           prescriptionPage.selectMedicineName(firstMedicineName);
	       }
	   }



 
   @Test(dataProvider = "getDataForLogin", priority = 9)
   public void useGeneratedMedicines46(HashMap<String, String> input) throws InterruptedException {
	   
	   SalesDashboards salesdash= new SalesDashboards(driver);
	   salesdash.navigateSalesWithRetry3();
//	   salesdash.openSalesDashboard();
	   System.out.println("📌 targetMobileNumber created: " + targetMobileNumber);
	   salesdash.clickfornewipbill(targetMobileNumber);
	   Thread.sleep(5000);
	   System.out.println(firstMedicineName+"       new med");
	   salesdash.selectAlternativeForMedicine(firstMedicineName,
			   "ubfjhl");
//			   "hfdaumgkp");
	   salesdash.clickSubmit();
	   PatientDetails patientPage = new PatientDetails(driver);
	    patientPage.clickSaveButton();
	    patientPage.yesButton();
	    patientPage.clickBackButton();
   }
   
   String batchNumber;
   String stocks;

   // ✅ Shared across tests
   public static List<Map<String, String>> collectedMedicineDetails = new ArrayList<>();

   @Test(dataProvider = "getDataForLogin", priority = 10)
   public void Directsales(HashMap<String, String> input) throws InterruptedException {
       SalesPage salesPage = new SalesPage(driver);
       salesPage.excape();
       salesPage.navigateSalesWithRetry2();
       salesPage.createSalesFlow3(
           input.getOrDefault("mobile", ""), 
           input.getOrDefault("customerName", ""), 
           "Dr.  Izaan"
       );

       List<String> medicines = List.of("syrup14", "medicine1syrup");

       // Loop through all medicines
       for (String medicine : medicines) {
           salesPage.selectMedicines(List.of(medicine));

           // Get batch & stock
           batchNumber = salesPage.getBatchNumber();
           stocks = salesPage.getStickQuantity();

           // Save details in map
           Map<String, String> details = new HashMap<>();
           details.put("Medicine", medicine);
           details.put("Batch", batchNumber);
           details.put("Stock", stocks);

           collectedMedicineDetails.add(details);

           salesPage.qty("2");
           salesPage.addbtn();
       }
       salesPage.excape();
       SalesDashboards salesdash = new SalesDashboards(driver);

       salesPage.excape();
       salesPage.findMedicineAndClick123("medicine1syrup", "edit");

       salesPage.clickHoldBill();
       salesPage.patientlist();

       String targetmobile = salesPage.lastEnteredMobileNumber;
       salesdash.checkforunbilledlist(targetmobile);
       salesdash.clickCloseLightbox();
       salesdash.enterCommonDiscountPercentage("4");
       
       PatientDetails patientPage = new PatientDetails(driver);
       patientPage.clickSaveButton();
       patientPage.yesButton();
//       patientPage.clickBackButton();
   }

   @Test(dataProvider = "getDataForLogin", priority = 11)
   public void verifyMedicineDetails(HashMap<String, String> input) throws InterruptedException {
	   Thread.sleep(5000);
	   StockList stocklist = new StockList(driver);
	   stocklist.clickStockMenu();
	   stocklist.clickStockListMenu();
       System.out.println("✅ Verifying collected medicine details...");
       for (Map<String, String> detail : SalesDashboard.collectedMedicineDetails) {
    	    System.out.println("Medicine: " + detail.get("Medicine"));
    	    System.out.println("Batch: " + detail.get("Batch"));
    	    System.out.println("Stock: " + detail.get("Stock"));
    	    System.out.println("-----------------------");

    	    // Convert Stock (String → int) and subtract 4
    	    int stockValue = Integer.parseInt(detail.get("Stock"));
    	    int updatedStock = stockValue - 2;

    	    // Use updated stock in your method
    	    stocklist.enterValueInComboBox(detail.get("Medicine"));
    	    Thread.sleep(5000);
    	    stocklist.findMedicineAndClickEdit(
    	        detail.get("Medicine"),
    	        detail.get("Batch"),
    	        String.valueOf(updatedStock) // pass as String again
    	    );
    	}

   }
   @Test(dataProvider = "getDataForLogin", priority = 12)
   public void printer(HashMap<String, String> input) throws InterruptedException {
//	  SalesPage salesPage = new SalesPage(driver);
	
	   SalesPage salesPage = new SalesPage(driver);
	   salesPage.excape();
	   login.navigateSalesWithRetry2();
       SearchAndReturnBill searchBill = salesPage.search();
       searchBill.enterPatientName("342");
       searchBill.clickDelete();
       searchBill.enterMobileNumber("9886347678");
//       searchBill.print("342");
//       searchBill.print("576");
       PrintTemplate template = new PrintTemplate(driver);
//       template.openDropdown();
//       template.selectSalesBillTemplate("sales_thermal_print");
   }
// 
// @Test(dataProvider = "getDataForLogin", priority = 13)
// public void editsales(HashMap<String, String> input) throws InterruptedException {
//	   SalesPage salesPage = new SalesPage(driver);
//	   login.navigateSalesWithRetry2();
//     SearchAndReturnBill searchBill = salesPage.search();
//     searchBill.enterPatientName("251");
//     searchBill.clickDelete();
//     searchBill.enterMobileNumber("9307559545");
//     searchBill.edit("251");
////     searchBill.edit("576");
//     salesPage.enterCommonDiscountPercentage("2");
//   PatientDetails patientPage = new PatientDetails(driver);
// patientPage.clickSaveButton();
// patientPage.yesButton();
// }
//   

 
// PrescriptionPage prescriptionPage;
 
 
 @Test(dataProvider = "getDataForLogin",priority = 14)
 public void testeEditLastVisit2(HashMap<String, String> input) {
     // Step 1: Sarch patient
 	EMR	emrPage = new EMR(driver);
     emrPage.enterPatientNameOrMobile(registrationPage.storedFirstName);

     // Step 2: Click the first John abraham in list
     emrPage.clickFirstJohnAbraham(registrationPage.storedFirstName, 1);

     // Step 3: Click EMR / Accounts
     emrPage.clickEmrAccounts();
     emrPage.clickCaseSheetWrapper();
     emrPage.clickDoctorName("Dr. Izaan");
     // Step 4: Click Edit in last visit
//     emrPage.clickEditLastVisit();
 }
 @Test(dataProvider = "getDataForLogin", priority = 15)
 public void prescriptionarchive(HashMap<String, String> input) throws InterruptedException {

     // Step 1: Create Page Object
      prescriptionPage = new PrescriptionPage(driver);
      Thread.sleep(5000);       // Step 2: Open Prescription section
     prescriptionPage.clickPrescriptionToggle();
     prescriptionPage.addPrescriptionBtne2();
     // Step 3: Define medicines dynamically
     List<Map<String, String>> medicineList = new ArrayList<>();

     // Medicine 1
     Map<String, String> med1 = new HashMap<>();
     med1.put("medicine", "");
     med1.put("frequency", "1 - 0 - 1  Twice a day");
     med1.put("dosage", "3.0");
     med1.put("unit", "nos");
     med1.put("when", "After Food");
     med1.put("duration", "5d");
     med1.put("quantity", "5");
     med1.put("route", "hbsd");
     med1.put("instructions", "Hot Water");
     med1.put("doctor", "Izaan");
     med1.put("nurse", "Fddf");
     medicineList.add(med1);

     // Medicine 2



     // Step 4: Loop through medicines and fill the form
     for (Map<String, String> med : medicineList) {
         try {
             // Select or add medicine
             prescriptionPage.selectMedicineName(med.get("medicine"));
         
             // If new medicine creation popup appears
             if (prescriptionPage.isAddMedicinePopupDisplayed()) {
                 prescriptionPage.enterMedicineName(prescriptionPage.finalMedicine);
               

//                 prescriptionPage.enterMedicineCode("M"+"235");
                 prescriptionPage.selectMedicineType("Schedule A1");
                 prescriptionPage.selectMedicineCategory("SALTS");
                 prescriptionPage.selectManufacturer("	CALTEN");
                 prescriptionPage.selectGenericName("METFORMIN HCL");
                 prescriptionPage.selectRack("ajhj");
                 prescriptionPage.enterUnits("10");
                 prescriptionPage.selectGST("0");
                 prescriptionPage.checkIsVaccine();
                 
                 prescriptionPage.clickSaveButton();
                 prescriptionPage.clickCloseButton();
               
               
             }
         } catch (Exception e) {
             System.out.println("⚠️ Error while adding Medicine: " + e.getMessage());
             e.printStackTrace();
         }

//          Fill prescription details
         prescriptionPage.selectMedicineName2(prescriptionPage.finalMedicine+" /"+" METFORMIN HCL");
         prescriptionPage.addGeneratedMedicine(prescriptionPage.finalMedicine);
         prescriptionPage.selectUnit(med.get("unit"));
         prescriptionPage.selectDosage(med.get("dosage"));
         prescriptionPage.selectFrequency(med.get("frequency"));
         prescriptionPage.selectWhenToTaken(med.get("when"));
         prescriptionPage.selectDuration(med.get("duration"));
         prescriptionPage.enterQuantity(med.get("quantity"));
         prescriptionPage.selectRoute(med.get("route"));
         prescriptionPage.selectInstructions(med.get("instructions"));
         prescriptionPage.enterNotes("Monitor for side effects.");
         prescriptionPage.selectPerformingDoctor(med.get("doctor"));
         prescriptionPage.selectPerformingNurse(med.get("nurse"));

         // Add Medicine to prescription list
         prescriptionPage.clickAddMedicine();
      
         prescriptionPage.clickCloseButton1();
     }

     // Step 5: Save Prescription
  
     prescriptionPage.clickSendToPharmacy();
     // Step 6: Collapse Prescription section
     prescriptionPage.clickPrescriptionToggle();
//     System.out.println("Generated Medicines in this test: " + prescriptionPage.getGeneratedMedicines());
 }
// 
 String secondMedicineName;

 @Test(dataProvider = "getDataForLogin", priority = 16)
 public void useGeneratedMedicines24(HashMap<String, String> input) {
     List<String> meds = prescriptionPage.getGeneratedMedicines();
     System.out.println("📌 Medicines created: " + meds);

     if (meds.size() > 1) {
         // Take the second medicine and store in class-level variable
         secondMedicineName = meds.get(1);
         System.out.println("✅ Second medicine stored: " + secondMedicineName);

         // Select it on the page
//         prescriptionPage.selectMedicineName(secondMedicineName);
     } else {
         System.out.println("⚠️ Only one medicine available, cannot pick second.");
     }
 }

   @Test(dataProvider = "getDataForLogin", priority = 17)
   public void useGeneratedMedicines2(HashMap<String, String> input) throws InterruptedException {
//	   data.navigateSalesWithRetry2();
	   SalesDashboards salesdash= new SalesDashboards(driver);
	   salesdash.navigateSalesWithRetry2();
	   salesdash.openSalesDashboard();
	   System.out.println("📌 targetMobileNumber created: " + targetMobileNumber);
	   salesdash.clickForNewIpBill2(targetMobileNumber,"Archive");
	   SalesDashborad_Archivedlist salesarchive = new SalesDashborad_Archivedlist(driver);
	   salesarchive.clickArchivedListTab();
	   salesarchive.checkForArchiveOrNewBill(targetMobileNumber, "NewBill");
	   System.out.println("medicine"+" " +secondMedicineName );
	   salesdash.selectAlternativeForMedicine(secondMedicineName, "ubfjhl");
	   salesdash.clickSubmit();
       PatientDetails patientPage = new PatientDetails(driver);
     patientPage.clickSaveButton();
     patientPage.yesButton();
     
//     patientPage.clickBackButton();
   }
//   
//   
//
 @Test(dataProvider = "getDataForLogin", priority = 18)
 public void excelreport(HashMap<String, String> input) throws InterruptedException, AWTException {
	 SalesPage salesPage = new SalesPage(driver); 
	 salesPage.excape();
	 data.navigateSalesWithRetry3();
	 data.navigateSalesWithRetry2();
	   ExcelPrint excelprint = new ExcelPrint(driver);
	   excelprint.clickCloudDownload();
	   excelprint.clickExportOption("CSV");
	   
     salesPage.enter();
	
 }
 
 public static List<Map<String, String>> collectedMedicineDetails1 = new ArrayList<>();
   String batchNumber1;
   String stocks1;

   @Test(dataProvider = "getDataForLogin", priority = 19)
   public void salesreturn(HashMap<String, String> input) throws InterruptedException, AWTException {
       data.navigateSalesWithRetry2();
       Thread.sleep(5000);
       String billNo;

       // Step 2: Sales Page Flow
       SalesPage salesPage = new SalesPage(driver);
       salesPage.createSalesFlow3(
               input.getOrDefault("mobile", ""), 
               input.getOrDefault("customerName", ""), 
               "Dr.  Izaan"
       );

       // Step 3: Add Medicines in Sales
       List<String> medicines1 = List.of("syrup14");
       List<String> quantities = new ArrayList<>();
       List<String> discounts = new ArrayList<>();

       for (String medicine : medicines1) {
           salesPage.selectMedicines(List.of(medicine));

           // Get batch & stock
           batchNumber1 = salesPage.getBatchNumber();
           stocks1 = salesPage.getStickQuantity();

           Map<String, String> details = new HashMap<>();
           details.put("Medicine", medicine);
           details.put("Batch", batchNumber1);
           details.put("Stock", stocks1);

           salesPage.qty("2");
           salesPage.addbtn();

           // add values for return flow
           quantities.add("2");
           discounts.add("5");
           collectedMedicineDetails1.add(details);
       }

       // Step 4: Save Bill
       PatientDetails patientPage = new PatientDetails(driver);
       patientPage.clickSaveButton();
       patientPage.yesButton();
 
       billNo = salesPage.getBillNumber();
       System.out.println("✅ Generated Bill No: " + billNo);
       patientPage.clickBackButton();
       // Step 5: Search and navigate to Return page
       SearchAndReturnBill searchBill = salesPage.search();
       searchBill.searchAndReturnBill(billNo);
  
       // Step 6: Execute the Return Flow
       SalesReturnPage returnPage = new SalesReturnPage(driver);

       // use the same lists for return flow
       returnPage.processSalesReturn(medicines1, quantities, discounts);
       returnPage.savetheSales();
   }
 @Test(dataProvider = "getDataForLogin", priority = 20)
 public void verifyMedicineDetails1(HashMap<String, String> input) throws InterruptedException {
	   Thread.sleep(5000);
	   StockList stocklist = new StockList(driver);
	   stocklist.clickStockMenu();
	   stocklist.clickStockListMenu();
     System.out.println("✅ Verifying collected medicine details...");
     for (Map<String, String> detail : SalesDashboard.collectedMedicineDetails1) {
  	    System.out.println("Medicine: " + detail.get("Medicine"));
  	    System.out.println("Batch: " + detail.get("Batch"));
  	    System.out.println("Stock: " + detail.get("Stock"));
  	    System.out.println("-----------------------");

  	    // Convert Stock (String → int) and subtract 4
  	    int stockValue = Integer.parseInt(detail.get("Stock"));
  	    int updatedStock = stockValue;

  	    // Use updated stock in your method
  	    stocklist.enterValueInComboBox(detail.get("Medicine"));
  	    Thread.sleep(5000);
  	    stocklist.findMedicineAndClickEdit(
  	        detail.get("Medicine"),
  	        detail.get("Batch"),
  	        String.valueOf(updatedStock) // pass as String again
  	    );
  	}

 }
   String customernName;
 @Test(dataProvider = "getDataForLogin", priority = 21)
 public void fulllcreditbil(HashMap<String, String> input) throws InterruptedException {
	 Thread.sleep(8000);
data.navigateSalesWithRetry2(); 
	 SalesPage salesPage = new SalesPage(driver);
    salesPage.creditbill(
        input.getOrDefault("mobile", ""), 
        input.getOrDefault("customerName", ""), 
        ""
    );
    customernName=salesPage.storedFirstName;
    salesPage.clickAddReferralDoctor();
    String externaldoctorname =salesPage.external;
//    Thread.sleep(5000);
    DynamicDoctor dynamicDoctor = new DynamicDoctor(driver);
//    dynamicDoctor.enterPhysicianName("Dr. John");
    dynamicDoctor.enterLastName("Doe");
//    dynamicDoctor.enterDisplayName("Dr. JD");
    dynamicDoctor.selectGender("Male");
    dynamicDoctor.enterDOB("01/15/1980");
//    dynamicDoctor.enterAge("43");
//    dynamicDoctor.enterEmail("john.doe@example.com");
    dynamicDoctor.enterMobile("9876543210");
    dynamicDoctor.enterAltMobile("9123456780");
    dynamicDoctor.enterWorkPhone("02212345678");
    dynamicDoctor.selectAppointmentBookingType("Not Applicable");
    dynamicDoctor.enterPanCard("ABCDE1234F");
    dynamicDoctor.selectDepartment("Accounts");
    dynamicDoctor.selectJobType("Permanent Employee");
    dynamicDoctor.toggleIsActive(true);

    // ===== Communication Address =====
//    dynamicDoctor.fillCommunicationAddress("123 Main Street", "MG Road", "400001", "Mumbai");
//    dynamicDoctor.selectDistrict("Mumbai");
//    dynamicDoctor.selectState("Maharashtra");
//    dynamicDoctor.selectCountry("India");

    // Save the physician
    dynamicDoctor.clickSave();
    Thread.sleep(3000);
    salesPage.excape();
    salesPage.selecctdynamicdoctor(externaldoctorname);
    List<String> medicines = List.of("syrup14", "medicine1syrup");
 
    // Loop through all medicines
    for (String medicine : medicines) {
        salesPage.selectMedicines(List.of(medicine));
 
        salesPage.qty("2");
        salesPage.addbtn();
    }
 
    SalesDashboards salesdash = new SalesDashboards(driver);
    salesPage.excape();
    salesdash.selectFullCreditBill();
 
 
    PatientDetails patientPage = new PatientDetails(driver);
    patientPage.clickSaveButton();
    patientPage.yesButton();
    patientPage.clickBackButton();
    
 }
 
////// 
@Test(dataProvider = "getDataForLogin", priority = 22)
public void fulllcreditbill(HashMap<String, String> input) throws InterruptedException {
	Creditbill creditbill = new Creditbill(driver);
	boolean isSuccess = false;

	while (!isSuccess) {
	    try {
	        creditbill.sales();
	        creditbill.creditbillacoounts();
	        isSuccess = true; // passed successfully
	    } catch (Exception e) {
	        System.out.println("Failed... Retrying again.");
	        // loop continues
	    }
	}
	creditbill.clickEditByPatientName(customernName);
	 PatientDetails patientPage = new PatientDetails(driver);
	    patientPage.clickSaveButton();
	    patientPage.yesButton();
	
}


   @DataProvider
   public Object[][] getDataForLogin() throws IOException {
       List<HashMap<String, String>> data = getJsonDataToMap(
           System.getProperty("user.dir") + "//src//main//java//ezion//Resources//AppointMent.json"
       );
       return new Object[][] { { data.get(0) } };
   }
}
