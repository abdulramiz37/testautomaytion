package TestComponents;

import java.awt.AWTException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EzionAbstractionComponents.WaitsUtils;
import EzionpageObjects.UserIdPage;
import PharmacySalesPage.PatientDetails;
import PharmacySalesPage.SalesPage;
import PharmacySalesPage.SearchAndReturnBill;
import PharmacyStocks.StockList;
import TestComponents.PharmacyUpdates.SalesDashboard;
import PharmacySalesPage.SalesReturnPage;
import abdulTest.BaseTest;

public class SalesReturn2 extends BaseTest {

    UserIdPage loginPage;
    SalesPage salesPage;
    SearchAndReturnBill searchBill;
    SalesReturnPage returnPage;

    String billNo;
    HashMap<String, String> currentInput;

    @Test(dataProvider = "getData")
    public void SalesReturn2_Login(HashMap<String, String> input) throws InterruptedException {
        this.currentInput = input;
//        loginPage = login.login(input.get("userId"));
//        loginPage.enterMobileNumber(input.get("personId"));
//        loginPage.enterPassword(input.get("password"));
        
        String userId = prop.getProperty("USER_ID");
        String personId = prop.getProperty("PERSON_ID");
        String password = prop.getProperty("PASSWORD");
        String browser = System.getProperty("BROWSER");
        loginPage = login.login(userId);
        loginPage.enterMobileNumber(personId);
        loginPage.enterPassword(password);
        loginPage.clickContinue();
        System.out.println("Browser: " + browser);
//        System.out.println("Base URL: " + baseUrl);
        System.out.println("User ID: " + userId);
        System.out.println("Person ID: " + personId);
        loginPage.clickContinue();
    }
//    public static List<Map<String, String>> collectedMedicineDetails1 = new ArrayList<>();
    public static List<Map<String, String>> collectedMedicineDetails1 = new ArrayList<>();
    String batchNumber1;
    String stocks1;

    @Test(dataProvider = "getData", priority = 19)
    public void salesreturn(HashMap<String, String> input) throws InterruptedException, AWTException {
    	loginPage.navigateSalesWithRetry2();
        Thread.sleep(5000);
        String billNo;

        // Step 2: Sales Page Flow
        SalesPage salesPage = new SalesPage(driver);
        salesPage.createSalesFlow3(
                input.getOrDefault("mobile", ""), 
                input.getOrDefault("customerName", ""), 
                "Dr.  Izaan"
        );

        // Step 3: Add Medicines in Sales
        List<String> medicines1 = List.of("syrup14");
        List<String> quantities = new ArrayList<>();
        List<String> discounts = new ArrayList<>();

        for (String medicine : medicines1) {
            salesPage.selectMedicines(List.of(medicine));

            // Get batch & stock
            batchNumber1 = salesPage.getBatchNumber();
            stocks1 = salesPage.getStickQuantity();

            Map<String, String> details = new HashMap<>();
            details.put("Medicine", medicine);
            details.put("Batch", batchNumber1);
            details.put("Stock", stocks1);

            salesPage.qty("2");
            salesPage.addbtn();

            // add values for return flow
            quantities.add("2");
            discounts.add("5");
            collectedMedicineDetails1.add(details);
        }

        // Step 4: Save Bill
        PatientDetails patientPage = new PatientDetails(driver);
        patientPage.clickSaveButton();
        WaitsUtils.waitForPageLoad(driver);
        patientPage.yesButton();
        WaitsUtils.waitForPageLoad(driver);
        billNo = salesPage.getBillNumber();
        WaitsUtils.waitForPageLoad(driver);
        System.out.println("✅ Generated Bill No: " + billNo);
        patientPage.clickBackButton();
        // Step 5: Search and navigate to Return page
        SearchAndReturnBill searchBill = salesPage.search();
        WaitsUtils.waitForPageLoad(driver);
        searchBill.searchAndReturnBill(billNo);

        // Step 6: Execute the Return Flow
        SalesReturnPage returnPage = new SalesReturnPage(driver);

        // use the same lists for return flow
        returnPage.processSalesReturn(medicines1, quantities, discounts);
        returnPage.savetheSales();  
    }
  @Test(dataProvider = "getData", priority = 20)
  public void verifyMedicineDetails1(HashMap<String, String> input) throws InterruptedException {
 	   Thread.sleep(5000);
 	 
 	   StockList stocklist = new StockList(driver);
// 	  stocklist.clickBackButton();
 	   stocklist.clickStockMenu();
 	   stocklist.clickStockListMenu();
 	  System.out.println("✅ Verifying collected medicine details...");
 	 for (Map<String, String> detail : collectedMedicineDetails1) {
 	     System.out.println("Medicine: " + detail.get("Medicine"));
 	     System.out.println("Batch: " + detail.get("Batch"));
 	     System.out.println("Stock: " + detail.get("Stock"));
 	     System.out.println("-----------------------");

 	     int stockValue = Integer.parseInt(detail.get("Stock"));
 	     int updatedStock = stockValue;

 	     stocklist.enterValueInComboBox(detail.get("Medicine"));
 	     Thread.sleep(5000);
 	     stocklist.findMedicineAndClickEdit(
 	         detail.get("Medicine"),
 	         detail.get("Batch"),
 	         String.valueOf(updatedStock)
 	     );
 	 }
  }


    @DataProvider
    public Object[][] getData() throws IOException {
        List<HashMap<String, String>> data = getJsonDataToMap(
            System.getProperty("user.dir") + "//src//main//java//ezion//Resources//SalesPage.json"
        );
        return new Object[][] { { data.get(0) } };
    }
}

