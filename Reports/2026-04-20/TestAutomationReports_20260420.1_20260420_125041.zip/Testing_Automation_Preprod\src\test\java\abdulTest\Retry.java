package abdulTest;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class Retry implements IRetryAnalyzer {

    private int count = 0;
    private static final int maxTry = 3;

    @Override
    public boolean retry(ITestResult result) {

        if (count < maxTry - 1) {
            count++;

            try {
                WebDriver driver = BaseTest.getDriver();
                String base64 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
                System.out.println("Screenshot taken for: " + result.getName() + "_Attempt_" + count);
            } catch (Exception e) {
                System.out.println("Screenshot failed: " + e.getMessage());
            }

            System.out.println("Retrying Test: " 
                + result.getName() + " | Attempt: " + (count + 1));

            return true;
        }
        return false;
    }
}