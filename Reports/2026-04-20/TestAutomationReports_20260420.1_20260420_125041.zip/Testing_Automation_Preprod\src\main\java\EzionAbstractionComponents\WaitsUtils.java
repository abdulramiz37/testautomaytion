package EzionAbstractionComponents;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

import java.time.Duration;

public class WaitsUtils extends Abstraction {

    private WebDriver driver;

    // ── defaults ─────────────────────
    public static final int DEFAULT_TIMEOUT_SEC = 30;
    public static final int SHORT_TIMEOUT_SEC = 10;
    public static final long POLL_EVERY_MS = 300;
    // ────────────────────────────────

    // ✅ FIXED CONSTRUCTOR
    public WaitsUtils(WebDriver driver) {
        super(driver);
        this.driver = driver;
    }

    // ─────────────────────────────────
    // 1. waitRegular
    // ─────────────────────────────────
    public static void waitRegular(WebDriver driver, int milliseconds) {
        new WebDriverWait(driver, Duration.ofMillis(milliseconds), Duration.ofMillis(milliseconds))
                .until(d -> true);
    }

    // ─────────────────────────────────
    // 2. visibility
    // ─────────────────────────────────
    public static WebElement waitForElementVisible(WebDriver driver, By locator, int timeoutSeconds) {
        return buildWait(driver, timeoutSeconds)
                .until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    public static WebElement waitForElementVisible(WebDriver driver, By locator) {
        return waitForElementVisible(driver, locator, DEFAULT_TIMEOUT_SEC);
    }

    public static WebElement waitForElementVisible(WebDriver driver, WebElement element, int timeoutSeconds) {
        return buildWait(driver, timeoutSeconds)
                .until(ExpectedConditions.visibilityOf(element));
    }

    public static WebElement waitForElementVisible(WebDriver driver, WebElement element) {
        return waitForElementVisible(driver, element, DEFAULT_TIMEOUT_SEC);
    }

    // ─────────────────────────────────
    // 3. clickable
    // ─────────────────────────────────
    public static WebElement waitForElementClickable(WebDriver driver, By locator, int timeoutSeconds) {
        return buildWait(driver, timeoutSeconds)
                .until(ExpectedConditions.elementToBeClickable(locator));
    }

    public static WebElement waitForElementClickable(WebDriver driver, By locator) {
        return waitForElementClickable(driver, locator, DEFAULT_TIMEOUT_SEC);
    }

    public static WebElement waitForElementClickable(WebDriver driver, WebElement element, int timeoutSeconds) {
        return buildWait(driver, timeoutSeconds)
                .until(ExpectedConditions.elementToBeClickable(element));
    }

    public static WebElement waitForElementClickable(WebDriver driver, WebElement element) {
        return waitForElementClickable(driver, element, DEFAULT_TIMEOUT_SEC);
    }

    // ─────────────────────────────────
    // 4. invisible / stale
    // ─────────────────────────────────
    public static boolean waitForElementInvisible(WebDriver driver, WebElement element, int timeoutSeconds) {
        return buildWait(driver, timeoutSeconds)
                .until(ExpectedConditions.invisibilityOf(element));
    }

    public static boolean waitForElementInvisible(WebDriver driver, WebElement element) {
        return waitForElementInvisible(driver, element, DEFAULT_TIMEOUT_SEC);
    }

    public static boolean waitForElementInvisible(WebDriver driver, By locator, int timeoutSeconds) {
        return buildWait(driver, timeoutSeconds)
                .until(ExpectedConditions.invisibilityOfElementLocated(locator));
    }

    public static boolean waitForStaleness(WebDriver driver, WebElement element, int timeoutSeconds) {
        return buildWait(driver, timeoutSeconds)
                .until(ExpectedConditions.stalenessOf(element));
    }

    public static boolean waitForStaleness(WebDriver driver, WebElement element) {
        return waitForStaleness(driver, element, DEFAULT_TIMEOUT_SEC);
    }

    // ─────────────────────────────────
    // 5. page load
    // ─────────────────────────────────
    public static void waitForPageLoad(WebDriver driver, int timeoutSeconds) {
        buildWait(driver, timeoutSeconds).until(d -> {
            String state = ((JavascriptExecutor) d)
                    .executeScript("return document.readyState").toString();
            return "complete".equals(state);
        });
    }

    public static void waitForPageLoad(WebDriver driver) {
        waitForPageLoad(driver, DEFAULT_TIMEOUT_SEC);
    }

    // ─────────────────────────────────
    // 6. text / attribute
    // ─────────────────────────────────
    public static WebElement waitForTextPresent(WebDriver driver, By locator, String text, int timeoutSeconds) {
        buildWait(driver, timeoutSeconds)
                .until(ExpectedConditions.textToBePresentInElementLocated(locator, text));
        return driver.findElement(locator);
    }

    public static WebElement waitForTextPresent(WebDriver driver, By locator, String text) {
        return waitForTextPresent(driver, locator, text, DEFAULT_TIMEOUT_SEC);
    }

    public static void waitForAttributeValue(WebDriver driver, WebElement element,
                                            String attribute, String value, int timeoutSeconds) {
        buildWait(driver, timeoutSeconds)
                .until(ExpectedConditions.attributeToBe(element, attribute, value));
    }

    // ─────────────────────────────────
    // 7. alert/url/title
    // ─────────────────────────────────
    public static Alert waitForAlert(WebDriver driver, int timeoutSeconds) {
        return buildWait(driver, timeoutSeconds)
                .until(ExpectedConditions.alertIsPresent());
    }

    public static void waitForUrlContains(WebDriver driver, String fragment, int timeoutSeconds) {
        buildWait(driver, timeoutSeconds)
                .until(ExpectedConditions.urlContains(fragment));
    }

    public static void waitForTitleContains(WebDriver driver, String fragment, int timeoutSeconds) {
        buildWait(driver, timeoutSeconds)
                .until(ExpectedConditions.titleContains(fragment));
    }

    // ─────────────────────────────────
    // 8. smartWait
    // ─────────────────────────────────
    public static <T> T smartWait(WebDriver driver, ExpectedCondition<T> condition, int timeoutSeconds) {
        return buildWait(driver, timeoutSeconds).until(condition);
    }

    public static <T> T smartWait(WebDriver driver, ExpectedCondition<T> condition) {
        return smartWait(driver, condition, DEFAULT_TIMEOUT_SEC);
    }

    // ─────────────────────────────────
    // 9. fluent wait
    // ─────────────────────────────────
    public static FluentWait<WebDriver> fluentWait(WebDriver driver, int timeoutSeconds, int pollMs) {
        return new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(timeoutSeconds))
                .pollingEvery(Duration.ofMillis(pollMs))
                .ignoring(NoSuchElementException.class)
                .ignoring(StaleElementReferenceException.class);
    }

    public static FluentWait<WebDriver> fluentWait(WebDriver driver) {
        return fluentWait(driver, DEFAULT_TIMEOUT_SEC, (int) POLL_EVERY_MS);
    }

    // ─────────────────────────────────
    // internal
    // ─────────────────────────────────
    private static WebDriverWait buildWait(WebDriver driver, int timeoutSeconds) {
        return new WebDriverWait(driver,
                Duration.ofSeconds(timeoutSeconds),
                Duration.ofMillis(POLL_EVERY_MS));
    }
}