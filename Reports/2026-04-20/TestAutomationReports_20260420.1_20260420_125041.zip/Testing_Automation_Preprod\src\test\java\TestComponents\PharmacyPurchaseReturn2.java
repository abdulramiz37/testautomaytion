package TestComponents;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EzionAbstractionComponents.WaitsUtils;
import EzionpageObjects.UserIdPage;
import PharmacyPurchaseReturn.GRNVerificationPage;
import PharmacyPurchaseReturn.PharmacyPurchasePage;
import PharmacyPurchaseReturn.PurchaseReturnPage;
import PharmacyPurchaseReturn.Supplier_Dues_Page;
import abdulTest.BaseTest;

public class PharmacyPurchaseReturn2 extends BaseTest {

    UserIdPage data;
    PharmacyPurchasePage purchasePage;
    GRNVerificationPage grnPage;
    PurchaseReturnPage purchaseReturn;

    String invoiceNo;
    String grn;
    HashMap<String, String> currentInput;

    @Test(dataProvider = "getData",retryAnalyzer = abdulTest.Retry.class)
    public void PharmacyPurchaseReturn2_Login(HashMap<String, String> input) throws InterruptedException {

        this.currentInput = input;

        String userId = prop.getProperty("USER_ID");
        String personId = prop.getProperty("PERSON_ID");
        String password = prop.getProperty("PASSWORD");
        String browser = System.getProperty("BROWSER");

        data = login.login(userId);

        data.enterMobileNumber(personId);
        data.enterPassword(password);

        data.clickContinue();  // ✅ only once

        System.out.println("Browser: " + browser);
        System.out.println("User ID: " + userId);
        System.out.println("Person ID: " + personId);

        // ✅ wait after login
        WaitsUtils.waitForPageLoad(driver);

        data.navigateSalesWithRetrystart();
    }

    @Test(dependsOnMethods = "PharmacyPurchaseReturn2_Login",retryAnalyzer = abdulTest.Retry.class)
    public void PharmacyPurchaseReturn2_CreatePurchase() {
        WaitsUtils.waitForPageLoad(driver);
        purchasePage = data.purchasePage();

        purchasePage.createNewPurchase(
                currentInput.get("location"),
                currentInput.get("supplier"),
                currentInput.get("invoiceNumber"),
                currentInput.get("invDate"),
                currentInput.get("dueDate"),
                currentInput.get("expiryDate"),
                currentInput.get("medicineName"),
                currentInput.get("batchNo"),
                currentInput.get("strips"),
                currentInput.get("freeStrips"),
                currentInput.get("mrp"),
                currentInput.get("price")
        );

        invoiceNo = purchasePage.getGeneratedInvoiceNo();
        grnPage = purchasePage.save();
    }

    @Test(dependsOnMethods = "PharmacyPurchaseReturn2_CreatePurchase",retryAnalyzer = abdulTest.Retry.class)
    public void PharmacyPurchaseReturn2_GetGRN() {

      

        // ✅ wait after save action
        WaitsUtils.waitForPageLoad(driver);

        grnPage.getGRNNumber(invoiceNo);
        grn = grnPage.getStoredGRNNo();

        System.out.println("✅ GRN used in next step: " + grn);
    }

    @Test(dependsOnMethods = "PharmacyPurchaseReturn2_GetGRN",retryAnalyzer = abdulTest.Retry.class)
    public void PharmacyPurchaseReturn2_CreateReturn() {

        purchaseReturn = grnPage.returnPage();

        purchaseReturn.createPurchaseReturn(
                invoiceNo,
                grn,
                currentInput.get("location"),
                currentInput.get("supplier"),
                currentInput.get("medicineName"),
                currentInput.get("quantity")
        );

        purchaseReturn.savePurchasePage(currentInput.get("review"));

        // ✅ wait after save
        WaitsUtils.waitForPageLoad(driver);

        purchaseReturn.saveDetails(invoiceNo);

        System.out.println("✅ Purchase return completed.");
    }

    @Test(dependsOnMethods = "PharmacyPurchaseReturn2_CreateReturn",retryAnalyzer = abdulTest.Retry.class)
    public void SupplierDues() {

        Supplier_Dues_Page poPage = new Supplier_Dues_Page(driver);
        WaitsUtils.waitForPageLoad(driver);
        poPage.clickAccountsMenu();

        // ✅ wait after menu click
        WaitsUtils.waitForPageLoad(driver);

        poPage.clickSupplierDuesMenu();

        // ✅ wait after navigation
        WaitsUtils.waitForPageLoad(driver);

        String targetSupplierName = "supplier name";

        poPage.clickEditFromSecondTabAndUpdate(targetSupplierName);
        poPage.clickSaveButton();
        poPage.clickYesButton();

        // ✅ wait before next action

    }
    
    @Test(dependsOnMethods = "SupplierDues",retryAnalyzer = abdulTest.Retry.class)
    public void clickSupplierPaymentListMenu() {

        Supplier_Dues_Page poPage = new Supplier_Dues_Page(driver);
       
        poPage.clickAccountsMenu();
        poPage.clickSupplierPaymentListMenu();
    }

    @DataProvider
    public Object[][] getData() throws IOException {

        List<HashMap<String, String>> data = getJsonDataToMap(
                System.getProperty("user.dir") + "//src//main//java//ezion//Resources//PharmacyPurchaseReturn.json"
        );

        return new Object[][]{{data.get(0)}};
    }
}